/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 *  org.objectweb.asm.ClassWriter
 *  org.objectweb.asm.MethodVisitor
 */
package me.ries.ui;

import java.awt.Color;
import java.awt.Desktop;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import me.ries.Ries;
import me.ries.config.ConfigManager;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.FriendManagerModule;
import me.ries.module.impl.TargetManagerModule;
import me.ries.setting.BooleanOption;
import me.ries.setting.ColorOption;
import me.ries.setting.NumberOption;
import me.ries.setting.OptionBase;
import me.ries.setting.StringOption;
import me.ries.setting.TextOption;
import me.ries.ui.CGScreen;
import me.ries.util.FontUtil;
import me.ries.util.GaussianBlur;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import me.ries.util.SDFUtil;
import me.ries.util.ScissorUtil;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;

public final class ClickGui
extends CGScreen {
    private static final Color WINDOW_BG = new Color(15, 15, 18, 255);
    private static final Color CONTENT_BG = new Color(22, 22, 26, 255);
    private static final Color CARD_BG = new Color(30, 30, 36, 255);
    private static final Color BORDER_COLOR = new Color(42, 42, 48, 255);
    private static final Color TEXT_DARK = new Color(230, 230, 235, 255);
    private static final Color TEXT_MUTED = new Color(150, 150, 160, 255);
    private static final int TEXT_PRIMARY = ClickGui.color(244, 244, 245, 255);
    private static final int DANGER = ClickGui.color(239, 68, 68, 255);
    private static final float GUI_W = 420.0f;
    private static float guiHeight = 310.0f;
    private static float guiX;
    private static float guiY;
    private static float contentScrollOffset;
    private static float contentTargetScroll;
    private static boolean guiPositioned;
    private static boolean open;
    private static boolean lastToggleKeyDown;
    private static boolean lastEscapeDown;
    private static boolean leftDown;
    private static boolean rightDown;
    private static boolean leftClicked;
    private static boolean rightClicked;
    private static boolean middleClicked;
    private static boolean mouseConsumed;
    private static boolean waitingForKeybind;
    private static float mouseX;
    private static float mouseY;
    private static float deltaTime;
    private static float globalOpenAnimation;
    private static float guiScale;
    private static float dragOffsetX;
    private static float dragOffsetY;
    private static boolean draggingGui;
    private static boolean draggingBottom;
    private static boolean draggingAny;
    private static int mouseWheel;
    private static long lastFrameTime;
    private static int lastScaleFactor;
    private static Module keybindModule;
    private static NumberOption draggingSlider;
    private static ColorOption activeColorPicker;
    private static final TextField activeTextField;
    private static Tab selectedTab;
    private static String selectedFriendName;
    private static String selectedTargetName;
    private static String selectedManagerSubTab;
    private static String selectedConfig;
    private static List<String> configList;
    private static boolean saveFriends;
    private static boolean loadFriends;
    private static final TextField searchField;
    private static final TextField configNameField;
    private static final TextField friendNameField;
    private static final TextField targetNameField;
    private static final ClickGui INSTANCE;
    private static Object dummyScreen;
    private static float winScale;
    private static boolean isTypingSearch;
    private static boolean isTypingConfigName;
    private static boolean isTypingText;
    private static TextOption activeTextOption;
    private static NumberOption activeNumberOption;
    private static String activeNumberString;
    private static long lastWarnTime;
    private static boolean lastLeftDown;
    private static boolean lastRightDown;
    private static boolean lastMiddleDown;
    private static int lastDisplayWidth;
    private static int lastDisplayHeight;

    public static ClickGui getInstance() {
        return INSTANCE;
    }

    private static Class<?> createSubclass(Class<?> clazz) throws Exception {
        String string = clazz.getName().replace('.', '/');
        String string2 = string + "RiesDummy";
        String string3 = clazz.getName() + "RiesDummy";
        ClassWriter classWriter = new ClassWriter(0);
        classWriter.visit(52, 33, string2, null, string, null);
        MethodVisitor methodVisitor = classWriter.visitMethod(1, "<init>", "()V", null, null);
        methodVisitor.visitCode();
        methodVisitor.visitVarInsn(25, 0);
        methodVisitor.visitMethodInsn(183, string, "<init>", "()V", false);
        methodVisitor.visitInsn(177);
        methodVisitor.visitMaxs(1, 1);
        methodVisitor.visitEnd();
        classWriter.visitEnd();
        byte[] byArray = classWriter.toByteArray();
        Method method = ClassLoader.class.getDeclaredMethod("defineClass", String.class, byte[].class, Integer.TYPE, Integer.TYPE);
        method.setAccessible(true);
        return (Class)method.invoke((Object)clazz.getClassLoader(), string3, byArray, 0, byArray.length);
    }

    private static void createDummyScreen() {
        if (dummyScreen == null) {
            try {
                Class<?> clazz = MappingUtils.get("GuiScreen");
                if (clazz != null) {
                    try {
                        Class<?> clazz2 = ClickGui.createSubclass(clazz);
                        Constructor<?> constructor = clazz2.getDeclaredConstructor(new Class[0]);
                        constructor.setAccessible(true);
                        dummyScreen = constructor.newInstance(new Object[0]);
                    }
                    catch (Throwable throwable) {
                        Constructor<?> constructor = clazz.getDeclaredConstructor(new Class[0]);
                        constructor.setAccessible(true);
                        dummyScreen = constructor.newInstance(new Object[0]);
                    }
                }
            }
            catch (Throwable throwable) {
                Logger.warn("Failed to create dummy GuiScreen: " + throwable.getMessage());
            }
        }
    }

    private static void displayScreen(Object object) {
        try {
            Object object2 = MappingUtils.getMinecraft();
            if (object2 == null) {
                return;
            }
            Class<?> clazz = MappingUtils.get("GuiScreen");
            if (clazz == null) {
                return;
            }
            Method method = null;
            for (Method method2 : object2.getClass().getDeclaredMethods()) {
                if (method2.getReturnType() != Void.TYPE || method2.getParameterCount() != 1 || method2.getParameterTypes()[0] != clazz) continue;
                method2.setAccessible(true);
                method = method2;
                break;
            }
            if (method != null) {
                method.invoke(object2, object);
            } else {
                Field field = MappingUtils.getField("Minecraft.currentScreen");
                if (field != null) {
                    field.setAccessible(true);
                    field.set(object2, object);
                }
            }
        }
        catch (Throwable throwable) {
            Logger.warn("Failed to display dummy screen: " + throwable.getMessage());
        }
    }

    public static void open() {
        open = true;
        ClickGui.createDummyScreen();
        if (dummyScreen != null) {
            ClickGui.displayScreen(dummyScreen);
        }
        guiPositioned = false;
        GaussianBlur.invalidateFrameCache();
        lastFrameTime = System.currentTimeMillis();
    }

    public static void close() {
        open = false;
        GaussianBlur.invalidateFrameCache();
        draggingGui = false;
        draggingBottom = false;
        activeColorPicker = null;
        draggingSlider = null;
        waitingForKeybind = false;
        keybindModule = null;
        ClickGui.clearTyping();
        try {
            Field field;
            Object object = MappingUtils.getMinecraft();
            if (object != null && (field = MappingUtils.getField("Minecraft.currentScreen")) != null) {
                field.setAccessible(true);
                if (field.get(object) == dummyScreen) {
                    ClickGui.displayScreen(null);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        lastFrameTime = System.currentTimeMillis();
    }

    public static boolean isOpen() {
        return open || globalOpenAnimation > 0.02f;
    }

    public static boolean isUiEditMode() {
        return open;
    }

    public static boolean isDraggingAnyElement() {
        return draggingGui || draggingBottom || draggingAny;
    }

    public static void setDraggingAnyElement(boolean bl) {
        draggingAny = bl;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void renderFrame() {
        try {
            Module module = ClickGui.getClickGuiModule();
            ClickGui.handleToggleKey(module);
            ClickGui.updateDelta();
            ClickGui.updateScale();
            globalOpenAnimation = ClickGui.lerp(globalOpenAnimation, open ? 1.0f : 0.0f, deltaTime * 9.0f);
            if (open) {
                boolean bl = false;
                try {
                    Field field;
                    Object object = MappingUtils.getMinecraft();
                    if (object != null && (field = MappingUtils.getField("Minecraft.currentScreen")) != null) {
                        field.setAccessible(true);
                        if (field.get(object) == dummyScreen) {
                            bl = true;
                        }
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                if (!bl) {
                    ClickGui.close();
                    if (module != null && module.isEnabled()) {
                        module.disable();
                    }
                    return;
                }
            }
            if (!open && globalOpenAnimation < 0.02f) {
                globalOpenAnimation = 0.0f;
                ClickGui.updateMouseState();
                return;
            }
            ClickGui.updateMouseState();
            if (open) {
                try {
                    Mouse.getDX();
                    Mouse.getDY();
                    while (Mouse.next()) {
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                ClickGui.unpressKeybindings();
            }
            ClickGui.handleKeyboardEvents(module);
            ClickGui.handleEscapeKey(module);
            ClickGui.handleMouseWheel();
            float f = globalOpenAnimation;
            ClickGui.pushState();
            try {
                ClickGui.render(mouseX, mouseY, f);
            }
            finally {
                ClickGui.popState();
            }
            leftClicked = false;
            rightClicked = false;
            middleClicked = false;
        }
        catch (Throwable throwable) {
            ClickGui.logException("ClickGui render error", throwable);
        }
    }

    private static boolean isGameGuiOpen() {
        try {
            Object object = MappingUtils.getMinecraft();
            if (object == null) {
                return false;
            }
            Field field = MappingUtils.getField("Minecraft.currentScreen");
            if (field != null) {
                field.setAccessible(true);
                return field.get(object) != null;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private static void handleToggleKey(Module module) {
        if (!waitingForKeybind && !ClickGui.isTyping()) {
            boolean bl;
            int n;
            int n2 = n = module == null ? 54 : module.getKeyBind();
            if (n <= 0) {
                n = 54;
            }
            if ((bl = ClickGui.isKeyDown(n)) && !lastToggleKeyDown) {
                if (open) {
                    ClickGui.requestClose(module);
                } else if (module != null) {
                    if (!ClickGui.isGameGuiOpen()) {
                        module.enable();
                    }
                } else if (!ClickGui.isGameGuiOpen()) {
                    ClickGui.open();
                }
            }
            lastToggleKeyDown = bl;
        } else {
            lastToggleKeyDown = false;
        }
    }

    private static void requestClose(Module module) {
        if (module != null && module.isEnabled()) {
            module.disable();
        } else {
            ClickGui.close();
        }
    }

    private static void handleEscapeKey(Module module) {
        if (!ClickGui.isTyping() && !waitingForKeybind) {
            boolean bl = ClickGui.isKeyDown(1);
            if (bl && !lastEscapeDown) {
                ClickGui.requestClose(module);
            }
            lastEscapeDown = bl;
        } else {
            lastEscapeDown = false;
        }
    }

    private static void handleKeyboardEvents(Module module) {
        try {
            while (Keyboard.next()) {
                if (!Keyboard.getEventKeyState()) continue;
                int n = Keyboard.getEventKey();
                char c = Keyboard.getEventCharacter();
                if (waitingForKeybind && keybindModule != null) {
                    if (n != 1 && n != 14 && n != 211) {
                        if (n > 0) {
                            keybindModule.setKeyBind(n);
                        }
                    } else {
                        keybindModule.setKeyBind(0);
                    }
                    waitingForKeybind = false;
                    keybindModule = null;
                    mouseConsumed = true;
                    continue;
                }
                if (isTypingSearch) {
                    if (n != 1 && n != 28 && n != 156) {
                        ClickGui.searchField.handleKeyboard(n, c);
                        continue;
                    }
                    isTypingSearch = false;
                    ClickGui.searchField.setFocused(false);
                    continue;
                }
                if (isTypingConfigName) {
                    if (n == 1) {
                        isTypingConfigName = false;
                        ClickGui.configNameField.setFocused(false);
                        continue;
                    }
                    if (n != 28 && n != 156) {
                        ClickGui.configNameField.handleKeyboard(n, c);
                        continue;
                    }
                    ClickGui.createConfigFromField();
                    continue;
                }
                if (isTypingText) {
                    if (n == 1) {
                        isTypingText = false;
                        if (activeTextOption != null) {
                            ClickGui.activeTextField.setFocused(false);
                            activeTextOption = null;
                        }
                        if (activeNumberOption != null) {
                            activeNumberOption = null;
                        }
                        ClickGui.friendNameField.setFocused(false);
                        continue;
                    }
                    if (activeTextOption != null) {
                        if (n != 28 && n != 156) {
                            ClickGui.activeTextField.handleKeyboard(n, c);
                            activeTextOption.setText(ClickGui.activeTextField.getText());
                            continue;
                        }
                        activeTextOption.setText(ClickGui.activeTextField.getText());
                        isTypingText = false;
                        ClickGui.activeTextField.setFocused(false);
                        activeTextOption = null;
                        continue;
                    }
                    if (activeNumberOption != null) {
                        if (n != 28 && n != 156) {
                            if (n == 14) {
                                if (activeNumberString.length() <= 0) continue;
                                activeNumberString = activeNumberString.substring(0, activeNumberString.length() - 1);
                                continue;
                            }
                            if (c != '.' && c != ',' && (c < '0' || c > '9') && c != 45) continue;
                            char c2 = c;
                            if (c2 == ',') {
                                c2 = '.';
                            }
                            activeNumberString = activeNumberString + c2;
                            continue;
                        }
                        try {
                            double d = Double.parseDouble(activeNumberString);
                            if (d < activeNumberOption.getMin()) {
                                d = activeNumberOption.getMin();
                            }
                            if (d > activeNumberOption.getMax()) {
                                d = activeNumberOption.getMax();
                            }
                            activeNumberOption.setValue(d);
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                        isTypingText = false;
                        activeNumberOption = null;
                        continue;
                    }
                    if (ClickGui.targetNameField.isFocused()) {
                        ClickGui.targetNameField.handleKeyboard(n, c);
                    } else {
                        ClickGui.friendNameField.handleKeyboard(n, c);
                    }
                    continue;
                }
                if (n != 1) continue;
                ClickGui.requestClose(module);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static void handleMouseWheel() {
        if (open && mouseWheel != 0) {
            float f = 420.0f;
            if (ClickGui.isInside(mouseX, mouseY, guiX, guiY + 30.0f, 420.0f, guiHeight - 30.0f)) {
                contentTargetScroll += mouseWheel < 0 ? 30.0f : -30.0f;
                ClickGui.clampContentScroll();
            }
        }
    }

    private static int getActualScaleFactor() {
        return ScissorUtil.getScaleFactor();
    }

    private static void render(float f, float f2, float f3) {
        int n = ClickGui.getActualScaleFactor();
        int n2 = (int)Math.ceil((double)Display.getWidth() / (double)n);
        int n3 = (int)Math.ceil((double)Display.getHeight() / (double)n);
        ClickGui.drawRect(0.0f, 0.0f, n2, n3, ClickGui.color(0, 0, 0, (int)(120.0f * f3 * ClickGui.optionNumber("Overlay Alpha", 0.58).floatValue())));
        winScale = ClickGui.lerp(winScale, 1.0f, deltaTime * 14.0f);
        float f4 = 0.96f + 0.04f * f3;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)((float)n2 / 2.0f), (float)((float)n3 / 2.0f), (float)0.0f);
        GL11.glScalef((float)f4, (float)f4, (float)1.0f);
        GL11.glTranslatef((float)((float)(-n2) / 2.0f), (float)((float)(-n3) / 2.0f), (float)0.0f);
        mouseConsumed = false;
        ClickGui.handleGuiDrag(f, f2);
        ClickGui.renderMainWindow(f, f2, f3);
        GL11.glPopMatrix();
    }

    private static void renderMainWindow(float f, float f2, float f3) {
        int n = ClickGui.getActualScaleFactor();
        int n2 = (int)Math.ceil((double)Display.getWidth() / (double)n);
        int n3 = (int)Math.ceil((double)Display.getHeight() / (double)n);
        if (!guiPositioned) {
            guiX = ((float)n2 - ClickGui.s(420.0f)) / 2.0f;
            guiY = ((float)n3 - ClickGui.s(guiHeight)) / 2.0f;
            guiPositioned = true;
        }
        guiX = ClickGui.clamp(guiX, ClickGui.s(4.0f), Math.max(ClickGui.s(4.0f), (float)n2 - ClickGui.s(420.0f) - ClickGui.s(4.0f)));
        guiY = ClickGui.clamp(guiY, ClickGui.s(4.0f), Math.max(ClickGui.s(4.0f), (float)n3 - ClickGui.s(guiHeight) - ClickGui.s(4.0f)));
        float f4 = ClickGui.s(420.0f);
        float f5 = ClickGui.s(guiHeight);
        ClickGui.drawRoundedRect(guiX, guiY, f4, f5, ClickGui.s(5.0f), WINDOW_BG);
        ClickGui.drawRoundedOutline(guiX, guiY, f4, f5, ClickGui.s(5.0f), BORDER_COLOR.getRGB());
        float f6 = ClickGui.s(22.0f);
        ClickGui.drawRoundedRect(guiX, guiY, f4, f6, ClickGui.s(5.0f), new Color(25, 25, 30));
        ClickGui.drawRect(guiX, guiY + f6 - ClickGui.s(1.0f), f4, ClickGui.s(1.0f), BORDER_COLOR.getRGB());
        float f7 = ClickGui.s(0.68f);
        ClickGui.drawText("873", guiX + ClickGui.s(8.0f), guiY + ClickGui.s(5.0f), ClickGui.applyAlpha(TEXT_DARK.getRGB(), f3), false, f7);
        float f8 = ClickGui.s(8.0f);
        float f9 = guiX + f4 - ClickGui.s(16.0f);
        float f10 = guiY + ClickGui.s(6.0f);
        boolean bl = ClickGui.isInside(f, f2, f9 - ClickGui.s(4.0f), f10 - ClickGui.s(4.0f), f8 + ClickGui.s(8.0f), f8 + ClickGui.s(8.0f));
        ClickGui.drawText("X", f9, f10, ClickGui.applyAlpha(bl ? DANGER : TEXT_MUTED.getRGB(), f3), false, ClickGui.s(0.68f));
        if (bl && leftClicked && !mouseConsumed) {
            ClickGui.requestClose(ClickGui.getClickGuiModule());
            mouseConsumed = true;
            leftClicked = false;
        }
        float f11 = ClickGui.s(24.0f);
        float f12 = guiY + f6;
        ClickGui.drawRect(guiX, f12, f4, f11, ClickGui.color(20, 20, 24, (int)(255.0f * f3)));
        ClickGui.drawRect(guiX, f12 + f11 - ClickGui.s(1.0f), f4, ClickGui.s(1.0f), BORDER_COLOR.getRGB());
        Tab[] tabArray = Tab.values();
        float f13 = guiX + ClickGui.s(6.0f);
        float f14 = ClickGui.s(48.0f);
        float f15 = ClickGui.s(16.0f);
        float f16 = ClickGui.s(1.8f);
        Color color = ClickGui.accentColor(1.0f);
        for (int i = 0; i < tabArray.length; ++i) {
            Tab tab = tabArray[i];
            float f17 = f13 + (float)i * (f14 + f16);
            float f18 = f12 + (f11 - f15) / 2.0f;
            boolean bl2 = tab == selectedTab;
            boolean bl3 = ClickGui.isInside(f, f2, f17, f18, f14, f15);
            int n4 = bl2 ? ClickGui.color(color.getRed(), color.getGreen(), color.getBlue(), (int)(220.0f * f3)) : ClickGui.color(30, 30, 36, (int)((bl3 ? 255.0f : 200.0f) * f3));
            int n5 = bl2 ? ClickGui.color(255, 255, 255, (int)(255.0f * f3)) : ClickGui.color(200, 200, 205, (int)(220.0f * f3));
            ClickGui.drawRoundedRect(f17, f18, f14, f15, ClickGui.s(3.0f), n4);
            float f19 = ClickGui.s(0.56f);
            float f20 = (float)ClickGui.textWidth(tab.getDisplayName()) * f19;
            ClickGui.drawText(tab.getDisplayName(), f17 + (f14 - f20) / 2.0f, f18 + (f15 - (float)ClickGui.fontHeight() * f19) / 2.0f, n5, false, f19);
            if (!bl3 || !leftClicked || mouseConsumed) continue;
            selectedTab = tab;
            contentScrollOffset = 0.0f;
            contentTargetScroll = 0.0f;
            mouseConsumed = true;
            leftClicked = false;
        }
        float f21 = guiY + f6 + f11;
        float f22 = f5 - (f6 + f11);
        ClickGui.drawRect(guiX + ClickGui.s(1.0f), f21, f4 - ClickGui.s(2.0f), f22 - ClickGui.s(1.0f), CONTENT_BG.getRGB());
        ClickGui.enableScissor(guiX, f21, f4, f22);
        contentScrollOffset = ClickGui.lerp(contentScrollOffset, contentTargetScroll, deltaTime * 12.0f);
        if (selectedTab == Tab.MANAGER) {
            ClickGui.renderManagerTab(f, f2, f3, f21, f22);
        } else if (selectedTab == Tab.CONFIGS) {
            ClickGui.renderConfigsTab(f, f2, f3, f21, f22);
        } else if (selectedTab == Tab.CHANGELOG) {
            ClickGui.renderChangelogTab(f, f2, f3, f21, f22);
        } else {
            ClickGui.renderModuleGrid(f, f2, f3, f21, f22);
        }
        GL11.glDisable((int)3089);
    }

    private static void handleGuiDrag(float f, float f2) {
        float f3 = ClickGui.s(420.0f);
        float f4 = ClickGui.s(guiHeight);
        boolean bl = ClickGui.isInside(f, f2, guiX + f3 - ClickGui.s(24.0f), guiY, ClickGui.s(24.0f), ClickGui.s(22.0f));
        boolean bl2 = ClickGui.isInside(f, f2, guiX, guiY, f3, ClickGui.s(22.0f)) && !bl;
        boolean bl3 = bl2;
        if (leftClicked && bl2 && !mouseConsumed) {
            draggingGui = true;
            dragOffsetX = f - guiX;
            dragOffsetY = f2 - guiY;
            mouseConsumed = true;
        }
        if (draggingGui && leftDown) {
            guiX = f - dragOffsetX;
            guiY = f2 - dragOffsetY;
            mouseConsumed = true;
        }
        if (!leftDown) {
            draggingGui = false;
        }
        boolean bl4 = ClickGui.isInside(f, f2, guiX, guiY + f4 - ClickGui.s(6.0f), f3, ClickGui.s(12.0f));
        if (leftClicked && bl4 && !mouseConsumed) {
            draggingBottom = true;
            dragOffsetY = f2 - guiHeight;
            mouseConsumed = true;
        }
        if (draggingBottom && leftDown) {
            guiHeight = f2 - dragOffsetY;
            if (guiHeight < 200.0f) {
                guiHeight = 200.0f;
            }
            int n = ClickGui.getActualScaleFactor();
            int n2 = (int)Math.ceil((double)Display.getHeight() / (double)n);
            if (guiHeight > (float)n2 - guiY - 10.0f) {
                guiHeight = (float)n2 - guiY - 10.0f;
            }
            mouseConsumed = true;
        }
        if (!leftDown) {
            draggingBottom = false;
        }
    }

    private static List<Module> getFilteredModulesForTab(Tab tab) {
        ArrayList<Module> arrayList = new ArrayList<Module>();
        String string = searchField != null ? ClickGui.searchField.getText().trim().toLowerCase() : "";
        boolean bl = !string.isEmpty();
        for (Module module : ClickGui.getModules()) {
            if (module.isHidden()) continue;
            if (bl) {
                boolean bl2 = module.getName().toLowerCase().contains(string);
                if (!bl2 && module.getDescription() != null) {
                    bl2 = module.getDescription().toLowerCase().contains(string);
                }
                if (!bl2) continue;
                arrayList.add(module);
                continue;
            }
            if (tab == Tab.COMBAT && module.getCategory() == Category.COMBAT) {
                arrayList.add(module);
                continue;
            }
            if (tab == Tab.MOVEMENT && module.getCategory() == Category.MOVEMENT) {
                arrayList.add(module);
                continue;
            }
            if (tab == Tab.RENDER && module.getCategory() == Category.RENDER) {
                arrayList.add(module);
                continue;
            }
            if (tab == Tab.MOD && module.getCategory() == Category.MOD) {
                arrayList.add(module);
                continue;
            }
            if (tab != Tab.MISCELLANEOUS || module.getCategory() != Category.MISC && module.getCategory() != Category.PLAYER) continue;
            arrayList.add(module);
        }
        return arrayList;
    }

    private static void renderModuleGrid(float f, float f2, float f3, float f4, float f5) {
        float f6;
        List<Module> list = ClickGui.getFilteredModulesForTab(selectedTab);
        float f7 = ClickGui.s(10.0f);
        float f8 = ClickGui.s(192.0f);
        float f9 = guiX + f7;
        float f10 = f6 = f4 + ClickGui.s(8.0f) - contentScrollOffset;
        float f11 = f6;
        ClickGui.drawRect(guiX + ClickGui.s(210.0f) - ClickGui.s(0.5f), f4 + ClickGui.s(4.0f), ClickGui.s(1.0f), f5 - ClickGui.s(8.0f), BORDER_COLOR.getRGB());
        for (int i = 0; i < list.size(); ++i) {
            Module module = list.get(i);
            boolean bl = i % 2 == 0;
            float f12 = bl ? f9 : f9 + f8 + ClickGui.s(16.0f);
            float f13 = bl ? f10 : f11;
            float f14 = ClickGui.calculateCardHeight(module);
            ClickGui.renderModuleCardInline(module, f12, f13, f8, f14, f, f2, f3);
            if (bl) {
                f10 += f14 + ClickGui.s(8.0f);
                continue;
            }
            f11 += f14 + ClickGui.s(8.0f);
        }
        float f15 = Math.max(0.0f, Math.max(f10, f11) - f6 - f5 + ClickGui.s(16.0f));
        contentTargetScroll = ClickGui.clamp(contentTargetScroll, 0.0f, f15);
    }

    private static float calculateCardHeight(Module module) {
        float f = ClickGui.s(22.0f);
        boolean bl = true;
        if (bl) {
            for (OptionBase<?> optionBase : module.getOptions()) {
                if (!optionBase.isVisible()) continue;
                if (optionBase instanceof BooleanOption) {
                    f += ClickGui.s(15.0f);
                    continue;
                }
                if (optionBase instanceof NumberOption) {
                    f += ClickGui.s(24.0f);
                    continue;
                }
                if (optionBase instanceof StringOption) {
                    f += ClickGui.s(18.0f);
                    continue;
                }
                if (optionBase instanceof ColorOption) {
                    f += ClickGui.s(18.0f);
                    if (activeColorPicker != optionBase) continue;
                    f += ClickGui.s(42.0f);
                    continue;
                }
                if (!(optionBase instanceof TextOption)) continue;
                f += ClickGui.s(24.0f);
            }
        }
        return f;
    }

    private static void renderModuleCardInline(Module module, float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        float f8 = ClickGui.s(18.0f);
        ClickGui.drawRoundedRect(f, f2, f3, f4, ClickGui.s(3.0f), CARD_BG);
        ClickGui.drawRoundedOutline(f, f2, f3, f4, ClickGui.s(3.0f), ClickGui.cardBorderColor(f7));
        ClickGui.drawRoundedRect(f, f2, f3, f8, ClickGui.s(3.0f), CARD_BG);
        float f9 = ClickGui.s(8.0f);
        float f10 = f + ClickGui.s(5.0f);
        float f11 = f2 + (f8 - f9) / 2.0f;
        boolean bl = ClickGui.isInside(f5, f6, f10 - ClickGui.s(3.0f), f2, f9 + ClickGui.s(6.0f), f8);
        ClickGui.drawRoundedRect(f10, f11, f9, f9, ClickGui.s(1.5f), module.isEnabled() ? ClickGui.accentColor(f7) : new Color(180, 182, 185));
        if (module.isEnabled()) {
            ClickGui.drawCheck(f10, f11, f9, f7);
        }
        if (bl && leftClicked && !mouseConsumed) {
            module.toggle();
            mouseConsumed = true;
            leftClicked = false;
        }
        float f12 = ClickGui.s(0.68f);
        ClickGui.drawText(module.getName(), f10 + f9 + ClickGui.s(6.0f), f2 + (f8 - (float)FontUtil.getFontHeight() * f12) / 2.0f, TEXT_DARK.getRGB(), false, f12);
        String string = waitingForKeybind && keybindModule == module ? "..." : (module.getKeyBind() > 0 ? Keyboard.getKeyName((int)module.getKeyBind()) : "None");
        float f13 = ClickGui.s(0.56f);
        float f14 = (float)ClickGui.textWidth(string) * f13 + ClickGui.s(6.0f);
        float f15 = f + f3 - f14 - ClickGui.s(5.0f);
        boolean bl2 = ClickGui.isInside(f5, f6, f15, f2, f14, f8);
        ClickGui.drawRoundedRect(f15, f2 + (f8 - ClickGui.s(10.0f)) / 2.0f, f14, ClickGui.s(10.0f), ClickGui.s(1.5f), bl2 ? new Color(60, 60, 72) : new Color(45, 45, 54));
        ClickGui.drawText(string, f15 + ClickGui.s(3.0f), f2 + (f8 - (float)FontUtil.getFontHeight() * f13) / 2.0f, TEXT_DARK.getRGB(), false, f13);
        if (bl2 && leftClicked && !mouseConsumed) {
            waitingForKeybind = true;
            keybindModule = module;
            mouseConsumed = true;
            leftClicked = false;
        } else if (bl2 && middleClicked && !mouseConsumed) {
            module.setKeyBind(0);
            mouseConsumed = true;
            middleClicked = false;
        }
        float f16 = f2 + f8 + ClickGui.s(3.0f);
        float f17 = ClickGui.s(10.0f);
        float f18 = f + f17;
        float f19 = f3 - f17 - ClickGui.s(5.0f);
        for (OptionBase<?> optionBase : module.getOptions()) {
            if (!optionBase.isVisible()) continue;
            int n;
            float f20;
            float f21;
            float f22;
            float f23;
            float f24;
            float f25;
            OptionBase optionBase2;
            if (optionBase instanceof BooleanOption) {
                optionBase2 = (BooleanOption)optionBase;
                f25 = f18;
                f24 = ClickGui.s(10.0f);
                f23 = ClickGui.s(8.0f);
                boolean bl3 = ClickGui.isInside(f5, f6, f25 - ClickGui.s(3.0f), f16 - ClickGui.s(1.0f), f19, f23 + ClickGui.s(2.0f));
                boolean bl4 = (Boolean)optionBase2.getValue();
                ClickGui.drawRoundedRect(f25, f16, f24, f23, ClickGui.s(1.5f), bl4 ? ClickGui.accentColor(f7) : new Color(60, 60, 68));
                if (bl4) {
                    ClickGui.drawCheck(f25, f16, f24, f7);
                }
                float f26 = ClickGui.s(0.64f);
                ClickGui.drawText(optionBase2.getName(), f25 + f24 + ClickGui.s(6.0f), f16 - ClickGui.s(1.0f), TEXT_DARK.getRGB(), false, f26);
                if (bl3 && leftClicked && !mouseConsumed) {
                    optionBase2.setValue(!bl4);
                    mouseConsumed = true;
                    leftClicked = false;
                }
                f16 += ClickGui.s(15.0f);
                continue;
            }
            if (optionBase instanceof NumberOption) {
                optionBase2 = (NumberOption)optionBase;
                f25 = f18;
                f24 = f19;
                f23 = ClickGui.s(10.0f);
                float f27 = ClickGui.s(0.6f);
                ClickGui.drawText(optionBase2.getName(), f25, f16, TEXT_DARK.getRGB(), false, f27);
                boolean bl5 = ClickGui.isInside(f5, f6, f25, f16 += ClickGui.s(9.0f), f24, f23);
                ClickGui.drawRoundedRect(f25, f16, f24, f23, ClickGui.s(2.0f), new Color(45, 45, 54));
                double d = ((NumberOption)optionBase2).getMin();
                double d2 = ((NumberOption)optionBase2).getMax();
                double d3 = (Double)optionBase2.getValue();
                f22 = (float)((d3 - d) / (d2 - d));
                f22 = ClickGui.clamp(f22, 0.0f, 1.0f);
                ClickGui.drawRoundedRect(f25, f16, f24 * f22, f23, ClickGui.s(2.0f), ClickGui.accentColor(f7));
                String string2 = activeNumberOption == optionBase2 ? activeNumberString : (optionBase2.getName().contains("Range") ? String.format("%.2f blocks", d3) : (optionBase2.getName().contains("Rate") ? String.format("%d%%", (int)(d3 * 100.0)) : (optionBase2.getName().contains("Second") || optionBase2.getName().contains("CPS") ? String.format("%.1f CPS", d3) : (d3 == (double)((int)d3) ? String.format("%d", (int)d3) : String.format("%.2f", d3)))));
                float f28 = ClickGui.s(0.56f);
                f21 = (float)ClickGui.textWidth(string2) * f28;
                ClickGui.drawText(string2, f25 + (f24 - f21) / 2.0f, f16 + (f23 - (float)ClickGui.fontHeight() * f28) / 2.0f, ClickGui.color(240, 240, 245, (int)(220.0f * f7)), false, f28);
                if (activeNumberOption == optionBase2 && System.currentTimeMillis() / 500L % 2L == 0L) {
                    float f29 = f25 + (f24 - f21) / 2.0f + f21 + ClickGui.s(1.0f);
                    ClickGui.drawRect(f29, f16 + f23 * 0.15f, ClickGui.s(1.0f), f23 * 0.7f, TEXT_DARK.getRGB());
                }
                f20 = ClickGui.s(4.0f);
                ClickGui.drawRoundedRect(f25 + f24 * f22 - f20 / 2.0f, f16, f20, f23, ClickGui.s(1.0f), ClickGui.accentColor(f7));
                if (activeNumberOption == optionBase2) {
                    ClickGui.drawRoundedOutline(f25, f16, f24, f23, ClickGui.s(2.0f), ClickGui.accentColor(f7).getRGB());
                    if (leftClicked && !bl5 && !mouseConsumed) {
                        try {
                            double d4 = Double.parseDouble(activeNumberString);
                            if (d4 < ((NumberOption)optionBase2).getMin()) {
                                d4 = ((NumberOption)optionBase2).getMin();
                            }
                            if (d4 > ((NumberOption)optionBase2).getMax()) {
                                d4 = ((NumberOption)optionBase2).getMax();
                            }
                            ((NumberOption)optionBase2).setValue(d4);
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                        activeNumberOption = null;
                        isTypingText = false;
                    }
                }
                if (bl5 && leftClicked && !mouseConsumed && activeNumberOption != optionBase2) {
                    draggingSlider = (NumberOption)optionBase2;
                    mouseConsumed = true;
                    leftClicked = false;
                }
                if (bl5 && rightClicked && !mouseConsumed) {
                    activeNumberOption = (NumberOption)optionBase2;
                    activeNumberString = String.format(Locale.US, "%.2f", d3);
                    isTypingText = true;
                    mouseConsumed = true;
                    rightClicked = false;
                }
                if (draggingSlider == optionBase2) {
                    if (leftDown) {
                        double d5 = (f5 - f25) / f24;
                        d5 = ClickGui.clamp((float)d5, 0.0f, 1.0f);
                        double d6 = d + d5 * (d2 - d);
                        ((NumberOption)optionBase2).setValue(d6);
                    } else {
                        draggingSlider = null;
                    }
                }
                f16 += ClickGui.s(15.0f);
                continue;
            }
            if (optionBase instanceof StringOption) {
                optionBase2 = (StringOption)optionBase;
                f25 = f18;
                f24 = f19;
                f23 = ClickGui.s(10.0f);
                float f30 = ClickGui.s(0.64f);
                ClickGui.drawText(optionBase2.getName(), f25, f16 + ClickGui.s(1.0f), TEXT_DARK.getRGB(), false, f30);
                String string3 = (String)optionBase2.getValue();
                float f31 = ClickGui.s(0.6f);
                float f32 = (float)ClickGui.textWidth(string3) * f31 + ClickGui.s(6.0f);
                float f33 = f + f3 - f32 - ClickGui.s(5.0f);
                boolean bl6 = ClickGui.isInside(f5, f6, f33, f16, f32, f23);
                ClickGui.drawRoundedRect(f33, f16, f32, f23, ClickGui.s(1.5f), bl6 ? new Color(60, 60, 72) : new Color(45, 45, 54));
                ClickGui.drawText(string3, f33 + ClickGui.s(3.0f), f16 + (f23 - (float)FontUtil.getFontHeight() * f31) / 2.0f, TEXT_DARK.getRGB(), false, f31);
                if (bl6 && leftClicked && !mouseConsumed) {
                    List<String> list = ((StringOption)optionBase2).getModes();
                    int n2 = list.indexOf(string3);
                    n = (n2 + 1) % list.size();
                    ((StringOption)optionBase2).setValue(list.get(n));
                    mouseConsumed = true;
                    leftClicked = false;
                }
                f16 += ClickGui.s(18.0f);
                continue;
            }
            if (optionBase instanceof ColorOption) {
                optionBase2 = (ColorOption)optionBase;
                f25 = f18;
                f24 = ClickGui.s(10.0f);
                f23 = ClickGui.s(0.64f);
                ClickGui.drawText(optionBase2.getName(), f25, f16 + ClickGui.s(1.0f), TEXT_DARK.getRGB(), false, f23);
                Color color = (Color)optionBase2.getValue();
                float f34 = ClickGui.s(16.0f);
                float f35 = f + f3 - f34 - ClickGui.s(5.0f);
                boolean bl7 = ClickGui.isInside(f5, f6, f35, f16, f34, f24);
                ClickGui.drawRoundedRect(f35, f16, f34, f24, ClickGui.s(1.5f), color);
                ClickGui.drawRoundedOutline(f35, f16, f34, f24, ClickGui.s(1.5f), ClickGui.color(160, 164, 166, (int)(255.0f * f7)));
                if (bl7 && leftClicked && !mouseConsumed) {
                    activeColorPicker = activeColorPicker == optionBase2 ? null : (ColorOption)optionBase2;
                    mouseConsumed = true;
                    leftClicked = false;
                }
                f16 += ClickGui.s(18.0f);
                if (activeColorPicker != optionBase2) continue;
                float f36 = f19 - ClickGui.s(15.0f);
                float f37 = f18 + ClickGui.s(5.0f);
                ClickGui.drawText("R", f37, f16, TEXT_DARK.getRGB(), false, ClickGui.s(0.56f));
                ClickGui.drawRoundedRect(f37 + ClickGui.s(10.0f), f16 + ClickGui.s(1.0f), f36 - ClickGui.s(10.0f), ClickGui.s(3.0f), ClickGui.s(1.5f), new Color(50, 50, 58));
                float f38 = (float)color.getRed() / 255.0f;
                ClickGui.drawRoundedRect(f37 + ClickGui.s(10.0f), f16 + ClickGui.s(1.0f), (f36 - ClickGui.s(10.0f)) * f38, ClickGui.s(3.0f), ClickGui.s(1.5f), new Color(255, 100, 100));
                n = ClickGui.isInside(f5, f6, f37 + ClickGui.s(10.0f) - 5.0f, f16 - 2.0f, f36 - ClickGui.s(10.0f) + 10.0f, 6.0f) ? 1 : 0;
                if (n != 0 && leftDown) {
                    f22 = ClickGui.clamp((f5 - (f37 + ClickGui.s(10.0f))) / (f36 - ClickGui.s(10.0f)), 0.0f, 1.0f);
                    optionBase2.setValue(new Color((int)(f22 * 255.0f), color.getGreen(), color.getBlue(), color.getAlpha()));
                }
                ClickGui.drawText("G", f37, f16 += ClickGui.s(10.0f), TEXT_DARK.getRGB(), false, ClickGui.s(0.56f));
                ClickGui.drawRoundedRect(f37 + ClickGui.s(10.0f), f16 + ClickGui.s(1.0f), f36 - ClickGui.s(10.0f), ClickGui.s(3.0f), ClickGui.s(1.5f), new Color(50, 50, 58));
                f22 = (float)color.getGreen() / 255.0f;
                ClickGui.drawRoundedRect(f37 + ClickGui.s(10.0f), f16 + ClickGui.s(1.0f), (f36 - ClickGui.s(10.0f)) * f22, ClickGui.s(3.0f), ClickGui.s(1.5f), new Color(100, 255, 100));
                boolean bl8 = ClickGui.isInside(f5, f6, f37 + ClickGui.s(10.0f) - 5.0f, f16 - 2.0f, f36 - ClickGui.s(10.0f) + 10.0f, 6.0f);
                if (bl8 && leftDown) {
                    f21 = ClickGui.clamp((f5 - (f37 + ClickGui.s(10.0f))) / (f36 - ClickGui.s(10.0f)), 0.0f, 1.0f);
                    optionBase2.setValue(new Color(color.getRed(), (int)(f21 * 255.0f), color.getBlue(), color.getAlpha()));
                }
                ClickGui.drawText("B", f37, f16 += ClickGui.s(10.0f), TEXT_DARK.getRGB(), false, ClickGui.s(0.56f));
                ClickGui.drawRoundedRect(f37 + ClickGui.s(10.0f), f16 + ClickGui.s(1.0f), f36 - ClickGui.s(10.0f), ClickGui.s(3.0f), ClickGui.s(1.5f), new Color(50, 50, 58));
                f21 = (float)color.getBlue() / 255.0f;
                ClickGui.drawRoundedRect(f37 + ClickGui.s(10.0f), f16 + ClickGui.s(1.0f), (f36 - ClickGui.s(10.0f)) * f21, ClickGui.s(3.0f), ClickGui.s(1.5f), new Color(100, 100, 255));
                boolean bl9 = ClickGui.isInside(f5, f6, f37 + ClickGui.s(10.0f) - 5.0f, f16 - 2.0f, f36 - ClickGui.s(10.0f) + 10.0f, 6.0f);
                if (bl9 && leftDown) {
                    f20 = ClickGui.clamp((f5 - (f37 + ClickGui.s(10.0f))) / (f36 - ClickGui.s(10.0f)), 0.0f, 1.0f);
                    optionBase2.setValue(new Color(color.getRed(), color.getGreen(), (int)(f20 * 255.0f), color.getAlpha()));
                }
                f16 += ClickGui.s(12.0f);
                continue;
            }
            if (!(optionBase instanceof TextOption)) continue;
            optionBase2 = (TextOption)optionBase;
            f25 = f18;
            f24 = f19;
            f23 = ClickGui.s(10.0f);
            float f39 = ClickGui.s(0.6f);
            ClickGui.drawText(optionBase2.getName(), f25, f16, TEXT_DARK.getRGB(), false, f39);
            boolean bl10 = ClickGui.isInside(f5, f6, f25, f16 += ClickGui.s(9.0f), f24, f23);
            ClickGui.drawRoundedRect(f25, f16, f24, f23, ClickGui.s(1.5f), new Color(45, 45, 54));
            ClickGui.drawRoundedOutline(f25, f16, f24, f23, ClickGui.s(1.5f), ClickGui.color(70, 70, 82, (int)(255.0f * f7)));
            String string4 = isTypingText && activeTextOption == optionBase2 ? ClickGui.activeTextField.getText() : ((TextOption)optionBase2).getText();
            boolean bl11 = isTypingText && activeTextOption == optionBase2;
            float f40 = ClickGui.s(0.56f);
            int n3 = bl11 ? ClickGui.accentColor(f7).getRGB() : ClickGui.color(70, 70, 82, (int)(255.0f * f7));
            ClickGui.drawRoundedOutline(f25, f16, f24, f23, ClickGui.s(1.5f), n3);
            ClickGui.drawText(string4, f25 + ClickGui.s(3.0f), f16 + (f23 - (float)ClickGui.fontHeight() * f40) / 2.0f, TEXT_DARK.getRGB(), false, f40);
            if (bl11 && System.currentTimeMillis() / 500L % 2L == 0L) {
                float f41 = (float)ClickGui.textWidth(string4) * f40;
                ClickGui.drawRect(f25 + ClickGui.s(3.0f) + f41 + ClickGui.s(1.0f), f16 + f23 * 0.15f, ClickGui.s(1.0f), f23 * 0.7f, TEXT_DARK.getRGB());
            }
            if (bl10 && leftClicked && !mouseConsumed) {
                isTypingText = true;
                activeTextOption = (TextOption)optionBase2;
                ClickGui.activeTextField.setText(string4);
                ClickGui.activeTextField.setFocused(true);
                mouseConsumed = true;
                leftClicked = false;
            }
            f16 += ClickGui.s(15.0f);
        }
    }

    private static void renderManagerTab(float f, float f2, float f3, float f4, float f5) {
        // Sub-tab bar: Friend Manager | Target Manager
        float fSubTabY = f4 + ClickGui.s(8.0f);
        float fSubTabW = ClickGui.s(120.0f);
        float fSubTabH = ClickGui.s(20.0f);
        float fSubTabX1 = guiX + ClickGui.s(10.0f);
        float fSubTabX2 = fSubTabX1 + fSubTabW + ClickGui.s(6.0f);
        Color accent = ClickGui.accentColor(f3);
        boolean isFriend = "friend".equals(selectedManagerSubTab);
        boolean isTarget = "target".equals(selectedManagerSubTab);
        // Friend Manager sub-tab button
        boolean hoverF = ClickGui.isInside(f, f2, fSubTabX1, fSubTabY, fSubTabW, fSubTabH);
        int colF = isFriend ? ClickGui.color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int)(220.0f * f3)) : ClickGui.color(30, 30, 36, (int)((hoverF ? 255.0f : 200.0f) * f3));
        ClickGui.drawRoundedRect(fSubTabX1, fSubTabY, fSubTabW, fSubTabH, ClickGui.s(3.0f), colF);
        float fScale = ClickGui.s(0.6f);
        float fFW = (float)ClickGui.textWidth("Friend Manager") * fScale;
        ClickGui.drawText("Friend Manager", fSubTabX1 + (fSubTabW - fFW) / 2.0f, fSubTabY + (fSubTabH - (float)ClickGui.fontHeight() * fScale) / 2.0f, isFriend ? Color.WHITE.getRGB() : ClickGui.color(200, 200, 205, (int)(220.0f * f3)), false, fScale);
        if (hoverF && leftClicked && !mouseConsumed) {
            selectedManagerSubTab = "friend";
            mouseConsumed = true;
            leftClicked = false;
        }
        // Target Manager sub-tab button
        boolean hoverT = ClickGui.isInside(f, f2, fSubTabX2, fSubTabY, fSubTabW, fSubTabH);
        int colT = isTarget ? ClickGui.color(accent.getRed(), accent.getGreen(), accent.getBlue(), (int)(220.0f * f3)) : ClickGui.color(30, 30, 36, (int)((hoverT ? 255.0f : 200.0f) * f3));
        ClickGui.drawRoundedRect(fSubTabX2, fSubTabY, fSubTabW, fSubTabH, ClickGui.s(3.0f), colT);
        float fTW = (float)ClickGui.textWidth("Target Manager") * fScale;
        ClickGui.drawText("Target Manager", fSubTabX2 + (fSubTabW - fTW) / 2.0f, fSubTabY + (fSubTabH - (float)ClickGui.fontHeight() * fScale) / 2.0f, isTarget ? Color.WHITE.getRGB() : ClickGui.color(200, 200, 205, (int)(220.0f * f3)), false, fScale);
        if (hoverT && leftClicked && !mouseConsumed) {
            selectedManagerSubTab = "target";
            mouseConsumed = true;
            leftClicked = false;
        }
        // Content area below sub-tabs
        float fContentY = fSubTabY + fSubTabH + ClickGui.s(8.0f);
        float fContentH = f5 - (fContentY - f4);
        if (isFriend) {
            ClickGui.renderFriendPanel(f, f2, f3, fContentY, fContentH);
        } else if (isTarget) {
            ClickGui.renderTargetPanel(f, f2, f3, fContentY, fContentH);
        }
    }

    private static void renderFriendPanel(float f, float f2, float f3, float f4, float f5) {
        boolean bl;
        float f6 = guiX + ClickGui.s(10.0f);
        float f7 = ClickGui.s(192.0f);
        float f8 = f4;
        ClickGui.drawRoundedRect(f6, f8, f7, ClickGui.s(146.0f), ClickGui.s(3.0f), CARD_BG);
        ClickGui.drawRoundedOutline(f6, f8, f7, ClickGui.s(146.0f), ClickGui.s(3.0f), BORDER_COLOR.getRGB());
        float f9 = f8 + ClickGui.s(8.0f);
        // Module toggle button
        FriendManagerModule friendMod = Ries.getInstance().getModuleManager().getModule(FriendManagerModule.class);
        boolean fmEnabled = friendMod != null && friendMod.isEnabled();
        float fToggleW = ClickGui.s(36.0f);
        float fToggleH = ClickGui.s(13.0f);
        float fToggleX = f6 + f7 - ClickGui.s(8.0f) - fToggleW;
        float fToggleY = f9 + (ClickGui.s(0.72f) * (float)ClickGui.fontHeight() - fToggleH) / 2.0f;
        Color fmAccent = fmEnabled ? ClickGui.accentColor(f3) : new Color(60, 60, 70);
        ClickGui.drawRoundedRect(fToggleX, fToggleY, fToggleW, fToggleH, fToggleH / 2.0f, fmAccent);
        float fKnobR = fToggleH * 0.38f;
        float fKnobX = fmEnabled ? fToggleX + fToggleW - fToggleH / 2.0f : fToggleX + fToggleH / 2.0f;
        float fKnobY = fToggleY + fToggleH / 2.0f;
        ClickGui.drawCircle(fKnobX, fKnobY, fKnobR, Color.WHITE.getRGB());
        boolean fmToggleHover = ClickGui.isInside(f, f2, fToggleX, fToggleY, fToggleW, fToggleH);
        if (fmToggleHover && leftClicked && !mouseConsumed) {
            if (friendMod != null) friendMod.toggle();
            mouseConsumed = true;
            leftClicked = false;
        }
        ClickGui.drawText("Friend Actions", f6 + ClickGui.s(8.0f), f9, TEXT_DARK.getRGB(), false, ClickGui.s(0.72f));
        float f10 = f7 - ClickGui.s(16.0f);
        float f11 = ClickGui.s(18.0f);
        ClickGui.friendNameField.updateCoordinates(f6 + ClickGui.s(8.0f), f9 += ClickGui.s(18.0f), f10, f11);
        boolean bl2 = ClickGui.friendNameField.isHovered(f, f2);
        ClickGui.drawRoundedRect(f6 + ClickGui.s(8.0f), f9, f10, f11, ClickGui.s(3.0f), new Color(40, 40, 50));
        ClickGui.drawRoundedOutline(f6 + ClickGui.s(8.0f), f9, f10, f11, ClickGui.s(3.0f), ClickGui.color(70, 70, 82, (int)(255.0f * f3)));
        ClickGui.friendNameField.draw(f3);
        if (bl2 && leftClicked && !mouseConsumed) {
            isTypingText = true;
            ClickGui.friendNameField.setFocused(true);
            ClickGui.friendNameField.handleMouse(f, f2);
            mouseConsumed = true;
            leftClicked = false;
        } else if (leftClicked && !bl2 && isTypingText && ClickGui.friendNameField.isFocused()) {
            isTypingText = false;
            ClickGui.friendNameField.setFocused(false);
        }
        float f12 = (f7 - ClickGui.s(24.0f)) / 2.0f;
        float f13 = ClickGui.s(18.0f);
        float f14 = f6 + ClickGui.s(8.0f);
        float f15 = f14 + f12 + ClickGui.s(8.0f);
        boolean bl3 = ClickGui.isInside(f, f2, f14, f9 += ClickGui.s(26.0f), f12, f13);
        boolean bl4 = ClickGui.isInside(f, f2, f15, f9, f12, f13);
        Color color = ClickGui.accentColor(f3);
        ClickGui.drawRoundedRect(f14, f9, f12, f13, ClickGui.s(3.0f), bl3 ? new Color(60, 60, 72) : new Color(45, 45, 54));
        float f16 = ClickGui.s(0.64f);
        float f17 = (float)ClickGui.textWidth("Add Friend") * f16;
        ClickGui.drawText("Add Friend", f14 + (f12 - f17) / 2.0f, f9 + (f13 - (float)ClickGui.fontHeight() * f16) / 2.0f, Color.WHITE.getRGB(), false, f16);
        if (bl3 && leftClicked && !mouseConsumed) {
            String string = ClickGui.friendNameField.getText().trim();
            if (!string.isEmpty()) {
                FriendManagerModule.friends.add(string);
                ClickGui.friendNameField.setText("");
                Logger.info("[ClickGui] Added Friend: " + string);
            }
            mouseConsumed = true;
            leftClicked = false;
        }
        ClickGui.drawRoundedRect(f15, f9, f12, f13, ClickGui.s(3.0f), bl4 ? new Color(60, 60, 72) : new Color(45, 45, 54));
        float f18 = (float)ClickGui.textWidth("Clear") * f16;
        ClickGui.drawText("Clear", f15 + (f12 - f18) / 2.0f, f9 + (f13 - (float)ClickGui.fontHeight() * f16) / 2.0f, Color.WHITE.getRGB(), false, f16);
        if (bl4 && leftClicked && !mouseConsumed) {
            FriendManagerModule.friends.clear();
            selectedFriendName = "";
            Logger.info("[ClickGui] Cleared friends list.");
            mouseConsumed = true;
            leftClicked = false;
        }
        
        // Draw FriendManager sub-settings
        if (friendMod != null) {
            OptionBase<?> optChat = friendMod.getOption("ChatCommands");
            OptionBase<?> optMcf = friendMod.getOption("MCF");
            
            float fCheckW = ClickGui.s(10.0f);
            float fCheckH = ClickGui.s(8.0f);
            float fCheckX = f6 + ClickGui.s(8.0f);
            
            if (optChat instanceof BooleanOption) {
                float fY = f9 + ClickGui.s(24.0f);
                boolean hover = ClickGui.isInside(f, f2, fCheckX - ClickGui.s(3.0f), fY - ClickGui.s(1.0f), f7 - ClickGui.s(16.0f), fCheckH + ClickGui.s(2.0f));
                boolean val = (Boolean)optChat.getValue();
                ClickGui.drawRoundedRect(fCheckX, fY, fCheckW, fCheckH, ClickGui.s(1.5f), val ? ClickGui.accentColor(f3) : new Color(60, 60, 68));
                if (val) {
                    ClickGui.drawCheck(fCheckX, fY, fCheckW, f3);
                }
                ClickGui.drawText("ChatCommands", fCheckX + fCheckW + ClickGui.s(6.0f), fY - ClickGui.s(1.0f), TEXT_DARK.getRGB(), false, ClickGui.s(0.64f));
                if (hover && leftClicked && !mouseConsumed) {
                    ((BooleanOption)optChat).setValue(!val);
                    mouseConsumed = true;
                    leftClicked = false;
                }
            }
            
            if (optMcf instanceof BooleanOption) {
                float fY = f9 + ClickGui.s(38.0f);
                boolean hover = ClickGui.isInside(f, f2, fCheckX - ClickGui.s(3.0f), fY - ClickGui.s(1.0f), f7 - ClickGui.s(16.0f), fCheckH + ClickGui.s(2.0f));
                boolean val = (Boolean)optMcf.getValue();
                ClickGui.drawRoundedRect(fCheckX, fY, fCheckW, fCheckH, ClickGui.s(1.5f), val ? ClickGui.accentColor(f3) : new Color(60, 60, 68));
                if (val) {
                    ClickGui.drawCheck(fCheckX, fY, fCheckW, f3);
                }
                ClickGui.drawText("MCF", fCheckX + fCheckW + ClickGui.s(6.0f), fY - ClickGui.s(1.0f), TEXT_DARK.getRGB(), false, ClickGui.s(0.64f));
                if (hover && leftClicked && !mouseConsumed) {
                    ((BooleanOption)optMcf).setValue(!val);
                    mouseConsumed = true;
                    leftClicked = false;
                }
            }
        }

        float f19 = f6 + f7 + ClickGui.s(16.0f);
        ClickGui.drawRoundedRect(f19, f8, f7, f5 - ClickGui.s(10.0f), ClickGui.s(3.0f), CARD_BG);
        ClickGui.drawRoundedOutline(f19, f8, f7, f5 - ClickGui.s(10.0f), ClickGui.s(3.0f), BORDER_COLOR.getRGB());
        float f20 = f8 + ClickGui.s(8.0f);
        ClickGui.drawText("Friends List (" + FriendManagerModule.friends.size() + ")", f19 + ClickGui.s(8.0f), f20, TEXT_DARK.getRGB(), false, ClickGui.s(0.72f));
        f20 += ClickGui.s(18.0f);
        ArrayList<String> arrayList = new ArrayList<String>(FriendManagerModule.friends);
        float f21 = ClickGui.s(16.0f);
        for (int i = 0; i < arrayList.size(); ++i) {
            String string = arrayList.get(i);
            boolean bl5 = ClickGui.isInside(f, f2, f19 + ClickGui.s(8.0f), f20, f7 - ClickGui.s(16.0f), f21);
            bl = string.equals(selectedFriendName);
            if (bl || bl5) {
                ClickGui.drawRoundedRect(f19 + ClickGui.s(8.0f), f20, f7 - ClickGui.s(16.0f), f21, ClickGui.s(2.0f), bl ? color : new Color(50, 50, 60));
            }
            ClickGui.drawText(string, f19 + ClickGui.s(12.0f), f20 + (f21 - (float)FontUtil.getFontHeight() * ClickGui.s(0.64f)) / 2.0f, bl ? Color.WHITE.getRGB() : TEXT_DARK.getRGB(), false, ClickGui.s(0.64f));
            if (bl5 && leftClicked && !mouseConsumed) {
                selectedFriendName = string;
                mouseConsumed = true;
                leftClicked = false;
            }
            f20 += f21 + ClickGui.s(2.0f);
        }
        if (!selectedFriendName.isEmpty()) {
            float f22 = f8 + f5 - ClickGui.s(32.0f);
            float f23 = f7 - ClickGui.s(16.0f);
            float f24 = ClickGui.s(18.0f);
            bl = ClickGui.isInside(f, f2, f19 + ClickGui.s(8.0f), f22, f23, f24);
            ClickGui.drawRoundedRect(f19 + ClickGui.s(8.0f), f22, f23, f24, ClickGui.s(3.0f), bl ? DANGER : ClickGui.color(239, 68, 68, 180));
            float f25 = (float)ClickGui.textWidth("Remove Selected") * f16;
            ClickGui.drawText("Remove Selected", f19 + ClickGui.s(8.0f) + (f23 - f25) / 2.0f, f22 + (f24 - (float)ClickGui.fontHeight() * f16) / 2.0f, Color.WHITE.getRGB(), false, f16);
            if (bl && leftClicked && !mouseConsumed) {
                FriendManagerModule.friends.remove(selectedFriendName);
                selectedFriendName = "";
                mouseConsumed = true;
                leftClicked = false;
            }
        }
    }

    private static void renderTargetPanel(float f, float f2, float f3, float f4, float f5) {
        boolean bl;
        TargetManagerModule targetMod = Ries.getInstance().getModuleManager().getModule(TargetManagerModule.class);
        float f6 = guiX + ClickGui.s(10.0f);
        float f7 = ClickGui.s(192.0f);
        float f8 = f4;
        ClickGui.drawRoundedRect(f6, f8, f7, ClickGui.s(110.0f), ClickGui.s(3.0f), CARD_BG);
        ClickGui.drawRoundedOutline(f6, f8, f7, ClickGui.s(110.0f), ClickGui.s(3.0f), BORDER_COLOR.getRGB());
        float f9 = f8 + ClickGui.s(8.0f);
        // Module toggle button
        boolean tmEnabled = targetMod != null && targetMod.isEnabled();
        float fToggleW = ClickGui.s(36.0f);
        float fToggleH = ClickGui.s(13.0f);
        float fToggleX = f6 + f7 - ClickGui.s(8.0f) - fToggleW;
        float fToggleY = f9 + (ClickGui.s(0.72f) * (float)ClickGui.fontHeight() - fToggleH) / 2.0f;
        Color tmAccent = tmEnabled ? ClickGui.accentColor(f3) : new Color(60, 60, 70);
        ClickGui.drawRoundedRect(fToggleX, fToggleY, fToggleW, fToggleH, fToggleH / 2.0f, tmAccent);
        float fKnobR = fToggleH * 0.38f;
        float fKnobX = tmEnabled ? fToggleX + fToggleW - fToggleH / 2.0f : fToggleX + fToggleH / 2.0f;
        float fKnobY = fToggleY + fToggleH / 2.0f;
        ClickGui.drawCircle(fKnobX, fKnobY, fKnobR, Color.WHITE.getRGB());
        boolean tmToggleHover = ClickGui.isInside(f, f2, fToggleX, fToggleY, fToggleW, fToggleH);
        if (tmToggleHover && leftClicked && !mouseConsumed) {
            if (targetMod != null) targetMod.toggle();
            mouseConsumed = true;
            leftClicked = false;
        }
        ClickGui.drawText("Target Actions", f6 + ClickGui.s(8.0f), f9, TEXT_DARK.getRGB(), false, ClickGui.s(0.72f));
        float f10 = f7 - ClickGui.s(16.0f);
        float f11 = ClickGui.s(18.0f);
        ClickGui.targetNameField.updateCoordinates(f6 + ClickGui.s(8.0f), f9 += ClickGui.s(18.0f), f10, f11);
        boolean bl2 = ClickGui.targetNameField.isHovered(f, f2);
        ClickGui.drawRoundedRect(f6 + ClickGui.s(8.0f), f9, f10, f11, ClickGui.s(3.0f), new Color(40, 40, 50));
        ClickGui.drawRoundedOutline(f6 + ClickGui.s(8.0f), f9, f10, f11, ClickGui.s(3.0f), ClickGui.color(70, 70, 82, (int)(255.0f * f3)));
        ClickGui.targetNameField.draw(f3);
        if (bl2 && leftClicked && !mouseConsumed) {
            isTypingText = true;
            ClickGui.targetNameField.setFocused(true);
            ClickGui.targetNameField.handleMouse(f, f2);
            mouseConsumed = true;
            leftClicked = false;
        } else if (leftClicked && !bl2 && isTypingText && ClickGui.targetNameField.isFocused()) {
            isTypingText = false;
            ClickGui.targetNameField.setFocused(false);
        }
        float f12 = (f7 - ClickGui.s(24.0f)) / 2.0f;
        float f13 = ClickGui.s(18.0f);
        float f14 = f6 + ClickGui.s(8.0f);
        float f15 = f14 + f12 + ClickGui.s(8.0f);
        boolean bl3 = ClickGui.isInside(f, f2, f14, f9 += ClickGui.s(26.0f), f12, f13);
        boolean bl4 = ClickGui.isInside(f, f2, f15, f9, f12, f13);
        Color color = ClickGui.accentColor(f3);
        ClickGui.drawRoundedRect(f14, f9, f12, f13, ClickGui.s(3.0f), bl3 ? new Color(60, 60, 72) : new Color(45, 45, 54));
        float f16 = ClickGui.s(0.64f);
        float f17 = (float)ClickGui.textWidth("Add Target") * f16;
        ClickGui.drawText("Add Target", f14 + (f12 - f17) / 2.0f, f9 + (f13 - (float)ClickGui.fontHeight() * f16) / 2.0f, Color.WHITE.getRGB(), false, f16);
        if (bl3 && leftClicked && !mouseConsumed) {
            String string = ClickGui.targetNameField.getText().trim();
            if (!string.isEmpty() && targetMod != null) {
                String current = targetMod.getTargetName().trim();
                String newTarget = current.isEmpty() ? string : current + "," + string;
                targetMod.setTargetName(newTarget);
                if (!targetMod.isEnabled()) targetMod.toggle();
                ClickGui.targetNameField.setText("");
                Logger.info("[ClickGui] Added Target: " + string);
            }
            mouseConsumed = true;
            leftClicked = false;
        }
        ClickGui.drawRoundedRect(f15, f9, f12, f13, ClickGui.s(3.0f), bl4 ? new Color(60, 60, 72) : new Color(45, 45, 54));
        float f18 = (float)ClickGui.textWidth("Clear") * f16;
        ClickGui.drawText("Clear", f15 + (f12 - f18) / 2.0f, f9 + (f13 - (float)ClickGui.fontHeight() * f16) / 2.0f, Color.WHITE.getRGB(), false, f16);
        if (bl4 && leftClicked && !mouseConsumed) {
            if (targetMod != null) {
                targetMod.setTargetName("");
                if (targetMod.isEnabled()) targetMod.toggle();
            }
            selectedTargetName = "";
            Logger.info("[ClickGui] Cleared target list.");
            mouseConsumed = true;
            leftClicked = false;
        }
        float f19 = f6 + f7 + ClickGui.s(16.0f);
        ClickGui.drawRoundedRect(f19, f8, f7, f5 - ClickGui.s(10.0f), ClickGui.s(3.0f), CARD_BG);
        ClickGui.drawRoundedOutline(f19, f8, f7, f5 - ClickGui.s(10.0f), ClickGui.s(3.0f), BORDER_COLOR.getRGB());
        float f20 = f8 + ClickGui.s(8.0f);
        String rawTargets = targetMod != null ? targetMod.getTargetName().trim() : "";
        ArrayList<String> targetList = new ArrayList<String>();
        if (!rawTargets.isEmpty()) {
            for (String t : rawTargets.split(",")) {
                String tt = t.trim();
                if (!tt.isEmpty()) targetList.add(tt);
            }
        }
        ClickGui.drawText("Target List (" + targetList.size() + ")", f19 + ClickGui.s(8.0f), f20, TEXT_DARK.getRGB(), false, ClickGui.s(0.72f));
        f20 += ClickGui.s(18.0f);
        float f21 = ClickGui.s(16.0f);
        for (int i = 0; i < targetList.size(); ++i) {
            String string = targetList.get(i);
            boolean bl5 = ClickGui.isInside(f, f2, f19 + ClickGui.s(8.0f), f20, f7 - ClickGui.s(16.0f), f21);
            bl = string.equals(selectedTargetName);
            if (bl || bl5) {
                ClickGui.drawRoundedRect(f19 + ClickGui.s(8.0f), f20, f7 - ClickGui.s(16.0f), f21, ClickGui.s(2.0f), bl ? color : new Color(50, 50, 60));
            }
            ClickGui.drawText(string, f19 + ClickGui.s(12.0f), f20 + (f21 - (float)FontUtil.getFontHeight() * ClickGui.s(0.64f)) / 2.0f, bl ? Color.WHITE.getRGB() : TEXT_DARK.getRGB(), false, ClickGui.s(0.64f));
            if (bl5 && leftClicked && !mouseConsumed) {
                selectedTargetName = string;
                mouseConsumed = true;
                leftClicked = false;
            }
            f20 += f21 + ClickGui.s(2.0f);
        }
        if (!selectedTargetName.isEmpty()) {
            float f22 = f8 + f5 - ClickGui.s(32.0f);
            float f23 = f7 - ClickGui.s(16.0f);
            float f24 = ClickGui.s(18.0f);
            bl = ClickGui.isInside(f, f2, f19 + ClickGui.s(8.0f), f22, f23, f24);
            ClickGui.drawRoundedRect(f19 + ClickGui.s(8.0f), f22, f23, f24, ClickGui.s(3.0f), bl ? DANGER : ClickGui.color(239, 68, 68, 180));
            float f25 = (float)ClickGui.textWidth("Remove Selected") * f16;
            ClickGui.drawText("Remove Selected", f19 + ClickGui.s(8.0f) + (f23 - f25) / 2.0f, f22 + (f24 - (float)ClickGui.fontHeight() * f16) / 2.0f, Color.WHITE.getRGB(), false, f16);
            if (bl && leftClicked && !mouseConsumed) {
                // Remove selectedTargetName from comma-separated list
                if (targetMod != null) {
                    ArrayList<String> newList = new ArrayList<String>(targetList);
                    newList.remove(selectedTargetName);
                    targetMod.setTargetName(String.join(",", newList));
                    if (newList.isEmpty() && targetMod.isEnabled()) targetMod.toggle();
                }
                selectedTargetName = "";
                mouseConsumed = true;
                leftClicked = false;
            }
        }
    }

    private static void renderConfigsTab(float f, float f2, float f3, float f4, float f5) {
        float f6;
        boolean bl;
        float f7 = guiX + ClickGui.s(10.0f);
        float f8 = ClickGui.s(192.0f);
        float f9 = f4 + ClickGui.s(10.0f);
        if (configList == null || configList.isEmpty()) {
            configList = ConfigManager.getInstance().getConfigList();
        }
        ClickGui.drawRoundedRect(f7, f9, f8, f5 - ClickGui.s(20.0f), ClickGui.s(3.0f), CARD_BG);
        ClickGui.drawRoundedOutline(f7, f9, f8, f5 - ClickGui.s(20.0f), ClickGui.s(3.0f), BORDER_COLOR.getRGB());
        float f10 = f9 + ClickGui.s(8.0f);
        ClickGui.drawText("Config Actions", f7 + ClickGui.s(8.0f), f10, TEXT_DARK.getRGB(), false, ClickGui.s(0.72f));
        float f11 = f8 - ClickGui.s(16.0f);
        float f12 = ClickGui.s(18.0f);
        ClickGui.configNameField.updateCoordinates(f7 + ClickGui.s(8.0f), f10 += ClickGui.s(18.0f), f11, f12);
        boolean bl2 = ClickGui.configNameField.isHovered(f, f2);
        ClickGui.drawRoundedRect(f7 + ClickGui.s(8.0f), f10, f11, f12, ClickGui.s(3.0f), new Color(40, 40, 50));
        ClickGui.drawRoundedOutline(f7 + ClickGui.s(8.0f), f10, f11, f12, ClickGui.s(3.0f), ClickGui.color(70, 70, 82, (int)(255.0f * f3)));
        ClickGui.configNameField.draw(f3);
        if (bl2 && leftClicked && !mouseConsumed) {
            isTypingConfigName = true;
            ClickGui.configNameField.setFocused(true);
            ClickGui.configNameField.handleMouse(f, f2);
            mouseConsumed = true;
            leftClicked = false;
        } else if (leftClicked && !bl2 && isTypingConfigName) {
            isTypingConfigName = false;
            ClickGui.configNameField.setFocused(false);
        }
        f10 += ClickGui.s(26.0f);
        float f13 = f8 - ClickGui.s(16.0f);
        float f14 = ClickGui.s(16.0f);
        float f15 = ClickGui.s(6.0f);
        String[] stringArray = new String[]{"Load Selected Config", "Delete Selected Config", "Save Current Config", "Open Configs Folder"};
        Color color = ClickGui.accentColor(f3);
        for (int i = 0; i < stringArray.length; ++i) {
            String string = stringArray[i];
            bl = ClickGui.isInside(f, f2, f7 + ClickGui.s(8.0f), f10, f13, f14);
            ClickGui.drawRoundedRect(f7 + ClickGui.s(8.0f), f10, f13, f14, ClickGui.s(3.0f), bl ? new Color(60, 60, 72) : new Color(45, 45, 54));
            float f16 = ClickGui.s(0.64f);
            f6 = (float)ClickGui.textWidth(string) * f16;
            ClickGui.drawText(string, f7 + ClickGui.s(8.0f) + (f13 - f6) / 2.0f, f10 + (f14 - (float)ClickGui.fontHeight() * f16) / 2.0f, Color.WHITE.getRGB(), false, f16);
            if (bl && leftClicked && !mouseConsumed) {
                if (i == 0) {
                    if (!selectedConfig.isEmpty()) {
                        ConfigManager.getInstance().loadConfig(Ries.getInstance().getModuleManager(), selectedConfig);
                        Logger.info("[ClickGui] Loaded config: " + selectedConfig);
                    }
                } else if (i == 1) {
                    if (!selectedConfig.isEmpty()) {
                        ConfigManager.getInstance().deleteConfig(selectedConfig);
                        configList = ConfigManager.getInstance().getConfigList();
                        selectedConfig = "";
                        Logger.info("[ClickGui] Deleted config: " + selectedConfig);
                    }
                } else if (i == 2) {
                    String string2 = ClickGui.configNameField.getText().trim();
                    if (!string2.isEmpty()) {
                        ConfigManager.getInstance().saveConfig(Ries.getInstance().getModuleManager(), string2);
                        configList = ConfigManager.getInstance().getConfigList();
                        ClickGui.configNameField.setText("");
                        selectedConfig = string2;
                        Logger.info("[ClickGui] Saved config: " + string2);
                    }
                } else if (i == 3) {
                    try {
                        String appData = System.getenv("APPDATA");
                        File configFolder = new File(appData + File.separator + "ries");
                        if (!configFolder.exists()) configFolder.mkdirs();
                        Desktop.getDesktop().open(configFolder);
                    }
                    catch (Throwable throwable) {
                        try {
                            String appData = System.getenv("APPDATA");
                            Runtime.getRuntime().exec("explorer.exe " + appData + "\\ries");
                        }
                        catch (Throwable throwable2) {
                            // empty catch block
                        }
                    }
                }
                mouseConsumed = true;
                leftClicked = false;
            }
            f10 += f14 + f15;
        }
        float f17 = ClickGui.s(8.0f);
        float f18 = f7 + ClickGui.s(8.0f);
        bl = ClickGui.isInside(f, f2, f18, f10 += ClickGui.s(6.0f), f13, f17);
        ClickGui.drawRoundedRect(f18, f10, f17, f17, ClickGui.s(1.5f), saveFriends ? color : new Color(60, 60, 68));
        if (saveFriends) {
            ClickGui.drawCheck(f18, f10, f17, f3);
        }
        ClickGui.drawText("Save Friends", f18 + f17 + ClickGui.s(6.0f), f10 - ClickGui.s(1.0f), TEXT_DARK.getRGB(), false, ClickGui.s(0.64f));
        if (bl && leftClicked && !mouseConsumed) {
            saveFriends = !saveFriends;
            mouseConsumed = true;
            leftClicked = false;
        }
        boolean bl3 = ClickGui.isInside(f, f2, f18, f10 += ClickGui.s(14.0f), f13, f17);
        ClickGui.drawRoundedRect(f18, f10, f17, f17, ClickGui.s(1.5f), loadFriends ? color : new Color(60, 60, 68));
        if (loadFriends) {
            ClickGui.drawCheck(f18, f10, f17, f3);
        }
        ClickGui.drawText("Load Friends", f18 + f17 + ClickGui.s(6.0f), f10 - ClickGui.s(1.0f), TEXT_DARK.getRGB(), false, ClickGui.s(0.64f));
        if (bl3 && leftClicked && !mouseConsumed) {
            loadFriends = !loadFriends;
            mouseConsumed = true;
            leftClicked = false;
        }
        f6 = f7 + f8 + ClickGui.s(16.0f);
        ClickGui.drawRoundedRect(f6, f9, f8, f5 - ClickGui.s(20.0f), ClickGui.s(3.0f), CARD_BG);
        ClickGui.drawRoundedOutline(f6, f9, f8, f5 - ClickGui.s(20.0f), ClickGui.s(3.0f), BORDER_COLOR.getRGB());
        float f19 = f9 + ClickGui.s(8.0f);
        ClickGui.drawText("Config List", f6 + ClickGui.s(8.0f), f19, TEXT_DARK.getRGB(), false, ClickGui.s(0.72f));
        f19 += ClickGui.s(18.0f);
        float f20 = ClickGui.s(16.0f);
        for (int i = 0; i < configList.size(); ++i) {
            String string = configList.get(i);
            boolean bl4 = ClickGui.isInside(f, f2, f6 + ClickGui.s(8.0f), f19, f8 - ClickGui.s(16.0f), f20);
            boolean bl5 = string.equals(selectedConfig);
            if (bl5 || bl4) {
                ClickGui.drawRoundedRect(f6 + ClickGui.s(8.0f), f19, f8 - ClickGui.s(16.0f), f20, ClickGui.s(2.0f), bl5 ? color : new Color(50, 50, 60));
            }
            ClickGui.drawText(string, f6 + ClickGui.s(12.0f), f19 + (f20 - (float)FontUtil.getFontHeight() * ClickGui.s(0.64f)) / 2.0f, bl5 ? Color.WHITE.getRGB() : TEXT_DARK.getRGB(), false, ClickGui.s(0.64f));
            if (bl4 && leftClicked && !mouseConsumed) {
                selectedConfig = string;
                mouseConsumed = true;
                leftClicked = false;
            }
            f19 += f20 + ClickGui.s(2.0f);
        }
    }

    private static void clampContentScroll() {
    }

    private static void warnThrottled(String string) {
        long l = System.currentTimeMillis();
        if (l - lastWarnTime > 5000L) {
            Logger.warn(string);
            lastWarnTime = l;
        }
    }

    private static OptionBase<?> guiOption(String string) {
        Module module = ClickGui.getClickGuiModule();
        return module != null ? module.getOption(string) : null;
    }

    private static Boolean optionBoolean(String string, boolean bl) {
        OptionBase<?> optionBase = ClickGui.guiOption(string);
        return optionBase instanceof BooleanOption ? (Boolean)((BooleanOption)optionBase).getValue() : bl;
    }

    private static Double optionNumber(String string, double d) {
        OptionBase<?> optionBase = ClickGui.guiOption(string);
        return optionBase instanceof NumberOption ? (Double)((NumberOption)optionBase).getValue() : d;
    }

    private static Color accentColor(float f) {
        OptionBase<?> optionBase = ClickGui.guiOption("Accent");
        Color color = optionBase instanceof ColorOption ? (Color)((ColorOption)optionBase).getValue() : new Color(99, 102, 241, 255);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), ClickGui.clampInt((int)((float)color.getAlpha() * f)));
    }

    private static int cardBorderColor(float f) {
        OptionBase<?> optionBase = ClickGui.guiOption("Card Border");
        Color color = optionBase instanceof ColorOption ? (Color)((ColorOption)optionBase).getValue() : new Color(60, 60, 75, 200);
        return ClickGui.color(color.getRed(), color.getGreen(), color.getBlue(), ClickGui.clampInt((int)((float)color.getAlpha() * f)));
    }

    private static boolean isTyping() {
        return isTypingSearch || isTypingConfigName || isTypingText;
    }

    private static void clearTyping() {
        isTypingText = false;
        isTypingConfigName = false;
        isTypingSearch = false;
        ClickGui.searchField.setFocused(false);
        ClickGui.configNameField.setFocused(false);
        ClickGui.friendNameField.setFocused(false);
    }

    private static float getMouseX() {
        try {
            return Mouse.getX();
        }
        catch (Throwable throwable) {
            return 0.0f;
        }
    }

    private static float getMouseY() {
        try {
            return Display.getHeight() - Mouse.getY();
        }
        catch (Throwable throwable) {
            return 0.0f;
        }
    }

    private static boolean isKeyDown(int n) {
        try {
            return Keyboard.isKeyDown((int)n);
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private static boolean isMouseDown(int n) {
        try {
            return Mouse.isButtonDown((int)n);
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private static void pushState() {
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)2896);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
    }

    private static void popState() {
        GL11.glPopAttrib();
    }

    private static void updateDelta() {
        long l = System.currentTimeMillis();
        deltaTime = (float)(l - lastFrameTime) / 1000.0f;
        lastFrameTime = l;
    }

    private static void updateScale() {
        double d = ClickGui.optionNumber("UI Scale", 0.7);
        float f = ClickGui.clamp((float)d, 0.5f, 2.0f);
        if (f != guiScale) {
            guiScale = f;
            guiPositioned = false;
        }
        int n = Display.getWidth();
        int n2 = Display.getHeight();
        int n3 = ClickGui.getActualScaleFactor();
        if (n != lastDisplayWidth || n2 != lastDisplayHeight || n3 != lastScaleFactor) {
            guiPositioned = false;
            lastDisplayWidth = n;
            lastDisplayHeight = n2;
            lastScaleFactor = n3;
        }
    }

    private static void updateMouseState() {
        int n = ClickGui.getActualScaleFactor();
        int n2 = Mouse.getX();
        int n3 = Mouse.getY();
        int n4 = Display.getWidth();
        int n5 = Display.getHeight();
        int n6 = (int)Math.ceil((double)n4 / (double)n);
        int n7 = (int)Math.ceil((double)n5 / (double)n);
        mouseX = n4 <= 0 ? 0.0f : (float)n2 * (float)n6 / (float)n4;
        mouseY = (float)n7 - (float)n3 * (float)n7 / (float)n5 - 1.0f;
        leftDown = ClickGui.isMouseDown(0);
        rightDown = ClickGui.isMouseDown(1);
        leftClicked = leftDown && !lastLeftDown;
        rightClicked = rightDown && !lastRightDown;
        boolean bl = ClickGui.isMouseDown(2);
        middleClicked = bl && !lastMiddleDown;
        lastLeftDown = leftDown;
        lastRightDown = rightDown;
        lastMiddleDown = bl;
        try {
            mouseWheel = Mouse.getDWheel();
        }
        catch (Throwable throwable) {
            mouseWheel = 0;
        }
    }

    private static void ensureInitialized() {
    }

    private static void logException(String string, Throwable throwable) {
        Logger.warn(string + ": " + throwable.getMessage());
    }

    private static void unpressKeybindings() {
    }

    private static int alpha(int n) {
        return n >> 24 & 0xFF;
    }

    private static int color(int n, int n2, int n3, int n4) {
        return (n4 & 0xFF) << 24 | (n & 0xFF) << 16 | (n2 & 0xFF) << 8 | n3 & 0xFF;
    }

    private static int applyAlpha(int n, float f) {
        int n2 = (int)((float)(n >> 24 & 0xFF) * f);
        return n & 0xFFFFFF | (n2 & 0xFF) << 24;
    }

    private static Module getClickGuiModule() {
        return Ries.getInstance().getModuleManager().getModule("ClickGUI");
    }

    private static List<Module> getModules() {
        return Ries.getInstance().getModuleManager().getModules();
    }

    private static boolean isInside(float f, float f2, float f3, float f4, float f5, float f6) {
        return f >= f3 && f <= f3 + f5 && f2 >= f4 && f2 <= f4 + f6;
    }

    private static float lerp(float f, float f2, float f3) {
        return f + (f2 - f) * ClickGui.clamp(f3, 0.0f, 1.0f);
    }

    private static float clamp(float f, float f2, float f3) {
        return Math.max(f2, Math.min(f3, f));
    }

    private static int clampInt(int n) {
        return Math.max(0, Math.min(255, n));
    }

    private static void enableScissor(float f, float f2, float f3, float f4) {
        int n = ClickGui.getActualScaleFactor();
        GL11.glEnable((int)3089);
        GL11.glScissor((int)((int)(f * (float)n)), (int)((int)((float)Display.getHeight() - (f2 + f4) * (float)n)), (int)((int)(f3 * (float)n)), (int)((int)(f4 * (float)n)));
    }

    private static void drawCheck(float f, float f2, float f3, float f4) {
        GL11.glDisable((int)3553);
        GL11.glLineWidth((float)1.8f);
        GL11.glBegin((int)3);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)f4);
        GL11.glVertex2f((float)(f + f3 * 0.22f), (float)(f2 + f3 * 0.52f));
        GL11.glVertex2f((float)(f + f3 * 0.46f), (float)(f2 + f3 * 0.76f));
        GL11.glVertex2f((float)(f + f3 * 0.78f), (float)(f2 + f3 * 0.24f));
        GL11.glEnd();
        GL11.glEnable((int)3553);
    }

    private static float s(float f) {
        return f * guiScale;
    }

    private static int textWidth(String string) {
        return FontUtil.getStringWidth(string);
    }

    private static int fontHeight() {
        return FontUtil.getFontHeight();
    }

    private static void drawRect(float f, float f2, float f3, float f4, int n) {
        if (f3 <= 0.0f || f4 <= 0.0f || ClickGui.alpha(n) == 0) {
            return;
        }
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        ClickGui.setColor(n);
        GL11.glBegin((int)7);
        GL11.glVertex2f((float)f, (float)f2);
        GL11.glVertex2f((float)(f + f3), (float)f2);
        GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
        GL11.glVertex2f((float)f, (float)(f2 + f4));
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    private static void drawRoundedRect(float f, float f2, float f3, float f4, float f5, Color color) {
        ClickGui.drawRoundedRect(f, f2, f3, f4, f5, color.getRGB());
    }

    private static void drawRoundedRect(float f, float f2, float f3, float f4, float f5, int n) {
        if (f3 <= 0.0f || f4 <= 0.0f || ClickGui.alpha(n) == 0) {
            return;
        }
        if ((f5 = Math.min(f5, Math.min(f3, f4) / 2.0f)) <= 0.0f) {
            ClickGui.drawRect(f, f2, f3, f4, n);
        } else {
            SDFUtil.drawRoundedRect(f, f2, f3, f4, f5, n);
        }
    }

    private static void drawRoundedOutline(float f, float f2, float f3, float f4, float f5, int n) {
        if (f3 <= 0.0f || f4 <= 0.0f || ClickGui.alpha(n) == 0) {
            return;
        }
        f5 = Math.min(f5, Math.min(f3, f4) / 2.0f);
        SDFUtil.drawRoundedOutline(f, f2, f3, f4, f5, 1.0f, n);
    }

    private static void drawSoftShadow(float f, float f2, float f3, float f4, float f5, float f6) {
    }

    private static void drawCircle(float f, float f2, float f3, int n) {
        if (f3 <= 0.0f || ClickGui.alpha(n) == 0) {
            return;
        }
        SDFUtil.drawRoundedRect(f - f3, f2 - f3, f3 * 2.0f, f3 * 2.0f, f3, n);
    }

    private static void drawGradientRect(float f, float f2, float f3, float f4, int n, int n2, boolean bl) {
        if (f3 <= 0.0f || f4 <= 0.0f) {
            return;
        }
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)7);
        if (bl) {
            ClickGui.setColor(n);
            GL11.glVertex2f((float)f, (float)f2);
            GL11.glVertex2f((float)f, (float)(f2 + f4));
            ClickGui.setColor(n2);
            GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
            GL11.glVertex2f((float)(f + f3), (float)f2);
        } else {
            ClickGui.setColor(n);
            GL11.glVertex2f((float)f, (float)f2);
            GL11.glVertex2f((float)(f + f3), (float)f2);
            ClickGui.setColor(n2);
            GL11.glVertex2f((float)(f + f3), (float)(f2 + f4));
            GL11.glVertex2f((float)f, (float)(f2 + f4));
        }
        GL11.glEnd();
        GL11.glEnable((int)3553);
    }

    private static int lerpColor(int n, int n2, float f) {
        int n3 = n >> 24 & 0xFF;
        int n4 = n >> 16 & 0xFF;
        int n5 = n >> 8 & 0xFF;
        int n6 = n & 0xFF;
        int n7 = n2 >> 24 & 0xFF;
        int n8 = n2 >> 16 & 0xFF;
        int n9 = n2 >> 8 & 0xFF;
        int n10 = n2 & 0xFF;
        int n11 = (int)((float)n3 + (float)(n7 - n3) * f);
        int n12 = (int)((float)n4 + (float)(n8 - n4) * f);
        int n13 = (int)((float)n5 + (float)(n9 - n5) * f);
        int n14 = (int)((float)n6 + (float)(n10 - n6) * f);
        return ClickGui.color(n12, n13, n14, n11);
    }

    private static void setColor(int n) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f);
    }

    private static String trimToWidth(String string, int n, float f) {
        if (string == null) {
            return "";
        }
        float f2 = f;
        int n2 = (int)((float)n / f2);
        if (FontUtil.getStringWidth(string) <= n2) {
            return string;
        }
        String string2 = string;
        while (string2.length() > 0 && FontUtil.getStringWidth(string2 + "...") > n2) {
            string2 = string2.substring(0, string2.length() - 1);
        }
        return string2 + "...";
    }

    private static void createConfigFromField() {
        String string = ClickGui.configNameField.getText().trim();
        if (!string.isEmpty()) {
            ConfigManager.getInstance().saveConfig(Ries.getInstance().getModuleManager(), string);
            configList = ConfigManager.getInstance().getConfigList();
            ClickGui.configNameField.setText("");
            selectedConfig = string;
        }
    }

    private static void clearTypingSearch() {
        isTypingSearch = false;
        ClickGui.searchField.setFocused(false);
    }

    private static void drawText(String string, float f, float f2, int n, boolean bl, float f3) {
        if (string != null && !string.isEmpty() && ClickGui.alpha(n) > 0 && !FontUtil.drawString(string, f, f2, n, bl, f3)) {
            ClickGui.warnThrottled("ClickGui drawText skipped: FontRenderer mapping is not ready");
        }
    }

    private static float getDeltaTime() {
        return deltaTime;
    }

    private static float getGuiScale() {
        return guiScale;
    }

    private static void renderChangelogTab(float f, float f2, float f3, float f4, float f5) {
        float f6 = guiX + ClickGui.s(10.0f);
        float f7 = ClickGui.s(390.0f);
        float f8 = f4 + ClickGui.s(10.0f);
        float f9 = f5 - ClickGui.s(20.0f);
        ClickGui.drawRoundedRect(f6, f8, f7, f9, ClickGui.s(4.0f), CARD_BG);
        ClickGui.drawRoundedOutline(f6, f8, f7, f9, ClickGui.s(4.0f), BORDER_COLOR.getRGB());
        float f10 = f6 + ClickGui.s(12.0f);
        float f11 = f8 + ClickGui.s(12.0f) - contentScrollOffset;
        ClickGui.drawText("\u00a7lMASSACRE CLIENT - G\u00dcNCELLEME NOTLARI", f10, f11, ClickGui.accentColor(f3).getRGB(), false, ClickGui.s(0.85f));
        ClickGui.drawText("En son yap\u0131lan t\u00fcm g\u00fcncellemeler ve hile geli\u015ftirmeleri.", f10, f11 += ClickGui.s(22.0f), TEXT_DARK.getRGB(), false, ClickGui.s(0.58f));
        ClickGui.drawRect(f10, f11 += ClickGui.s(18.0f), f7 - ClickGui.s(24.0f), ClickGui.s(1.0f), BORDER_COLOR.getRGB());
        f11 += ClickGui.s(12.0f);
        f11 = ClickGui.drawChangelogEntry("ClickGUI 'Mod' Sekmesi Geli\u015ftirmesi", "ClickGUI men\u00fcs\u00fcn\u00fcn \u00fcst k\u0131sm\u0131na \u00f6zel 'Mod' sekmesi eklendi. \u00d6zel eklentiler (Bot, PartBot, GrindBot, IllegalBot, TargetManager, FriendManager vb.) bu sekme alt\u0131nda topland\u0131.", f10, f11, f3);
        f11 = ClickGui.drawChangelogEntry("IRC / Massacre Chat G\u00fcncellemeleri", "Sohbet sunucusuna ba\u011fl\u0131 Massacre kullan\u0131c\u0131lar\u0131n\u0131n birbirini otomatik dost eklemesi (AutoFriend) ve '.m list' komutunda kendini gizleme (HideSelf) \u00f6zellikleri eklendi. Admin \u015fifresi yenilendi.", f10, f11, f3);
        f11 = ClickGui.drawChangelogEntry("AutoHead Ba\u011f\u0131ms\u0131z Mod\u00fcl\u00fc", "Eski KillAura i\u00e7indeki kafa yeme \u00f6zelli\u011fi, ba\u011f\u0131ms\u0131z 'AutoHead' mod\u00fcl\u00fcne d\u00f6n\u00fc\u015ft\u00fcr\u00fcld\u00fc. Can yeme limiti ve gecikme s\u00fcresi \u00f6zelle\u015ftirilebilir yap\u0131ld\u0131.", f10, f11, f3);
        f11 = ClickGui.drawChangelogEntry("Reach G\u00fcvenlik & AutoRange Motoru", "Reach mod\u00fcl\u00fcn\u00fcn sol t\u0131ka bas\u0131l\u0131 tutuldu\u011funda s\u00fcrekli vurmas\u0131 engellendi (t\u0131k ba\u015f\u0131na 1 vuru\u015f paketi). Ping tabanl\u0131 \u00e7al\u0131\u015fan ve ban yemenizi tamamen engelleyen 'AutoRange' modu eklendi. Menzil s\u0131n\u0131r\u0131 30.0 bloka \u00e7\u0131kar\u0131ld\u0131.", f10, f11, f3);
        f11 = ClickGui.drawChangelogEntry("Velocity & Killaura \u0130yile\u015ftirmeleri", "Velocity mod\u00fcl\u00fcndeki dynamic scaling yap\u0131s\u0131 geli\u015ftirildi. Killaura i\u00e7in packet-level silent rotasyonlar ve \u00fc\u00e7\u00fcnc\u00fc \u015fah\u0131s (F5) render bak\u0131\u015f\u0131 entegre edildi.", f10, f11, f3);
        float f12 = f11 + contentScrollOffset - f8;
        float f13 = Math.max(0.0f, f12 - f9 + ClickGui.s(10.0f));
        if (selectedTab == Tab.CHANGELOG) {
            int n = Mouse.getDWheel();
            if (n != 0) {
                contentTargetScroll -= (float)n * 0.08f;
            }
            contentTargetScroll = Math.max(0.0f, Math.min(contentTargetScroll, f13));
        }
    }

    private static float drawChangelogEntry(String string, String string2, float f, float f2, float f3) {
        ClickGui.drawRect(f, f2 + ClickGui.s(2.0f), ClickGui.s(4.0f), ClickGui.s(8.0f), ClickGui.accentColor(f3).getRGB());
        ClickGui.drawText("\u00a7l" + string, f + ClickGui.s(8.0f), f2, TEXT_DARK.getRGB(), false, ClickGui.s(0.68f));
        f2 += ClickGui.s(13.0f);
        List<String> list = ClickGui.wrapText(string2, 70);
        for (String string3 : list) {
            ClickGui.drawText("\u00a77" + string3, f + ClickGui.s(8.0f), f2, TEXT_DARK.getRGB(), false, ClickGui.s(0.55f));
            f2 += ClickGui.s(10.0f);
        }
        return f2 += ClickGui.s(10.0f);
    }

    private static List<String> wrapText(String string, int n) {
        ArrayList<String> arrayList = new ArrayList<String>();
        String[] stringArray = string.split(" ");
        StringBuilder stringBuilder = new StringBuilder();
        for (String string2 : stringArray) {
            if (stringBuilder.length() + string2.length() + 1 > n) {
                arrayList.add(stringBuilder.toString());
                stringBuilder = new StringBuilder();
            }
            if (stringBuilder.length() > 0) {
                stringBuilder.append(" ");
            }
            stringBuilder.append(string2);
        }
        if (stringBuilder.length() > 0) {
            arrayList.add(stringBuilder.toString());
        }
        return arrayList;
    }

    static {
        activeNumberString = "";
        draggingBottom = false;
        draggingAny = false;
        activeTextField = new TextField("", 100);
        selectedTab = Tab.COMBAT;
        selectedFriendName = "";
        selectedTargetName = "";
        selectedManagerSubTab = "friend";
        selectedConfig = "";
        configList = new ArrayList<String>();
        saveFriends = true;
        loadFriends = true;
        searchField = new TextField("Search...", 20);
        configNameField = new TextField("Config Name", 20);
        friendNameField = new TextField("Friend Name", 24);
        targetNameField = new TextField("Target Name", 24);
        INSTANCE = new ClickGui();
    }

    private static final class TextField {
        private final String placeholder;
        private final int maxLength;
        private String text = "";
        private boolean focused;
        private float x;
        private float y;
        private float w;
        private float h;
        private int cursor;
        private long lastBlink;
        private boolean blinkOn = true;
        private float inlineXOffset = 0.0f;

        private TextField(String string, int n) {
            this.placeholder = string;
            this.maxLength = n;
        }

        private String getText() {
            return this.text;
        }

        private void setText(String string) {
            this.text = string == null ? "" : string;
            String string2 = this.text;
            if (this.text.length() > this.maxLength) {
                this.text = this.text.substring(0, this.maxLength);
            }
            this.cursor = this.text.length();
        }

        private void setFocused(boolean bl) {
            this.focused = bl;
            this.lastBlink = System.currentTimeMillis();
            this.blinkOn = true;
        }

        private void updateCoordinates(float f, float f2, float f3, float f4) {
            this.x = f;
            this.y = f2;
            this.w = f3;
            this.h = f4;
        }

        private boolean isHovered(float f, float f2) {
            return ClickGui.isInside(f, f2, this.x, this.y, this.w, this.h);
        }

        private boolean isFocused() {
            return this.focused;
        }

        private void handleMouse(float f, float f2) {
            if (!this.isHovered(f, f2)) {
                return;
            }
            float f3 = ClickGui.s(0.72f);
            float f4 = f - this.x - ClickGui.s(7.0f) - this.inlineXOffset;
            this.cursor = 0;
            for (int i = 1; i <= this.text.length(); ++i) {
                if (!((float)FontUtil.getStringWidth(this.text.substring(0, i)) * f3 <= f4)) continue;
                this.cursor = i;
            }
        }

        private void handleKeyboard(int n, char c) {
            if (n == 14 && this.cursor > 0) {
                this.text = this.text.substring(0, this.cursor - 1) + this.text.substring(this.cursor);
                --this.cursor;
            } else if (n == 211 && this.cursor < this.text.length()) {
                this.text = this.text.substring(0, this.cursor) + this.text.substring(this.cursor + 1);
            } else if (n == 203) {
                this.cursor = Math.max(0, this.cursor - 1);
            } else if (n == 205) {
                this.cursor = Math.min(this.text.length(), this.cursor + 1);
            } else if (n == 199) {
                this.cursor = 0;
            } else if (n == 207) {
                this.cursor = this.text.length();
            } else if (c >= ' ' && c != '\u007f' && this.text.length() < this.maxLength) {
                this.text = this.text.substring(0, this.cursor) + c + this.text.substring(this.cursor);
                ++this.cursor;
            }
        }

        private void draw(float f) {
            long l = System.currentTimeMillis();
            if (l - this.lastBlink > 500L) {
                this.blinkOn = !this.blinkOn;
                this.lastBlink = l;
            }
            float f2 = ClickGui.s(0.72f);
            String string = this.text.isEmpty() && !this.focused ? this.placeholder : this.text;
            int n = this.text.isEmpty() && !this.focused ? TEXT_MUTED.getRGB() : TEXT_DARK.getRGB();
            float f3 = this.y + (this.h - (float)FontUtil.getFontHeight() * f2) / 2.0f;
            ClickGui.drawText(string, this.x + ClickGui.s(7.0f) + this.inlineXOffset, f3, ClickGui.applyAlpha(n, f), false, f2);
            if (this.focused && this.blinkOn) {
                float f4 = this.x + ClickGui.s(7.0f) + this.inlineXOffset + (float)FontUtil.getStringWidth(this.text.substring(0, Math.min(this.cursor, this.text.length()))) * f2;
                ClickGui.drawRect(f4, this.y + ClickGui.s(5.0f), ClickGui.s(1.0f), this.h - ClickGui.s(10.0f), ClickGui.applyAlpha(TEXT_DARK.getRGB(), f));
            }
        }
    }

    private static enum Tab {
        COMBAT("Combat"),
        MOVEMENT("Movement"),
        RENDER("Render"),
        MOD("Mod"),
        MISCELLANEOUS("Misc"),
        MANAGER("Manager"),
        CONFIGS("Configs"),
        CHANGELOG("Updates");

        private final String displayName;

        private Tab(String string2) {
            this.displayName = string2;
        }

        public String getDisplayName() {
            return this.displayName;
        }
    }
}

