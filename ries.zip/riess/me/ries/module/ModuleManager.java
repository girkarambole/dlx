/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package me.ries.module;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import me.ries.event.EventBus;
import me.ries.module.Module;
import me.ries.module.impl.AimBotModule;
import me.ries.module.impl.ArrayListModule;
import me.ries.module.impl.AutoArmorModule;
import me.ries.module.impl.AutoHeadModule;
import me.ries.module.impl.BlockRemoverModule;
import me.ries.module.impl.BotModule;
import me.ries.module.impl.ChamsModule;
import me.ries.module.impl.ChatManagerModule;
import me.ries.module.impl.ChestStealerModule;
import me.ries.module.impl.ClickGuiModule;
import me.ries.module.impl.EspModule;
import me.ries.module.impl.FastPlaceModule;
import me.ries.module.impl.FlyModule;
import me.ries.module.impl.FriendManagerModule;
import me.ries.module.impl.HitboxModule;
import me.ries.module.impl.IllegalBotModule;
import me.ries.module.impl.InvManagerModule;
import me.ries.module.impl.InventoryMoveModule;
import me.ries.module.impl.KillAuraModule;
import me.ries.module.impl.LookTPModule;
import me.ries.module.impl.MassacreChatModule;
import me.ries.module.impl.ParticlesModule;
import me.ries.module.impl.ReachModule;
import me.ries.module.impl.ScaffoldModule;
import me.ries.module.impl.ScoreBoardModule;
import me.ries.module.impl.SpeedModule;
import me.ries.module.impl.SpinbotModule;
import me.ries.module.impl.SpotifyWidget;
import me.ries.module.impl.StrafeModule;
import me.ries.module.impl.StreamerModule;
import me.ries.module.impl.TPAuraModule;
import me.ries.module.impl.TargetHudModule;
import me.ries.module.impl.TargetIndicatorModule;
import me.ries.module.impl.TargetManagerModule;
import me.ries.module.impl.ToggleSoundsModule;
import me.ries.module.impl.TracersModule;
import me.ries.module.impl.VClipDownModule;
import me.ries.module.impl.VClipUpModule;
import me.ries.module.impl.VelocityModule;
import me.ries.module.impl.WatermarkModule;
import me.ries.module.impl.DeveloperModeModule;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Keyboard;

public class ModuleManager {
    private List<Module> modules = new ArrayList<Module>();
    private Map<Module, Boolean> keyStates = new IdentityHashMap<Module, Boolean>();
    private Field cachedCurrentScreen = null;
    private Field cachedMinecraft = null;
    private boolean currentScreenInit = false;

    public void loadModules() {
        Logger.info("ModuleManager: Loading modules...");
        this.modules.clear();
        this.keyStates.clear();
        this.addModule(new ClickGuiModule());
        this.addModule(new SpotifyWidget());
        this.addModule(new WatermarkModule());
        this.addModule(new ArrayListModule());
        this.addModule(new KillAuraModule());
        this.addModule(new ReachModule());
        this.addModule(new HitboxModule());
        this.addModule(new AimBotModule());
        this.addModule(new VelocityModule());
        this.addModule(new SpeedModule());
        this.addModule(new ScaffoldModule());
        this.addModule(new FlyModule());
        this.addModule(new VClipUpModule());
        this.addModule(new VClipDownModule());
        this.addModule(new LookTPModule());
        this.addModule(new FastPlaceModule());
        this.addModule(new FriendManagerModule());
        this.addModule(new ChestStealerModule());
        this.addModule(new AutoArmorModule());
        this.addModule(new InvManagerModule());
        this.addModule(new EspModule());
        this.addModule(new TargetHudModule());
        this.addModule(new StrafeModule());
        this.addModule(new SpinbotModule());
        this.addModule(new InventoryMoveModule());
        this.addModule(new TPAuraModule());
        this.addModule(new TargetIndicatorModule());
        this.addModule(new BlockRemoverModule());
        this.addModule(new ScoreBoardModule());
        this.addModule(new ParticlesModule());
        this.addModule(new TracersModule());
        this.addModule(new ChamsModule());
        this.addModule(new ToggleSoundsModule());
        this.addModule(new ChatManagerModule());
        this.addModule(new TargetManagerModule());
        this.addModule(new BotModule());
        this.addModule(new IllegalBotModule());
        this.addModule(new MassacreChatModule());
        this.addModule(new StreamerModule());
        this.addModule(new AutoHeadModule());
        this.addModule(new DeveloperModeModule());
        Logger.info("ModuleManager: Loaded " + this.modules.size() + " modules");
    }

    public void registerEventListeners(EventBus eventBus) {
        Logger.info("ModuleManager: Registering event listeners...");
    }

    public void handleKeyBinds() {
        try {
            if (!Keyboard.isCreated()) {
                return;
            }
            boolean bl = false;
            if (!this.currentScreenInit) {
                try {
                    this.cachedCurrentScreen = MappingUtils.getField("Minecraft.currentScreen");
                    if (this.cachedCurrentScreen != null) {
                        this.cachedCurrentScreen.setAccessible(true);
                    }
                    this.cachedMinecraft = MappingUtils.getField("Minecraft.theMinecraft");
                    if (this.cachedMinecraft != null) {
                        this.cachedMinecraft.setAccessible(true);
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                this.currentScreenInit = true;
            }
            if (this.cachedMinecraft != null && this.cachedCurrentScreen != null) {
                try {
                    Object object = this.cachedMinecraft.get(null);
                    if (object != null && this.cachedCurrentScreen.get(object) != null) {
                        bl = true;
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            for (Module module : this.modules) {
                if (module instanceof ClickGuiModule || module instanceof VClipUpModule || module instanceof VClipDownModule || module instanceof LookTPModule) continue;
                int n = module.getKeyBind();
                if (n <= 0) {
                    this.keyStates.put(module, Boolean.FALSE);
                    continue;
                }
                boolean bl2 = Keyboard.isKeyDown((int)n);
                boolean bl3 = Boolean.TRUE.equals(this.keyStates.get(module));
                if (bl2 && !bl3 && !bl) {
                    module.toggle();
                }
                this.keyStates.put(module, bl2);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public void updateModules() {
        for (Module module : new ArrayList<Module>(this.modules)) {
            if (!module.isEnabled() || module instanceof ReachModule) continue;
            try {
                module.onUpdate();
            }
            catch (Throwable throwable) {
                Logger.error("Module update error [" + module.getName() + "]: " + throwable.toString());
            }
        }
    }

    public void disableAllModules() {
        for (Module module : this.modules) {
            if (!module.isEnabled()) continue;
            module.disable();
        }
    }

    public void addModule(Module module) {
        this.modules.add(module);
    }

    public Module getModule(String string) {
        for (Module module : this.modules) {
            if (!module.getName().equalsIgnoreCase(string)) continue;
            return module;
        }
        return null;
    }

    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module module : this.modules) {
            if (!clazz.isInstance(module)) continue;
            return (T)((Module)clazz.cast(module));
        }
        return null;
    }

    public List<Module> getModules() {
        return new ArrayList<Module>(this.modules);
    }
}

