/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import me.ries.Ries;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.impl.FriendManagerModule;
import me.ries.module.impl.TargetManagerModule;
import me.ries.module.impl.ToggleSoundsModule;
import me.ries.notification.NotificationManager;
import me.ries.setting.OptionBase;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public abstract class Module {
    protected String name;
    protected String description;
    protected Category category;
    protected int keyBind;
    protected boolean enabled = false;
    private final List<OptionBase<?>> options = new ArrayList();

    public Module(String string, String string2) {
        this(string, string2, Category.MISC, 0);
    }

    public Module(String string, String string2, Category category, int n) {
        this.name = string;
        this.description = string2;
        this.category = category == null ? Category.MISC : category;
        this.keyBind = n;
    }

    public abstract void onEnable();

    public abstract void onDisable();

    public abstract void onUpdate();

    public void toggle() {
        if (this.enabled) {
            this.disable();
        } else {
            this.enable();
        }
    }

    public void enable() {
        if (!this.enabled) {
            try {
                this.onEnable();
                this.enabled = true;
                try {
                    NotificationManager.postModule(this.name, true);
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                try {
                    ToggleSoundsModule toggleSoundsModule = Ries.getInstance().getModuleManager().getModule(ToggleSoundsModule.class);
                    if (toggleSoundsModule != null && toggleSoundsModule.isEnabled()) {
                        toggleSoundsModule.playToggleSound(true);
                    }
                }
                catch (Throwable throwable) {}
            }
            catch (Throwable throwable) {
                this.enabled = false;
                Logger.warn("Module enable failed for " + this.name + " - " + throwable.getMessage());
            }
        }
    }

    public void disable() {
        if (this.enabled) {
            try {
                this.onDisable();
            }
            catch (Throwable throwable) {
                Logger.warn("Module disable failed for " + this.name + " - " + throwable.getMessage());
            }
            finally {
                this.enabled = false;
                try {
                    NotificationManager.postModule(this.name, false);
                }
                catch (Throwable throwable) {}
                try {
                    ToggleSoundsModule toggleSoundsModule = Ries.getInstance().getModuleManager().getModule(ToggleSoundsModule.class);
                    if (toggleSoundsModule != null && toggleSoundsModule.isEnabled()) {
                        toggleSoundsModule.playToggleSound(false);
                    }
                }
                catch (Throwable throwable) {}
            }
        }
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public Category getCategory() {
        return this.category;
    }

    public int getKeyBind() {
        return this.keyBind;
    }

    public void setKeyBind(int n) {
        this.keyBind = n;
    }

    public List<OptionBase<?>> getOptions() {
        return Collections.unmodifiableList(this.options);
    }

    public OptionBase<?> getOption(String string) {
        if (string == null) {
            return null;
        }
        for (OptionBase<?> optionBase : this.options) {
            if (!optionBase.getName().equalsIgnoreCase(string)) continue;
            return optionBase;
        }
        return null;
    }

    protected void addOption(OptionBase<?> optionBase) {
        if (optionBase != null) {
            this.options.add(optionBase);
        }
    }

    protected void addOptions(OptionBase<?> ... optionBaseArray) {
        if (optionBaseArray != null) {
            for (OptionBase<?> optionBase : optionBaseArray) {
                this.addOption(optionBase);
            }
        }
    }

    public boolean isHidden() {
        return false;
    }

    public String getOptionPrefix() {
        for (OptionBase<?> optionBase : this.options) {
            Object obj = optionBase.getValue();
            if (obj instanceof Double) {
                double d = (Double)obj;
                return d == Math.floor(d) ? String.valueOf((int)d) : String.format("%.1f", d);
            }
            if (!(obj instanceof String)) continue;
            String string = (String)obj;
            return string.length() > 5 ? string.substring(0, 5) : string;
        }
        return "";
    }

    protected boolean isValidCombatTarget(Object object) {
        String string;
        Object object2;
        if (object == null) {
            return false;
        }
        if (object == this.getThePlayer()) {
            return false;
        }
        try {
            object2 = MinecraftMapper.getName(object);
            if (object2 != null) {
                string = ((String)object2).replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim();
                if (string.startsWith("[CR]")) {
                    return false;
                }
                if (string.matches(".*[\\[\\]].*")) {
                    return false;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            object2 = Ries.getInstance().getModuleManager().getModule(TargetManagerModule.class);
            if (object2 != null && ((Module)object2).isEnabled()) {
                if (!TargetManagerModule.isTarget(object)) {
                    return false;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return !FriendManagerModule.isFriend(object);
    }

    protected Object getMinecraft() {
        try {
            Class<?> clazz = MappingUtils.get("Minecraft");
            if (clazz == null) {
                return null;
            }
            Method method = MappingUtils.getMethod("Minecraft.getInstance");
            if (method != null) {
                method.setAccessible(true);
                return method.invoke(null, new Object[0]);
            }
            Field field = MappingUtils.getField("Minecraft.theMinecraft");
            if (field == null) {
                return null;
            }
            field.setAccessible(true);
            return field.get(null);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    protected Object getThePlayer() {
        try {
            Object object = this.getMinecraft();
            if (object == null) {
                return null;
            }
            Method method = MappingUtils.getMethod("Minecraft.getThePlayer");
            if (method != null) {
                method.setAccessible(true);
                return method.invoke(object, new Object[0]);
            }
            Field field = MappingUtils.getField("Minecraft.thePlayer");
            if (field == null) {
                return null;
            }
            field.setAccessible(true);
            return field.get(object);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    protected Object getTheWorld() {
        try {
            Object object = this.getMinecraft();
            if (object == null) {
                return null;
            }
            Method method = MappingUtils.getMethod("Minecraft.getTheWorld");
            if (method != null) {
                method.setAccessible(true);
                return method.invoke(object, new Object[0]);
            }
            Object object2 = this.getThePlayer();
            if (object2 == null) {
                return null;
            }
            Field field = MappingUtils.getField("EntityPlayerSP.worldObj");
            if (field == null) {
                return null;
            }
            field.setAccessible(true);
            return field.get(object2);
        }
        catch (Throwable throwable) {
            return null;
        }
    }
}

