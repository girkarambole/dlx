package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Random;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.setting.OptionBase;
import me.ries.setting.StringOption;
import me.ries.util.BotTracker;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class TPAuraModule extends Module {
   private final NumberOption targetRange = new NumberOption("Target Range", (double)6.0F, (double)3.0F, (double)8.0F, (double)0.5F, this);
   private final NumberOption cps = new NumberOption("CPS", (double)12.0F, (double)5.0F, (double)20.0F, (double)1.0F, this);
   private final NumberOption smoothness = new NumberOption("Smoothness", 0.2, 0.05, (double)0.5F, 0.05, this);
   private final NumberOption spinRadius = new NumberOption("Spin Radius", (double)3.5F, (double)2.0F, (double)5.0F, (double)0.25F, this);
   private final NumberOption spinSpeed = new NumberOption("Spin Speed", 1.3, (double)1.0F, (double)3.0F, 0.05, this);
   private final NumberOption fov = new NumberOption("FOV", (double)360.0F, (double)15.0F, (double)360.0F, (double)5.0F, this);
   private final BooleanOption rotationEnabled = new BooleanOption("Rotation", true, this);
   private final StringOption rotationMode = new StringOption("RotMode", "Silent", this, new String[]{"Silent", "Body"});
   private final NumberOption rotationSpeed = new NumberOption("RotSpeed", 0.65, 0.1, (double)1.0F, 0.05, this);
   private final NumberOption aimPoint = new NumberOption("AimPoint", (double)0.5F, (double)0.0F, (double)1.0F, 0.05, this);
   private final StringOption targetLock = new StringOption("TargetLock", "Off", this, new String[]{"On", "Off"});
   private final BooleanOption rangeCircle = new BooleanOption("RangeCircle", true, this);
   private final BooleanOption targetMarker = new BooleanOption("TargetMarker", true, this);
   private final BooleanOption tracer = new BooleanOption("Tracer", false, this);
   private final BooleanOption headRide = new BooleanOption("HeadRide", false, this);
   private final NumberOption headHeight = new NumberOption("HeadHeight", 1.0, 0.0, 3.0, 0.5, this);
   private static final float VIS_WHITE = 0.96F;
   private static final float VIS_LIGHT = 0.78F;
   private static final float VIS_MID = 0.52F;
   private static final float VIS_DARK = 0.1F;
   private long lastAttackTime = 0L;
   private final Random random = new Random();
   private Object lastTarget = null;
   private long lastTargetTime = 0L;
   private double smoothTX = (double)0.0F;
   private double smoothTY = (double)0.0F;
   private double smoothTZ = (double)0.0F;
   private boolean targetInit = false;
   private float lastYaw = 0.0F;
   private float lastPitch = 0.0F;
   private boolean rotationInitialized = false;
 
   public TPAuraModule() {
      super("TPAura", "Teleport aura", Category.COMBAT, 0);
      this.addOptions(new OptionBase[]{this.targetRange, this.cps, this.smoothness, this.spinRadius, this.spinSpeed, this.fov, this.rotationEnabled, this.rotationMode, this.rotationSpeed, this.aimPoint, this.targetLock, this.rangeCircle, this.targetMarker, this.tracer, this.headRide, this.headHeight});
      Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener() {
         public void onEvent(Event event) {
            if (event instanceof Render3DEvent) {
               TPAuraModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
            }

         }
      });
   }

   public String getMode() {
      return "JumpSpin";
   }

   public String getOptionPrefix() {
      double r = (Double)this.targetRange.getValue();
      return r == Math.floor(r) ? String.valueOf((int)r) : String.format("%.1f", r);
   }

   public void onEnable() {
      this.lastYaw = MinecraftMapper.getRotationYaw();
      this.lastPitch = MinecraftMapper.getRotationPitch();
      this.rotationInitialized = false;
   }

   public void onDisable() {
      this.resetState();
   }

   public Object getHudTarget() {
      return this.lastTarget;
   }

   public void onUpdate() {
      if (this.isEnabled()) {
         Object player = MinecraftMapper.getPlayer();
         if (player != null) {
            Object target = this.getBestTarget();

            // HeadRide aktifken hedef oldu mu? Aninda birak
            if (target != null && (Boolean)this.headRide.getValue()) {
               float hp = MappingUtils.getEntityHealth(target);
               if (hp <= 0.0f) {
                  target = null;
                  this.lastTarget = null;
                  this.targetInit = false;
                  this.releaseHeadRide(player);
               }
            }

            if (target == null) {
               this.lastTarget = null;
               this.targetInit = false;
               // HeadRide modunda hedef yoksa gravity'yi geri yukle
               if ((Boolean)this.headRide.getValue()) {
                  this.releaseHeadRide(player);
               }
            } else {
               this.lastTarget = target;
               this.lastTargetTime = System.currentTimeMillis();
               double rawTX = MinecraftMapper.getPosX(target);
               double rawTY = MinecraftMapper.getPosY(target);
               double rawTZ = MinecraftMapper.getPosZ(target);
               if (!this.targetInit) {
                  this.smoothTX = rawTX;
                  this.smoothTY = rawTY;
                  this.smoothTZ = rawTZ;
                  this.targetInit = true;
               }

               this.smoothTX = this.lerp(this.smoothTX, rawTX, (double)0.25F);
               this.smoothTY = this.lerp(this.smoothTY, rawTY, (double)0.25F);
               this.smoothTZ = this.lerp(this.smoothTZ, rawTZ, (double)0.25F);
               double tX = this.smoothTX;
               double tY = this.smoothTY;
               double tZ = this.smoothTZ;
               double playerX = MinecraftMapper.getPosX();
               double playerY = MinecraftMapper.getPosY();
               double playerZ = MinecraftMapper.getPosZ();

               // HeadRide: Hedefin kafasinin ustune bin
               if ((Boolean)this.headRide.getValue()) {
                  this.handleHeadRide(target, playerX, playerY, playerZ, tX, tY, tZ);
               } else {
                  this.handleJumpSpin(playerX, playerY, playerZ, tX, tZ);
               }

               long now = System.currentTimeMillis();
               if (now - this.lastAttackTime >= (long)((double)1000.0F / (Double)this.cps.getValue())) {
                  this.applyRotation(target);
                  this.attackEntity(target);
                  this.lastAttackTime = now;
               } else {
                  this.applyRotation(target);
               }
            }
         }
      }

   }

   private double[] computeSpinOrbit(double tX, double tZ) {
      double t = (double)System.currentTimeMillis() / (double)1000.0F * (Double)this.spinSpeed.getValue();
      double destX = tX + Math.cos(t * (double)3.0F) * (Double)this.spinRadius.getValue();
      double destZ = tZ + Math.sin(t * (double)3.0F) * (Double)this.spinRadius.getValue();
      return new double[]{destX, destZ};
   }

   /**
    * HeadRide: Hedefin kafasinin ustune tp eder.
    * headHeight kadar (max 3 blok) yukari konumlanir.
    */
   private void handleHeadRide(Object target, double px, double py, double pz, double tX, double tY, double tZ) {
      try {
         // --- Hizli olum tespiti ---
         float targetHp = MappingUtils.getEntityHealth(target);
         if (targetHp <= 0.0f) {
            // Hedef oldu, gravity'yi geri yukle ve cik
            Object player = MinecraftMapper.getPlayer();
            if (player != null) this.releaseHeadRide(player);
            return;
         }
         try {
            Field deadField = MappingUtils.getField("Entity.isDead");
            if (deadField == null) deadField = MappingUtils.getField("Entity.dead");
            if (deadField != null) {
               deadField.setAccessible(true);
               Object val = deadField.get(target);
               if (val instanceof Boolean && (Boolean)val) {
                  Object player = MinecraftMapper.getPlayer();
                  if (player != null) this.releaseHeadRide(player);
                  return;
               }
            }
         } catch (Throwable ignored) {}

         // Hedefin entity yuksekligi (genelde 1.8 blok)
         float targetEntityHeight = MappingUtils.getEyeHeight(target);
         double targetTopY = tY + (double)targetEntityHeight * 1.1;

         // Max 3 blok siniri
         double hh = Math.min(3.0, Math.max(0.0, (Double)this.headHeight.getValue()));
         double destY = targetTopY + hh;

         // Yatay olarak hedefin tam ustune gel (X/Z ayni)
         double destX = tX;
         double destZ = tZ;

         double dX = destX - px;
         double dZ = destZ - pz;
         double horizDist = Math.sqrt(dX * dX + dZ * dZ);

         Object player = MinecraftMapper.getPlayer();
         if (player == null) return;

         if (horizDist > 0.15 || Math.abs(py - destY) > 0.2) {
            // Hizli teleport: pozisyon field'larini dogrudan ayarla
            double sm = (Double)this.smoothness.getValue();
            double newX = this.lerp(px, destX, sm * 2.0);
            double newY = this.lerp(py, destY, sm * 1.5);
            double newZ = this.lerp(pz, destZ, sm * 2.0);

            // Once setPositionAndUpdate ile dene
            try {
               Method setPos = MappingUtils.getMethod("Entity.setPositionAndUpdate");
               if (setPos != null) {
                  setPos.setAccessible(true);
                  setPos.invoke(player, newX, newY, newZ);
               } else {
                  Field pxF = MappingUtils.getField("Entity.posX");
                  Field pyF = MappingUtils.getField("Entity.posY");
                  Field pzF = MappingUtils.getField("Entity.posZ");
                  if (pxF != null) { pxF.setAccessible(true); pxF.setDouble(player, newX); }
                  if (pyF != null) { pyF.setAccessible(true); pyF.setDouble(player, newY); }
                  if (pzF != null) { pzF.setAccessible(true); pzF.setDouble(player, newZ); }
               }
            } catch (Throwable ex) {
               try {
                  Field pxF = MappingUtils.getField("Entity.posX");
                  Field pyF = MappingUtils.getField("Entity.posY");
                  Field pzF = MappingUtils.getField("Entity.posZ");
                  if (pxF != null) { pxF.setAccessible(true); pxF.setDouble(player, newX); }
                  if (pyF != null) { pyF.setAccessible(true); pyF.setDouble(player, newY); }
                  if (pzF != null) { pzF.setAccessible(true); pzF.setDouble(player, newZ); }
               } catch (Throwable ex2) {}
            }

            // Momentum sifirla - kafada durmak icin
            Field motXF = MappingUtils.getField("Entity.motionX");
            Field motYF = MappingUtils.getField("Entity.motionY");
            Field motZF = MappingUtils.getField("Entity.motionZ");
            if (motXF != null) { motXF.setAccessible(true); motXF.setDouble(player, 0.0); }
            if (motYF != null) { motYF.setAccessible(true); motYF.setDouble(player, 0.0); }
            if (motZF != null) { motZF.setAccessible(true); motZF.setDouble(player, 0.0); }
         }
      } catch (Throwable t) {
      }
   }

   /**
    * HeadRide'dan cikince gravity'yi geri yukle (asagi duser).
    */
   private void releaseHeadRide(Object player) {
      try {
         Field motYF = MappingUtils.getField("Entity.motionY");
         if (motYF != null) {
            motYF.setAccessible(true);
            double curMotY = motYF.getDouble(player);
            // Eger hava durumdaysa asagi itki uygula
            if (curMotY >= -0.01) {
               motYF.setDouble(player, -0.1);
            }
         }
         // Yatay momentum zaten sifir, dokunmuyoruz
      } catch (Throwable t) {}
   }

   private void handleJumpSpin(double px, double py, double pz, double tX, double tZ) {
      double[] orbit = this.computeSpinOrbit(tX, tZ);
      double sm = (Double)this.smoothness.getValue();
      double nextX = this.lerp(px, orbit[0], sm);
      double nextZ = this.lerp(pz, orbit[1], sm);
      double dX = nextX - px;
      double dZ = nextZ - pz;
 
      double mult = (Double)this.spinSpeed.getValue();
      double baseSpeed = 0.22;
      double speed = baseSpeed * mult;
 
      Object player = MinecraftMapper.getPlayer();
      if (player != null && this.isOnGround(player)) {
         this.setMotionY(0.42);
         speed *= 1.2;
      }
 
      double dist = Math.sqrt(dX * dX + dZ * dZ);
      if (dist > 0.001) {
         dX = (dX / dist) * speed;
         dZ = (dZ / dist) * speed;
      }
 
      MinecraftMapper.setMotionX(dX);
      MinecraftMapper.setMotionZ(dZ);
   }

   private void attackEntity(Object entity) {
      try {
         String targetName = this.getName(entity);
         float targetHealth = this.getHealth(entity);
         double targetDist = this.distanceTo(entity);
         Logger.kaAttack("attackEntity -> name=" + targetName + " health=" + targetHealth + " dist=" + String.format("%.2f", targetDist) + " mode=JumpSpin range=" + String.format("%.1f", this.targetRange.getValue()) + " cps=" + String.format("%.1f", this.cps.getValue()));

         try {
            Method swing = MappingUtils.getMethod("EntityPlayerSP.swingItem");
            if (swing == null) {
               swing = MappingUtils.getMethod("EntityPlayer.swingItem");
            }

            if (swing == null) {
               swing = MappingUtils.getMethod("Entity.swingItem");
            }

            Object player = MinecraftMapper.getPlayer();
            if (swing != null && player != null) {
               swing.setAccessible(true);
               swing.invoke(player);
            }
         } catch (Throwable var12) {
         }

         boolean success = MinecraftMapper.attackEntity(entity);
         if (!success) {
            Logger.kaWarn("attackEntity: raw attack returned false -> target=" + targetName);
            Logger.warn("TPAura raw attack failed");
         } else {
            Logger.kaDebug("attackEntity: SUCCESS -> " + targetName);
         }

         try {
            if (Mouse.isButtonDown(1)) {
               Object player = MinecraftMapper.getPlayer();
               Method getHeldItem = MappingUtils.getMethod("EntityPlayer.getHeldItem");
               Method setItemInUse = MappingUtils.getMethod("EntityPlayer.setItemInUse");
               if (getHeldItem != null && setItemInUse != null && player != null) {
                  getHeldItem.setAccessible(true);
                  setItemInUse.setAccessible(true);
                  Object heldItem = getHeldItem.invoke(player);
                  if (heldItem != null) {
                     setItemInUse.invoke(player, heldItem, 72000);
                  }
               }
            }
         } catch (Throwable var11) {
         }
      } catch (Throwable t) {
         Logger.kaWarn("attackEntity EXCEPTION: " + t.getClass().getSimpleName() + " -> " + t.getMessage());
         Logger.warn("TPAura attack failed: " + t.getMessage());
      }

   }

   private String getName(Object entity) {
      return MinecraftMapper.getName(entity);
   }

   private float getHealth(Object entity) {
      return MappingUtils.getEntityHealth(entity);
   }

   private Object getBestTarget() {
      boolean lock = "On".equals(this.targetLock.getValue());
      if (this.lastTarget != null) {
         boolean timeValid = lock || (System.currentTimeMillis() - this.lastTargetTime < 2000L);
         if (timeValid && this.isValidTarget(this.lastTarget)) {
            double dist = this.distanceTo(this.lastTarget);
            double rangeLimit = (Double)this.targetRange.getValue();
            if (lock) {
               rangeLimit *= 1.5;
            }
            if (dist <= rangeLimit) {
               return this.lastTarget;
            }
         }
      }

      Object best = null;
      double minDist = Double.MAX_VALUE;
      List<Object> entities = MinecraftMapper.getPlayerEntitiesInWorld();
      if (entities == null) {
         return null;
      } else {
         for(Object e : entities) {
            BotTracker.observe(e);
            if (this.isValidTarget(e)) {
               double d = this.distanceTo(e);
               if (d <= (Double)this.targetRange.getValue() && d < minDist) {
                  minDist = d;
                  best = e;
               }
            }
         }

         return best;
      }
   }

   private boolean isValidTarget(Object entity) {
      if (entity != null && entity != MinecraftMapper.getPlayer()) {
         List<Object> entities = MinecraftMapper.getPlayerEntitiesInWorld();
         if (entities == null || !entities.contains(entity)) {
            return false;
         }
         if (!this.isValidCombatTarget(entity)) {
            return false;
         } else if (BotTracker.isBot(entity)) {
            return false;
         } else if (BotTracker.isBotByHp(entity)) {
            return false;
         } else {
            float[] needed = this.getRotationsTo(entity);
            if (needed != null) {
               float yawDiff = angleDiff(MinecraftMapper.getRotationYaw(), needed[0]);
               if (yawDiff > (Double)this.fov.getValue()) {
                  return false;
               }
            }
            try {
               Field deadField = MappingUtils.getField("Entity.isDead");
               if (deadField == null) {
                  deadField = MappingUtils.getField("Entity.dead");
               }

               if (deadField != null) {
                  deadField.setAccessible(true);
                  Object val = deadField.get(entity);
                  if (val instanceof Boolean && (Boolean)val) {
                     return false;
                  }
               }
            } catch (Throwable var4) {
            }

            try {
               Field deathTimeField = MappingUtils.getField("EntityLivingBase.deathTime");
               if (deathTimeField == null) {
                  deathTimeField = MappingUtils.getField("EntityLiving.deathTime");
               }
               if (deathTimeField != null) {
                  deathTimeField.setAccessible(true);
                  if (deathTimeField.getInt(entity) > 0) {
                     return false;
                  }
               }
            } catch (Throwable var5) {
            }

            float hp = MappingUtils.getEntityHealth(entity);
            if (hp <= 0.0F) {
               return false;
            } else {
               String name = MinecraftMapper.getName(entity);
               return name != null && !name.replaceAll("§.", "").trim().isEmpty();
            }
         }
      } else {
         return false;
      }
   }

   private double distanceTo(Object entity) {
      try {
         double dx = MinecraftMapper.getPosX() - MinecraftMapper.getPosX(entity);
         double dy = MinecraftMapper.getPosY() - MinecraftMapper.getPosY(entity);
         double dz = MinecraftMapper.getPosZ() - MinecraftMapper.getPosZ(entity);
         return Math.sqrt(dx * dx + dy * dy + dz * dz);
      } catch (Throwable var8) {
         return Double.MAX_VALUE;
      }
   }

   private double lerp(double start, double end, double alpha) {
      return start + (end - start) * alpha;
   }

   private void resetState() {
      this.lastTarget = null;
      this.targetInit = false;
      this.smoothTX = (double)0.0F;
      this.smoothTY = (double)0.0F;
      this.smoothTZ = (double)0.0F;
   }

   public void onRender3D(float partialTicks) {
      if (this.isEnabled()) {
         if ((Boolean)this.rangeCircle.getValue()) {
            this.renderRangeCircle(partialTicks);
         }

         Object target = this.lastTarget;
         if (target != null) {
            if ((Boolean)this.targetMarker.getValue()) {
               this.renderTargetMarker(target, partialTicks);
            }

            if ((Boolean)this.tracer.getValue()) {
               this.renderTracer(target, partialTicks);
            }
         }
      }

   }

   private void glMono(float shade, float alpha) {
      GL11.glColor4f(shade, shade, shade + 0.02F, alpha);
   }

   private void pushVisualState() {
      GL11.glPushAttrib(1048575);
      GL11.glDisable(3553);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(2929);
      GL11.glDisable(2884);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
   }

   private void drawGroundRing(double radius, float y, float shade, float alpha, int step) {
      GL11.glBegin(2);
      this.glMono(shade, alpha);

      for(int i = 0; i <= 360; i += step) {
         double angle = Math.toRadians((double)i);
         GL11.glVertex3d(Math.cos(angle) * radius, (double)y, Math.sin(angle) * radius);
      }

      GL11.glEnd();
   }

   private void drawHorizontalRing(float cx, float cz, float y, float radius, float shade, float alpha, int segments) {
      GL11.glBegin(2);
      this.glMono(shade, alpha);

      for(int i = 0; i < segments; ++i) {
         double ang = (Math.PI * 2D) * (double)i / (double)segments;
         GL11.glVertex3d((double)cx + Math.cos(ang) * (double)radius, (double)y, (double)cz + Math.sin(ang) * (double)radius);
      }

      GL11.glEnd();
   }

   private void renderRangeCircle(float partialTicks) {
      Object player = this.getThePlayer();
      if (player != null) {
         double[] p = MappingUtils.getInterpolatedPos(player, partialTicks);
         double camX = MappingUtils.getRenderPosX();
         double camY = MappingUtils.getRenderPosY();
         double camZ = MappingUtils.getRenderPosZ();
         double currentRange = (Double)this.targetRange.getValue();
         double rotAngle = (double)(System.currentTimeMillis() % 4000L) / (double)4000.0F * Math.PI * (double)2.0F;
         double rotAngleInner = (double)(-(System.currentTimeMillis() % 6000L)) / (double)6000.0F * Math.PI * (double)2.0F;
         this.pushVisualState();
         GL11.glPushMatrix();
         GL11.glTranslated(p[0] - camX, p[1] - camY, p[2] - camZ);
         GL11.glBegin(5);

         for(int i = 0; i <= 360; i += 4) {
            double angle = Math.toRadians((double)i);
            double dx = Math.cos(angle) * currentRange;
            double dz = Math.sin(angle) * currentRange;
            this.glMono(0.78F, 0.1F);
            GL11.glVertex3d(dx, 0.02, dz);
            this.glMono(0.78F, 0.0F);
            GL11.glVertex3d(dx, 0.38, dz);
         }

         GL11.glEnd();
         GL11.glLineWidth(1.0F);
         this.drawGroundRing(currentRange, 0.03F, 0.96F, 0.88F, 4);
         GL11.glLineWidth(0.6F);
         this.drawGroundRing(currentRange * 0.94, 0.025F, 0.52F, 0.35F, 6);
         GL11.glLineWidth(1.0F);
         GL11.glBegin(1);

         for(int i = 0; i < 4; ++i) {
            double angle = rotAngle + (Math.PI / 4D) + (double)i * (Math.PI / 2D);
            double cos = Math.cos(angle);
            double sin = Math.sin(angle);
            this.glMono(0.96F, 0.75F);
            GL11.glVertex3d(cos * currentRange * 0.98, 0.03, sin * currentRange * 0.98);
            GL11.glVertex3d(cos * (currentRange + 0.32), 0.03, sin * (currentRange + 0.32));
         }

         GL11.glEnd();
         GL11.glLineWidth(1.2F);
         int arcCount = 8;
         int arcSteps = 6;
         double arcSpan = Math.toRadians((double)18.0F);

         for(int i = 0; i < arcCount; ++i) {
            double baseAngle = rotAngleInner + (double)i * ((Math.PI * 2D) / (double)arcCount);
            GL11.glBegin(3);
            this.glMono(0.96F, 0.5F);

            for(int s = 0; s <= arcSteps; ++s) {
               double ang = baseAngle + arcSpan * (double)s / (double)arcSteps;
               double r = currentRange + 0.06;
               GL11.glVertex3d(Math.cos(ang) * r, 0.03, Math.sin(ang) * r);
            }

            GL11.glEnd();
         }

         GL11.glPopMatrix();
         GL11.glPopAttrib();
      }

   }

   private void renderTargetMarker(Object entity, float partialTicks) {
      double[] p = MappingUtils.getInterpolatedPos(entity, partialTicks);
      double camX = MappingUtils.getRenderPosX();
      double camY = MappingUtils.getRenderPosY();
      double camZ = MappingUtils.getRenderPosZ();
      float cycleMs = 2400.0F;
      float phase = (float)(System.currentTimeMillis() % (long)cycleMs) / cycleMs;
      float pp = phase < 0.5F ? phase * 2.0F : 2.0F - phase * 2.0F;
      float eased = pp * pp * (3.0F - 2.0F * pp);
      float y = 0.08F + 1.5F * eased;
      this.pushVisualState();
      GL11.glPushMatrix();
      GL11.glTranslated(p[0] - camX, p[1] - camY, p[2] - camZ);
      float half = 0.42F;
      float arm = 0.16F;
      GL11.glLineWidth(1.4F);
      this.drawCornerBrackets(half, half, y, arm, 0.96F, 0.92F);
      GL11.glLineWidth(1.0F);
      this.drawHorizontalRing(0.0F, 0.0F, y, half * 0.58F, 0.78F, 0.55F, 24);
      GL11.glLineWidth(0.8F);
      this.drawHorizontalRing(0.0F, 0.0F, y, half * 0.14F, 0.52F, 0.45F, 16);
      GL11.glPopMatrix();
      GL11.glPopAttrib();
   }

   private void renderTracer(Object entity, float partialTicks) {
      Object player = this.getThePlayer();
      if (player != null) {
         double[] p = MappingUtils.getInterpolatedPos(player, partialTicks);
         double[] t = MappingUtils.getInterpolatedPos(entity, partialTicks);
         double camX = MappingUtils.getRenderPosX();
         double camY = MappingUtils.getRenderPosY();
         double camZ = MappingUtils.getRenderPosZ();
         double x1 = p[0];
         double y1 = p[1] + 1.62;
         double z1 = p[2];
         double x2 = t[0];
         double y2 = t[1] + 0.81;
         double z2 = t[2];
         this.pushVisualState();
         GL11.glPushMatrix();
         GL11.glTranslated(-camX, -camY, -camZ);
         GL11.glLineWidth(2.2F);
         GL11.glBegin(1);
         this.glMono(0.1F, 0.28F);
         GL11.glVertex3d(x1, y1, z1);
         GL11.glVertex3d(x2, y2, z2);
         GL11.glEnd();
         GL11.glLineWidth(1.0F);
         GL11.glBegin(1);
         this.glMono(0.96F, 0.72F);
         GL11.glVertex3d(x1, y1, z1);
         GL11.glVertex3d(x2, y2, z2);
         GL11.glEnd();
         GL11.glPopMatrix();
         GL11.glPopAttrib();
      }

   }

   private void drawCornerBrackets(float halfW, float halfD, float y, float arm, float shade, float alpha) {
      float f = arm * 0.28F;
      f = Math.min(f, arm * 0.45F);
      this.drawBracketStrip(-halfW, -halfD, y, arm, f, 1.0F, 1.0F, shade, alpha);
      this.drawBracketStrip(halfW, -halfD, y, arm, f, -1.0F, 1.0F, shade, alpha);
      this.drawBracketStrip(-halfW, halfD, y, arm, f, 1.0F, -1.0F, shade, alpha);
      this.drawBracketStrip(halfW, halfD, y, arm, f, -1.0F, -1.0F, shade, alpha);
   }

   private void drawBracketStrip(float cx, float cz, float y, float arm, float f, float sx, float sz, float shade, float alpha) {
      GL11.glBegin(3);
      this.glMono(shade, alpha);
      GL11.glVertex3d((double)(cx + sx * arm), (double)y, (double)cz);
      GL11.glVertex3d((double)(cx + sx * f), (double)y, (double)cz);
      float arcCx = cx + sx * f;
      float arcCz = cz + sz * f;
      double angleStart = sz > 0.0F ? (Math.PI * 1.5D) : (Math.PI / 2D);
      double angleEnd = sx > 0.0F ? Math.PI : (double)0.0F;
      double sweep = angleEnd - angleStart;
      if (sweep > Math.PI) {
         sweep -= (Math.PI * 2D);
      } else if (sweep < -Math.PI) {
         sweep += (Math.PI * 2D);
      }

      for(int i = 0; i <= 5; ++i) {
         double ang = angleStart + sweep * ((double)i / (double)5.0F);
         GL11.glVertex3d((double)arcCx + Math.cos(ang) * (double)f, (double)y, (double)arcCz + Math.sin(ang) * (double)f);
      }

      GL11.glVertex3d((double)cx, (double)y, (double)(cz + sz * arm));
      GL11.glEnd();
   }

   private float[] getRotationsTo(Object target) {
      Object player = MinecraftMapper.getPlayer();
      if (player != null && target != null) {
         double pX = MinecraftMapper.getPosX(player);
         double pY = MinecraftMapper.getPosY(player) + (double)MappingUtils.getEyeHeight(player);
         double pZ = MinecraftMapper.getPosZ(player);
         double tX = MinecraftMapper.getPosX(target);
         double targetHeight = (double)MappingUtils.getEyeHeight(target);
         double tZ = MinecraftMapper.getPosZ(target);
         double ap = (Double)this.aimPoint.getValue();
         double tY = MinecraftMapper.getPosY(target) + targetHeight * ap * (double)2.0F * 0.9;
         double dX = tX - pX;
         double dY = tY - pY;
         double dZ = tZ - pZ;
         double d = Math.sqrt(dX * dX + dZ * dZ);
         float yaw = (float)Math.toDegrees(Math.atan2(dZ, dX)) - 90.0F;
         float pitch = (float)(-Math.toDegrees(Math.atan2(dY, d)));
         return new float[]{yaw, pitch};
      } else {
         return null;
      }
   }

   private float smoothAngle(float current, float target, float speed) {
      float diff;
      for(diff = target - current; diff > 180.0F; diff -= 360.0F) {
      }

      while(diff < -180.0F) {
         diff += 360.0F;
      }

      float mappedSpeed;
      float noiseMultiplier;
      if (speed <= 0.5F) {
         mappedSpeed = 0.1F + (speed - 0.1F) * 2.25F;
         noiseMultiplier = 1.0F;
      } else {
         mappedSpeed = 1.0F;
         noiseMultiplier = 1.0F - (speed - 0.5F) / 0.5F;
      }

      float step = diff * mappedSpeed;
      if (noiseMultiplier > 0.0F) {
         step += (float)(this.random.nextGaussian() * 0.4 * (double)noiseMultiplier);
      }

      return current + step;
   }

   private static float snapToGCD(float delta, float gcd) {
      return (float)Math.round(delta / gcd) * gcd;
   }

   private float getGCDFix() {
      float sensitivity = 0.5F;
      float f = sensitivity * 0.6F + 0.2F;
      return f * f * f * 1.2F;
   }

   private static float angleDiff(float a, float b) {
      float diff = Math.abs(a - b) % 360.0F;
      return diff > 180.0F ? 360.0F - diff : diff;
   }
   private boolean applyRotation(Object target) {
      if (!(Boolean)this.rotationEnabled.getValue()) {
         return true;
      } else {
         float[] rotations = this.getRotationsTo(target);
         if (rotations == null) {
            return true;
         } else {
            float targetYaw = rotations[0];
            float targetPitch = rotations[1];
            if (targetPitch > 90.0F) {
               targetPitch = 90.0F;
            }

            if (targetPitch < -90.0F) {
               targetPitch = -90.0F;
            }

            if (!this.rotationInitialized) {
               Object player = MinecraftMapper.getPlayer();
               if (player != null) {
                  try {
                     Field yawF = MappingUtils.getField("Entity.rotationYaw");
                     if (yawF != null) {
                        yawF.setAccessible(true);
                        this.lastYaw = yawF.getFloat(player);
                     }

                     Field pitchF = MappingUtils.getField("Entity.rotationPitch");
                     if (pitchF != null) {
                        pitchF.setAccessible(true);
                        this.lastPitch = pitchF.getFloat(player);
                     }
                  } catch (Throwable var9) {
                  }
               }

               this.rotationInitialized = true;
            }

            float speed = ((Double)this.rotationSpeed.getValue()).floatValue();
            float smoothYaw = this.smoothAngle(this.lastYaw, targetYaw, speed);
            float smoothPitch = this.smoothAngle(this.lastPitch, targetPitch, speed);

            float gcd = this.getGCDFix();
            float deltaYaw = smoothYaw - this.lastYaw;
            float deltaPitch = smoothPitch - this.lastPitch;
            smoothYaw = this.lastYaw + snapToGCD(deltaYaw, gcd);
            smoothPitch = this.lastPitch + snapToGCD(deltaPitch, gcd);

            this.lastYaw = smoothYaw;
            this.lastPitch = smoothPitch;
            boolean silent = "Silent".equals(this.rotationMode.getValue());
            if (silent) {
               this.sendSilentRotation(smoothYaw, smoothPitch);
            } else {
               this.setPlayerRotation(smoothYaw, smoothPitch);
            }

            return true;
         }
      }
   }

   private void setPlayerRotation(float yaw, float pitch) {
      try {
         Object player = MinecraftMapper.getPlayer();
         if (player == null) {
            return;
         }

         Field yawF = MappingUtils.getField("Entity.rotationYaw");
         Field pitchF = MappingUtils.getField("Entity.rotationPitch");
         if (yawF != null) {
            yawF.setAccessible(true);
            yawF.setFloat(player, yaw);
         }

         if (pitchF != null) {
            pitchF.setAccessible(true);
            pitchF.setFloat(player, pitch);
         }
      } catch (Throwable var6) {
      }

   }

   private void sendSilentRotation(float yaw, float pitch) {
      try {
         Class<?> c05 = MappingUtils.get("C05PacketPlayerLook");
         if (c05 != null) {
            Object player = MinecraftMapper.getPlayer();
            boolean onGround = true;

            try {
               Field f = MappingUtils.getField("Entity.onGround");
               if (f != null) {
                  f.setAccessible(true);
                  onGround = f.getBoolean(player);
               }
            } catch (Throwable var11) {
            }

            Object packet = c05.getConstructor(Float.TYPE, Float.TYPE, Boolean.TYPE).newInstance(yaw, pitch, onGround);
            this.sendPacket(packet);
            return;
         }

         Class<?> c03 = MappingUtils.get("C03PacketPlayer");
         if (c03 != null) {
            Object packet = c03.getConstructor().newInstance();
            Field yawF = MappingUtils.getField("C03PacketPlayer.yaw");
            Field pitchF = MappingUtils.getField("C03PacketPlayer.pitch");
            Field groundF = MappingUtils.getField("C03PacketPlayer.onGround");
            if (yawF != null && pitchF != null) {
               yawF.setAccessible(true);
               pitchF.setAccessible(true);
               yawF.setFloat(packet, yaw);
               pitchF.setFloat(packet, pitch);
               if (groundF != null) {
                  groundF.setAccessible(true);
                  Object player = MinecraftMapper.getPlayer();

                  try {
                     Field f = MappingUtils.getField("Entity.onGround");
                     if (f != null) {
                        f.setAccessible(true);
                        groundF.setBoolean(packet, f.getBoolean(player));
                     }
                  } catch (Throwable var12) {
                  }
               }

               this.sendPacket(packet);
            }
         }
      } catch (Throwable var13) {
      }

   }

   private void sendPacket(Object packet) {
      try {
         Object player = MinecraftMapper.getPlayer();
         if (player == null) {
            return;
         }

         Field sendQueueField = MappingUtils.getField("EntityPlayerSP.sendQueue");
         if (sendQueueField != null) {
            sendQueueField.setAccessible(true);
            Object netHandler = sendQueueField.get(player);
            Method sendPacket = MappingUtils.getMethod("NetHandlerPlayClient.sendPacket");
            if (packet != null && netHandler != null && sendPacket != null) {
               sendPacket.setAccessible(true);
               sendPacket.invoke(netHandler, packet);
            }
         }
      } catch (Throwable var6) {
      }

   }

   private boolean isOnGround(Object player) {
      try {
         Field f = MappingUtils.getField("Entity.onGround");
         if (f != null) {
            f.setAccessible(true);
            return f.getBoolean(player);
         }
      } catch (Throwable var3) {
      }
      return true;
   }

   private void setMotionY(double motionY) {
      try {
         Object player = MinecraftMapper.getPlayer();
         if (player != null) {
            Field f = MappingUtils.getField("Entity.motionY");
            if (f != null) {
               f.setAccessible(true);
               f.setDouble(player, motionY);
            }
         }
      } catch (Throwable var5) {
      }
   }
}
