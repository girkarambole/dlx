/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  io.netty.buffer.Unpooled
 *  io.netty.channel.Channel
 *  org.lwjgl.input.Mouse
 */
package me.ries.module.impl;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import me.ries.Ries;
import me.ries.chat.RiesChatManager;
import me.ries.event.EventListener;
import me.ries.event.PacketReceiveEvent;
import me.ries.event.PacketSendEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.MassacreChatModule;
import me.ries.setting.BooleanOption;
import me.ries.util.ChatUtils;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;

public class FriendManagerModule
extends Module {
    public static final Set<String> friends = Collections.synchronizedSet(new HashSet());
    private final BooleanOption chatCommands = new BooleanOption("ChatCommands", true, (Module)this);
    private final BooleanOption mcf = new BooleanOption("MCF", false, (Module)this);
    private EventListener chatListener;
    private boolean wasMiddleDown = false;
    private long lastMcfTime = 0L;
    private static final long MCF_COOLDOWN_MS = 500L;
    private static String pendingTeleportNick = null;
    private static long teleportRequestTime = 0L;

    public FriendManagerModule() {
        super("FriendManager", "Friend list manager", Category.MOD, 0);
        this.chatCommands.setGroup("Features");
        this.mcf.setGroup("Features");
        this.addOptions(this.chatCommands, this.mcf);
    }

    @Override
    public boolean isHidden() {
        return true;
    }

    @Override
    public void onEnable() {
        try {
            Module module = Ries.getInstance().getModuleManager().getModule("TargetManager");
            if (module != null && module.isEnabled()) {
                module.disable();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        this.chatListener = event -> {
            if (((Boolean)this.chatCommands.getValue()).booleanValue()) {
                Object object = null;
                boolean bl = event instanceof PacketReceiveEvent;
                boolean bl2 = event instanceof PacketSendEvent;
                if (bl) {
                    object = ((PacketReceiveEvent)event).getPacket();
                } else if (bl2) {
                    object = ((PacketSendEvent)event).getPacket();
                }
                if (object != null) {
                    Class<?> clazz;
                    AccessibleObject accessibleObject;
                    Class<?> clazz2;
                    if (bl && pendingTeleportNick != null) {
                        if (System.currentTimeMillis() - teleportRequestTime > 3000L) {
                            pendingTeleportNick = null;
                        } else {
                            clazz2 = MappingUtils.get("S02PacketChat");
                            if (clazz2 != null && clazz2.isInstance(object)) {
                                try {
                                    Object object2;
                                    String string = "";
                                    Method method = MappingUtils.getMethod("S02PacketChat.getChatComponent");
                                    if (method != null && (object2 = method.invoke(object, new Object[0])) != null && (accessibleObject = MappingUtils.getMethod("IChatComponent.getUnformattedText")) != null) {
                                        string = (String)((Method)accessibleObject).invoke(object2, new Object[0]);
                                    }
                                    if (string != null && (string.contains("zaten arkada\u00c3\u2026\u00c5\u00b8\u00c3\u201e\u00c2\u00b1n") || string.contains("zaten arkadasin") || string.contains("Arkada\u00c3\u2026\u00c5\u00b8l\u00c3\u201e\u00c2\u00b1k iste\u00c3\u201e\u00c5\u00b8i g\u00c3\u0192\u00c2\u00b6nderildi") || string.contains("istegi gonderildi"))) {
                                        FriendManagerModule.sendChatPacket("/ark git " + pendingTeleportNick);
                                        pendingTeleportNick = null;
                                    }
                                }
                                catch (Throwable throwable) {
                                    // empty catch block
                                }
                            }
                        }
                    }
                    if ((clazz = MappingUtils.get("C01PacketChatMessage")) != null && clazz.isInstance(object)) {
                        String chatMessageText = null;
                        try {
                            Method getMessageMethod = MappingUtils.getMethod("C01PacketChatMessage.getMessage");
                            if (getMessageMethod != null) {
                                getMessageMethod.setAccessible(true);
                                chatMessageText = (String)getMessageMethod.invoke(object, new Object[0]);
                            }
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                        if (chatMessageText == null) {
                            try {
                                Field messageField = MappingUtils.getField("C01PacketChatMessage.message");
                                if (messageField != null) {
                                    messageField.setAccessible(true);
                                    chatMessageText = (String)messageField.get(object);
                                }
                            }
                            catch (Throwable throwable) {
                                // empty catch block
                            }
                        }
                        if (chatMessageText != null && chatMessageText.startsWith(".")) {
                            event.cancel();
                            if (chatMessageText.startsWith(".friend")) {
                                String[] args = chatMessageText.trim().split("\\s+");
                                this.handleFriendCommand(args);
                            }
                        }
                    }
                }
            }
        };
        try {
            Ries.getInstance().getEventBus().subscribe(PacketSendEvent.class, this.chatListener);
            Ries.getInstance().getEventBus().subscribe(PacketReceiveEvent.class, this.chatListener);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        Logger.info("[FriendManager] enabled, friends=" + friends.size());
    }

    @Override
    public void onDisable() {
        if (this.chatListener != null) {
            try {
                Ries.getInstance().getEventBus().unsubscribe(PacketSendEvent.class, this.chatListener);
                Ries.getInstance().getEventBus().unsubscribe(PacketReceiveEvent.class, this.chatListener);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            this.chatListener = null;
        }
    }

    @Override
    public void onUpdate() {
        if (((Boolean)this.mcf.getValue()).booleanValue() && this.getCurrentScreen() == null) {
            long l;
            boolean bl = false;
            try {
                bl = Mouse.isButtonDown((int)2);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (bl && !this.wasMiddleDown && (l = System.currentTimeMillis()) - this.lastMcfTime >= 500L) {
                this.lastMcfTime = l;
                this.handleMcf();
            }
            this.wasMiddleDown = bl;
        }
    }

    private static void sendChatPacket(String string) {
        try {
            io.netty.channel.Channel channel = MinecraftMapper.getNetworkChannel();
            if (channel == null) {
                return;
            }
            io.netty.buffer.ByteBuf byteBuf = io.netty.buffer.Unpooled.buffer();
            byteBuf.writeByte(1);
            byte[] byArray = string.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            int n = byArray.length;
            while ((n & 0xFFFFFF80) != 0) {
                byteBuf.writeByte(n & 0x7F | 0x80);
                n >>>= 7;
            }
            byteBuf.writeByte(n);
            byteBuf.writeBytes(byArray);
            channel.writeAndFlush((Object)byteBuf);
        }
        catch (Exception exception) {
            Logger.warn("Isinlanma basarisiz");
        }
    }

    public static boolean isFriend(String string) {
        if (string == null) {
            return false;
        }
        String string2 = string.replaceAll("\u00a7.", "").trim();
        String string3 = string2.toLowerCase();
        try {
            MassacreChatModule massacreChatModule = Ries.getInstance().getModuleManager().getModule(MassacreChatModule.class);
            if (massacreChatModule != null && massacreChatModule.isEnabled() && massacreChatModule.getAutoFriendValue() && RiesChatManager.activeRiesUsers.contains(string3)) {
                return true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return friends.contains(string2) || friends.contains(string3);
    }

    public static boolean isFriend(Object object) {
        return object == null ? false : FriendManagerModule.isFriend(MinecraftMapper.getName(object));
    }

    public static boolean isEclipseUser(String string) {
        return false;
    }

    public static boolean isEclipseUser(Object object) {
        return object == null ? false : FriendManagerModule.isEclipseUser(MinecraftMapper.getName(object));
    }

    private void handleFriendCommand(String[] stringArray) {
        if (stringArray.length < 2) {
            FriendManagerModule.sendHelp();
        } else {
            switch (stringArray[1].toLowerCase()) {
                case "add": {
                    if (stringArray.length < 3) {
                        ChatUtils.addChatMessage("\u00a7cUsage: .friend add <name>");
                        break;
                    }
                    FriendManagerModule.addFriend(stringArray[2]);
                    break;
                }
                case "remove": 
                case "rm": {
                    if (stringArray.length < 3) {
                        ChatUtils.addChatMessage("\u00a7cUsage: .friend remove <name>");
                        break;
                    }
                    FriendManagerModule.removeFriend(stringArray[2]);
                    break;
                }
                case "list": {
                    FriendManagerModule.listFriends();
                    break;
                }
                default: {
                    FriendManagerModule.sendHelp();
                }
            }
        }
    }

    private static void addFriend(String string) {
        if (friends.contains(string)) {
            ChatUtils.addChatMessage("\u00a7e[Friends] \u00a7f" + string + " \u00a77is already a friend");
        } else {
            friends.add(string);
            ChatUtils.addChatMessage("\u00a77[Friends] \u00a7a+ \u00a7f" + string);
            Logger.info("[FriendManager] added: " + string);
        }
    }

    private static void removeFriend(String string) {
        if (friends.remove(string)) {
            ChatUtils.addChatMessage("\u00a77[Friends] \u00a7c- \u00a7f" + string);
            Logger.info("[FriendManager] removed: " + string);
        } else {
            ChatUtils.addChatMessage("\u00a7e[Friends] \u00a7f" + string + " \u00a77is not a friend");
        }
    }

    private static void listFriends() {
        if (friends.isEmpty()) {
            ChatUtils.addChatMessage("\u00a77[Friends] \u00a7fNo friends added yet");
        } else {
            ChatUtils.addChatMessage("\u00a77[Friends] \u00a7f(" + friends.size() + "): \u00a7a" + String.join((CharSequence)"\u00a77, \u00a7a", friends));
        }
    }

    private static void sendHelp() {
        ChatUtils.addChatMessage("\u00a77[Friends] \u00a7f.friend add/remove <name> | list");
    }

    private void handleMcf() {
        try {
            Object object = this.getEntityFromMouseOver();
            if (object == null) {
                object = this.getClosestPlayer(3.5);
            }
            if (object == null || object == this.getThePlayer()) {
                return;
            }
            String string = MinecraftMapper.getName(object);
            if (string == null || string.trim().isEmpty()) {
                return;
            }
            if (friends.contains(string = string.replaceAll("\u00a7.", "").trim())) {
                FriendManagerModule.removeFriend(string);
            } else {
                FriendManagerModule.addFriend(string);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private Object getEntityFromMouseOver() {
        try {
            Object object = this.getMinecraft();
            if (object == null) {
                return null;
            }
            Field field = MappingUtils.getField("Minecraft.objectMouseOver");
            if (field == null) {
                return null;
            }
            field.setAccessible(true);
            Object object2 = field.get(object);
            if (object2 == null) {
                return null;
            }
            Field field2 = MappingUtils.getField("MovingObjectPosition.entityHit");
            if (field2 == null) {
                return null;
            }
            field2.setAccessible(true);
            return field2.get(object2);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private Object getClosestPlayer(double d) {
        try {
            Object object = this.getThePlayer();
            if (object == null) {
                return null;
            }
            Field field = MappingUtils.getField("Entity.posX");
            Field field2 = MappingUtils.getField("Entity.posY");
            Field field3 = MappingUtils.getField("Entity.posZ");
            Field field4 = MappingUtils.getField("Entity.rotationYaw");
            Field field5 = MappingUtils.getField("Entity.rotationPitch");
            if (field != null && field2 != null && field3 != null && field4 != null) {
                field.setAccessible(true);
                field2.setAccessible(true);
                field3.setAccessible(true);
                field4.setAccessible(true);
                if (field5 != null) {
                    field5.setAccessible(true);
                }
                double d2 = field.getDouble(object);
                double d3 = field2.getDouble(object) + 1.62;
                double d4 = field3.getDouble(object);
                float f = field4.getFloat(object);
                float f2 = field5 != null ? field5.getFloat(object) : 0.0f;
                double d5 = Math.toRadians((double)f + 90.0);
                double d6 = Math.toRadians(-f2);
                double d7 = Math.cos(d6) * Math.cos(d5);
                double d8 = Math.sin(d6);
                double d9 = Math.cos(d6) * Math.sin(d5);
                double d10 = d * d;
                double d11 = 15.0;
                Object object2 = null;
                double d12 = d11;
                for (Object object3 : MinecraftMapper.getPlayerEntitiesInWorld()) {
                    double d13;
                    double d14;
                    double d15;
                    double d16;
                    double d17;
                    if (object3 == object || (d17 = (d16 = field.getDouble(object3) - d2) * d16 + (d15 = field2.getDouble(object3) + 0.9 - d3) * d15 + (d14 = field3.getDouble(object3) - d4) * d14) > d10) continue;
                    double d18 = Math.sqrt(d17);
                    if (d18 < 1.0E-9) continue;
                    double d19 = (d16 * d7 + d15 * d8 + d14 * d9) / d18;
                    double d20 = Math.toDegrees(Math.acos(d19 = Math.max(-1.0, Math.min(1.0, d19))));
                    if (!(d20 < d12)) continue;
                    d12 = d20;
                    object2 = object3;
                }
                return object2;
            }
            return null;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private Object getCurrentScreen() {
        try {
            Object object = this.getMinecraft();
            if (object == null) {
                return null;
            }
            Field field = MappingUtils.getField("Minecraft.currentScreen");
            if (field == null) {
                return null;
            }
            field.setAccessible(true);
            return field.get(object);
        }
        catch (Throwable throwable) {
            return null;
        }
    }
}

