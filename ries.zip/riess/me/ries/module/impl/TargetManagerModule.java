package me.ries.module.impl;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import me.ries.Ries;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.TextOption;
import me.ries.util.ChatUtils;
import me.ries.util.Logger;
import me.ries.mapping.MinecraftMapper;

public class TargetManagerModule extends Module {
    public static final Set<String> targets = Collections.synchronizedSet(new HashSet<String>());
    private final TextOption targetName = new TextOption("Target Name", "", (Module)this);

    public TargetManagerModule() {
        super("TargetManager", "Forces combat modules to only target specific players", Category.MOD, 0);
        this.addOptions(this.targetName);
    }

    @Override
    public boolean isHidden() {
        return true;
    }

    @Override
    public void onEnable() {
        try {
            Module module = Ries.getInstance().getModuleManager().getModule("FriendManager");
            if (module != null && module.isEnabled()) {
                module.disable();
            }
        } catch (Throwable throwable) {
            // empty catch block
        }
        Logger.info("[TargetManager] enabled, targets=" + targets.size());
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
    }

    public static boolean isTarget(String name) {
        if (name == null) {
            return false;
        }
        String string2 = name.replaceAll("§.", "").trim().toLowerCase();
        return targets.contains(string2);
    }

    public static boolean isTarget(Object object) {
        return object == null ? false : TargetManagerModule.isTarget(MinecraftMapper.getName(object));
    }

    public String getTargetName() {
        // Sync targets set to comma-separated string for compatibility with options
        return String.join(",", targets);
    }

    public void setTargetName(String string) {
        this.targetName.setText(string);
        targets.clear();
        if (string != null && !string.trim().isEmpty()) {
            for (String t : string.split(",")) {
                String tt = t.trim().toLowerCase();
                if (!tt.isEmpty()) {
                    targets.add(tt);
                }
            }
        }
    }

    public void handleTargetCommand(String[] stringArray) {
        if (stringArray.length < 2) {
            TargetManagerModule.sendHelp();
            return;
        }
        switch (stringArray[1].toLowerCase()) {
            case "add": {
                if (stringArray.length < 3) {
                    ChatUtils.addChatMessage("§cUsage: .target add <name>");
                    break;
                }
                TargetManagerModule.addTarget(stringArray[2]);
                break;
            }
            case "remove": 
            case "rm": 
            case "delete": 
            case "del": {
                if (stringArray.length < 3) {
                    ChatUtils.addChatMessage("§cUsage: .target remove <name>");
                    break;
                }
                TargetManagerModule.removeTarget(stringArray[2]);
                break;
            }
            case "list": {
                TargetManagerModule.listTargets();
                break;
            }
            case "clear": 
            case "reset": 
            case "sifirla": 
            case "sıfırla": {
                targets.clear();
                this.targetName.setText("");
                ChatUtils.addChatMessage("§a[TargetManager] §fTarget list cleared.");
                break;
            }
            default: {
                TargetManagerModule.sendHelp();
            }
        }
    }

    public static void addTarget(String string) {
        String lower = string.toLowerCase();
        if (targets.contains(lower)) {
            ChatUtils.addChatMessage("§e[TargetManager] §f" + string + " §7is already a target");
        } else {
            targets.add(lower);
            // Update TextOption representation too
            TargetManagerModule targetMod = Ries.getInstance().getModuleManager().getModule(TargetManagerModule.class);
            if (targetMod != null) {
                targetMod.targetName.setText(String.join(",", targets));
            }
            ChatUtils.addChatMessage("§7[TargetManager] §a+ §f" + string);
            Logger.info("[TargetManager] added: " + string);
        }
    }

    public static void removeTarget(String string) {
        String lower = string.toLowerCase();
        if (targets.remove(lower)) {
            TargetManagerModule targetMod = Ries.getInstance().getModuleManager().getModule(TargetManagerModule.class);
            if (targetMod != null) {
                targetMod.targetName.setText(String.join(",", targets));
            }
            ChatUtils.addChatMessage("§7[TargetManager] §c- §f" + string);
            Logger.info("[TargetManager] removed: " + string);
        } else {
            ChatUtils.addChatMessage("§e[TargetManager] §f" + string + " §7is not a target");
        }
    }

    private static void listTargets() {
        if (targets.isEmpty()) {
            ChatUtils.addChatMessage("§7[TargetManager] §fNo targets added yet");
        } else {
            ChatUtils.addChatMessage("§7[TargetManager] §f(" + targets.size() + "): §a" + String.join("§7, §a", targets));
        }
    }

    private static void sendHelp() {
        ChatUtils.addChatMessage("§7[TargetManager] §f.target add/remove <name> | list | clear");
    }
}
