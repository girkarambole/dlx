package me.ries.module.impl;

import me.ries.Ries;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.util.Logger;

public class DeveloperModeModule extends Module {
    public DeveloperModeModule() {
        super("DeveloperMode", "Hides or shows advanced option controls", Category.MOD, 0);
    }

    @Override
    public void onEnable() {
        Logger.info("DeveloperMode enabled - all options visible");
    }

    @Override
    public void onDisable() {
        Logger.info("DeveloperMode disabled - advanced options hidden and enforced");
    }

    @Override
    public void onUpdate() {
    }

    public static boolean isDevModeActive() {
        try {
            DeveloperModeModule mod = Ries.getInstance().getModuleManager().getModule(DeveloperModeModule.class);
            return mod != null && mod.isEnabled();
        } catch (Throwable t) {
            return false;
        }
    }
}
