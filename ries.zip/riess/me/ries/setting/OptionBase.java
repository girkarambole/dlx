/*
 * Decompiled with CFR 0.152.
 */
package me.ries.setting;

import me.ries.module.Module;

public abstract class OptionBase<T> {
    private final String name;
    private final T defaultValue;
    private final Module module;
    private String group = "";
    private String dependency = "";
    protected T value;

    protected OptionBase(String name, T defaultValue, Module module) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
        this.module = module;
    }

    public String getName() {
        return this.name;
    }

    public T getValue() {
        if (!me.ries.module.impl.DeveloperModeModule.isDevModeActive()) {
            String modName = this.module != null ? this.module.getName() : "";
            String optName = this.name != null ? this.name : "";
            
            if (modName.equalsIgnoreCase("KillAura")) {
                if (optName.equalsIgnoreCase("KeepSprint")) return (T) "On";
                if (optName.equalsIgnoreCase("AttackMode")) return (T) "Single";
                if (optName.equalsIgnoreCase("TargetLock")) return (T) "On";
                if (optName.equalsIgnoreCase("RangeCircle")) return (T) Boolean.FALSE;
                if (optName.equalsIgnoreCase("TargetMarker")) return (T) Boolean.FALSE;
                if (optName.equalsIgnoreCase("Tracer")) return (T) Boolean.FALSE;
                if (optName.equalsIgnoreCase("Raytrace")) return (T) Boolean.TRUE;
                if (optName.equalsIgnoreCase("FOV")) return (T) Double.valueOf(360.0);
                if (optName.equalsIgnoreCase("RotSpeed")) return (T) Double.valueOf(1.0);
                if (optName.equalsIgnoreCase("AimPoint")) return this.defaultValue;
            } else if (modName.equalsIgnoreCase("Reach")) {
                if (optName.equalsIgnoreCase("WallCheck")) return (T) Boolean.TRUE;
                if (optName.equalsIgnoreCase("Range Jitter")) return (T) Double.valueOf(0.0);
                if (optName.equalsIgnoreCase("DynamicChance")) return (T) Boolean.FALSE;
                if (optName.equalsIgnoreCase("AutoRange")) return (T) Boolean.FALSE;
            } else if (modName.equalsIgnoreCase("TPAura")) {
                if (optName.equalsIgnoreCase("HeadRide")) return (T) Boolean.TRUE;
                if (optName.equalsIgnoreCase("RangeCircle")) return (T) Boolean.FALSE;
                if (optName.equalsIgnoreCase("TargetMarker")) return (T) Boolean.FALSE;
                if (optName.equalsIgnoreCase("Tracer")) return (T) Boolean.FALSE;
                if (optName.equalsIgnoreCase("RotSpeed")) return (T) Double.valueOf(1.0);
                if (optName.equalsIgnoreCase("AimPoint")) return this.defaultValue;
                if (optName.equalsIgnoreCase("TargetLock")) return (T) "On";
            } else if (modName.equalsIgnoreCase("Fly")) {
                if (optName.equalsIgnoreCase("Packet Hold")) return (T) Boolean.TRUE;
            }
        }
        return this.value;
    }

    public boolean isVisible() {
        if (me.ries.module.impl.DeveloperModeModule.isDevModeActive()) {
            return true;
        }
        String modName = this.module != null ? this.module.getName() : "";
        String optName = this.name != null ? this.name : "";
        
        if (modName.equalsIgnoreCase("KillAura")) {
            if (optName.equalsIgnoreCase("KeepSprint") ||
                optName.equalsIgnoreCase("AttackMode") ||
                optName.equalsIgnoreCase("TargetLock") ||
                optName.equalsIgnoreCase("RangeCircle") ||
                optName.equalsIgnoreCase("TargetMarker") ||
                optName.equalsIgnoreCase("Tracer") ||
                optName.equalsIgnoreCase("Raytrace") ||
                optName.equalsIgnoreCase("FOV") ||
                optName.equalsIgnoreCase("RotSpeed") ||
                optName.equalsIgnoreCase("AimPoint")) {
                return false;
            }
        } else if (modName.equalsIgnoreCase("Reach")) {
            if (optName.equalsIgnoreCase("WallCheck") ||
                optName.equalsIgnoreCase("Range Jitter") ||
                optName.equalsIgnoreCase("Reach FOV") ||
                optName.equalsIgnoreCase("DynamicChance") ||
                optName.equalsIgnoreCase("AutoRange")) {
                return false;
            }
        } else if (modName.equalsIgnoreCase("Hitbox")) {
            if (optName.equalsIgnoreCase("CageDistance") ||
                optName.equalsIgnoreCase("CageAlpha") ||
                optName.equalsIgnoreCase("CageThickness")) {
                return false;
            }
        } else if (modName.equalsIgnoreCase("TPAura")) {
            if (optName.equalsIgnoreCase("Spin Radius") ||
                optName.equalsIgnoreCase("Spin Speed") ||
                optName.equalsIgnoreCase("HeadRide") ||
                optName.equalsIgnoreCase("RangeCircle") ||
                optName.equalsIgnoreCase("TargetMarker") ||
                optName.equalsIgnoreCase("Tracer") ||
                optName.equalsIgnoreCase("RotSpeed") ||
                optName.equalsIgnoreCase("AimPoint") ||
                optName.equalsIgnoreCase("TargetLock")) {
                return false;
            }
        } else if (modName.equalsIgnoreCase("Fly")) {
            if (optName.equalsIgnoreCase("Packet Hold") ||
                optName.equalsIgnoreCase("Hold Duration") ||
                optName.equalsIgnoreCase("Teleport Speed")) {
                return false;
            }
        }
        return true;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public T getDefaultValue() {
        return this.defaultValue;
    }

    public Module getModule() {
        return this.module;
    }

    public String getGroup() {
        return this.group;
    }

    public OptionBase<T> setGroup(String group) {
        this.group = group == null ? "" : group;
        return this;
    }

    public String getDependency() {
        return this.dependency;
    }

    public OptionBase<T> setDependency(String dependency) {
        this.dependency = dependency == null ? "" : dependency;
        return this;
    }

    public Object toConfigValue() {
        return this.value;
    }

    public abstract void fromConfigValue(Object var1);
}

