/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.ries.module.impl.ClickGuiModule
 *  me.ries.notification.Notification$Type
 *  me.ries.ui.ClickGui
 *  me.ries.util.FontUtil
 *  me.ries.util.GaussianBlur
 *  me.ries.util.RoundedUtil
 *  me.ries.util.ScissorUtil
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package me.ries.notification;

import java.awt.Color;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import me.ries.module.impl.ClickGuiModule;
import me.ries.notification.Notification;
import me.ries.ui.ClickGui;
import me.ries.util.FontUtil;
import me.ries.util.GaussianBlur;
import me.ries.util.RoundedUtil;
import me.ries.util.ScissorUtil;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class NotificationManager {
    private static final int MAX_STACK = 4;
    private static final long DURATION_MS = 2400L;
    private static final Color BG = new Color(0, 0, 0);
    private static final Color C_TITLE = new Color(237, 237, 237);
    private static final Color C_MSG = new Color(135, 135, 135);
    private static final float MIN_W = 90.0f;
    private static final float RADIUS = 6.0f;
    private static final float MAR_R = 10.0f;
    private static final float MAR_B = 10.0f;
    private static final float GAP = 2.0f;
    private static final float PAD_X = 8.0f;
    private static final float PAD_Y = 6.0f;
    private static final float T_SCALE = 0.5f;
    private static final float M_SCALE = 0.45f;
    public static float posX = -1.0f;
    public static float posY = -1.0f;
    private static boolean isDragging = false;
    private static float dragOffX = 0.0f;
    private static float dragOffY = 0.0f;
    private static final Deque<Entry> queue = new ConcurrentLinkedDeque<Entry>();
    private static final Map<String, Float> sm = new ConcurrentHashMap<String, Float>();
    private static final Object LOCK = new Object();
    private static long seq = 0L;
    private static Entry previewEntry = null;

    private static float getH(Notification notification) {
        if (notification != null && (notification.getTitle().equalsIgnoreCase("Module") || notification.getTitle().isEmpty())) {
            return 16.0f;
        }
        return 12.0f + (float)FontUtil.getFontHeight() * 0.5f + 1.0f + (float)FontUtil.getFontHeight() * 0.45f;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void post(String string, String string2, Notification.Type type, long l) {
        Object object;
        Object object2 = object = LOCK;
        synchronized (object2) {
            while (queue.size() >= 4) {
                queue.pollFirst();
            }
            queue.addLast(new Entry(seq++, new Notification(string, string2, type, l)));
        }
    }

    public static void info(String string, String string2) {
        NotificationManager.post(string, string2, Notification.Type.INFO, 2400L);
    }

    public static void info(String string, String string2, long l) {
        NotificationManager.post(string, string2, Notification.Type.INFO, l);
    }

    public static void postModule(String string, boolean bl) {
        try {
            if (ClickGuiModule.moduleAlerts != null && !((Boolean)ClickGuiModule.moduleAlerts.getValue()).booleanValue()) {
                return;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        NotificationManager.post("Module", string + (bl ? " has enabled" : " has disabled"), bl ? Notification.Type.ENABLED : Notification.Type.DISABLED, 2400L);
    }

    public static Notification getCurrentNotification() {
        return queue.isEmpty() ? null : NotificationManager.queue.peekLast().n;
    }

    public static void resetDragState() {
        isDragging = false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void render() {
        Serializable serializable;
        Object object;
        boolean bl = ClickGui.isUiEditMode();
        Object object2 = object = LOCK;
        synchronized (object2) {
            Iterator<Entry> iterator = queue.iterator();
            while (iterator.hasNext()) {
                Entry entry = iterator.next();
                if (!entry.n.isFinished() || !(NotificationManager.anim(((StringBuilder)(serializable = new StringBuilder())).append("a").append(entry.id).toString(), 0.0f) < 0.02f)) continue;
                sm.remove("a" + entry.id);
                sm.remove("s" + entry.id);
                sm.remove("y" + entry.id);
                iterator.remove();
            }
        }
        if (bl && queue.isEmpty() && previewEntry == null) {
            previewEntry = new Entry(seq++, new Notification("Geist Toast", "Drag to reposition", Notification.Type.INFO, Long.MAX_VALUE));
        }
        if (!bl) {
            previewEntry = null;
        }
        boolean bl2 = !queue.isEmpty() || previewEntry != null;
        boolean bl3 = bl2;
        if (bl2) {
            int n = ScissorUtil.getScaledWidth();
            int n2 = ScissorUtil.getScaledHeight();
            if (n > 0 && n2 > 0) {
                if (bl && queue.isEmpty() && previewEntry != null) {
                    serializable = new ArrayList();
                    ((ArrayList)serializable).add(previewEntry);
                } else {
                    serializable = new ArrayList<Entry>(queue);
                }
                int n3 = ((ArrayList)serializable).size();
                if (n3 != 0) {
                    float f = posX < 0.0f ? (float)n + posX : posX;
                    float f2 = posY < 0.0f ? (float)n2 + posY : posY;
                    float f3 = f2;
                    if (bl && !Mouse.isGrabbed()) {
                        NotificationManager.handleDrag(f, f2, n, n2, (List<Entry>)((Object)serializable));
                        f = posX < 0.0f ? (float)n + posX : posX;
                        f2 = posY < 0.0f ? (float)n2 + posY : posY;
                    }
                    GL11.glPushAttrib((int)1048575);
                    GL11.glMatrixMode((int)5889);
                    GL11.glPushMatrix();
                    GL11.glLoadIdentity();
                    GL11.glOrtho((double)0.0, (double)n, (double)n2, (double)0.0, (double)-1000.0, (double)1000.0);
                    GL11.glMatrixMode((int)5888);
                    GL11.glPushMatrix();
                    GL11.glLoadIdentity();
                    GL11.glDisable((int)3553);
                    GL11.glEnable((int)3042);
                    GL11.glBlendFunc((int)770, (int)771);
                    GL11.glDisable((int)2929);
                    GL11.glDisable((int)2896);
                    GL11.glDisable((int)3008);
                    GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                    try {
                        int n4;
                        float f4 = f2;
                        float[] fArray = new float[n3];
                        for (n4 = n3 - 1; n4 >= 0; --n4) {
                            Entry entry = (Entry)((ArrayList)serializable).get(n4);
                            float f5 = NotificationManager.getH(entry.n);
                            fArray[n4] = f4 -= f5;
                            f4 -= 2.0f;
                        }
                        for (n4 = 0; n4 < n3; ++n4) {
                            float f6;
                            Entry entry = (Entry)((ArrayList)serializable).get(n4);
                            int n5 = n3 - 1 - n4;
                            boolean bl4 = entry == previewEntry;
                            boolean bl5 = !bl4 && entry.n.isFinished();
                            boolean bl6 = bl5;
                            float f7 = bl4 ? 1.0f : (f6 = NotificationManager.anim("a" + entry.id, bl5 ? 0.0f : 1.0f, bl5 ? 0.14f : 0.17f));
                            if (f6 < 0.01f && bl5) continue;
                            float f8 = NotificationManager.easeOut(f6);
                            float f9 = bl4 ? 1.0f : NotificationManager.anim("s" + entry.id, (float)Math.pow(0.93f, n5), 0.15f);
                            float f10 = fArray[n4];
                            if (!bl4) {
                                if (!sm.containsKey("y" + entry.id)) {
                                    sm.put("y" + entry.id, Float.valueOf(f10));
                                }
                                f10 = NotificationManager.anim("y" + entry.id, f10, 0.16f);
                            }
                            float f11 = NotificationManager.calcW(entry);
                            float f12 = bl4 ? 0.0f : (1.0f - f8) * (f11 + 10.0f + 8.0f);
                            float f13 = f - f11 + f12;
                            float f14 = (float)Math.pow(0.75, n5);
                            float f15 = bl4 ? 1.0f : f8 * f14;
                            NotificationManager.drawToast(entry, f13, f10, f11, f9, f15, bl && bl4);
                        }
                    }
                    finally {
                        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                        GL11.glMatrixMode((int)5889);
                        GL11.glPopMatrix();
                        GL11.glMatrixMode((int)5888);
                        GL11.glPopMatrix();
                        GL11.glPopAttrib();
                        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                    }
                }
            }
        }
    }

    private static void drawToast(Entry entry, float f, float f2, float f3, float f4, float f5, boolean bl) {
        int n;
        float f6;
        float f7;
        float f8;
        float f9;
        float f10 = NotificationManager.getH(entry.n);
        boolean bl2 = entry.n.getTitle().equalsIgnoreCase("Module") || entry.n.getTitle().isEmpty();
        float f11 = bl2 ? 8.0f : 6.0f;
        float f12 = f + f3 * 0.5f;
        float f13 = f2 + f10 * 0.5f;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)f12, (float)f13, (float)0.0f);
        GL11.glScalef((float)f4, (float)f4, (float)1.0f);
        GL11.glTranslatef((float)(-f12), (float)(-f13), (float)0.0f);
        float f14 = 8.0f;
        int n2 = 90;
        try {
            if (ClickGuiModule.notifBlur != null) {
                f14 = ((Double)ClickGuiModule.notifBlur.getValue()).floatValue();
            }
            if (ClickGuiModule.notifAlpha != null) {
                n2 = (int)(((Double)ClickGuiModule.notifAlpha.getValue()).floatValue() * 255.0f);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (f14 > 0.0f) {
            GaussianBlur.renderBlurRounded((float)f, (float)f2, (float)f3, (float)f10, (float)f11, (float)(f14 * f5));
        }
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RoundedUtil.roundedRect((double)f, (double)f2, (double)f3, (double)f10, (double)f11, (Color)new Color(BG.getRed(), BG.getGreen(), BG.getBlue(), (int)((float)n2 * f5)));
        GL11.glDisable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        int n3 = bl ? new Color(0, 144, 255, (int)(255.0f * f5)).getRGB() : new Color(255, 255, 255, (int)(20.0f * f5)).getRGB();
        RoundedUtil.drawRoundOutline((float)f, (float)f2, (float)f3, (float)f10, (float)f11, (float)1.0f, (int)n3);
        GL11.glDisable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        float f15 = bl2 ? 10.0f : 14.0f;
        float f16 = f15 / 2.0f;
        float f17 = bl2 ? f + 10.0f : f + 8.0f + f16;
        float f18 = f2 + f10 * 0.5f;
        if (bl2) {
            if (entry.n.getType() == Notification.Type.ENABLED) {
                NotificationManager.drawCheckmark(f17, f18, f15, new Color(80, 220, 100, (int)(220.0f * f5)));
            } else if (entry.n.getType() == Notification.Type.DISABLED) {
                NotificationManager.drawCross(f17, f18, f15, new Color(220, 60, 60, (int)(220.0f * f5)));
            } else {
                NotificationManager.drawInfoIcon(f17, f18, new Color(100, 180, 255, (int)(220.0f * f5)));
            }
        } else if (entry.n.getType() == Notification.Type.ENABLED) {
            NotificationManager.drawCircle(f17, f18, f16, new Color(255, 255, 255, (int)(120.0f * f5)));
            NotificationManager.drawCheckmark(f17, f18, f15, new Color(255, 255, 255, (int)(220.0f * f5)));
        } else if (entry.n.getType() == Notification.Type.DISABLED) {
            NotificationManager.drawFilledCircle(f17, f18, f16, new Color(220, 60, 60, (int)(45.0f * f5)));
            NotificationManager.drawCircle(f17, f18, f16, new Color(220, 60, 60, (int)(180.0f * f5)));
            NotificationManager.drawCross(f17, f18, f15, new Color(220, 60, 60, (int)(220.0f * f5)));
        } else {
            NotificationManager.drawCircle(f17, f18, f16, new Color(100, 180, 255, (int)(120.0f * f5)));
            NotificationManager.drawInfoIcon(f17, f18, new Color(100, 180, 255, (int)(220.0f * f5)));
        }
        if (bl2) {
            f9 = f + 22.0f;
            f8 = FontUtil.getFontHeight();
            f7 = 0.48f;
            f6 = f2 + (f10 - f8 * f7) * 0.5f - 0.5f;
            n = new Color(C_TITLE.getRed(), C_TITLE.getGreen(), C_TITLE.getBlue(), (int)(255.0f * f5)).getRGB();
            GL11.glEnable((int)3553);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GL11.glPushMatrix();
            GL11.glTranslatef((float)f9, (float)f6, (float)0.0f);
            GL11.glScalef((float)f7, (float)f7, (float)1.0f);
            FontUtil.drawString((String)entry.n.getMessage(), (float)0.0f, (float)0.0f, (int)n, (boolean)false);
            GL11.glPopMatrix();
        } else {
            f9 = f + 28.0f;
            f8 = FontUtil.getFontHeight();
            f7 = f8 * 0.5f + 1.0f + f8 * 0.45f;
            f6 = f2 + (f10 - f7) * 0.5f;
            n = new Color(C_TITLE.getRed(), C_TITLE.getGreen(), C_TITLE.getBlue(), (int)(255.0f * f5)).getRGB();
            GL11.glEnable((int)3553);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GL11.glPushMatrix();
            GL11.glTranslatef((float)f9, (float)f6, (float)0.0f);
            GL11.glScalef((float)0.5f, (float)0.5f, (float)1.0f);
            FontUtil.drawString((String)entry.n.getTitle(), (float)0.0f, (float)0.0f, (int)n, (boolean)false);
            GL11.glPopMatrix();
            int n4 = new Color(C_MSG.getRed(), C_MSG.getGreen(), C_MSG.getBlue(), (int)(255.0f * f5)).getRGB();
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GL11.glPushMatrix();
            GL11.glTranslatef((float)f9, (float)(f6 + f8 * 0.5f + 1.0f), (float)0.0f);
            GL11.glScalef((float)0.45f, (float)0.45f, (float)1.0f);
            FontUtil.drawString((String)entry.n.getMessage(), (float)0.0f, (float)0.0f, (int)n4, (boolean)false);
            GL11.glPopMatrix();
        }
        GL11.glDisable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        f9 = entry.n.getProgress();
        if (!bl2 && f9 < 1.0f) {
            f8 = (f3 - 12.0f) * (1.0f - f9);
            f7 = f + 6.0f;
            f6 = f2 + f10 - 2.0f;
            Color color = entry.n.getType() == Notification.Type.ENABLED ? new Color(80, 220, 100, (int)(200.0f * f5)) : (entry.n.getType() == Notification.Type.DISABLED ? new Color(220, 60, 60, (int)(200.0f * f5)) : new Color(100, 180, 255, (int)(200.0f * f5)));
            RoundedUtil.rect((double)f7, (double)f6, (double)f8, (double)1.5, (Color)color);
        }
        GL11.glPopMatrix();
    }

    private static void handleDrag(float f, float f2, int n, int n2, List<Entry> list) {
        if (!ClickGui.isUiEditMode()) {
            isDragging = false;
        } else {
            int n3 = ScissorUtil.mapMouseX((int)Mouse.getX());
            int n4 = ScissorUtil.mapMouseY((int)Mouse.getY());
            float f3 = 90.0f;
            float f4 = 0.0f;
            for (Entry entry : list) {
                float f5 = NotificationManager.calcW(entry);
                if (f5 > f3) {
                    f3 = f5;
                }
                f4 += NotificationManager.getH(entry.n) + 2.0f;
            }
            if (f4 > 0.0f) {
                f4 -= 2.0f;
            }
            float f6 = f - f3;
            float f7 = f2 - f4;
            boolean bl = (float)n3 >= f6 && (float)n3 <= f && (float)n4 >= f7 && (float)n4 <= f2;
            boolean bl2 = bl;
            if (Mouse.isButtonDown((int)0)) {
                if (!isDragging && bl) {
                    if (ClickGui.isDraggingAnyElement()) {
                        return;
                    }
                    isDragging = true;
                    dragOffX = (float)n3 - f;
                    dragOffY = (float)n4 - f2;
                    ClickGui.setDraggingAnyElement((boolean)true);
                }
                if (isDragging) {
                    float f8 = (float)n3 - dragOffX;
                    float f9 = (float)n4 - dragOffY;
                    f8 = Math.max(f3 + 5.0f, Math.min((float)n - 5.0f, f8));
                    f9 = Math.max(f4 + 5.0f, Math.min((float)n2 - 5.0f, f9));
                    posX = f8 > (float)n / 2.0f ? -((float)n - f8) : f8;
                    posY = f9 > (float)n2 / 2.0f ? -((float)n2 - f9) : f9;
                }
            } else {
                if (isDragging) {
                    ClickGui.setDraggingAnyElement((boolean)false);
                }
                isDragging = false;
            }
        }
    }

    private static float calcW(Entry entry) {
        boolean bl;
        boolean bl2 = bl = entry.n.getTitle().equalsIgnoreCase("Module") || entry.n.getTitle().isEmpty();
        if (bl) {
            float f = 28.0f;
            float f2 = (float)FontUtil.getStringWidth((String)entry.n.getMessage()) * 0.48f;
            return Math.max(85.0f, f + f2);
        }
        float f = 38.0f;
        float f3 = (float)FontUtil.getStringWidth((String)entry.n.getTitle()) * 0.5f;
        float f4 = (float)FontUtil.getStringWidth((String)entry.n.getMessage()) * 0.45f;
        return Math.max(105.0f, f + Math.max(f3, f4));
    }

    private static float anim(String string, float f) {
        Float f2 = sm.get(string);
        return f2 != null ? f2.floatValue() : f;
    }

    private static float anim(String string, float f, float f2) {
        float f3 = sm.containsKey(string) ? sm.get(string).floatValue() : (f > 0.5f ? 0.0f : 1.0f);
        f3 += (f - f3) * f2;
        sm.put(string, Float.valueOf(f3));
        return f3;
    }

    private static float easeOut(float f) {
        float f2 = 1.0f - f;
        return 1.0f - f2 * f2 * f2;
    }

    private static void drawCircle(float f, float f2, float f3, Color color) {
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)1.0f);
        GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
        GL11.glBegin((int)2);
        for (int i = 0; i < 360; i += 10) {
            double d = (double)i * Math.PI / 180.0;
            GL11.glVertex2d((double)((double)f + Math.cos(d) * (double)f3), (double)((double)f2 + Math.sin(d) * (double)f3));
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    private static void drawFilledCircle(float f, float f2, float f3, Color color) {
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
        GL11.glBegin((int)9);
        for (int i = 0; i < 360; i += 10) {
            double d = (double)i * Math.PI / 180.0;
            GL11.glVertex2d((double)((double)f + Math.cos(d) * (double)f3), (double)((double)f2 + Math.sin(d) * (double)f3));
        }
        GL11.glEnd();
    }

    private static void drawCheckmark(float f, float f2, float f3, Color color) {
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)1.5f);
        GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
        GL11.glBegin((int)3);
        GL11.glVertex2f((float)(f - f3 * 0.3f), (float)f2);
        GL11.glVertex2f((float)(f - f3 * 0.05f), (float)(f2 + f3 * 0.25f));
        GL11.glVertex2f((float)(f + f3 * 0.3f), (float)(f2 - f3 * 0.25f));
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    private static void drawCross(float f, float f2, float f3, Color color) {
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)1.5f);
        GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
        GL11.glBegin((int)1);
        GL11.glVertex2f((float)(f - f3 * 0.25f), (float)(f2 - f3 * 0.25f));
        GL11.glVertex2f((float)(f + f3 * 0.25f), (float)(f2 + f3 * 0.25f));
        GL11.glVertex2f((float)(f + f3 * 0.25f), (float)(f2 - f3 * 0.25f));
        GL11.glVertex2f((float)(f - f3 * 0.25f), (float)(f2 + f3 * 0.25f));
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    private static void drawInfoIcon(float f, float f2, Color color) {
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)1.5f);
        GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
        GL11.glBegin((int)1);
        GL11.glVertex2f((float)f, (float)(f2 - 3.0f));
        GL11.glVertex2f((float)f, (float)(f2 - 2.0f));
        GL11.glVertex2f((float)f, (float)(f2 - 0.5f));
        GL11.glVertex2f((float)f, (float)(f2 + 3.0f));
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    private static class Entry {
        final long id;
        final Notification n;

        Entry(long l, Notification notification) {
            this.id = l;
            this.n = notification;
        }
    }
}
