/*
 * Decompiled with CFR 0.152.
 */
package me.ries.notification;

public class Notification {
    private final String title;
    private final String message;
    private final Type type;
    private final long startTime;
    private final long duration;

    public Notification(String string, String string2, Type type, long l) {
        this.title = string;
        this.message = string2;
        this.type = type;
        this.duration = l;
        this.startTime = System.currentTimeMillis();
    }

    public String getTitle() {
        return this.title;
    }

    public String getMessage() {
        return this.message;
    }

    public Type getType() {
        return this.type;
    }

    public long getStartTime() {
        return this.startTime;
    }

    public long getDuration() {
        return this.duration;
    }

    public float getProgress() {
        return Math.min(1.0f, (float)(System.currentTimeMillis() - this.startTime) / (float)this.duration);
    }

    public boolean isFinished() {
        return System.currentTimeMillis() - this.startTime > this.duration;
    }

    public static enum Type {
        ENABLED,
        DISABLED,
        INFO;

    }
}

