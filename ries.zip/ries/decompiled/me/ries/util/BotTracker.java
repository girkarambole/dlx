/*
 * Decompiled with CFR 0.152.
 */
package me.ries.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import me.ries.mapping.MinecraftMapper;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public final class BotTracker {
    private static final Map<Object, Float> maxHealthMap = new WeakHashMap<Object, Float>();
    private static final Map<String, Long> deadPlayers = new ConcurrentHashMap<String, Long>();
    private static volatile long lastKillTime = 0L;
    private static volatile Field dataWatcherField = null;
    private static volatile Method getFloatMethod = null;
    private static volatile Method getLocationSkin = null;
    private static volatile boolean reflCached = false;

    private BotTracker() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void observe(Object entity) {
        if (entity != null) {
            try {
                BotTracker.ensureReflection();
                float hp = BotTracker.getEntityHealthRaw(entity);
                if (hp <= 0.0f) {
                    return;
                }
                Map<Object, Float> map = maxHealthMap;
                synchronized (map) {
                    Float prev = maxHealthMap.get(entity);
                    if (prev == null || hp > prev.floatValue()) {
                        maxHealthMap.put(entity, Float.valueOf(hp));
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public static void observeAll() {
        try {
            for (Object entity : MinecraftMapper.getPlayerEntitiesInWorld()) {
                BotTracker.observe(entity);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static boolean isBot(Object entity) {
        block7: {
            if (entity == null) {
                return false;
            }
            try {
                String entId = String.valueOf(BotTracker.getId(entity));
                if (entId.length() == 8) {
                    Logger.kaDebug("[BotTracker] BOT(id8) id=" + entId);
                    return true;
                }
                BotTracker.ensureReflection();
                if (getLocationSkin == null) break block7;
                try {
                    String skinPath;
                    Object skin = getLocationSkin.invoke(entity, new Object[0]);
                    if (skin != null && ((skinPath = skin.toString().toLowerCase()).contains("steve.png") || skinPath.contains("alex.png"))) {
                        Logger.kaDebug("[BotTracker] BOT(skin) id=" + entId);
                        return true;
                    }
                }
                catch (Throwable throwable) {}
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static boolean isBotByHp(Object entity) {
        if (entity == null) {
            return false;
        }
        try {
            float currentHp = BotTracker.getEntityHealthRaw(entity);
            if (currentHp <= 0.0f) {
                return false;
            }
            Map<Object, Float> map = maxHealthMap;
            synchronized (map) {
                Float maxObserved = maxHealthMap.get(entity);
                if (maxObserved == null) {
                    maxHealthMap.put(entity, Float.valueOf(currentHp));
                    maxObserved = Float.valueOf(currentHp);
                }
                if (Math.abs(currentHp - 1.0f) < 0.05f && maxObserved.floatValue() <= 1.05f) {
                    Logger.kaDebug("[BotTracker] BOT(hp1) maxObserved=" + maxObserved);
                    return true;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    public static boolean isFixedLowHp(Object entity) {
        return BotTracker.isBot(entity) || BotTracker.isBotByHp(entity);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void reset() {
        Map<Object, Float> map = maxHealthMap;
        synchronized (map) {
            maxHealthMap.clear();
        }
    }

    public static float getEntityHealthRaw(Object entity) {
        block8: {
            if (entity == null) {
                return 0.0f;
            }
            try {
                Object val;
                Object dw;
                BotTracker.ensureReflection();
                if (dataWatcherField != null && getFloatMethod != null && (dw = dataWatcherField.get(entity)) != null && (val = getFloatMethod.invoke(dw, 25)) instanceof Number) {
                    float raw = ((Number)val).floatValue();
                    return raw / 571.875f;
                }
            }
            catch (Throwable dw) {
                // empty catch block
            }
            try {
                Class<?> absCls = MappingUtils.get("AbstractClientPlayer");
                if (absCls == null || !absCls.isInstance(entity)) break block8;
                for (Method m : absCls.getDeclaredMethods()) {
                    float hp;
                    if (m.getParameterCount() != 0 || m.getReturnType() != Float.TYPE || (m.getModifiers() & 8) != 0) continue;
                    m.setAccessible(true);
                    Object val = m.invoke(entity, new Object[0]);
                    if (val instanceof Number && (hp = ((Number)val).floatValue()) >= 0.0f && hp <= 20.0f) {
                        return hp;
                    }
                    break;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return 0.0f;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void ensureReflection() {
        if (reflCached) return;
        Class<BotTracker> clazz = BotTracker.class;
        synchronized (BotTracker.class) {
            Method m2;
            if (reflCached) return;
            try {
                Field f = MappingUtils.getField("Entity.dataWatcher");
                if (f != null) {
                    f.setAccessible(true);
                    dataWatcherField = f;
                }
            }
            catch (Throwable f) {
                // empty catch block
            }
            try {
                m2 = MappingUtils.getMethod("DataWatcher.getFloat");
                if (m2 != null) {
                    m2.setAccessible(true);
                    getFloatMethod = m2;
                }
            }
            catch (Throwable m2) {
                // empty catch block
            }
            try {
                m2 = MappingUtils.getMethod("AbstractClientPlayer.getLocationSkin");
                if (m2 != null) {
                    m2.setAccessible(true);
                    getLocationSkin = m2;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            reflCached = true;
            Logger.info("[BotTracker] init: dw=" + (dataWatcherField != null) + " getFloat=" + (getFloatMethod != null) + " skin=" + (getLocationSkin != null));
            // ** MonitorExit[var0] (shouldn't be in output)
            return;
        }
    }

    public static void registerKill(String rawName) {
        if (rawName == null) {
            return;
        }
        String clean = rawName.replaceAll("\u00c3\u201a\u00c2\u00a7[0-9a-fk-or]", "").trim().toLowerCase();
        if (!clean.isEmpty()) {
            deadPlayers.put(clean, System.currentTimeMillis());
            lastKillTime = System.currentTimeMillis();
            Logger.info("[BotTracker] Registered kill: " + clean);
        }
    }

    public static boolean isDeadRecently(Object entity) {
        if (entity == null) {
            return false;
        }
        if (System.currentTimeMillis() - lastKillTime < 180L) {
            return true;
        }
        try {
            String clean;
            Long time;
            String name = MinecraftMapper.getName(entity);
            if (name != null && (time = deadPlayers.get(clean = name.replaceAll("\u00c3\u201a\u00c2\u00a7[0-9a-fk-or]", "").trim().toLowerCase())) != null) {
                if (System.currentTimeMillis() - time < 3500L) {
                    return true;
                }
                deadPlayers.remove(clean);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private static int getId(Object entity) {
        try {
            Method m = MappingUtils.getMethod("Entity.getEntityId");
            if (m != null) {
                m.setAccessible(true);
                return ((Number)m.invoke(entity, new Object[0])).intValue();
            }
            Field f = MappingUtils.getField("Entity.entityId");
            if (f != null) {
                f.setAccessible(true);
                return f.getInt(entity);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return -1;
    }
}

