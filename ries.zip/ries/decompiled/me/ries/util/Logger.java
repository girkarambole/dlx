/*
 * Decompiled with CFR 0.152.
 */
package me.ries.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {
    private static final String LOG_DIR = "C:\\ries\\logs";
    private static final String LOG_FILE = "C:\\ries\\logs\\Ries.log";
    private static final DateTimeFormatter formatter;
    private static final PrintStream OUT;

    public static void info(String message) {
        Logger.log("[INFO] ", message);
    }

    public static void warn(String message) {
        Logger.log("[WARN] ", message);
    }

    public static void error(String message) {
        Logger.log("[ERROR]", message);
    }

    public static void debug(String message) {
        Logger.log("[DEBUG]", message);
    }

    public static void kaInfo(String message) {
    }

    public static void kaDebug(String message) {
    }

    public static void kaWarn(String message) {
    }

    public static void kaAttack(String message) {
    }

    private static void log(String level, String message) {
        String timestamp = LocalDateTime.now().format(formatter);
        String line = timestamp + " " + level + " " + message;
        OUT.println(line);
        try (OutputStreamWriter writer = new OutputStreamWriter((OutputStream)new FileOutputStream(LOG_FILE, true), StandardCharsets.UTF_8);){
            writer.write(line + "\n");
        }
        catch (IOException e) {
            e.printStackTrace(OUT);
        }
    }

    static {
        PrintStream utf8Out;
        formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
        new File(LOG_DIR).mkdirs();
        try {
            utf8Out = new PrintStream((OutputStream)System.out, true, "UTF-8");
        }
        catch (Exception var2) {
            utf8Out = System.out;
        }
        OUT = utf8Out;
        System.setOut(OUT);
    }
}

