/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.objectweb.asm.ClassReader
 *  org.objectweb.asm.ClassVisitor
 *  org.objectweb.asm.ClassWriter
 *  org.objectweb.asm.Label
 *  org.objectweb.asm.MethodVisitor
 */
package me.ries.util;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.ArrayList;
import java.util.List;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

public class Obfuscator {
    public static void main(String[] stringArray) {
        try {
            File file;
            ArrayList<File> arrayList = new ArrayList<File>();
            for (String object : stringArray) {
                file = new File(object);
                if (!file.exists()) {
                    System.out.println("Path not found: " + object);
                    continue;
                }
                Obfuscator.findClassFiles(file, arrayList);
            }
            System.out.println("Obfuscating " + arrayList.size() + " class files with safe different-name slot sharing...");
            int n = 0;
            for (File file2 : arrayList) {
                try {
                    byte[] byArray = Files.readAllBytes(file2.toPath());
                    file = new ClassReader(byArray);
                    ClassWriter classWriter = new ClassWriter(1);
                    ClassVisitor classVisitor = new ClassVisitor(327680, (ClassVisitor)classWriter){

                        public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
                            MethodVisitor methodVisitor = super.visitMethod(n, string, string2, string3, stringArray);
                            return new MethodVisitor(327680, methodVisitor){
                                private Label startLabel;
                                private Label endLabel;

                                public void visitCode() {
                                    super.visitCode();
                                    this.startLabel = new Label();
                                    super.visitLabel(this.startLabel);
                                }

                                public void visitMaxs(int n, int n2) {
                                    this.endLabel = new Label();
                                    super.visitLabel(this.endLabel);
                                    if (this.startLabel != null && n2 > 0) {
                                        super.visitLocalVariable("dummy1", "Ljava/lang/String;", null, this.startLabel, this.endLabel, 0);
                                        super.visitLocalVariable("dummy2", "Ljava/lang/Integer;", null, this.startLabel, this.endLabel, 0);
                                    }
                                    super.visitMaxs(n, n2);
                                }
                            };
                        }
                    };
                    file.accept(classVisitor, 0);
                    Files.write(file2.toPath(), classWriter.toByteArray(), new OpenOption[0]);
                    ++n;
                }
                catch (Throwable throwable) {
                    System.out.println("Failed to obfuscate: " + file2.getName() + " -> " + throwable.getMessage());
                }
            }
            System.out.println("Successfully obfuscated " + n + " files.");
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    private static void findClassFiles(File file, List<File> list) {
        if (file.isDirectory()) {
            File[] fileArray = file.listFiles();
            if (fileArray != null) {
                for (File file2 : fileArray) {
                    Obfuscator.findClassFiles(file2, list);
                }
            }
        } else if (file.getName().endsWith(".class")) {
            list.add(file);
        }
    }
}

