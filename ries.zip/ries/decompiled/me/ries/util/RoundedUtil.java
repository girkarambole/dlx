/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package me.ries.util;

import java.awt.Color;
import me.ries.util.ScissorUtil;
import org.lwjgl.opengl.GL11;

public final class RoundedUtil {
    private static final float[] SIN = new float[361];
    private static final float[] COS = new float[361];

    private RoundedUtil() {
    }

    public static void roundedRect(double x, double y, double w, double h, double radius, Color color) {
        RoundedUtil.roundedRect(x, y, w, h, radius, color.getRGB());
    }

    public static void roundedRect(double x, double y, double w, double h, double radius, int rgba) {
        float a = (float)(rgba >> 24 & 0xFF) / 255.0f;
        float r = (float)(rgba >> 16 & 0xFF) / 255.0f;
        float g = (float)(rgba >> 8 & 0xFF) / 255.0f;
        float b = (float)(rgba & 0xFF) / 255.0f;
        RoundedUtil.drawGradientRounded((float)x, (float)y, (float)w, (float)h, (float)radius, r, g, b, a, r, g, b, a, false);
    }

    public static void drawLeftRoundedRect(double x, double y, double w, double h, double radius, Color color) {
        drawLeftRoundedRect(x, y, w, h, radius, color.getRGB());
    }

    public static void drawLeftRoundedRect(double x, double y, double w, double h, double radius, int rgba) {
        float a = (float)(rgba >> 24 & 0xFF) / 255.0f;
        float r = (float)(rgba >> 16 & 0xFF) / 255.0f;
        float g = (float)(rgba >> 8 & 0xFF) / 255.0f;
        float b = (float)(rgba & 0xFF) / 255.0f;
        float fx = (float)x;
        float fy = (float)y;
        float fw = (float)w;
        float fh = (float)h;
        float fr = (float)Math.min(radius, Math.min(w, h) / 2.0);
        if (fr < 0.0f) fr = 0.0f;
        int seg = (int)Math.min(Math.max(fr * 1.2f, 12.0f), 36.0f);

        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);

        GL11.glBegin((int)9);
        RoundedUtil.drawArc(fx + fr, fy + fr, fr, seg, 180, 270);
        GL11.glVertex2f(fx + fw, fy);
        GL11.glVertex2f(fx + fw, fy + fh);
        RoundedUtil.drawArc(fx + fr, fy + fh - fr, fr, seg, 90, 180);
        GL11.glEnd();

        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    public static void drawPartialLeftRoundedRect(double x, double y, double w, double h, double topLeftR, double bottomLeftR, Color color) {
        drawPartialLeftRoundedRect(x, y, w, h, topLeftR, bottomLeftR, color.getRGB());
    }

    public static void drawPartialLeftRoundedRect(double x, double y, double w, double h, double topLeftR, double bottomLeftR, int rgba) {
        float a = (float)(rgba >> 24 & 0xFF) / 255.0f;
        float r = (float)(rgba >> 16 & 0xFF) / 255.0f;
        float g = (float)(rgba >> 8 & 0xFF) / 255.0f;
        float b = (float)(rgba & 0xFF) / 255.0f;
        float fx = (float)x;
        float fy = (float)y;
        float fw = (float)w;
        float fh = (float)h;
        float ftr = (float)Math.min(topLeftR, Math.min(w, h) / 2.0);
        float fbr = (float)Math.min(bottomLeftR, Math.min(w, h) / 2.0);
        if (ftr < 0.0f) ftr = 0.0f;
        if (fbr < 0.0f) fbr = 0.0f;
        int segT = (int)Math.min(Math.max(ftr * 1.2f, 12.0f), 36.0f);
        int segB = (int)Math.min(Math.max(fbr * 1.2f, 12.0f), 36.0f);

        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);

        GL11.glBegin((int)9);
        if (ftr > 0.0f) {
            RoundedUtil.drawArc(fx + ftr, fy + ftr, ftr, segT, 180, 270);
        } else {
            GL11.glVertex2f(fx, fy);
        }
        GL11.glVertex2f(fx + fw, fy);
        GL11.glVertex2f(fx + fw, fy + fh);
        if (fbr > 0.0f) {
            RoundedUtil.drawArc(fx + fbr, fy + fh - fbr, fbr, segB, 90, 180);
        } else {
            GL11.glVertex2f(fx, fy + fh);
        }
        GL11.glEnd();

        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    public static void drawPartialLeftRoundedOutline(float x, float y, float w, float h, float topLeftR, float bottomLeftR, float lineWidth, Color color) {
        drawPartialLeftRoundedOutline(x, y, w, h, topLeftR, bottomLeftR, true, true, lineWidth, color);
    }

    public static void drawPartialLeftRoundedOutline(float x, float y, float w, float h, float topLeftR, float bottomLeftR, boolean drawTop, boolean drawBottom, float lineWidth, Color color) {
        float a = (float)color.getAlpha() / 255.0f;
        float r = (float)color.getRed() / 255.0f;
        float g = (float)color.getGreen() / 255.0f;
        float b = (float)color.getBlue() / 255.0f;
        float ftr = Math.min(topLeftR, Math.min(w, h) / 2.0f);
        float fbr = Math.min(bottomLeftR, Math.min(w, h) / 2.0f);
        if (ftr < 0.0f) ftr = 0.0f;
        if (fbr < 0.0f) fbr = 0.0f;
        int segT = (int)Math.min(Math.max(ftr * 1.2f, 12.0f), 36.0f);
        int segB = (int)Math.min(Math.max(fbr * 1.2f, 12.0f), 36.0f);

        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
        GL11.glLineWidth((float)lineWidth);

        // Top edge: arc + horizontal line (only if first item)
        if (drawTop) {
            GL11.glBegin((int)3);
            if (ftr > 0.0f) {
                RoundedUtil.drawArc(x + ftr, y + ftr, ftr, segT, 180, 270);
            } else {
                GL11.glVertex2f(x, y);
            }
            GL11.glVertex2f(x + w, y);
            GL11.glEnd();
        }

        // Right vertical edge (always)
        GL11.glBegin((int)1);
        GL11.glVertex2f(x + w, y);
        GL11.glVertex2f(x + w, y + h);
        GL11.glEnd();

        // Bottom edge: horizontal line + arc (only if last item)
        if (drawBottom) {
            GL11.glBegin((int)3);
            GL11.glVertex2f(x + w, y + h);
            if (fbr > 0.0f) {
                RoundedUtil.drawArc(x + fbr, y + h - fbr, fbr, segB, 90, 180);
            } else {
                GL11.glVertex2f(x, y + h);
            }
            GL11.glEnd();
        }

        // Left vertical edge between arcs (always)
        float leftTopY = drawTop ? (ftr > 0.0f ? y + ftr : y) : y;
        float leftBotY = drawBottom ? (fbr > 0.0f ? y + h - fbr : y + h) : y + h;
        if (leftBotY > leftTopY) {
            GL11.glBegin((int)1);
            GL11.glVertex2f(x, leftTopY);
            GL11.glVertex2f(x, leftBotY);
            GL11.glEnd();
        }

        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    public static void drawLeftRoundedOutline(float x, float y, float w, float h, float radius, float lineWidth, Color color) {
        drawLeftRoundedOutline(x, y, w, h, radius, lineWidth, color.getRGB());
    }

    public static void drawLeftRoundedOutline(float x, float y, float w, float h, float radius, float lineWidth, int rgba) {
        float a = (float)(rgba >> 24 & 0xFF) / 255.0f;
        float r = (float)(rgba >> 16 & 0xFF) / 255.0f;
        float g = (float)(rgba >> 8 & 0xFF) / 255.0f;
        float b = (float)(rgba & 0xFF) / 255.0f;
        if (radius < 0.0f) {
            radius = 0.0f;
        }
        radius = Math.min(radius, Math.min(w, h) / 2.0f);
        int seg = (int)Math.min(Math.max(radius * 1.2f, 12.0f), 36.0f);
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
        GL11.glLineWidth((float)lineWidth);
        GL11.glBegin((int)3);
        RoundedUtil.drawArc(x + radius, y + radius, radius, seg, 180, 270);
        GL11.glVertex2f(x + w, y);
        GL11.glEnd();
        GL11.glBegin((int)1);
        GL11.glVertex2f(x + w, y);
        GL11.glVertex2f(x + w, y + h);
        GL11.glEnd();
        GL11.glBegin((int)3);
        GL11.glVertex2f(x + w, y + h);
        RoundedUtil.drawArc(x + radius, y + h - radius, radius, seg, 90, 180);
        GL11.glEnd();
        GL11.glBegin((int)1);
        GL11.glVertex2f(x, y + radius);
        GL11.glVertex2f(x, y + h - radius);
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    public static void drawHorizontalGradientRoundedRect(double x, double y, double w, double h, double radius, Color left, Color right) {
        float r1 = (float)left.getRed() / 255.0f;
        float g1 = (float)left.getGreen() / 255.0f;
        float b1 = (float)left.getBlue() / 255.0f;
        float a1 = (float)left.getAlpha() / 255.0f;
        float r2 = (float)right.getRed() / 255.0f;
        float g2 = (float)right.getGreen() / 255.0f;
        float b2 = (float)right.getBlue() / 255.0f;
        float a2 = (float)right.getAlpha() / 255.0f;
        RoundedUtil.drawGradientRounded((float)x, (float)y, (float)w, (float)h, (float)radius, r1, g1, b1, a1, r2, g2, b2, a2, true);
    }

    public static void rect(double x, double y, double w, double h, Color color) {
        RoundedUtil.rect(x, y, w, h, color.getRGB());
    }

    public static void rect(double x, double y, double w, double h, int rgba) {
        float a = (float)(rgba >> 24 & 0xFF) / 255.0f;
        float r = (float)(rgba >> 16 & 0xFF) / 255.0f;
        float g = (float)(rgba >> 8 & 0xFF) / 255.0f;
        float b = (float)(rgba & 0xFF) / 255.0f;
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
        GL11.glBegin((int)7);
        GL11.glVertex2d((double)x, (double)y);
        GL11.glVertex2d((double)(x + w), (double)y);
        GL11.glVertex2d((double)(x + w), (double)(y + h));
        GL11.glVertex2d((double)x, (double)(y + h));
        GL11.glEnd();
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    public static void drawRoundOutline(float x, float y, float w, float h, float radius, float lineWidth, Color color) {
        RoundedUtil.drawRoundOutline(x, y, w, h, radius, lineWidth, color.getRGB());
    }

    public static void drawRoundOutline(float x, float y, float w, float h, float radius, float lineWidth, int rgba) {
        float a = (float)(rgba >> 24 & 0xFF) / 255.0f;
        float r = (float)(rgba >> 16 & 0xFF) / 255.0f;
        float g = (float)(rgba >> 8 & 0xFF) / 255.0f;
        float b = (float)(rgba & 0xFF) / 255.0f;
        if (radius < 0.0f) {
            radius = 0.0f;
        }
        radius = Math.min(radius, Math.min(w, h) / 2.0f);
        int seg = (int)Math.min(Math.max(radius * 1.2f, 12.0f), 36.0f);
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
        GL11.glLineWidth((float)lineWidth);
        GL11.glBegin((int)2);
        RoundedUtil.drawArc(x + radius, y + radius, radius, seg, 180, 270);
        RoundedUtil.drawArc(x + w - radius, y + radius, radius, seg, 270, 360);
        RoundedUtil.drawArc(x + w - radius, y + h - radius, radius, seg, 0, 90);
        RoundedUtil.drawArc(x + radius, y + h - radius, radius, seg, 90, 180);
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    public static void drawStarBorder(float x, float y, float w, float h, float radius, float lineWidth, Color color, float speedSec, float pulse) {
        int deg;
        int i;
        float r = (float)color.getRed() / 255.0f;
        float g = (float)color.getGreen() / 255.0f;
        float b = (float)color.getBlue() / 255.0f;
        float maxA = (float)color.getAlpha() / 255.0f;
        long cycleTime = (long)(speedSec * 1000.0f);
        float progress = (float)(System.currentTimeMillis() % cycleTime) / (float)cycleTime;
        long cycle = System.currentTimeMillis() / cycleTime;
        if (cycle % 2L == 1L) {
            progress = 1.0f - progress;
        }
        float topStarX = x - w + w * 3.0f * progress;
        float topStarY = y - 12.0f + h * 0.5f / 2.0f;
        float topStarAlpha = (1.0f - progress) * (0.7f + 0.3f * pulse) * maxA;
        float bottomStarX = x + w * 2.0f - w * 3.0f * progress;
        float bottomStarY = y + h + 12.0f - h * 0.5f / 2.0f;
        float bottomStarAlpha = (1.0f - progress) * (0.7f + 0.3f * pulse) * maxA;
        float glowRadius = w * (0.15f + 0.15f * pulse);
        if (radius < 0.0f) {
            radius = 0.0f;
        }
        radius = Math.min(radius, Math.min(w, h) / 2.0f);
        int seg = (int)Math.min(Math.max(radius * 1.2f, 12.0f), 36.0f);
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)(lineWidth + 1.5f * pulse));
        GL11.glBegin((int)2);
        int straightSegs = 20;
        for (i = 0; i <= seg; ++i) {
            deg = 180 + 90 * i / seg;
            RoundedUtil.emitStarVertex(x + radius + COS[deg % 360] * radius, y + radius + SIN[deg % 360] * radius, topStarX, topStarY, topStarAlpha, bottomStarX, bottomStarY, bottomStarAlpha, glowRadius, r, g, b);
        }
        for (i = 1; i < straightSegs; ++i) {
            RoundedUtil.emitStarVertex(x + radius + (w - 2.0f * radius) * (float)i / (float)straightSegs, y, topStarX, topStarY, topStarAlpha, bottomStarX, bottomStarY, bottomStarAlpha, glowRadius, r, g, b);
        }
        for (i = 0; i <= seg; ++i) {
            deg = 270 + 90 * i / seg;
            RoundedUtil.emitStarVertex(x + w - radius + COS[deg % 360] * radius, y + radius + SIN[deg % 360] * radius, topStarX, topStarY, topStarAlpha, bottomStarX, bottomStarY, bottomStarAlpha, glowRadius, r, g, b);
        }
        for (i = 1; i < straightSegs; ++i) {
            RoundedUtil.emitStarVertex(x + w, y + radius + (h - 2.0f * radius) * (float)i / (float)straightSegs, topStarX, topStarY, topStarAlpha, bottomStarX, bottomStarY, bottomStarAlpha, glowRadius, r, g, b);
        }
        for (i = 0; i <= seg; ++i) {
            deg = 0 + 90 * i / seg;
            RoundedUtil.emitStarVertex(x + w - radius + COS[deg % 360] * radius, y + h - radius + SIN[deg % 360] * radius, topStarX, topStarY, topStarAlpha, bottomStarX, bottomStarY, bottomStarAlpha, glowRadius, r, g, b);
        }
        for (i = 1; i < straightSegs; ++i) {
            RoundedUtil.emitStarVertex(x + w - radius - (w - 2.0f * radius) * (float)i / (float)straightSegs, y + h, topStarX, topStarY, topStarAlpha, bottomStarX, bottomStarY, bottomStarAlpha, glowRadius, r, g, b);
        }
        for (i = 0; i <= seg; ++i) {
            deg = 90 + 90 * i / seg;
            RoundedUtil.emitStarVertex(x + radius + COS[deg % 360] * radius, y + h - radius + SIN[deg % 360] * radius, topStarX, topStarY, topStarAlpha, bottomStarX, bottomStarY, bottomStarAlpha, glowRadius, r, g, b);
        }
        for (i = 1; i < straightSegs; ++i) {
            RoundedUtil.emitStarVertex(x, y + h - radius - (h - 2.0f * radius) * (float)i / (float)straightSegs, topStarX, topStarY, topStarAlpha, bottomStarX, bottomStarY, bottomStarAlpha, glowRadius, r, g, b);
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    private static void emitStarVertex(float px, float py, float topX, float topY, float topAlpha, float botX, float botY, float botAlpha, float glowRadius, float r, float g, float b) {
        float distTop = (float)Math.sqrt((px - topX) * (px - topX) + (py - topY) * (py - topY));
        float distBot = (float)Math.sqrt((px - botX) * (px - botX) + (py - botY) * (py - botY));
        float aTop = Math.max(0.0f, 1.0f - distTop / glowRadius);
        float aBot = Math.max(0.0f, 1.0f - distBot / glowRadius);
        aTop *= aTop;
        aBot *= aBot;
        float alpha = Math.max(aTop * topAlpha, aBot * botAlpha);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)alpha);
        GL11.glVertex2f((float)px, (float)py);
    }

    public static void drawRound(float x, float y, float w, float h, float radius, Color color) {
        RoundedUtil.roundedRect((double)x, (double)y, (double)w, (double)h, (double)radius, color);
    }

    public static void drawRound(float x, float y, float w, float h, float radius, int rgba) {
        RoundedUtil.roundedRect((double)x, (double)y, (double)w, (double)h, (double)radius, rgba);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void drawRoundProgressOutline(float x, float y, float w, float h, float radius, float lineWidth, float progress, Color bright, Color dark) {
        if (!((progress = Math.max(0.0f, Math.min(1.0f, progress))) <= 0.01f)) {
            float clipH = h * progress;
            ScissorUtil.push(x - lineWidth, y + h - clipH - lineWidth, w + lineWidth * 2.0f, clipH + lineWidth * 2.0f);
            try {
                RoundedUtil.drawRoundOutline(x, y, w, h, radius, lineWidth, bright);
            }
            finally {
                ScissorUtil.pop();
            }
        }
    }

    private static void drawGradientRounded(float x, float y, float w, float h, float radius, float r1, float g1, float b1, float a1, float r2, float g2, float b2, float a2, boolean horizontal) {
        if (radius < 0.0f) {
            radius = 0.0f;
        }
        radius = Math.min(radius, Math.min(w, h) / 2.0f);
        int seg = (int)Math.min(Math.max(radius * 1.2f, 12.0f), 36.0f);
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)9);
        RoundedUtil.renderCorner(x, y, w, h, radius, seg, 180, 270, r1, g1, b1, a1, r2, g2, b2, a2, horizontal);
        RoundedUtil.renderCorner(x, y, w, h, radius, seg, 270, 360, r1, g1, b1, a1, r2, g2, b2, a2, horizontal);
        RoundedUtil.renderCorner(x, y, w, h, radius, seg, 0, 90, r1, g1, b1, a1, r2, g2, b2, a2, horizontal);
        RoundedUtil.renderCorner(x, y, w, h, radius, seg, 90, 180, r1, g1, b1, a1, r2, g2, b2, a2, horizontal);
        GL11.glEnd();
        GL11.glShadeModel((int)7424);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    private static void renderCorner(float x, float y, float w, float h, float radius, int seg, int start, int end, float r1, float g1, float b1, float a1, float r2, float g2, float b2, float a2, boolean horizontal) {
        float cx = x + (start != 180 && start != 90 ? w - radius : radius);
        float cy = y + (start != 180 && start != 270 ? h - radius : radius);
        for (int i = 0; i <= seg; ++i) {
            int deg = start + (end - start) * i / seg;
            int idx = deg % 360;
            if (idx < 0) {
                idx += 360;
            }
            float px = cx + COS[idx] * radius;
            float py = cy + SIN[idx] * radius;
            float pct = horizontal ? (px - x) / w : (py - y) / h;
            float r = r1 + (r2 - r1) * pct;
            float g = g1 + (g2 - g1) * pct;
            float b = b1 + (b2 - b1) * pct;
            float a = a1 + (a2 - a1) * pct;
            GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
            GL11.glVertex2f((float)px, (float)py);
        }
    }

    private static void drawArc(float cx, float cy, float radius, int seg, int start, int end) {
        for (int i = 0; i <= seg; ++i) {
            int deg = start + (end - start) * i / seg;
            int idx = deg % 360;
            if (idx < 0) {
                idx += 360;
            }
            GL11.glVertex2f((float)(cx + COS[idx] * radius), (float)(cy + SIN[idx] * radius));
        }
    }

    public static void drawRoundTextured(float x, float y, float w, float h, float radius, float alpha) {
        if (radius < 0.0f) {
            radius = 0.0f;
        }
        radius = Math.min(radius, Math.min(w, h) / 2.0f);
        int seg = (int)Math.min(Math.max(radius * 1.2f, 12.0f), 36.0f);
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        GL11.glEnable((int)3553);
        GL11.glBegin((int)9);
        RoundedUtil.renderTexturedCorner(x, y, w, h, radius, seg, 180, 270);
        RoundedUtil.renderTexturedCorner(x, y, w, h, radius, seg, 270, 360);
        RoundedUtil.renderTexturedCorner(x, y, w, h, radius, seg, 0, 90);
        RoundedUtil.renderTexturedCorner(x, y, w, h, radius, seg, 90, 180);
        GL11.glEnd();
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    private static void renderTexturedCorner(float x, float y, float w, float h, float radius, int seg, int start, int end) {
        float cx = x + (start != 180 && start != 90 ? w - radius : radius);
        float cy = y + (start != 180 && start != 270 ? h - radius : radius);
        for (int i = 0; i <= seg; ++i) {
            int deg = start + (end - start) * i / seg;
            int idx = deg % 360;
            if (idx < 0) {
                idx += 360;
            }
            float px = cx + COS[idx] * radius;
            float py = cy + SIN[idx] * radius;
            float u = (px - x) / w;
            float v = (py - y) / h;
            GL11.glTexCoord2f((float)u, (float)v);
            GL11.glVertex2f((float)px, (float)py);
        }
    }

    public static void drawRoundTexturedSliced(float x, float y, float w, float h, float radius, float alpha) {
        float step = 0.5f;
        float aaWidth = 0.8f;
        GL11.glPushMatrix();
        GL11.glEnable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        for (float dy = 0.0f; dy < h; dy += step) {
            for (float dx = 0.0f; dx < w; dx += step) {
                float pixelAlpha = RoundedUtil.cornerPixelAlpha(dx, dy, w, h, radius, aaWidth);
                if (pixelAlpha <= 0.005f) continue;
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)(alpha * pixelAlpha));
                float px = x + dx;
                float py = y + dy;
                float u = dx / w;
                float v = dy / h;
                float uSpan = step / w;
                float vSpan = step / h;
                GL11.glBegin((int)7);
                GL11.glTexCoord2f((float)u, (float)v);
                GL11.glVertex2f((float)px, (float)py);
                GL11.glTexCoord2f((float)u, (float)(v + vSpan));
                GL11.glVertex2f((float)px, (float)(py + step));
                GL11.glTexCoord2f((float)(u + uSpan), (float)(v + vSpan));
                GL11.glVertex2f((float)(px + step), (float)(py + step));
                GL11.glTexCoord2f((float)(u + uSpan), (float)v);
                GL11.glVertex2f((float)(px + step), (float)py);
                GL11.glEnd();
            }
        }
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    private static float cornerPixelAlpha(float dx, float dy, float w, float h, float radius, float aaWidth) {
        float dist;
        if (dx >= radius && dx <= w - radius) {
            return 1.0f;
        }
        if (dy >= radius && dy <= h - radius) {
            return 1.0f;
        }
        if (dx < radius && dy < radius) {
            dist = (float)Math.sqrt((dx - radius) * (dx - radius) + (dy - radius) * (dy - radius));
        } else if (dx > w - radius && dy < radius) {
            float ddx = dx - (w - radius);
            dist = (float)Math.sqrt(ddx * ddx + (dy - radius) * (dy - radius));
        } else if (dx < radius && dy > h - radius) {
            float ddy = dy - (h - radius);
            dist = (float)Math.sqrt((dx - radius) * (dx - radius) + ddy * ddy);
        } else {
            float ddx = dx - (w - radius);
            float ddy = dy - (h - radius);
            dist = (float)Math.sqrt(ddx * ddx + ddy * ddy);
        }
        return Math.max(0.0f, Math.min(1.0f, (radius - dist) / aaWidth + 0.5f));
    }

    static {
        for (int i = 0; i <= 360; ++i) {
            RoundedUtil.SIN[i] = (float)Math.sin(Math.toRadians(i));
            RoundedUtil.COS[i] = (float)Math.cos(Math.toRadians(i));
        }
    }
}
