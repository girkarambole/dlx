/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL20
 */
package me.ries.util;

import java.awt.Color;
import java.nio.Buffer;
import java.nio.FloatBuffer;
import me.ries.util.Logger;
import me.ries.util.ScissorUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public final class FloatingLines {
    private static final String VERT_SIMPLE = "#version 120\nvoid main() {\n    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n}\n";
    private static final String FRAG = "#version 120\n\nuniform float iTime;\nuniform vec3  iResolution;\nuniform float animationSpeed;\nuniform bool  enableTop;\nuniform bool  enableMiddle;\nuniform bool  enableBottom;\nuniform int   topLineCount;\nuniform int   middleLineCount;\nuniform int   bottomLineCount;\nuniform float topLineDistance;\nuniform float middleLineDistance;\nuniform float bottomLineDistance;\nuniform vec3  topWavePosition;\nuniform vec3  middleWavePosition;\nuniform vec3  bottomWavePosition;\nuniform vec2  iMouse;\nuniform bool  interactive;\nuniform float bendRadius;\nuniform float bendStrength;\nuniform float bendInfluence;\nuniform bool  parallax;\nuniform float parallaxStrength;\nuniform vec2  parallaxOffset;\nuniform vec3  lineGradient[8];\nuniform int   lineGradientCount;\nuniform float globalAlpha;\nuniform bool  clipEnabled;\nuniform vec4  clipRect;\nuniform float clipRadius;\n\nconst vec3 BLACK = vec3(0.0);\nconst vec3 PINK  = vec3(233.0, 71.0, 245.0) / 255.0;\nconst vec3 BLUE  = vec3(47.0,  75.0, 162.0) / 255.0;\n\nmat2 rotate(float r) {\n    return mat2(cos(r), sin(r), -sin(r), cos(r));\n}\n\nvec3 background_color(vec2 uv) {\n    vec3 col = vec3(0.0);\n    float y = sin(uv.x - 0.2) * 0.3 - 0.1;\n    float m = uv.y - y;\n    col += mix(BLUE, BLACK, smoothstep(0.0, 1.0, abs(m)));\n    col += mix(PINK, BLACK, smoothstep(0.0, 1.0, abs(m - 0.8)));\n    return col * 0.5;\n}\n\nvec3 gradLookup(float t) {\n    if (lineGradientCount <= 0) return vec3(0.0);\n    if (lineGradientCount == 1) return lineGradient[0];\n    float scaled = clamp(t, 0.0, 0.9999) * float(lineGradientCount - 1);\n    float f = fract(scaled);\n    int   i = int(floor(scaled));\n    vec3 a = lineGradient[0];\n    vec3 b = lineGradient[0];\n    if (i == 0) { a = lineGradient[0]; b = lineGradient[1]; }\n    else if (i == 1) { a = lineGradient[1]; b = lineGradient[2]; }\n    else if (i == 2) { a = lineGradient[2]; b = lineGradient[3]; }\n    else if (i == 3) { a = lineGradient[3]; b = lineGradient[4]; }\n    else if (i == 4) { a = lineGradient[4]; b = lineGradient[5]; }\n    else if (i == 5) { a = lineGradient[5]; b = lineGradient[6]; }\n    else             { a = lineGradient[6]; b = lineGradient[7]; }\n    return mix(a, b, f) * 0.5;\n}\n\nfloat wave(vec2 uv, float offset, vec2 screenUv, vec2 mouseUv, bool shouldBend) {\n    float time       = iTime * animationSpeed;\n    float x_movement = time * 0.1;\n    float amp        = sin(offset + time * 0.2) * 0.3;\n    float y          = sin(uv.x + offset + x_movement) * amp;\n    if (shouldBend) {\n        vec2  d         = screenUv - mouseUv;\n        float influence = exp(-dot(d, d) * bendRadius);\n        float bendOff   = (mouseUv.y - screenUv.y) * influence * bendStrength * bendInfluence;\n        y += bendOff;\n    }\n    float m = uv.y - y;\n    return 0.0175 / max(abs(m) + 0.01, 0.001) + 0.01;\n}\n\nfloat roundedBoxSDF(vec2 p, vec2 center, vec2 halfSize, float r) {\n    vec2 q = abs(p - center) - halfSize + vec2(r);\n    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;\n}\n\nvoid main() {\n    vec2 fragCoord = gl_FragCoord.xy;\n    float clipMask = 1.0;\n    if (clipEnabled) {\n        vec2 center = clipRect.xy + clipRect.zw * 0.5;\n        vec2 halfSize = clipRect.zw * 0.5;\n        float d = roundedBoxSDF(fragCoord, center, halfSize, clipRadius);\n        clipMask = 1.0 - smoothstep(-0.5, 0.5, d);\n        if (clipMask < 0.004) discard;\n    }\n    vec2 baseUv = (2.0 * fragCoord - iResolution.xy) / iResolution.y;\n    baseUv.y *= -1.0;\n    if (parallax) baseUv += parallaxOffset;\n\n    vec3 col = vec3(0.0);\n    vec3 b   = (lineGradientCount > 0) ? vec3(0.0) : background_color(baseUv);\n\n    vec2 mouseUv = vec2(0.0);\n    if (interactive) {\n        mouseUv = (2.0 * iMouse - iResolution.xy) / iResolution.y;\n        mouseUv.y *= -1.0;\n    }\n\n    if (enableBottom) {\n        float bCount = float(bottomLineCount);\n        float angle0 = bottomWavePosition.z * log(length(baseUv) + 1.0);\n        vec2  ruv0   = baseUv * rotate(angle0);\n        for (int i = 0; i < 6; ++i) {\n            if (i >= bottomLineCount) break;\n            float fi = float(i);\n            float t  = fi / max(bCount - 1.0, 1.0);\n            vec3  lc = (lineGradientCount > 0) ? gradLookup(t) : b;\n            col += lc * wave(ruv0 + vec2(bottomLineDistance * fi + bottomWavePosition.x, bottomWavePosition.y),\n                             1.5 + 0.2 * fi, baseUv, mouseUv, interactive) * 0.2;\n        }\n    }\n\n    if (enableMiddle) {\n        float mCount = float(middleLineCount);\n        float angle1 = middleWavePosition.z * log(length(baseUv) + 1.0);\n        vec2  ruv1   = baseUv * rotate(angle1);\n        for (int i = 0; i < 6; ++i) {\n            if (i >= middleLineCount) break;\n            float fi = float(i);\n            float t  = fi / max(mCount - 1.0, 1.0);\n            vec3  lc = (lineGradientCount > 0) ? gradLookup(t) : b;\n            col += lc * wave(ruv1 + vec2(middleLineDistance * fi + middleWavePosition.x, middleWavePosition.y),\n                             2.0 + 0.15 * fi, baseUv, mouseUv, interactive);\n        }\n    }\n\n    if (enableTop) {\n        float tCount = float(topLineCount);\n        float angle2 = topWavePosition.z * log(length(baseUv) + 1.0);\n        vec2  ruv2   = baseUv * rotate(angle2);\n        ruv2.x *= -1.0;\n        for (int i = 0; i < 6; ++i) {\n            if (i >= topLineCount) break;\n            float fi = float(i);\n            float t  = fi / max(tCount - 1.0, 1.0);\n            vec3  lc = (lineGradientCount > 0) ? gradLookup(t) : b;\n            col += lc * wave(ruv2 + vec2(topLineDistance * fi + topWavePosition.x, topWavePosition.y),\n                             1.0 + 0.2 * fi, baseUv, mouseUv, interactive) * 0.1;\n        }\n    }\n\n    gl_FragColor = vec4(clamp(col, 0.0, 1.0), globalAlpha * clipMask);\n}\n";
    private static int program = -1;
    private static boolean initFailed = false;
    private static long startTime = System.currentTimeMillis();
    private static float smoothMouseX = -1000.0f;
    private static float smoothMouseY = -1000.0f;
    private static float bendInfluence = 0.0f;
    private static float parallaxX = 0.0f;
    private static float parallaxY = 0.0f;
    private static final float[][] DEFAULT_GRADIENT = new float[][]{{0.18431373f, 0.29411766f, 0.63529414f}, {0.47058824f, 0.23529412f, 0.78431374f}, {0.9137255f, 0.2784314f, 0.9607843f}};
    private static float[][] dynamicGradient = null;
    private static final FloatBuffer[] PROJ_BACKUPS = new FloatBuffer[]{BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16)};
    private static final FloatBuffer[] MODEL_BACKUPS = new FloatBuffer[]{BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16)};
    private static int backupDepth = 0;

    private static void backupMatrices() {
        if (backupDepth < PROJ_BACKUPS.length) {
            FloatBuffer proj = PROJ_BACKUPS[backupDepth];
            FloatBuffer model = MODEL_BACKUPS[backupDepth];
            ((Buffer)proj).clear();
            ((Buffer)model).clear();
            GL11.glGetFloat((int)2983, (FloatBuffer)proj);
            GL11.glGetFloat((int)2982, (FloatBuffer)model);
            ++backupDepth;
        }
    }

    private static void restoreMatrices() {
        if (backupDepth > 0) {
            FloatBuffer proj = PROJ_BACKUPS[--backupDepth];
            FloatBuffer model = MODEL_BACKUPS[backupDepth];
            ((Buffer)proj).rewind();
            ((Buffer)model).rewind();
            GL11.glMatrixMode((int)5889);
            GL11.glLoadMatrix((FloatBuffer)proj);
            GL11.glMatrixMode((int)5888);
            GL11.glLoadMatrix((FloatBuffer)model);
        }
    }

    private FloatingLines() {
    }

    public static void render(float alpha) {
        if (!((alpha = Math.max(0.0f, Math.min(0.45f, alpha))) < 0.01f) && FloatingLines.ensureProgram()) {
            int screenW = Display.getWidth();
            int screenH = Display.getHeight();
            if (screenW > 0 && screenH > 0) {
                float rawMX = Mouse.getX();
                float rawMY = Mouse.getY();
                float damping = 0.05f;
                if (smoothMouseX < -900.0f) {
                    smoothMouseX = rawMX;
                    smoothMouseY = rawMY;
                }
                smoothMouseX += (rawMX - smoothMouseX) * damping;
                smoothMouseY += (rawMY - smoothMouseY) * damping;
                float targetInf = rawMX >= 0.0f && rawMX <= (float)screenW && rawMY >= 0.0f && rawMY <= (float)screenH ? 1.0f : 0.0f;
                bendInfluence += (targetInf - bendInfluence) * damping;
                float pStrength = 0.2f;
                float centerX = (float)screenW / 2.0f;
                float centerY = (float)screenH / 2.0f;
                float targetPX = (rawMX - centerX) / (float)screenW * pStrength;
                float targetPY = -((rawMY - centerY) / (float)screenH) * pStrength;
                parallaxX += (targetPX - parallaxX) * damping;
                parallaxY += (targetPY - parallaxY) * damping;
                float iTime = (float)(System.currentTimeMillis() - startTime) / 1000.0f;
                GL11.glPushAttrib((int)286977);
                FloatingLines.backupMatrices();
                GL11.glMatrixMode((int)5889);
                GL11.glLoadIdentity();
                GL11.glOrtho((double)0.0, (double)screenW, (double)0.0, (double)screenH, (double)-1.0, (double)1.0);
                GL11.glMatrixMode((int)5888);
                GL11.glLoadIdentity();
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glDisable((int)3553);
                GL11.glDisable((int)2929);
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
                GL20.glUseProgram((int)program);
                FloatingLines.setFloat("iTime", iTime);
                FloatingLines.setFloat3("iResolution", screenW, screenH, 1.0f);
                FloatingLines.setFloat("animationSpeed", 1.0f);
                FloatingLines.setBool("enableTop", true);
                FloatingLines.setBool("enableMiddle", true);
                FloatingLines.setBool("enableBottom", true);
                FloatingLines.setInt("topLineCount", 6);
                FloatingLines.setInt("middleLineCount", 6);
                FloatingLines.setInt("bottomLineCount", 6);
                FloatingLines.setFloat("topLineDistance", 0.05f);
                FloatingLines.setFloat("middleLineDistance", 0.05f);
                FloatingLines.setFloat("bottomLineDistance", 0.05f);
                FloatingLines.setFloat3("topWavePosition", 10.0f, 0.5f, -0.4f);
                FloatingLines.setFloat3("middleWavePosition", 5.0f, 0.0f, 0.2f);
                FloatingLines.setFloat3("bottomWavePosition", 2.0f, -0.7f, 0.4f);
                FloatingLines.setFloat2("iMouse", smoothMouseX, smoothMouseY);
                FloatingLines.setBool("interactive", true);
                FloatingLines.setFloat("bendRadius", 5.0f);
                FloatingLines.setFloat("bendStrength", -0.5f);
                FloatingLines.setFloat("bendInfluence", bendInfluence);
                FloatingLines.setBool("parallax", true);
                FloatingLines.setFloat("parallaxStrength", pStrength);
                FloatingLines.setFloat2("parallaxOffset", parallaxX, parallaxY);
                FloatingLines.setFloat("globalAlpha", alpha);
                FloatingLines.setBool("clipEnabled", false);
                float[][] grads = dynamicGradient != null ? dynamicGradient : DEFAULT_GRADIENT;
                FloatingLines.setInt("lineGradientCount", grads.length);
                for (int i = 0; i < grads.length; ++i) {
                    FloatingLines.setFloat3("lineGradient[" + i + "]", grads[i][0], grads[i][1], grads[i][2]);
                }
                GL11.glBegin((int)7);
                GL11.glVertex2f((float)0.0f, (float)0.0f);
                GL11.glVertex2f((float)screenW, (float)0.0f);
                GL11.glVertex2f((float)screenW, (float)screenH);
                GL11.glVertex2f((float)0.0f, (float)screenH);
                GL11.glEnd();
                GL20.glUseProgram((int)0);
                FloatingLines.restoreMatrices();
                GL11.glPopAttrib();
            }
        }
    }

    public static void renderRegion(float guiX, float guiY, float guiW, float guiH, float alpha) {
        FloatingLines.renderRegion(guiX, guiY, guiW, guiH, 0.0f, alpha);
    }

    public static void renderRegion(float guiX, float guiY, float guiW, float guiH, float cornerRadius, float alpha) {
        if (!((alpha = Math.max(0.0f, Math.min(0.45f, alpha))) < 0.01f) && !(guiW <= 0.0f) && !(guiH <= 0.0f) && FloatingLines.ensureProgram()) {
            int screenW = Display.getWidth();
            int screenH = Display.getHeight();
            if (screenW > 0 && screenH > 0) {
                int scale = ScissorUtil.getScaleFactor();
                int px = Math.round(guiX * (float)scale);
                int pw = Math.round(guiW * (float)scale);
                int ph = Math.round(guiH * (float)scale);
                int py = Math.round(((float)ScissorUtil.getScaledHeight() - (guiY + guiH)) * (float)scale);
                if (pw > 0 && ph > 0) {
                    float clipR = Math.max(0.0f, cornerRadius) * (float)scale;
                    boolean clipRounded = clipR > 0.5f;
                    float iTime = (float)(System.currentTimeMillis() - startTime) / 1000.0f;
                    GL11.glPushAttrib((int)28672);
                    GL11.glEnable((int)3089);
                    GL11.glScissor((int)px, (int)py, (int)pw, (int)ph);
                    FloatingLines.backupMatrices();
                    GL11.glMatrixMode((int)5889);
                    GL11.glLoadIdentity();
                    GL11.glOrtho((double)0.0, (double)screenW, (double)0.0, (double)screenH, (double)-1.0, (double)1.0);
                    GL11.glMatrixMode((int)5888);
                    GL11.glLoadIdentity();
                    GL11.glEnable((int)3042);
                    GL11.glBlendFunc((int)770, (int)771);
                    GL11.glDisable((int)3553);
                    GL11.glDisable((int)2929);
                    GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
                    GL20.glUseProgram((int)program);
                    FloatingLines.setFloat("iTime", iTime);
                    FloatingLines.setFloat3("iResolution", screenW, screenH, 1.0f);
                    FloatingLines.setFloat("animationSpeed", 1.0f);
                    FloatingLines.setBool("enableTop", true);
                    FloatingLines.setBool("enableMiddle", true);
                    FloatingLines.setBool("enableBottom", true);
                    FloatingLines.setInt("topLineCount", 4);
                    FloatingLines.setInt("middleLineCount", 4);
                    FloatingLines.setInt("bottomLineCount", 4);
                    FloatingLines.setFloat("topLineDistance", 0.05f);
                    FloatingLines.setFloat("middleLineDistance", 0.05f);
                    FloatingLines.setFloat("bottomLineDistance", 0.05f);
                    FloatingLines.setFloat3("topWavePosition", 10.0f, 0.5f, -0.4f);
                    FloatingLines.setFloat3("middleWavePosition", 5.0f, 0.0f, 0.2f);
                    FloatingLines.setFloat3("bottomWavePosition", 2.0f, -0.7f, 0.4f);
                    FloatingLines.setFloat2("iMouse", (float)px + (float)pw * 0.5f, (float)py + (float)ph * 0.5f);
                    FloatingLines.setBool("interactive", false);
                    FloatingLines.setFloat("bendRadius", 5.0f);
                    FloatingLines.setFloat("bendStrength", -0.5f);
                    FloatingLines.setFloat("bendInfluence", 0.0f);
                    FloatingLines.setBool("parallax", false);
                    FloatingLines.setFloat("parallaxStrength", 0.0f);
                    FloatingLines.setFloat2("parallaxOffset", 0.0f, 0.0f);
                    FloatingLines.setFloat("globalAlpha", alpha);
                    FloatingLines.setBool("clipEnabled", clipRounded);
                    if (clipRounded) {
                        FloatingLines.setFloat4("clipRect", px, py, pw, ph);
                        FloatingLines.setFloat("clipRadius", clipR);
                    }
                    float[][] grads = dynamicGradient != null ? dynamicGradient : DEFAULT_GRADIENT;
                    FloatingLines.setInt("lineGradientCount", grads.length);
                    for (int i = 0; i < grads.length; ++i) {
                        FloatingLines.setFloat3("lineGradient[" + i + "]", grads[i][0], grads[i][1], grads[i][2]);
                    }
                    float x1 = px;
                    float y1 = py;
                    float x2 = px + pw;
                    float y2 = py + ph;
                    GL11.glBegin((int)7);
                    GL11.glVertex2f((float)x1, (float)y1);
                    GL11.glVertex2f((float)x2, (float)y1);
                    GL11.glVertex2f((float)x2, (float)y2);
                    GL11.glVertex2f((float)x1, (float)y2);
                    GL11.glEnd();
                    GL20.glUseProgram((int)0);
                    FloatingLines.restoreMatrices();
                    GL11.glPopAttrib();
                }
            }
        }
    }

    private static boolean ensureProgram() {
        if (program != -1) {
            return true;
        }
        if (initFailed) {
            return false;
        }
        try {
            int vs = GL20.glCreateShader((int)35633);
            GL20.glShaderSource((int)vs, (CharSequence)VERT_SIMPLE);
            GL20.glCompileShader((int)vs);
            if (GL20.glGetShaderi((int)vs, (int)35713) == 0) {
                String log = GL20.glGetShaderInfoLog((int)vs, (int)2048);
                Logger.warn("[FloatingLines] Vertex shader compile failed: " + log);
                GL20.glDeleteShader((int)vs);
                initFailed = true;
                return false;
            }
            int fs = GL20.glCreateShader((int)35632);
            GL20.glShaderSource((int)fs, (CharSequence)FRAG);
            GL20.glCompileShader((int)fs);
            if (GL20.glGetShaderi((int)fs, (int)35713) == 0) {
                String log = GL20.glGetShaderInfoLog((int)fs, (int)2048);
                Logger.warn("[FloatingLines] Fragment shader compile failed: " + log);
                GL20.glDeleteShader((int)vs);
                GL20.glDeleteShader((int)fs);
                initFailed = true;
                return false;
            }
            program = GL20.glCreateProgram();
            GL20.glAttachShader((int)program, (int)vs);
            GL20.glAttachShader((int)program, (int)fs);
            GL20.glLinkProgram((int)program);
            if (GL20.glGetProgrami((int)program, (int)35714) == 0) {
                String log = GL20.glGetProgramInfoLog((int)program, (int)2048);
                Logger.warn("[FloatingLines] Program link failed: " + log);
                GL20.glDeleteProgram((int)program);
                program = -1;
                GL20.glDeleteShader((int)vs);
                GL20.glDeleteShader((int)fs);
                initFailed = true;
                return false;
            }
            GL20.glDeleteShader((int)vs);
            GL20.glDeleteShader((int)fs);
            Logger.info("[FloatingLines] Shader compiled and linked OK.");
            return true;
        }
        catch (Exception e) {
            Logger.warn("[FloatingLines] Shader init exception: " + e.getMessage());
            initFailed = true;
            return false;
        }
    }

    private static void setFloat(String n, float v) {
        int l = GL20.glGetUniformLocation((int)program, (CharSequence)n);
        if (l >= 0) {
            GL20.glUniform1f((int)l, (float)v);
        }
    }

    private static void setInt(String n, int v) {
        int l = GL20.glGetUniformLocation((int)program, (CharSequence)n);
        if (l >= 0) {
            GL20.glUniform1i((int)l, (int)v);
        }
    }

    private static void setBool(String n, boolean v) {
        int l = GL20.glGetUniformLocation((int)program, (CharSequence)n);
        if (l >= 0) {
            GL20.glUniform1i((int)l, (int)(v ? 1 : 0));
        }
    }

    private static void setFloat2(String n, float x, float y) {
        int l = GL20.glGetUniformLocation((int)program, (CharSequence)n);
        if (l >= 0) {
            GL20.glUniform2f((int)l, (float)x, (float)y);
        }
    }

    private static void setFloat3(String n, float x, float y, float z) {
        int l = GL20.glGetUniformLocation((int)program, (CharSequence)n);
        if (l >= 0) {
            GL20.glUniform3f((int)l, (float)x, (float)y, (float)z);
        }
    }

    private static void setFloat4(String n, float x, float y, float z, float w) {
        int l = GL20.glGetUniformLocation((int)program, (CharSequence)n);
        if (l >= 0) {
            GL20.glUniform4f((int)l, (float)x, (float)y, (float)z, (float)w);
        }
    }

    public static void setAccentColor(Color c) {
        if (c == null) {
            dynamicGradient = null;
        } else {
            float r = (float)c.getRed() / 255.0f;
            float g = (float)c.getGreen() / 255.0f;
            float b = (float)c.getBlue() / 255.0f;
            float brightness = Math.max(r, Math.max(g, b));
            float darkBlend = Math.max(0.0f, 1.0f - brightness * 4.0f);
            float[] dark1 = new float[]{r * 0.4f + 0.04f * darkBlend, g * 0.4f + 0.04f * darkBlend, b * 0.4f + 0.04f * darkBlend};
            float[] mid = new float[]{r + 0.1f * darkBlend, g + 0.1f * darkBlend, b + 0.1f * darkBlend};
            float[] bright = new float[]{Math.min(r * 1.2f + 0.18f * darkBlend, 1.0f), Math.min(g * 1.2f + 0.18f * darkBlend, 1.0f), Math.min(b * 1.2f + 0.18f * darkBlend, 1.0f)};
            dynamicGradient = new float[][]{dark1, mid, bright};
        }
    }

    public static void cleanup() {
        if (program != -1) {
            GL20.glDeleteProgram((int)program);
        }
        program = -1;
        initFailed = false;
    }
}

