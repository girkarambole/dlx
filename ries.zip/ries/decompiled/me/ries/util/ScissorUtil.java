/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 */
package me.ries.util;

import java.util.ArrayDeque;
import java.util.Deque;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

public class ScissorUtil {
    private static final Deque<ScissorState> scissorStack = new ArrayDeque<ScissorState>();
    public static int actualHeight = -1;

    public static int getActualHeight() {
        return actualHeight != -1 ? actualHeight : Display.getHeight();
    }

    public static void push(double x, double y, double width, double height) {
        int scaleFactor = ScissorUtil.getScaleFactor();
        int realX = (int)Math.round(x * (double)scaleFactor);
        int realY = (int)Math.round(((double)ScissorUtil.getScaledHeight() - (y + height)) * (double)scaleFactor);
        int realW = (int)Math.round(width * (double)scaleFactor);
        int realH = (int)Math.round(height * (double)scaleFactor);
        if (realW < 0) {
            realW = 0;
        }
        if (realH < 0) {
            realH = 0;
        }
        if (!scissorStack.isEmpty()) {
            ScissorState parent = scissorStack.peek();
            int maxX = Math.min(realX + realW, parent.x + parent.w);
            int maxY = Math.min(realY + realH, parent.y + parent.h);
            realX = Math.max(realX, parent.x);
            realY = Math.max(realY, parent.y);
            realW = Math.max(0, maxX - realX);
            realH = Math.max(0, maxY - realY);
        }
        boolean wasEnabled = GL11.glIsEnabled((int)3089);
        scissorStack.push(new ScissorState(realX, realY, realW, realH, wasEnabled));
        GL11.glEnable((int)3089);
        GL11.glScissor((int)realX, (int)realY, (int)realW, (int)realH);
    }

    public static void pop() {
        if (!scissorStack.isEmpty()) {
            ScissorState removed = scissorStack.pop();
            if (scissorStack.isEmpty()) {
                if (!removed.wasEnabled) {
                    GL11.glDisable((int)3089);
                }
            } else {
                ScissorState parent = scissorStack.peek();
                GL11.glScissor((int)parent.x, (int)parent.y, (int)parent.w, (int)parent.h);
            }
        }
    }

    public static int getScaleFactor() {
        return 2;
    }

    public static int getScaledWidth() {
        return (int)Math.ceil((double)Display.getWidth() / (double)ScissorUtil.getScaleFactor());
    }

    public static int getScaledHeight() {
        return (int)Math.ceil((double)ScissorUtil.getActualHeight() / (double)ScissorUtil.getScaleFactor());
    }

    public static int mapMouseX(int rawMouseX) {
        int displayW = Display.getWidth();
        int scaledW = ScissorUtil.getScaledWidth();
        return displayW <= 0 ? 0 : (int)((long)rawMouseX * (long)scaledW / (long)displayW);
    }

    public static int mapMouseY(int rawMouseY) {
        int actualH = ScissorUtil.getActualHeight();
        int scaledH = ScissorUtil.getScaledHeight();
        if (actualH <= 0) {
            return 0;
        }
        int mapped = (int)((long)rawMouseY * (long)scaledH / (long)actualH);
        return scaledH - mapped - 1;
    }

    @Deprecated
    public static void enable(double x, double y, double width, double height) {
        ScissorUtil.push(x, y, width, height);
    }

    @Deprecated
    public static void disable() {
        ScissorUtil.pop();
    }

    @Deprecated
    public static double getScaleFactorDouble() {
        return ScissorUtil.getScaleFactor();
    }

    private static class ScissorState {
        final int x;
        final int y;
        final int w;
        final int h;
        final boolean wasEnabled;

        ScissorState(int x, int y, int w, int h, boolean wasEnabled) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.wasEnabled = wasEnabled;
        }
    }
}

