/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL20
 */
package me.ries.util;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class SDFUtil {
    private static final String VERTEX_SHADER = "#version 120\nvarying vec2 st;\nvoid main() {\n    st = gl_MultiTexCoord0.st;\n    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n}";
    private static final String FRAGMENT_SHADER = "#version 120\nuniform vec2 rectSize;\nuniform float radius;\nuniform vec4 color;\nuniform float outlineThickness;\nvarying vec2 st;\nfloat roundedBoxSDF(vec2 p, vec2 b, float r) {\n    vec2 q = abs(p) - b + r;\n    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;\n}\nvoid main() {\n    vec2 paddedSize = rectSize + vec2(3.0);\n    vec2 pixelPos = st * paddedSize;\n    vec2 halfSize = rectSize * 0.5;\n    vec2 p = pixelPos - (paddedSize * 0.5);\n    float d = roundedBoxSDF(p, halfSize, radius);\n    float alpha = 1.0;\n    if (outlineThickness > 0.0) {\n        float centerD = abs(d + outlineThickness * 0.5) - outlineThickness * 0.5;\n        alpha = 1.0 - smoothstep(0.0, 1.0, centerD);\n    } else {\n        alpha = 1.0 - smoothstep(0.0, 1.0, d);\n    }\n    if (alpha <= 0.0) discard;\n    gl_FragColor = vec4(color.rgb, color.a * alpha);\n}";
    private static int program = -1;
    private static int rectSizeUniform;
    private static int radiusUniform;
    private static int colorUniform;
    private static int outlineUniform;

    public static void init() {
        if (program == -1) {
            try {
                int vert = GL20.glCreateShader((int)35633);
                int frag = GL20.glCreateShader((int)35632);
                GL20.glShaderSource((int)vert, (CharSequence)VERTEX_SHADER);
                GL20.glShaderSource((int)frag, (CharSequence)FRAGMENT_SHADER);
                GL20.glCompileShader((int)vert);
                GL20.glCompileShader((int)frag);
                program = GL20.glCreateProgram();
                GL20.glAttachShader((int)program, (int)vert);
                GL20.glAttachShader((int)program, (int)frag);
                GL20.glLinkProgram((int)program);
                rectSizeUniform = GL20.glGetUniformLocation((int)program, (CharSequence)"rectSize");
                radiusUniform = GL20.glGetUniformLocation((int)program, (CharSequence)"radius");
                colorUniform = GL20.glGetUniformLocation((int)program, (CharSequence)"color");
                outlineUniform = GL20.glGetUniformLocation((int)program, (CharSequence)"outlineThickness");
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void drawRoundedRect(float x, float y, float width, float height, float radius, int color) {
        SDFUtil.draw(x, y, width, height, radius, 0.0f, color);
    }

    public static void drawRoundedOutline(float x, float y, float width, float height, float radius, float thickness, int color) {
        SDFUtil.draw(x, y, width, height, radius, thickness, color);
    }

    private static void draw(float x, float y, float width, float height, float radius, float outlineThickness, int color) {
        if (!(width <= 0.0f) && !(height <= 0.0f)) {
            SDFUtil.init();
            if (program != -1) {
                float a = (float)(color >> 24 & 0xFF) / 255.0f;
                float r = (float)(color >> 16 & 0xFF) / 255.0f;
                float g = (float)(color >> 8 & 0xFF) / 255.0f;
                float b = (float)(color & 0xFF) / 255.0f;
                if (!(a <= 0.0f)) {
                    GL11.glEnable((int)3042);
                    GL11.glBlendFunc((int)770, (int)771);
                    GL11.glDisable((int)3008);
                    GL11.glDisable((int)3553);
                    GL20.glUseProgram((int)program);
                    GL20.glUniform2f((int)rectSizeUniform, (float)width, (float)height);
                    GL20.glUniform1f((int)radiusUniform, (float)radius);
                    GL20.glUniform4f((int)colorUniform, (float)r, (float)g, (float)b, (float)a);
                    GL20.glUniform1f((int)outlineUniform, (float)outlineThickness);
                    float pad = 1.5f;
                    GL11.glBegin((int)7);
                    GL11.glTexCoord2f((float)0.0f, (float)0.0f);
                    GL11.glVertex2f((float)(x - pad), (float)(y - pad));
                    GL11.glTexCoord2f((float)0.0f, (float)1.0f);
                    GL11.glVertex2f((float)(x - pad), (float)(y + height + pad));
                    GL11.glTexCoord2f((float)1.0f, (float)1.0f);
                    GL11.glVertex2f((float)(x + width + pad), (float)(y + height + pad));
                    GL11.glTexCoord2f((float)1.0f, (float)0.0f);
                    GL11.glVertex2f((float)(x + width + pad), (float)(y - pad));
                    GL11.glEnd();
                    GL20.glUseProgram((int)0);
                    GL11.glEnable((int)3553);
                    GL11.glEnable((int)3008);
                    GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                }
            }
        }
    }
}

