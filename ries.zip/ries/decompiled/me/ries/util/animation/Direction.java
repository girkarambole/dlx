/*
 * Decompiled with CFR 0.152.
 */
package me.ries.util.animation;

public enum Direction {
    FORWARDS,
    BACKWARDS;


    public Direction opposite() {
        return this == FORWARDS ? BACKWARDS : FORWARDS;
    }

    public boolean forwards() {
        return this == FORWARDS;
    }

    public boolean backwards() {
        return this == BACKWARDS;
    }
}

