/*
 * Decompiled with CFR 0.152.
 */
package me.ries.util.animation;

import me.ries.util.animation.Direction;

public abstract class Animation {
    private long lastMS = System.currentTimeMillis();
    protected int duration;
    protected double endPoint;
    protected Direction direction;

    public Animation(int ms, double endPoint) {
        this(ms, endPoint, Direction.FORWARDS);
    }

    public Animation(int ms, double endPoint, Direction direction) {
        this.duration = ms;
        this.endPoint = endPoint;
        this.direction = direction;
    }

    public boolean finished(Direction direction) {
        return this.isDone() && this.direction == direction;
    }

    public void reset() {
        this.lastMS = System.currentTimeMillis();
    }

    public boolean isDone() {
        return System.currentTimeMillis() - this.lastMS > (long)this.duration;
    }

    public Direction getDirection() {
        return this.direction;
    }

    public Animation setDirection(Direction direction) {
        if (this.direction != direction) {
            this.direction = direction;
            long elapsed = System.currentTimeMillis() - this.lastMS;
            long remaining = Math.min((long)this.duration, elapsed);
            this.lastMS = System.currentTimeMillis() - ((long)this.duration - remaining);
        }
        return this;
    }

    public Double getOutput() {
        long elapsed = System.currentTimeMillis() - this.lastMS;
        double t = Math.min(1.0, (double)elapsed / (double)this.duration);
        if (this.direction.forwards()) {
            return this.isDone() ? this.endPoint : this.getEquation(t) * this.endPoint;
        }
        return this.isDone() ? 0.0 : (1.0 - this.getEquation(t)) * this.endPoint;
    }

    protected abstract double getEquation(double var1);
}

