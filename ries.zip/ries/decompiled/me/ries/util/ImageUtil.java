/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.GL11
 */
package me.ries.util;

import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class ImageUtil {
    private static final Map<String, Integer> textureCache = new HashMap<String, Integer>();

    public static int getTexture(String path, boolean makeWhite) {
        if (textureCache.containsKey(path)) {
            return textureCache.get(path);
        }
        try {
            File f = new File(path);
            if (!f.exists()) {
                System.out.println("Image not found: " + path);
                return -1;
            }
            BufferedImage image = ImageIO.read(f);
            if (image == null) {
                return -1;
            }
            int[] pixels = new int[image.getWidth() * image.getHeight()];
            image.getRGB(0, 0, image.getWidth(), image.getHeight(), pixels, 0, image.getWidth());
            ByteBuffer buffer = BufferUtils.createByteBuffer((int)(image.getWidth() * image.getHeight() * 4));
            for (int i = 0; i < pixels.length; ++i) {
                int pixel = pixels[i];
                int a = pixel >> 24 & 0xFF;
                int r = pixel >> 16 & 0xFF;
                int g = pixel >> 8 & 0xFF;
                int b = pixel & 0xFF;
                if (makeWhite && a > 0) {
                    r = 255;
                    g = 255;
                    b = 255;
                }
                buffer.put((byte)r);
                buffer.put((byte)g);
                buffer.put((byte)b);
                buffer.put((byte)a);
            }
            ByteBuffer tempBuffer = buffer;
            ((Buffer)tempBuffer).flip();
            int textureID = GL11.glGenTextures();
            GL11.glBindTexture((int)3553, (int)textureID);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10242, (int)10496);
            GL11.glTexParameteri((int)3553, (int)10243, (int)10496);
            GL11.glTexImage2D((int)3553, (int)0, (int)32856, (int)image.getWidth(), (int)image.getHeight(), (int)0, (int)6408, (int)5121, (ByteBuffer)buffer);
            textureCache.put(path, textureID);
            return textureID;
        }
        catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public static void drawImage(int textureId, float x, float y, float w, float h, int color) {
        if (textureId != -1) {
            GL11.glEnable((int)3553);
            GL11.glEnable((int)3042);
            GL11.glBindTexture((int)3553, (int)textureId);
            float a = (float)(color >> 24 & 0xFF) / 255.0f;
            float r = (float)(color >> 16 & 0xFF) / 255.0f;
            float g = (float)(color >> 8 & 0xFF) / 255.0f;
            float b = (float)(color & 0xFF) / 255.0f;
            GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
            GL11.glBegin((int)7);
            GL11.glTexCoord2f((float)0.0f, (float)0.0f);
            GL11.glVertex2f((float)x, (float)y);
            GL11.glTexCoord2f((float)0.0f, (float)1.0f);
            GL11.glVertex2f((float)x, (float)(y + h));
            GL11.glTexCoord2f((float)1.0f, (float)1.0f);
            GL11.glVertex2f((float)(x + w), (float)(y + h));
            GL11.glTexCoord2f((float)1.0f, (float)0.0f);
            GL11.glVertex2f((float)(x + w), (float)y);
            GL11.glEnd();
            GL11.glBindTexture((int)3553, (int)0);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)3042);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
    }
}

