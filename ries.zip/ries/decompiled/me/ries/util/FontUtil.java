/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.GL11
 */
package me.ries.util;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Method;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import me.ries.mapping.MinecraftMapper;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public final class FontUtil {
    public static final int DEFAULT_HEIGHT = 16;
    private static final String[] FONT_PATHS = new String[]{"C:\\ries\\fonts\\wachenfont.ttf", "C:\\ries\\fonts\\ammminoglufont.ttf"};
    private static final int FONT_SIZE = 18;
    private static final int FIRST_CHAR = 32;
    private static final int LAST_CHAR = 1024;
    private static final int GLYPH_PADDING = 4;
    private static final Glyph[] GLYPHS = new Glyph[1025];
    private static volatile Method drawStringMethod;
    private static volatile Method stringWidthMethod;
    private static boolean customFontAttempted;
    private static boolean customFontReady;
    private static int textureId;
    private static int atlasWidth;
    private static int atlasHeight;
    private static int lineHeight;
    private static float heightScale;

    private FontUtil() {
    }

    public static boolean isReady() {
        return FontUtil.ensureCustomFont() || FontUtil.getFontRenderer() != null && FontUtil.getDrawStringMethod() != null;
    }

    public static boolean drawString(String string, float f, float f2, int n) {
        return FontUtil.drawString(string, f, f2, n, false, 1.0f);
    }

    public static boolean drawStringWithShadow(String string, float f, float f2, int n) {
        return FontUtil.drawString(string, f, f2, n, true, 1.0f);
    }

    public static boolean drawString(String string, float f, float f2, int n, boolean bl) {
        return FontUtil.drawString(string, f, f2, n, bl, 1.0f);
    }

    public static boolean drawString(String string, float f, float f2, int n, boolean bl, float f3) {
        if (string != null && string.length() != 0 && FontUtil.alpha(n) > 0 && !(f3 <= 0.0f)) {
            if (FontUtil.ensureCustomFont()) {
                if (bl) {
                    FontUtil.drawCustomString(string, f + f3, f2 + f3, FontUtil.shadowColor(n), f3);
                }
                FontUtil.drawCustomString(string, f, f2, n, f3);
                return true;
            }
            return FontUtil.drawMinecraftString(string, f, f2, n, bl, f3);
        }
        return false;
    }

    public static boolean drawCenteredString(String string, float f, float f2, int n, boolean bl, float f3) {
        return FontUtil.drawString(string, f - (float)FontUtil.getStringWidth(string) * f3 / 2.0f, f2, n, bl, f3);
    }

    public static int getStringWidth(String string) {
        if (string != null && string.length() != 0) {
            if (FontUtil.ensureCustomFont()) {
                float f = 0.0f;
                for (int i = 0; i < string.length(); ++i) {
                    char c = string.charAt(i);
                    if (c == '\u00a7' && i + 1 < string.length()) {
                        ++i;
                        continue;
                    }
                    Glyph glyph = FontUtil.glyph(c);
                    f += glyph == null ? 16.0f / heightScale : (float)glyph.advance;
                }
                return Math.round(f * heightScale);
            }
            return FontUtil.getMinecraftStringWidth(string);
        }
        return 0;
    }

    public static int getFontHeight() {
        return 16;
    }

    public static int getHeight() {
        return FontUtil.getFontHeight();
    }

    public static String trimToWidth(String string, int n, float f) {
        if (string == null) {
            return "";
        }
        if (n > 0 && !(f <= 0.0f)) {
            StringBuilder stringBuilder;
            if ((float)FontUtil.getStringWidth(string) * f <= (float)n) {
                return string;
            }
            String string2 = "...";
            String string3 = string;
            while (string3.length() > 0 && (float)FontUtil.getStringWidth((stringBuilder = new StringBuilder()).append(string3).append(string2).toString()) * f > (float)n) {
                string3 = string3.substring(0, string3.length() - 1);
            }
            return string3.length() == 0 ? string2 : string3 + string2;
        }
        return "";
    }

    private static boolean ensureCustomFont() {
        if (customFontReady && textureId > 0) {
            return true;
        }
        if (customFontAttempted && !customFontReady) {
            return false;
        }
        customFontAttempted = true;
        try {
            File file = FontUtil.findFontFile();
            if (file == null) {
                Logger.warn("FontUtil custom font not found in C:\\ries\\fonts");
                return false;
            }
            Font font = Font.createFont(0, file).deriveFont(0, 18.0f);
            BufferedImage bufferedImage = new BufferedImage(1, 1, 2);
            Graphics2D graphics2D = bufferedImage.createGraphics();
            FontUtil.setupGraphics(graphics2D);
            graphics2D.setFont(font);
            FontMetrics fontMetrics = graphics2D.getFontMetrics();
            lineHeight = Math.max(16, fontMetrics.getHeight());
            heightScale = 16.0f / (float)lineHeight;
            atlasWidth = 1024;
            int n = lineHeight + 8;
            atlasHeight = FontUtil.nextPowerOfTwo(FontUtil.calculateAtlasHeight(fontMetrics, n));
            BufferedImage bufferedImage2 = new BufferedImage(atlasWidth, atlasHeight, 2);
            Graphics2D graphics2D2 = bufferedImage2.createGraphics();
            FontUtil.setupGraphics(graphics2D2);
            graphics2D2.setComposite(AlphaComposite.Clear);
            graphics2D2.fillRect(0, 0, atlasWidth, atlasHeight);
            graphics2D2.setComposite(AlphaComposite.SrcOver);
            graphics2D2.setFont(font);
            graphics2D2.setColor(Color.WHITE);
            int n2 = 4;
            int n3 = 4;
            for (int i = 32; i <= 1024; ++i) {
                int n4 = Math.max(1, fontMetrics.charWidth((char)i));
                int n5 = n4 + 8;
                if (n2 + n5 >= atlasWidth) {
                    n2 = 4;
                    n3 += n;
                }
                if (n3 + n >= atlasHeight) break;
                graphics2D2.drawString(String.valueOf((char)i), n2 + 4, n3 + 4 + fontMetrics.getAscent());
                FontUtil.GLYPHS[i] = new Glyph(n2, n3, n5, n, n4);
                n2 += n5;
            }
            graphics2D.dispose();
            graphics2D2.dispose();
            FontUtil.uploadTexture(bufferedImage2);
            customFontReady = true;
            Logger.info("FontUtil loaded custom font: " + file.getAbsolutePath());
            return true;
        }
        catch (Throwable throwable) {
            Logger.warn("FontUtil custom font failed: " + throwable.getMessage());
            customFontReady = false;
            return false;
        }
    }

    private static File findFontFile() {
        for (String string : FONT_PATHS) {
            File file = new File(string);
            if (!file.isFile()) continue;
            return file;
        }
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void drawCustomString(String string, float f, float f2, int n, float f3) {
        float f4 = f3 * heightScale;
        float f5 = 0.0f;
        GL11.glPushMatrix();
        try {
            GL11.glTranslatef((float)f, (float)f2, (float)0.0f);
            GL11.glScalef((float)f4, (float)f4, (float)1.0f);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glBindTexture((int)3553, (int)textureId);
            int n2 = n;
            FontUtil.setColor(n2);
            GL11.glBegin((int)7);
            for (int i = 0; i < string.length(); ++i) {
                char c;
                int n3;
                char c2 = string.charAt(i);
                if (c2 == '\u00a7' && i + 1 < string.length() && (n3 = "0123456789abcdefklmnor".indexOf(c = string.charAt(i + 1))) >= 0) {
                    ++i;
                    if (n3 < 16) {
                        int[] nArray = new int[]{0, 170, 43520, 43690, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA, 0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF};
                        int n4 = nArray[n3];
                        int n5 = FontUtil.alpha(n2);
                        n2 = n5 << 24 | n4;
                        GL11.glEnd();
                        FontUtil.setColor(n2);
                        GL11.glBegin((int)7);
                        continue;
                    }
                    if (c != 'r') continue;
                    n2 = n;
                    GL11.glEnd();
                    FontUtil.setColor(n2);
                    GL11.glBegin((int)7);
                    continue;
                }
                Glyph glyph = FontUtil.glyph(c2);
                if (glyph == null) {
                    f5 += 16.0f / heightScale;
                    continue;
                }
                float f6 = f5 - 4.0f;
                float f7 = -4.0f;
                float f8 = f6 + (float)glyph.width;
                float f9 = f7 + (float)glyph.height;
                float f10 = ((float)glyph.x + 0.5f) / (float)atlasWidth;
                float f11 = ((float)glyph.y + 0.5f) / (float)atlasHeight;
                float f12 = ((float)(glyph.x + glyph.width) - 0.5f) / (float)atlasWidth;
                float f13 = ((float)(glyph.y + glyph.height) - 0.5f) / (float)atlasHeight;
                GL11.glTexCoord2f((float)f10, (float)f11);
                GL11.glVertex2f((float)f6, (float)f7);
                GL11.glTexCoord2f((float)f10, (float)f13);
                GL11.glVertex2f((float)f6, (float)f9);
                GL11.glTexCoord2f((float)f12, (float)f13);
                GL11.glVertex2f((float)f8, (float)f9);
                GL11.glTexCoord2f((float)f12, (float)f11);
                GL11.glVertex2f((float)f8, (float)f7);
                f5 += (float)glyph.advance;
            }
            GL11.glEnd();
            GL11.glBindTexture((int)3553, (int)0);
        }
        finally {
            GL11.glPopMatrix();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static boolean drawMinecraftString(String string, float f, float f2, int n, boolean bl, float f3) {
        try {
            Object object = FontUtil.getFontRenderer();
            Method method = FontUtil.getDrawStringMethod();
            if (object != null && method != null) {
                GL11.glPushMatrix();
                try {
                    GL11.glScalef((float)f3, (float)f3, (float)1.0f);
                    method.invoke(object, string, Float.valueOf(f / f3), Float.valueOf(f2 / f3), n, bl);
                }
                finally {
                    GL11.glPopMatrix();
                }
                return true;
            }
            return false;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private static int getMinecraftStringWidth(String string) {
        try {
            Object object;
            Object object2 = FontUtil.getFontRenderer();
            Method method = FontUtil.getStringWidthMethod(object2);
            if (object2 != null && method != null && (object = method.invoke(object2, string)) instanceof Number) {
                return ((Number)object).intValue();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return string.length() * 6;
    }

    private static Object getFontRenderer() {
        return MinecraftMapper.getFontRenderer();
    }

    private static Method getDrawStringMethod() {
        Method method = drawStringMethod;
        if (method != null) {
            return method;
        }
        Method method2 = MappingUtils.getMethod("FontRenderer.drawString");
        if (method2 == null) {
            return null;
        }
        method2.setAccessible(true);
        drawStringMethod = method2;
        return method2;
    }

    private static Method getStringWidthMethod(Object object) {
        Method[] methodArray;
        Method method = stringWidthMethod;
        if (method != null) {
            return method;
        }
        if (object == null) {
            return null;
        }
        Method method2 = MappingUtils.getMethod("FontRenderer.getStringWidth");
        if (method2 != null) {
            method2.setAccessible(true);
            stringWidthMethod = method2;
            return method2;
        }
        for (Method method3 : methodArray = object.getClass().getDeclaredMethods()) {
            Class<?>[] classArray = method3.getParameterTypes();
            if (classArray.length != 1 || classArray[0] != String.class || method3.getReturnType() != Integer.TYPE) continue;
            method3.setAccessible(true);
            stringWidthMethod = method3;
            return method3;
        }
        return null;
    }

    private static Glyph glyph(char c) {
        return c >= ' ' && c <= '\u0400' ? GLYPHS[c] : GLYPHS[63];
    }

    private static void uploadTexture(BufferedImage bufferedImage) {
        int[] nArray = new int[bufferedImage.getWidth() * bufferedImage.getHeight()];
        bufferedImage.getRGB(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight(), nArray, 0, bufferedImage.getWidth());
        ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)(bufferedImage.getWidth() * bufferedImage.getHeight() * 4));
        for (int n : nArray) {
            byteBuffer.put((byte)(n >> 16 & 0xFF));
            byteBuffer.put((byte)(n >> 8 & 0xFF));
            byteBuffer.put((byte)(n & 0xFF));
            byteBuffer.put((byte)(n >> 24 & 0xFF));
        }
        Object object = byteBuffer;
        ((Buffer)object).flip();
        textureId = GL11.glGenTextures();
        GL11.glBindTexture((int)3553, (int)textureId);
        GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
        GL11.glTexParameteri((int)3553, (int)10242, (int)10496);
        GL11.glTexParameteri((int)3553, (int)10243, (int)10496);
        GL11.glTexImage2D((int)3553, (int)0, (int)32856, (int)bufferedImage.getWidth(), (int)bufferedImage.getHeight(), (int)0, (int)6408, (int)5121, (ByteBuffer)byteBuffer);
        GL11.glBindTexture((int)3553, (int)0);
    }

    private static void setupGraphics(Graphics2D graphics2D) {
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    }

    private static int nextPowerOfTwo(int n) {
        int n2;
        for (n2 = 1; n2 < n; n2 <<= 1) {
        }
        return n2;
    }

    private static int calculateAtlasHeight(FontMetrics fontMetrics, int n) {
        int n2 = 4;
        int n3 = 4;
        for (int i = 32; i <= 1024; ++i) {
            int n4 = Math.max(1, fontMetrics.charWidth((char)i));
            int n5 = n4 + 8;
            if (n2 + n5 >= atlasWidth) {
                n2 = 4;
                n3 += n;
            }
            n2 += n5;
        }
        return n3 + n + 4;
    }

    private static void setColor(int n) {
        float f = (float)FontUtil.alpha(n) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f);
    }

    private static int shadowColor(int n) {
        int n2 = FontUtil.alpha(n);
        return n2 << 24;
    }

    private static int alpha(int n) {
        return n >>> 24 & 0xFF;
    }

    static {
        textureId = -1;
        lineHeight = 16;
        heightScale = 1.0f;
    }

    private static final class Glyph {
        private final int x;
        private final int y;
        private final int width;
        private final int height;
        private final int advance;

        private Glyph(int n, int n2, int n3, int n4, int n5) {
            this.x = n;
            this.y = n2;
            this.width = n3;
            this.height = n4;
            this.advance = n5;
        }
    }
}

