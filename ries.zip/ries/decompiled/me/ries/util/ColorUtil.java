/*
 * Decompiled with CFR 0.152.
 */
package me.ries.util;

import java.awt.Color;
import java.util.regex.Pattern;

public final class ColorUtil {
    private final Pattern COLOR_PATTERN = Pattern.compile("(?i)\u00c3\u201a\u00c2\u00a7[0-9A-FK-OR]");

    public static Color liveColorBrighter(Color c, float factor) {
        return ColorUtil.brighter(c, factor);
    }

    public Color liveColorDarker(Color c, float factor) {
        return this.darker(c, factor);
    }

    public static Color brighter(Color c, float factor) {
        int r = c.getRed();
        int g = c.getGreen();
        int b = c.getBlue();
        int alpha = c.getAlpha();
        int i = (int)(1.0 / (1.0 - (double)factor));
        if (r == 0 && g == 0 && b == 0) {
            return new Color(i, i, i, alpha);
        }
        if (r > 0 && r < i) {
            r = i;
        }
        if (g > 0 && g < i) {
            g = i;
        }
        if (b > 0 && b < i) {
            b = i;
        }
        return new Color(Math.min((int)((float)r / factor), 255), Math.min((int)((float)g / factor), 255), Math.min((int)((float)b / factor), 255), alpha);
    }

    public Color darker(Color c, double FACTOR) {
        return new Color(Math.max((int)((double)c.getRed() * FACTOR), 0), Math.max((int)((double)c.getGreen() * FACTOR), 0), Math.max((int)((double)c.getBlue() * FACTOR), 0), c.getAlpha());
    }

    public static int getColor(float hueoffset, float saturation, float brightness) {
        float speed = 4500.0f;
        float hue = (float)(System.currentTimeMillis() % 4500L) / 4500.0f;
        return Color.HSBtoRGB(hue - hueoffset / 54.0f, saturation, brightness);
    }

    public static int getStaticColor(float hueoffset, float saturation, float brightness) {
        return Color.HSBtoRGB(hueoffset / 54.0f, saturation, brightness);
    }

    public Color blend2colors(Color color1, Color color2, double offset) {
        float hue = System.currentTimeMillis();
        if ((offset += (double)hue) > 1.0) {
            double left = offset % 1.0;
            int off = (int)offset;
            offset = off % 2 == 0 ? left : 1.0 - left;
        }
        double inversePercent = 1.0 - offset;
        int redPart = (int)((double)color1.getRed() * inversePercent + (double)color2.getRed() * offset);
        int greenPart = (int)((double)color1.getGreen() * inversePercent + (double)color2.getGreen() * offset);
        int bluePart = (int)((double)color1.getBlue() * inversePercent + (double)color2.getBlue() * offset);
        return new Color(redPart, greenPart, bluePart);
    }

    public static int getRainbow() {
        float hue = (float)(System.currentTimeMillis() % 10000L) / 10000.0f;
        return Color.HSBtoRGB(hue, 0.5f, 1.0f);
    }

    public String stripColor(String text) {
        return this.COLOR_PATTERN.matcher(text).replaceAll("");
    }

    public static Color mixColors(Color color1, Color color2, double percent) {
        double inverse_percent = 1.0 - percent;
        int redPart = (int)((double)color1.getRed() * percent + (double)color2.getRed() * inverse_percent);
        int greenPart = (int)((double)color1.getGreen() * percent + (double)color2.getGreen() * inverse_percent);
        int bluePart = (int)((double)color1.getBlue() * percent + (double)color2.getBlue() * inverse_percent);
        return new Color(Math.max(0, Math.min(255, redPart)), Math.max(0, Math.min(255, greenPart)), Math.max(0, Math.min(255, bluePart)));
    }

    public static Color blendColors(float[] fractions, Color[] colors, float progress) {
        if (fractions == null) {
            throw new IllegalArgumentException("Fractions can't be null");
        }
        if (colors == null) {
            throw new IllegalArgumentException("Colours can't be null");
        }
        if (fractions.length == colors.length) {
            int[] getFractionBlack = ColorUtil.getFraction(fractions, progress);
            float[] range = new float[]{fractions[getFractionBlack[0]], fractions[getFractionBlack[1]]};
            Color[] colorRange = new Color[]{colors[getFractionBlack[0]], colors[getFractionBlack[1]]};
            float max = range[1] - range[0];
            float value = progress - range[0];
            float weight = value / max;
            return ColorUtil.blend(colorRange[0], colorRange[1], 1.0f - weight);
        }
        throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
    }

    public static int[] getFraction(float[] fractions, float progress) {
        int startPoint;
        int[] range = new int[2];
        for (startPoint = 0; startPoint < fractions.length && fractions[startPoint] <= progress; ++startPoint) {
        }
        if (startPoint >= fractions.length) {
            startPoint = fractions.length - 1;
        }
        range[0] = startPoint - 1;
        range[1] = startPoint;
        return range;
    }

    public static Color blend(Color color1, Color color2, double ratio) {
        float r = (float)ratio;
        float ir = 1.0f - r;
        float[] rgb1 = new float[3];
        float[] rgb2 = new float[3];
        color1.getColorComponents(rgb1);
        color2.getColorComponents(rgb2);
        float red = rgb1[0] * r + rgb2[0] * ir;
        float green = rgb1[1] * r + rgb2[1] * ir;
        float blue = rgb1[2] * r + rgb2[2] * ir;
        if (red < 0.0f) {
            red = 0.0f;
        } else if (red > 255.0f) {
            red = 255.0f;
        }
        if (green < 0.0f) {
            green = 0.0f;
        } else if (green > 255.0f) {
            green = 255.0f;
        }
        if (blue < 0.0f) {
            blue = 0.0f;
        } else if (blue > 255.0f) {
            blue = 255.0f;
        }
        Color color3 = null;
        try {
            color3 = new Color(red, green, blue);
        }
        catch (IllegalArgumentException exp) {
            exp.printStackTrace();
        }
        return color3;
    }

    public static Double interpolate(double oldValue, double newValue, double interpolationValue) {
        return oldValue + (newValue - oldValue) * interpolationValue;
    }

    public static int interpolateInt(int oldValue, int newValue, double interpolationValue) {
        return ColorUtil.interpolate(oldValue, newValue, (float)interpolationValue).intValue();
    }

    public static Color interpolateColorC(int color1, int color2, float amount) {
        amount = Math.min(1.0f, Math.max(0.0f, amount));
        return new Color(ColorUtil.interpolateInt(ColorUtil.getRed(color1), ColorUtil.getRed(color2), amount), ColorUtil.interpolateInt(ColorUtil.getGreen(color1), ColorUtil.getGreen(color2), amount), ColorUtil.interpolateInt(ColorUtil.getBlue(color1), ColorUtil.getBlue(color2), amount), ColorUtil.interpolateInt(ColorUtil.getAlpha(color1), ColorUtil.getAlpha(color2), amount));
    }

    public static Color TwoColorEffect(int cl1, int cl2, double speed, int index) {
        int angle = (int)(((double)System.currentTimeMillis() / speed + (double)index) % 360.0);
        angle = (angle >= 180 ? 360 - angle : angle) * 2;
        return ColorUtil.interpolateColorC(cl1, cl2, (float)angle / 360.0f);
    }

    public static int getRed(int hex) {
        return hex >> 16 & 0xFF;
    }

    public static int getGreen(int hex) {
        return hex >> 8 & 0xFF;
    }

    public static int getBlue(int hex) {
        return hex & 0xFF;
    }

    public static int getAlpha(int hex) {
        return hex >> 24 & 0xFF;
    }

    public static String getColor(int n) {
        if (n != 1) {
            if (n == 2) {
                return "\u00c3\u201a\u00c2\u00a7a";
            }
            if (n == 3) {
                return "\u00c3\u201a\u00c2\u00a73";
            }
            if (n == 4) {
                return "\u00c3\u201a\u00c2\u00a74";
            }
            if (n >= 5) {
                return "\u00c3\u201a\u00c2\u00a7e";
            }
        }
        return "\u00c3\u201a\u00c2\u00a7f";
    }

    public static Color applyOpacity(Color color, float opacity) {
        opacity = Math.min(1.0f, Math.max(0.0f, opacity));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * opacity));
    }

    public static int applyOpacity(int color, float opacity) {
        Color old = new Color(color);
        return ColorUtil.applyOpacity(old, opacity).getRGB();
    }

    public static Color getHealthColor(float healthPercent) {
        if (healthPercent > 0.6f) {
            return new Color(85, 255, 85);
        }
        return healthPercent > 0.25f ? new Color(255, 200, 0) : new Color(255, 85, 85);
    }

    public static Color getRainbow(int speed, int offset) {
        float hue = (float)((System.currentTimeMillis() + (long)offset) % (long)speed) / (float)speed;
        return Color.getHSBColor(hue, 0.45f, 1.0f);
    }
}
