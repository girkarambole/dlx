/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL20
 *  org.lwjgl.opengl.GL30
 */
package me.ries.util;

import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import me.ries.util.GLErrorChecker;
import me.ries.util.ScissorUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public class GaussianBlur {
    private static int blurProgram = -1;
    private static boolean shaderInitFailed = false;
    private static int texture1 = -1;
    private static int texture2 = -1;
    private static int fbo2 = -1;
    private static int lastWidth = 0;
    private static int lastHeight = 0;
    private static long renderFrameId = 0L;
    private static long preparedFrameId = -1L;
    private static float preparedRadius = -1.0f;
    private static final float RADIUS_CACHE_TOLERANCE = 0.35f;
    private static final float[] SIN = new float[361];
    private static final float[] COS = new float[361];
    private static final FloatBuffer[] PROJ_BACKUPS;
    private static final FloatBuffer[] MODEL_BACKUPS;
    private static int backupDepth;
    private static final String VERT_SRC = "#version 120\nvoid main() {\n    gl_TexCoord[0] = gl_MultiTexCoord0;\n    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n}";
    private static final String FRAG_SRC = "#version 120\nuniform sampler2D textureIn;\nuniform vec2 texelSize;\nuniform vec2 direction;\nuniform float radius;\nuniform float weights[256];\nvoid main() {\n    vec2 off = texelSize * direction;\n    vec3 col = texture2D(textureIn, gl_TexCoord[0].st).rgb * weights[0];\n    for (float f = 1.0; f <= radius; f++) {\n        int idx = int(f);\n        col += texture2D(textureIn, gl_TexCoord[0].st + f * off).rgb * weights[idx];\n        col += texture2D(textureIn, gl_TexCoord[0].st - f * off).rgb * weights[idx];\n    }\n    gl_FragColor = vec4(col, 1.0);\n}";
    private static final FloatBuffer weightBuffer;

    public static void beginFrame() {
        ++renderFrameId;
    }

    public static void invalidateFrameCache() {
        preparedFrameId = -1L;
        preparedRadius = -1.0f;
    }

    private static void backupMatrices() {
        if (backupDepth < PROJ_BACKUPS.length) {
            FloatBuffer proj = PROJ_BACKUPS[backupDepth];
            FloatBuffer model = MODEL_BACKUPS[backupDepth];
            FloatBuffer tempProj = proj;
            FloatBuffer tempModel = model;
            ((Buffer)tempProj).clear();
            ((Buffer)tempModel).clear();
            GL11.glGetFloat((int)2983, (FloatBuffer)proj);
            GL11.glGetFloat((int)2982, (FloatBuffer)model);
            ++backupDepth;
        }
    }

    private static void restoreMatrices() {
        if (backupDepth > 0) {
            FloatBuffer proj = PROJ_BACKUPS[--backupDepth];
            FloatBuffer model = MODEL_BACKUPS[backupDepth];
            FloatBuffer tempProj = proj;
            FloatBuffer tempModel = model;
            ((Buffer)tempProj).rewind();
            ((Buffer)tempModel).rewind();
            GL11.glMatrixMode((int)5889);
            GL11.glLoadMatrix((FloatBuffer)proj);
            GL11.glMatrixMode((int)5888);
            GL11.glLoadMatrix((FloatBuffer)model);
        }
    }

    private static boolean ensureShader() {
        if (blurProgram > 0) {
            return true;
        }
        if (shaderInitFailed) {
            return false;
        }
        try {
            int vs = GL20.glCreateShader((int)35633);
            GL20.glShaderSource((int)vs, (CharSequence)VERT_SRC);
            GL20.glCompileShader((int)vs);
            if (GL20.glGetShaderi((int)vs, (int)35713) == 0) {
                System.err.println("[GaussianBlur] Vertex shader compile error: " + GL20.glGetShaderInfoLog((int)vs, (int)1024));
                shaderInitFailed = true;
                return false;
            }
            int fs = GL20.glCreateShader((int)35632);
            GL20.glShaderSource((int)fs, (CharSequence)FRAG_SRC);
            GL20.glCompileShader((int)fs);
            if (GL20.glGetShaderi((int)fs, (int)35713) == 0) {
                System.err.println("[GaussianBlur] Fragment shader compile error: " + GL20.glGetShaderInfoLog((int)fs, (int)1024));
                shaderInitFailed = true;
                return false;
            }
            int prog = GL20.glCreateProgram();
            GL20.glAttachShader((int)prog, (int)vs);
            GL20.glAttachShader((int)prog, (int)fs);
            GL20.glLinkProgram((int)prog);
            if (GL20.glGetProgrami((int)prog, (int)35714) == 0) {
                System.err.println("[GaussianBlur] Program link error: " + GL20.glGetProgramInfoLog((int)prog, (int)1024));
                shaderInitFailed = true;
                return false;
            }
            blurProgram = prog;
            System.out.println("[GaussianBlur] Shader compiled OK.");
            return true;
        }
        catch (Exception e) {
            System.err.println("[GaussianBlur] Shader init exception: " + e.getMessage());
            shaderInitFailed = true;
            return false;
        }
    }

    private static boolean isTextureValid(int textureId) {
        if (textureId <= 0) {
            return false;
        }
        try {
            return GL11.glIsTexture((int)textureId);
        }
        catch (Exception var2) {
            return false;
        }
    }

    private static boolean isFBOValid(int fboId) {
        if (fboId <= 0) {
            return false;
        }
        try {
            return GL30.glIsFramebuffer((int)fboId);
        }
        catch (Exception var2) {
            return false;
        }
    }

    private static void cleanupResources() {
        if (texture1 > 0 && GaussianBlur.isTextureValid(texture1)) {
            GL11.glDeleteTextures((int)texture1);
        }
        if (texture2 > 0 && GaussianBlur.isTextureValid(texture2)) {
            GL11.glDeleteTextures((int)texture2);
        }
        if (fbo2 > 0 && GaussianBlur.isFBOValid(fbo2)) {
            GL30.glDeleteFramebuffers((int)fbo2);
        }
        texture1 = -1;
        texture2 = -1;
        fbo2 = -1;
        lastWidth = 0;
        lastHeight = 0;
    }

    private static boolean checkSetupFBO() {
        int w = Display.getWidth();
        int h = ScissorUtil.getActualHeight();
        if (w > 0 && h > 0) {
            if (texture1 != -1 && !GaussianBlur.isTextureValid(texture1)) {
                System.out.println("[GaussianBlur] Context loss detected, cleaning up...");
                GaussianBlur.cleanupResources();
            }
            if (texture1 != -1 && w == lastWidth && h == lastHeight) {
                return true;
            }
            GaussianBlur.invalidateFrameCache();
            GaussianBlur.cleanupResources();
            texture1 = GL11.glGenTextures();
            GL11.glBindTexture((int)3553, (int)texture1);
            GL11.glTexImage2D((int)3553, (int)0, (int)32856, (int)w, (int)h, (int)0, (int)6408, (int)5121, (ByteBuffer)null);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
            GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
            texture2 = GL11.glGenTextures();
            GL11.glBindTexture((int)3553, (int)texture2);
            GL11.glTexImage2D((int)3553, (int)0, (int)32856, (int)w, (int)h, (int)0, (int)6408, (int)5121, (ByteBuffer)null);
            GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
            GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
            GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
            fbo2 = GL30.glGenFramebuffers();
            GL30.glBindFramebuffer((int)36160, (int)fbo2);
            GL30.glFramebufferTexture2D((int)36160, (int)36064, (int)3553, (int)texture2, (int)0);
            int status = GL30.glCheckFramebufferStatus((int)36160);
            if (status != 36053) {
                System.err.println("[GaussianBlur] FBO not complete! Status: 0x" + Integer.toHexString(status));
                GL30.glBindFramebuffer((int)36160, (int)0);
                return false;
            }
            GL30.glBindFramebuffer((int)36160, (int)0);
            lastWidth = w;
            lastHeight = h;
            GLErrorChecker.check("GaussianBlur.checkSetupFBO");
            System.out.println("[GaussianBlur] FBO created: " + w + "x" + h);
            return true;
        }
        return false;
    }

    private static void setBlurUniforms(float dirX, float dirY, float radius) {
        int i;
        int w = Display.getWidth();
        int h = ScissorUtil.getActualHeight();
        GL20.glUniform1i((int)GL20.glGetUniformLocation((int)blurProgram, (CharSequence)"textureIn"), (int)0);
        GL20.glUniform2f((int)GL20.glGetUniformLocation((int)blurProgram, (CharSequence)"texelSize"), (float)(1.0f / (float)w), (float)(1.0f / (float)h));
        GL20.glUniform2f((int)GL20.glGetUniformLocation((int)blurProgram, (CharSequence)"direction"), (float)dirX, (float)dirY);
        GL20.glUniform1f((int)GL20.glGetUniformLocation((int)blurProgram, (CharSequence)"radius"), (float)radius);
        FloatBuffer tempWeightBuffer = weightBuffer;
        ((Buffer)tempWeightBuffer).clear();
        float total = 0.0f;
        int r = (int)radius;
        float sigma = radius / 2.0f;
        float[] weights = new float[r + 1];
        for (i = 0; i <= r; ++i) {
            weights[i] = GaussianBlur.gaussian(i, sigma);
            total += i == 0 ? weights[i] : weights[i] * 2.0f;
        }
        for (i = 0; i <= r; ++i) {
            weightBuffer.put(weights[i] / total);
        }
        FloatBuffer tempWeightBuffer2 = weightBuffer;
        ((Buffer)tempWeightBuffer2).flip();
        GL20.glUniform1((int)GL20.glGetUniformLocation((int)blurProgram, (CharSequence)"weights"), (FloatBuffer)weightBuffer);
    }

    private static float gaussian(float x, float sigma) {
        return (float)(Math.exp((double)(-(x * x)) / (2.0 * (double)sigma * (double)sigma)) / (Math.sqrt(Math.PI * 2) * (double)sigma));
    }

    private static void drawScreenQuad(float x, float y, float w, float h, int sw, int sh) {
        float u1 = x / (float)sw;
        float v1 = ((float)sh - y) / (float)sh;
        float u2 = (x + w) / (float)sw;
        float v2 = ((float)sh - y - h) / (float)sh;
        GL11.glBegin((int)7);
        GL11.glTexCoord2f((float)u1, (float)v1);
        GL11.glVertex2f((float)x, (float)y);
        GL11.glTexCoord2f((float)u1, (float)v2);
        GL11.glVertex2f((float)x, (float)(y + h));
        GL11.glTexCoord2f((float)u2, (float)v2);
        GL11.glVertex2f((float)(x + w), (float)(y + h));
        GL11.glTexCoord2f((float)u2, (float)v1);
        GL11.glVertex2f((float)(x + w), (float)y);
        GL11.glEnd();
    }

    private static void drawTexturedRoundedRect(float x, float y, float w, float h, float radius, int sw, int sh) {
        if ((radius = Math.min(radius, Math.min(w, h) / 2.0f)) < 0.0f) {
            radius = 0.0f;
        }
        int segments = (int)Math.min(Math.max(radius * 1.2f, 12.0f), 36.0f);
        GL11.glBegin((int)9);
        GaussianBlur.emitCornerVerts(x, y, w, h, radius, segments, 180, 270, sw, sh);
        GaussianBlur.emitCornerVerts(x, y, w, h, radius, segments, 270, 360, sw, sh);
        GaussianBlur.emitCornerVerts(x, y, w, h, radius, segments, 0, 90, sw, sh);
        GaussianBlur.emitCornerVerts(x, y, w, h, radius, segments, 90, 180, sw, sh);
        GL11.glEnd();
    }

    private static void emitCornerVerts(float x, float y, float w, float h, float radius, int segments, int startAngle, int endAngle, int sw, int sh) {
        float cx = x + (startAngle != 180 && startAngle != 90 ? w - radius : radius);
        float cy = y + (startAngle != 180 && startAngle != 270 ? h - radius : radius);
        for (int i = 0; i <= segments; ++i) {
            int angleDeg = startAngle + (endAngle - startAngle) * i / segments;
            int idx = angleDeg % 360;
            if (idx < 0) {
                idx += 360;
            }
            float px = cx + COS[idx] * radius;
            float py = cy + SIN[idx] * radius;
            float u = px / (float)sw;
            float v = ((float)sh - py) / (float)sh;
            GL11.glTexCoord2f((float)u, (float)v);
            GL11.glVertex2f((float)px, (float)py);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static boolean ensureFrameHorizontalBlur(float blurRadius) {
        if (blurRadius <= 0.0f) {
            return false;
        }
        if (!Display.isActive()) {
            return false;
        }
        if (preparedFrameId == renderFrameId && Math.abs(blurRadius - preparedRadius) <= 0.35f) {
            return true;
        }
        int screenW = Display.getWidth();
        int screenH = ScissorUtil.getActualHeight();
        if (screenW > 0 && screenH > 0) {
            if (GaussianBlur.ensureShader() && GaussianBlur.checkSetupFBO()) {
                boolean var5;
                int lastFBO = GL11.glGetInteger((int)36006);
                try {
                    boolean var4;
                    GL11.glPushAttrib((int)1048575);
                    GL11.glDisable((int)3089);
                    GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
                    GL11.glDepthMask((boolean)true);
                    GaussianBlur.backupMatrices();
                    GL11.glMatrixMode((int)5889);
                    GL11.glLoadIdentity();
                    GL11.glOrtho((double)0.0, (double)screenW, (double)screenH, (double)0.0, (double)-1.0, (double)1.0);
                    GL11.glMatrixMode((int)5888);
                    GL11.glLoadIdentity();
                    GL11.glDisable((int)2960);
                    GL11.glDisable((int)2929);
                    GL11.glDisable((int)3008);
                    GL11.glDisable((int)3042);
                    GL11.glDisable((int)2884);
                    GL11.glDisable((int)2896);
                    GL11.glEnable((int)3553);
                    GLErrorChecker.check("Blur - State Setup");
                    GL11.glBindTexture((int)3553, (int)texture1);
                    GL11.glCopyTexSubImage2D((int)3553, (int)0, (int)0, (int)0, (int)0, (int)0, (int)screenW, (int)screenH);
                    GLErrorChecker.check("Blur - glCopyTexSubImage2D");
                    GL30.glBindFramebuffer((int)36160, (int)fbo2);
                    GL11.glViewport((int)0, (int)0, (int)screenW, (int)screenH);
                    GL11.glClearColor((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
                    GL11.glClear((int)16384);
                    GLErrorChecker.check("Blur - FBO Bind & Clear");
                    GL20.glUseProgram((int)blurProgram);
                    GLErrorChecker.check("Blur - UseProgram");
                    GaussianBlur.setBlurUniforms(1.0f, 0.0f, blurRadius);
                    GLErrorChecker.check("Blur - Uniforms");
                    GL11.glBindTexture((int)3553, (int)texture1);
                    GaussianBlur.drawScreenQuad(0.0f, 0.0f, screenW, screenH, screenW, screenH);
                    GL20.glUseProgram((int)0);
                    GLErrorChecker.check("Blur - Draw & Cleanup");
                    preparedFrameId = renderFrameId;
                    preparedRadius = blurRadius;
                    boolean bl = var4 = true;
                    return bl;
                }
                catch (Exception var9) {
                    GaussianBlur.invalidateFrameCache();
                    var5 = false;
                }
                finally {
                    GaussianBlur.restoreMatrices();
                    GL11.glPopAttrib();
                    GL30.glBindFramebuffer((int)36160, (int)lastFBO);
                    GLErrorChecker.check("GaussianBlur.ensureFrameHorizontalBlur -> end");
                }
                return var5;
            }
            return false;
        }
        return false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static boolean performBlur(float radius, float drawX, float drawY, float drawW, float drawH) {
        int w = Display.getWidth();
        int h = ScissorUtil.getActualHeight();
        if (GaussianBlur.ensureShader() && GaussianBlur.checkSetupFBO()) {
            int lastFBO = GL11.glGetInteger((int)36006);
            try {
                GL11.glPushAttrib((int)1048575);
                GL11.glDisable((int)3089);
                GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
                GL11.glDepthMask((boolean)true);
                GaussianBlur.backupMatrices();
                GL11.glMatrixMode((int)5889);
                GL11.glLoadIdentity();
                GL11.glOrtho((double)0.0, (double)w, (double)h, (double)0.0, (double)-1.0, (double)1.0);
                GL11.glMatrixMode((int)5888);
                GL11.glLoadIdentity();
                GL11.glDisable((int)2960);
                GL11.glDisable((int)2929);
                GL11.glDisable((int)3008);
                GL11.glDisable((int)3042);
                GL11.glDisable((int)2884);
                GL11.glDisable((int)2896);
                GL11.glEnable((int)3553);
                GL11.glBindTexture((int)3553, (int)texture1);
                GL11.glCopyTexSubImage2D((int)3553, (int)0, (int)0, (int)0, (int)0, (int)0, (int)w, (int)h);
                GL30.glBindFramebuffer((int)36160, (int)fbo2);
                GL11.glViewport((int)0, (int)0, (int)w, (int)h);
                GL11.glClearColor((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
                GL11.glClear((int)16384);
                GL20.glUseProgram((int)blurProgram);
                GaussianBlur.setBlurUniforms(1.0f, 0.0f, radius);
                GL11.glBindTexture((int)3553, (int)texture1);
                GaussianBlur.drawScreenQuad(drawX, drawY, drawW, drawH, w, h);
                GL20.glUseProgram((int)0);
                GL30.glBindFramebuffer((int)36160, (int)lastFBO);
            }
            finally {
                GaussianBlur.restoreMatrices();
                GL11.glPopAttrib();
                GLErrorChecker.check("GaussianBlur.performBlur -> end");
            }
            return true;
        }
        return false;
    }

    public static void renderBlur(float radius) {
        int w = Display.getWidth();
        int h = ScissorUtil.getActualHeight();
        GaussianBlur.renderBlurRegion(0.0f, 0.0f, w, h, radius);
    }

    public static void renderBlur(float x, float y, float width, float height, float radius) {
        GaussianBlur.renderBlur(x, y, width, height, radius, 1.0f);
    }

    public static void renderBlur(float x, float y, float width, float height, float radius, float alpha) {
        int scale = ScissorUtil.getScaleFactor();
        GaussianBlur.renderBlurRegion(x * (float)scale, y * (float)scale, width * (float)scale, height * (float)scale, radius, alpha);
    }

    public static void renderBlurRounded(float x, float y, float width, float height, float cornerRadius, float blurRadius) {
        if (!(blurRadius <= 0.0f)) {
            int scale = ScissorUtil.getScaleFactor();
            float sx = x * (float)scale;
            float sy = y * (float)scale;
            float sw = width * (float)scale;
            float sh = height * (float)scale;
            float sr = cornerRadius * (float)scale;
            float pad = blurRadius + 4.0f;
            GaussianBlur.renderBlurRoundedImpl(blurRadius, sx, sy, sw, sh, sr, pad);
        }
    }

    private static void renderBlurRegion(float x, float y, float w, float h, float radius) {
        GaussianBlur.renderBlurRegion(x, y, w, h, radius, 1.0f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void renderBlurRegion(float x, float y, float w, float h, float radius, float alpha) {
        if (Display.isActive()) {
            int screenW = Display.getWidth();
            int screenH = ScissorUtil.getActualHeight();
            if (screenW > 0 && screenH > 0 && !(radius <= 0.0f) && !(alpha <= 0.01f) && GaussianBlur.ensureShader() && GaussianBlur.checkSetupFBO() && GaussianBlur.ensureFrameHorizontalBlur(radius)) {
                int lastFBO = GL11.glGetInteger((int)36006);
                try {
                    GL11.glPushAttrib((int)1048575);
                    GL11.glDisable((int)3089);
                    GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
                    GL11.glDepthMask((boolean)true);
                    GaussianBlur.backupMatrices();
                    GL11.glMatrixMode((int)5889);
                    GL11.glLoadIdentity();
                    GL11.glOrtho((double)0.0, (double)screenW, (double)screenH, (double)0.0, (double)-1.0, (double)1.0);
                    GL11.glMatrixMode((int)5888);
                    GL11.glLoadIdentity();
                    GL11.glDisable((int)2960);
                    GL11.glDisable((int)2929);
                    GL11.glDisable((int)3008);
                    GL11.glEnable((int)3042);
                    GL11.glBlendFunc((int)770, (int)771);
                    GL11.glDisable((int)2884);
                    GL11.glDisable((int)2896);
                    GL11.glEnable((int)3553);
                    GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
                    GL30.glBindFramebuffer((int)36160, (int)lastFBO);
                    GL11.glViewport((int)0, (int)0, (int)screenW, (int)screenH);
                    GL20.glUseProgram((int)blurProgram);
                    GaussianBlur.setBlurUniforms(0.0f, 1.0f, radius);
                    GL11.glBindTexture((int)3553, (int)texture2);
                    GaussianBlur.drawScreenQuad(x, y, w, h, screenW, screenH);
                    GL20.glUseProgram((int)0);
                    GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                }
                catch (Exception e) {
                    System.err.println("[GaussianBlur] renderBlurRegion error: " + e.getMessage());
                }
                finally {
                    GaussianBlur.restoreMatrices();
                    GL11.glPopAttrib();
                    GL30.glBindFramebuffer((int)36160, (int)lastFBO);
                    GLErrorChecker.check("GaussianBlur.renderBlurRegion -> end");
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void renderBlurRoundedImpl(float blurRadius, float rx, float ry, float rw, float rh, float cornerRad, float pad) {
        if (Display.isActive()) {
            int screenW = Display.getWidth();
            int screenH = ScissorUtil.getActualHeight();
            if (screenW > 0 && screenH > 0 && !(blurRadius <= 0.0f) && GaussianBlur.ensureShader() && GaussianBlur.checkSetupFBO() && GaussianBlur.ensureFrameHorizontalBlur(blurRadius)) {
                int lastFBO = GL11.glGetInteger((int)36006);
                try {
                    GL11.glPushAttrib((int)1048575);
                    GL11.glDisable((int)3089);
                    GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
                    GL11.glDepthMask((boolean)true);
                    GaussianBlur.backupMatrices();
                    GL11.glMatrixMode((int)5889);
                    GL11.glLoadIdentity();
                    GL11.glOrtho((double)0.0, (double)screenW, (double)screenH, (double)0.0, (double)-1.0, (double)1.0);
                    GL11.glMatrixMode((int)5888);
                    GL11.glLoadIdentity();
                    GL11.glDisable((int)2960);
                    GL11.glDisable((int)2929);
                    GL11.glDisable((int)3008);
                    GL11.glDisable((int)3042);
                    GL11.glDisable((int)2884);
                    GL11.glDisable((int)2896);
                    GL11.glEnable((int)3553);
                    GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                    GL30.glBindFramebuffer((int)36160, (int)lastFBO);
                    GL11.glViewport((int)0, (int)0, (int)screenW, (int)screenH);
                    GL20.glUseProgram((int)blurProgram);
                    GaussianBlur.setBlurUniforms(0.0f, 1.0f, blurRadius);
                    GL11.glBindTexture((int)3553, (int)texture2);
                    GaussianBlur.drawTexturedRoundedRect(rx, ry, rw, rh, cornerRad, screenW, screenH);
                    GL20.glUseProgram((int)0);
                }
                catch (Exception e) {
                    System.err.println("[GaussianBlur] renderBlurRounded error: " + e.getMessage());
                }
                finally {
                    GaussianBlur.restoreMatrices();
                    GL11.glPopAttrib();
                    GL30.glBindFramebuffer((int)36160, (int)lastFBO);
                    GLErrorChecker.check("GaussianBlur.renderBlurRoundedImpl -> end");
                }
            }
        }
    }

    static {
        for (int i = 0; i <= 360; ++i) {
            GaussianBlur.SIN[i] = (float)Math.sin(Math.toRadians(i));
            GaussianBlur.COS[i] = (float)Math.cos(Math.toRadians(i));
        }
        PROJ_BACKUPS = new FloatBuffer[]{BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16)};
        MODEL_BACKUPS = new FloatBuffer[]{BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16), BufferUtils.createFloatBuffer((int)16)};
        backupDepth = 0;
        weightBuffer = BufferUtils.createFloatBuffer((int)256);
    }
}

