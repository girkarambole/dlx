/*
 * Decompiled with CFR 0.152.
 */
package me.ries.util;

import java.lang.reflect.Field;
import sun.misc.Unsafe;

public class UnsafeHelper {
    private static Unsafe unsafe;

    public static Unsafe getUnsafe() {
        return unsafe;
    }

    public static void putObject(Object obj, long offset, Object value) {
        unsafe.putObject(obj, offset, value);
    }

    public static Object getObject(Object obj, long offset) {
        return unsafe.getObject(obj, offset);
    }

    static {
        try {
            Field field = Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            unsafe = (Unsafe)field.get(null);
        }
        catch (Exception e) {
            throw new RuntimeException("Failed to get Unsafe instance", e);
        }
    }
}

