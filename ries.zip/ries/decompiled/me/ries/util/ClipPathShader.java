/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL20
 */
package me.ries.util;

import java.awt.Color;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL20;

public class ClipPathShader {
    private static int program = -1;
    private static boolean failed = false;
    private static final String VERTEX_SHADER = "#version 120\nvoid main() {\n    gl_TexCoord[0] = gl_MultiTexCoord0;\n    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n}\n";
    private static final String FRAGMENT_SHADER = "#version 120\nuniform vec2 center;\nuniform float radius;\nuniform vec4 color;\nvoid main() {\n    float dist = distance(gl_FragCoord.xy, center);\n    if (dist > radius) {\n        discard;\n    }\n    gl_FragColor = color;\n}\n";

    private static void init() {
        if (!failed && program == -1) {
            try {
                int vs = GL20.glCreateShader((int)35633);
                GL20.glShaderSource((int)vs, (CharSequence)VERTEX_SHADER);
                GL20.glCompileShader((int)vs);
                int fs = GL20.glCreateShader((int)35632);
                GL20.glShaderSource((int)fs, (CharSequence)FRAGMENT_SHADER);
                GL20.glCompileShader((int)fs);
                program = GL20.glCreateProgram();
                GL20.glAttachShader((int)program, (int)vs);
                GL20.glAttachShader((int)program, (int)fs);
                GL20.glLinkProgram((int)program);
            }
            catch (Exception e) {
                failed = true;
                System.err.println("Failed to compile ClipPathShader: " + e.getMessage());
            }
        }
    }

    public static void begin(float cx, float cy, float radius, Color color) {
        ClipPathShader.init();
        if (!failed && program != -1) {
            GL20.glUseProgram((int)program);
            int centerLoc = GL20.glGetUniformLocation((int)program, (CharSequence)"center");
            int radiusLoc = GL20.glGetUniformLocation((int)program, (CharSequence)"radius");
            int colorLoc = GL20.glGetUniformLocation((int)program, (CharSequence)"color");
            float y = (float)Display.getHeight() - cy;
            GL20.glUniform2f((int)centerLoc, (float)cx, (float)y);
            GL20.glUniform1f((int)radiusLoc, (float)radius);
            GL20.glUniform4f((int)colorLoc, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
        }
    }

    public static void end() {
        if (!failed && program != -1) {
            GL20.glUseProgram((int)0);
        }
    }
}

