/*
 * Decompiled with CFR 0.152.
 */
package me.ries.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import me.ries.mapping.AutoMapper;
import me.ries.mapping.MappingConfiguration;
import me.ries.mapping.TypeConverter;
import me.ries.mapping.TypeReference;
import me.ries.util.Logger;

public class MappingUtils {
    private static final ConcurrentHashMap<String, Long> logThrottle = new ConcurrentHashMap();
    private static volatile long lastGameLogTime = 0L;

    public static void registerObfuscatedClass(String name, Class<?> clazz) {
        AutoMapper.put(name, clazz);
    }

    public static void registerClass(String name, String className) {
        try {
            Class<?> clazz = Class.forName(className);
            AutoMapper.put(name, clazz);
        }
        catch (ClassNotFoundException var3) {
            Logger.error("Failed to load class: " + className);
        }
    }

    public static Class<?> get(String name) {
        return AutoMapper.get(name);
    }

    public static Field getField(String fullName) {
        return AutoMapper.getField(fullName);
    }

    public static Method getMethod(String fullName) {
        return AutoMapper.getMethod(fullName);
    }

    public static boolean isClassLoaded(String name) {
        return AutoMapper.contains(name);
    }

    public static boolean isFieldMapped(String fullName) {
        return AutoMapper.containsField(fullName);
    }

    public static boolean isMethodMapped(String fullName) {
        return AutoMapper.containsMethod(fullName);
    }

    public static void exportMappings(String filePath) {
        AutoMapper.exportToFile(filePath);
    }

    public static String getStats() {
        return String.format("Classes: %d, Fields: %d, Methods: %d", AutoMapper.getClassCount(), AutoMapper.getFieldCount(), AutoMapper.getMethodCount());
    }

    public static <T> T map(Object source, Class<T> targetType) {
        return AutoMapper.map(source, targetType);
    }

    public static <T> T map(Object source, TypeReference<T> targetType) {
        return AutoMapper.map(source, targetType);
    }

    public static <T> List<T> mapList(Collection<?> source, Class<T> elementType) {
        return AutoMapper.mapList(source, elementType);
    }

    public static Object mapArray(Object source, Class<?> componentType) {
        return AutoMapper.mapArray(source, componentType);
    }

    public static void configure(MappingConfiguration configuration) {
        AutoMapper.setConfiguration(configuration);
    }

    public static void registerConverter(TypeConverter<?, ?> converter) {
        AutoMapper.registerConverter(converter);
    }

    public static String getObjectMappingCacheStats() {
        return AutoMapper.getObjectMappingCacheStats();
    }

    public static Object getMinecraft() {
        try {
            Method m = MappingUtils.getMethod("Minecraft.getMinecraft");
            if (m != null) {
                return m.invoke(null, new Object[0]);
            }
            Field f = MappingUtils.getField("Minecraft.theMinecraft");
            if (f != null) {
                return f.get(null);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static Object getThePlayer() {
        try {
            Method m;
            Object mc = MappingUtils.getField("Minecraft.theMinecraft").get(null);
            if (mc != null && (m = MappingUtils.getMethod("Minecraft.getThePlayer")) != null) {
                return m.invoke(mc, new Object[0]);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static Object getWorldObj() {
        try {
            Field f;
            Object player = MappingUtils.getThePlayer();
            if (player != null && (f = MappingUtils.getField("Entity.worldObj")) != null) {
                return f.get(player);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static Object getRenderManager() {
        try {
            Object mc = MappingUtils.getField("Minecraft.theMinecraft").get(null);
            if (mc != null) {
                Method m = MappingUtils.getMethod("Minecraft.getRenderManager");
                if (m != null) {
                    return m.invoke(mc, new Object[0]);
                }
                MappingUtils.logDebug("getRenderManager failed: Minecraft.getRenderManager method is null");
            }
        }
        catch (Exception e) {
            MappingUtils.logDebug("getRenderManager Exception: " + e.toString());
        }
        return null;
    }

    public static Object[] getPlayerEntitiesInWorld() {
        try {
            Object player = MappingUtils.getThePlayer();
            Object worldObj = MappingUtils.getWorldObj();
            MappingUtils.logDebugThrottled("gpeiw", "getPlayerEntitiesInWorld: player=" + (player == null ? "NULL" : player.getClass().getName()) + " world=" + (worldObj == null ? "NULL" : worldObj.getClass().getName()));
            if (player != null && worldObj != null) {
                Field playerEntitiesField = MappingUtils.getField("World.playerEntities");
                if (playerEntitiesField == null) {
                    MappingUtils.logDebugThrottled("gpeiw_nofield", "getPlayerEntitiesInWorld: World.playerEntities field NOT mapped");
                    return new Object[0];
                }
                Object entityList = playerEntitiesField.get(worldObj);
                if (!(entityList instanceof List)) {
                    MappingUtils.logDebugThrottled("gpeiw_notlist", "getPlayerEntitiesInWorld: playerEntities is not a List, got=" + (entityList == null ? "null" : entityList.getClass().getName()));
                    return new Object[0];
                }
                List list = (List)entityList;
                ArrayList result = new ArrayList();
                for (Object entity : list) {
                    if (entity == null || entity == player) continue;
                    result.add(entity);
                }
                MappingUtils.logDebugThrottled("gpeiw_result", "getPlayerEntitiesInWorld: total in list=" + list.size() + " after filter=" + result.size());
                return result.toArray();
            }
            return new Object[0];
        }
        catch (Exception e) {
            MappingUtils.logDebugThrottled("gpeiw_ex", "getPlayerEntitiesInWorld EXCEPTION: " + e);
            return new Object[0];
        }
    }

    public static void logDebug(String msg) {
        Logger.debug(msg);
    }

    public static void logDebugThrottled(String key, String msg) {
        long now = System.currentTimeMillis();
        Long last = logThrottle.get(key);
        if (last == null || now - last >= 3000L) {
            logThrottle.put(key, now);
            MappingUtils.logDebug(msg);
        }
    }

    public static double getRenderPosX() {
        try {
            Object renderManager = MappingUtils.getRenderManager();
            if (renderManager != null) {
                Field f = MappingUtils.getField("RenderManager.renderPosX");
                if (f != null) {
                    return f.getDouble(renderManager);
                }
                MappingUtils.logDebug("RenderPosX failed: Field RenderManager.renderPosX is null");
            } else {
                MappingUtils.logDebug("RenderPosX failed: RenderManager is null");
            }
        }
        catch (Exception e) {
            MappingUtils.logDebug("RenderPosX Exception: " + e.toString());
        }
        return 0.0;
    }

    public static double getRenderPosY() {
        try {
            Object renderManager = MappingUtils.getRenderManager();
            if (renderManager != null) {
                Field f = MappingUtils.getField("RenderManager.renderPosY");
                if (f != null) {
                    return f.getDouble(renderManager);
                }
                MappingUtils.logDebug("RenderPosY failed: Field RenderManager.renderPosY is null");
            }
        }
        catch (Exception e) {
            MappingUtils.logDebug("RenderPosY Exception: " + e.toString());
        }
        return 0.0;
    }

    public static double getRenderPosZ() {
        try {
            Object renderManager = MappingUtils.getRenderManager();
            if (renderManager != null) {
                Field f = MappingUtils.getField("RenderManager.renderPosZ");
                if (f != null) {
                    return f.getDouble(renderManager);
                }
                MappingUtils.logDebug("RenderPosZ failed: Field RenderManager.renderPosZ is null");
            }
        }
        catch (Exception e) {
            MappingUtils.logDebug("RenderPosZ Exception: " + e.toString());
        }
        return 0.0;
    }

    private static Field findFieldInHierarchy(Class<?> clazz, String fieldName) {
        for (Class<?> cur = clazz; cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            try {
                Field f = cur.getDeclaredField(fieldName);
                f.setAccessible(true);
                return f;
            }
            catch (NoSuchFieldException noSuchFieldException) {
                continue;
            }
        }
        return null;
    }

    public static double[] getInterpolatedPos(Object entity, float partialTicks) {
        try {
            Field prevZF;
            Field prevYF;
            Field prevXF = MappingUtils.getField("Entity.lastTickPosX");
            if (prevXF == null) {
                prevXF = MappingUtils.getField("Entity.prevPosX");
            }
            if ((prevYF = MappingUtils.getField("Entity.lastTickPosY")) == null) {
                prevYF = MappingUtils.getField("Entity.prevPosY");
            }
            if ((prevZF = MappingUtils.getField("Entity.lastTickPosZ")) == null) {
                prevZF = MappingUtils.getField("Entity.prevPosZ");
            }
            Field currXF = MappingUtils.getField("Entity.posX");
            Field currYF = MappingUtils.getField("Entity.posY");
            Field currZF = MappingUtils.getField("Entity.posZ");
            if (prevXF != null && currXF != null) {
                double prevX = prevXF.getDouble(entity);
                double prevY = prevYF.getDouble(entity);
                double prevZ = prevZF.getDouble(entity);
                double currX = currXF.getDouble(entity);
                double currY = currYF.getDouble(entity);
                double currZ = currZF.getDouble(entity);
                double x = prevX + (currX - prevX) * (double)partialTicks;
                double y = prevY + (currY - prevY) * (double)partialTicks;
                double z = prevZ + (currZ - prevZ) * (double)partialTicks;
                return new double[]{x, y, z};
            }
            MappingUtils.logDebug("getInterpolatedPos failed: Entity pos fields are null");
            return new double[]{0.0, 0.0, 0.0};
        }
        catch (Exception e) {
            MappingUtils.logDebug("getInterpolatedPos Exception: " + e.toString());
            return new double[]{0.0, 0.0, 0.0};
        }
    }

    public static boolean isValidTarget(Object entity) {
        if (entity == null) {
            return false;
        }
        try {
            Object thePlayer = MappingUtils.getThePlayer();
            if (entity.equals(thePlayer)) {
                return false;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return true;
    }

    public static String getName(Object entity) {
        try {
            Object gp;
            Field f = MappingUtils.getField("GameProfile.name");
            Field gpf = MappingUtils.getField("EntityPlayer.gameProfile");
            if (gpf != null && f != null && (gp = gpf.get(entity)) != null) {
                return (String)f.get(gp);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return "?";
    }

    public static float getEyeHeight(Object entity) {
        return 1.62f;
    }

    public static float getEntityHealth(Object entity) {
        float hp;
        Object val;
        Method getFloat;
        Field dwField2;
        if (entity == null) {
            return 0.0f;
        }
        try {
            float hp2;
            Object val2;
            Method m = MappingUtils.getMethod("EntityLivingBase.getHealth");
            if (m != null && (val2 = m.invoke(entity, new Object[0])) instanceof Number && (hp2 = ((Number)val2).floatValue()) >= 0.0f) {
                return hp2;
            }
        }
        catch (Exception m) {
            // empty catch block
        }
        try {
            Object dw;
            dwField2 = MappingUtils.getField("Entity.dataWatcher");
            getFloat = MappingUtils.getMethod("DataWatcher.getFloat");
            if (dwField2 != null && getFloat != null && (dw = dwField2.get(entity)) != null && (val = getFloat.invoke(dw, 25)) instanceof Number && (hp = ((Number)val).floatValue() / 571.875f) > 0.0f && hp <= 1024.0f) {
                return hp;
            }
        }
        catch (Exception dwField2) {
            // empty catch block
        }
        try {
            Object dw;
            dwField2 = MappingUtils.getField("Entity.dataWatcher");
            getFloat = MappingUtils.getMethod("DataWatcher.getFloat");
            if (dwField2 != null && getFloat != null && (dw = dwField2.get(entity)) != null && (val = getFloat.invoke(dw, 6)) instanceof Number && (hp = ((Number)val).floatValue()) > 0.0f && hp <= 1024.0f) {
                return hp;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return 0.0f;
    }

    public static float getYaw(Object entity) {
        try {
            Field f = MappingUtils.getField("Entity.rotationYaw");
            if (f != null) {
                return f.getFloat(entity);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return 0.0f;
    }

    public static String getCurrentGameMode() {
        try {
            Field sbField = MappingUtils.getField("ClientUtils.scoreBoard");
            if (sbField != null) {
                sbField.setAccessible(true);
                Object sbUtil = sbField.get(null);
                if (sbUtil != null) {
                    Field infoField = MappingUtils.getField("ScoreBoardUtil.scoreBoardInfo");
                    Method getTitle = MappingUtils.getMethod("ScoreBoardUtil.getTitle");
                    if (infoField != null && getTitle != null) {
                        String t;
                        Object title;
                        Object sbObj;
                        Map map;
                        infoField.setAccessible(true);
                        Object infoMap = infoField.get(sbUtil);
                        if (infoMap instanceof Map && !(map = (Map)infoMap).isEmpty() && (sbObj = map.values().iterator().next()) != null && (title = getTitle.invoke(sbUtil, new Object[0])) instanceof String && !(t = ((String)title).replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim()).isEmpty()) {
                            return t;
                        }
                    }
                }
            }
        }
        catch (Throwable sbField) {
            // empty catch block
        }
        try {
            String t;
            Object title;
            Object sbUtil;
            Method getScoreBoardInfo = MappingUtils.getMethod("ScoreBoardUtil.getScoreBoardInfo");
            Method getTitle = MappingUtils.getMethod("ScoreBoardUtil.getTitle");
            if (getScoreBoardInfo != null && getTitle != null && (sbUtil = getScoreBoardInfo.invoke(null, new Object[0])) != null && (title = getTitle.invoke(sbUtil, new Object[0])) instanceof String && !(t = ((String)title).replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim()).isEmpty()) {
                return t;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private static String extractGameName(Object gameObj) {
        Field f2;
        Object v;
        Method m2;
        if (gameObj == null) {
            return null;
        }
        try {
            m2 = MappingUtils.getMethod("CRGameInfo.getDisplayName");
            if (m2 != null && (v = m2.invoke(gameObj, new Object[0])) instanceof String && !((String)v).isEmpty()) {
                return (String)v;
            }
        }
        catch (Throwable m2) {
            // empty catch block
        }
        try {
            m2 = MappingUtils.getMethod("CRGameInfo.getName");
            if (m2 != null && (v = m2.invoke(gameObj, new Object[0])) instanceof String && !((String)v).isEmpty()) {
                return (String)v;
            }
        }
        catch (Throwable m3) {
            // empty catch block
        }
        try {
            f2 = MappingUtils.getField("CRGameInfo.displayname");
            if (f2 != null) {
                f2.setAccessible(true);
                v = f2.get(gameObj);
                if (v instanceof String && !((String)v).isEmpty()) {
                    return (String)v;
                }
            }
        }
        catch (Throwable f2) {
            // empty catch block
        }
        try {
            f2 = MappingUtils.getField("CRGameInfo.name");
            if (f2 != null) {
                f2.setAccessible(true);
                v = f2.get(gameObj);
                if (v instanceof String && !((String)v).isEmpty()) {
                    return (String)v;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    public static Object getInventory(Object entity) {
        try {
            Field f = MappingUtils.getField("EntityPlayer.inventory");
            if (f != null) {
                f.setAccessible(true);
                return f.get(entity);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    public static Object getHeldItem(Object entity) {
        try {
            Method m = MappingUtils.getMethod("EntityPlayer.getHeldItem");
            if (m != null) {
                m.setAccessible(true);
                return m.invoke(entity, new Object[0]);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    public static Object[] getArmorContents(Object entity) {
        try {
            Object inv = MappingUtils.getInventory(entity);
            if (inv == null) {
                return null;
            }
            Field f = MappingUtils.getField("InventoryPlayer.armorInventory");
            if (f != null) {
                f.setAccessible(true);
                Object arr = f.get(inv);
                if (arr instanceof Object[]) {
                    return (Object[])arr;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    public static String getItemName(Object itemStack) {
        if (itemStack == null) {
            return null;
        }
        try {
            Field itemField = MappingUtils.getField("ItemStack.item");
            if (itemField == null) {
                return null;
            }
            itemField.setAccessible(true);
            Object item = itemField.get(itemStack);
            if (item == null) {
                return null;
            }
            Method unloc = MappingUtils.getMethod("Item.getUnlocalizedName");
            if (unloc != null) {
                String val3;
                unloc.setAccessible(true);
                try {
                    val3 = (String)unloc.invoke(item, itemStack);
                    if (val3 != null && !val3.isEmpty()) {
                        return MappingUtils.stripItemPrefix(val3);
                    }
                }
                catch (Throwable val2) {
                    // empty catch block
                }
                try {
                    val3 = (String)unloc.invoke(item, new Object[0]);
                    if (val3 != null && !val3.isEmpty()) {
                        return MappingUtils.stripItemPrefix(val3);
                    }
                }
                catch (Throwable val3) {
                    // empty catch block
                }
            }
            for (int pass = 0; pass < 2; ++pass) {
                for (Method m : item.getClass().getMethods()) {
                    if (m.getReturnType() != String.class) continue;
                    try {
                        String val;
                        if (pass == 0 && m.getParameterCount() == 1) {
                            val = (String)m.invoke(item, itemStack);
                        } else {
                            if (pass != 1 || m.getParameterCount() != 0) continue;
                            val = (String)m.invoke(item, new Object[0]);
                        }
                        if (val == null || !val.startsWith("item.") && !val.startsWith("tile.")) continue;
                        return MappingUtils.stripItemPrefix(val);
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private static String stripItemPrefix(String val) {
        if (!val.startsWith("item.") && !val.startsWith("tile.")) {
            return val;
        }
        int dot = val.indexOf(46);
        return dot >= 0 ? val.substring(dot + 1) : val;
    }

    public static String getItemShortName(Object itemStack) {
        if (itemStack == null) {
            return null;
        }
        try {
            Method m = MappingUtils.getMethod("ItemStack.getDisplayName");
            if (m != null) {
                String dn;
                m.setAccessible(true);
                Object val = m.invoke(itemStack, new Object[0]);
                if (val instanceof String && !(dn = ((String)val).replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim()).isEmpty()) {
                    String short_ = MappingUtils.toShortTurkish(dn);
                    return short_ != null ? short_ : (dn.length() > 10 ? dn.substring(0, 10) : dn);
                }
            }
        }
        catch (Throwable m) {
            // empty catch block
        }
        String raw = MappingUtils.getItemName(itemStack);
        if (raw != null && !raw.isEmpty()) {
            String tr;
            String lower = raw.toLowerCase();
            int last = raw.lastIndexOf(46);
            String base = last >= 0 ? raw.substring(last + 1) : raw;
            String baseLow = base.toLowerCase();
            String mat = "";
            if (lower.contains("diamond")) {
                mat = "E.";
            } else if (lower.contains("iron")) {
                mat = "D.";
            } else if (lower.contains("gold")) {
                mat = "A.";
            } else if (lower.contains("leather")) {
                mat = "Dr.";
            } else if (lower.contains("chain")) {
                mat = "Zn.";
            } else if (lower.contains("stone")) {
                mat = "T.";
            } else if (lower.contains("wood")) {
                mat = "Ah.";
            }
            if (baseLow.equals("sword")) {
                tr = "K\u00c3\u201e\u00c2\u00b1l\u00c3\u201e\u00c2\u00b1\u00c3\u0192\u00c2\u00a7";
            } else if (baseLow.equals("axe")) {
                tr = "Balta";
            } else if (baseLow.equals("pickaxe")) {
                tr = "Kazma";
            } else if (baseLow.equals("shovel")) {
                tr = "K\u00c3\u0192\u00c2\u00bcrek";
            } else if (baseLow.equals("hoe")) {
                tr = "\u00c3\u0192\u00e2\u20ac\u00a1apa";
            } else if (baseLow.equals("bow")) {
                tr = "Yay";
            } else if (baseLow.equals("helmet")) {
                tr = "Mi\u00c3\u201e\u00c5\u00b8fer";
            } else if (baseLow.equals("chestplate")) {
                tr = "Z\u00c3\u201e\u00c2\u00b1rh";
            } else if (baseLow.equals("leggings")) {
                tr = "Tayt";
            } else if (baseLow.equals("boots")) {
                tr = "Bot";
            } else {
                if (lower.contains("goldenapple")) {
                    return "AElma";
                }
                tr = baseLow.equals("apple") ? "Elma" : (baseLow.equals("totem") ? "Totem" : (baseLow.equals("shield") ? "Kalkan" : (baseLow.equals("potion") ? "\u00c3\u201e\u00c2\u00b0ksir" : (baseLow.equals("splashpotion") ? "Atf.\u00c3\u201e\u00c2\u00b0ksir" : (lower.contains("enderpearl") ? "\u00c3\u201e\u00c2\u00b0nci" : (lower.contains("enderperl") ? "\u00c3\u201e\u00c2\u00b0nci" : (!lower.contains("fishingrod") && !lower.contains("fishing_rod") ? (baseLow.equals("rod") ? "Olta" : (lower.contains("snowball") ? "Kartopu" : (lower.contains("egg") ? "Yumurta" : (!lower.contains("flintandsteel") && !lower.contains("flint_and_steel") ? (lower.contains("compass") ? "Pusula" : (lower.contains("clock") ? "Saat" : (lower.contains("shears") ? "Makas" : (!lower.contains("leadmane") && !lower.contains("lead") ? (!lower.contains("nametag") && !lower.contains("name_tag") ? (lower.contains("book") ? "Kitap" : (lower.contains("arrow") ? "Ok" : (lower.contains("carrot") ? "Havu\u00c3\u0192\u00c2\u00a7" : (lower.contains("beef") ? "Et" : (lower.contains("porkchop") ? "Domuz" : (lower.contains("chicken") ? "Tavuk" : (lower.contains("fish") ? "Bal\u00c3\u201e\u00c2\u00b1k" : (lower.contains("bread") ? "Ekmek" : (lower.contains("melon") ? "Karpuz" : (lower.contains("cookie") ? "Kurabiye" : (lower.contains("torch") ? "Me\u00c3\u2026\u00c5\u00b8ale" : (lower.contains("stick") ? "\u00c3\u0192\u00e2\u20ac\u00a1ubuk" : (lower.contains("string") ? "\u00c3\u201e\u00c2\u00b0plik" : base))))))))))))) : "\u00c3\u201e\u00c2\u00b0simEt.") : "\u00c3\u201e\u00c2\u00b0p")))) : "\u00c3\u0192\u00e2\u20ac\u00a1akmak")))) : "Olta")))))));
            }
            return mat + tr;
        }
        return null;
    }

    private static String toShortTurkish(String displayName) {
        if (displayName == null) {
            return null;
        }
        String d = displayName.toLowerCase(Locale.ROOT);
        String mat = "";
        if (d.contains("elmas")) {
            mat = "E.";
        } else if (d.contains("demir")) {
            mat = "D.";
        } else if (d.contains("alt\u00c3\u201e\u00c2\u00b1n")) {
            mat = "A.";
        } else if (d.contains("deri")) {
            mat = "Dr.";
        } else if (d.contains("zincir")) {
            mat = "Zn.";
        } else if (d.contains("ta\u00c3\u2026\u00c5\u00b8")) {
            mat = "T.";
        } else if (!d.contains("ah\u00c3\u2026\u00c5\u00b8ap") && !d.contains("tahta")) {
            if (d.contains("ametist")) {
                mat = "Ame.";
            } else if (d.contains("buz")) {
                mat = "Bz.";
            }
        } else {
            mat = "Ah.";
        }
        String tr = null;
        if (d.contains("k\u00c3\u201e\u00c2\u00b1l\u00c3\u201e\u00c2\u00b1\u00c3\u0192\u00c2\u00a7")) {
            tr = "K\u00c3\u201e\u00c2\u00b1l\u00c3\u201e\u00c2\u00b1\u00c3\u0192\u00c2\u00a7";
        } else if (d.contains("balta")) {
            tr = "Balta";
        } else if (d.contains("kazma")) {
            tr = "Kazma";
        } else if (d.contains("k\u00c3\u0192\u00c2\u00bcrek")) {
            tr = "K\u00c3\u0192\u00c2\u00bcrek";
        } else if (d.contains("\u00c3\u0192\u00c2\u00a7apa")) {
            tr = "\u00c3\u0192\u00e2\u20ac\u00a1apa";
        } else if (d.contains("yay")) {
            tr = "Yay";
        } else if (d.contains("mi\u00c3\u201e\u00c5\u00b8fer")) {
            tr = "Mi\u00c3\u201e\u00c5\u00b8fer";
        } else if (!d.contains("g\u00c3\u0192\u00c2\u00b6\u00c3\u201e\u00c5\u00b8\u00c3\u0192\u00c2\u00bcsl\u00c3\u0192\u00c2\u00bck") && !d.contains("z\u00c3\u201e\u00c2\u00b1rh")) {
            if (!d.contains("tayt") && !d.contains("pantolon")) {
                if (!d.contains("bot") && !d.contains("\u00c3\u0192\u00c2\u00a7izme")) {
                    if (d.contains("olta")) {
                        tr = "Olta";
                    } else if (d.contains("yak\u00c3\u201e\u00c2\u00b1c\u00c3\u201e\u00c2\u00b1")) {
                        tr = "Yak.";
                    } else {
                        if (d.contains("alt\u00c3\u201e\u00c2\u00b1n elma")) {
                            return "AElma";
                        }
                        if (d.contains("elma")) {
                            tr = "Elma";
                        } else if (d.contains("kalkan")) {
                            tr = "Kalkan";
                        } else if (d.contains("totem")) {
                            tr = "Totem";
                        } else if (d.contains("inci")) {
                            tr = "\u00c3\u201e\u00c2\u00b0nci";
                        } else if (d.contains("iksir")) {
                            tr = "\u00c3\u201e\u00c2\u00b0ksir";
                        } else if (d.contains("kar topu")) {
                            tr = "Kartopu";
                        }
                    }
                } else {
                    tr = "Bot";
                }
            } else {
                tr = "Tayt";
            }
        } else {
            tr = "Z\u00c3\u201e\u00c2\u00b1rh";
        }
        return tr == null ? null : mat + tr;
    }

    private static String capitalize(String s) {
        return s != null && !s.isEmpty() ? Character.toUpperCase(s.charAt(0)) + s.substring(1) : s;
    }

    public static Map<Integer, Integer> getEnchantments(Object itemStack) {
        LinkedHashMap<Integer, Integer> result = new LinkedHashMap<Integer, Integer>();
        if (itemStack == null) {
            return result;
        }
        try {
            Method enchList = MappingUtils.getMethod("ItemStack.getEnchantmentTagList");
            if (enchList != null) {
                enchList.setAccessible(true);
                Object nbtList = enchList.invoke(itemStack, new Object[0]);
                if (nbtList != null) {
                    MappingUtils.readEnchantList(nbtList, result);
                    if (!result.isEmpty()) {
                        return result;
                    }
                }
            }
        }
        catch (Throwable enchList) {
            // empty catch block
        }
        try {
            Method hasTag = MappingUtils.getMethod("ItemStack.hasTagCompound");
            Method getTag = MappingUtils.getMethod("ItemStack.getTagCompound");
            if (getTag != null) {
                boolean has = true;
                if (hasTag != null) {
                    hasTag.setAccessible(true);
                    Object hv = hasTag.invoke(itemStack, new Object[0]);
                    boolean bl = has = hv instanceof Boolean ? (Boolean)hv : true;
                }
                if (has) {
                    getTag.setAccessible(true);
                    Object compound = getTag.invoke(itemStack, new Object[0]);
                    if (compound != null) {
                        Object storedNbt;
                        Object enchNbt = MappingUtils.getTagList(compound, "ench");
                        if (enchNbt != null) {
                            MappingUtils.readEnchantList(enchNbt, result);
                            if (!result.isEmpty()) {
                                return result;
                            }
                        }
                        if ((storedNbt = MappingUtils.getTagList(compound, "StoredEnchantments")) != null) {
                            MappingUtils.readEnchantList(storedNbt, result);
                            if (!result.isEmpty()) {
                                return result;
                            }
                        }
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return result;
    }

    private static Object getTagList(Object compound, String key) {
        try {
            Method getTagListM;
            Method hasKey = MappingUtils.getMethod("NBTTagCompound.hasKey");
            if (hasKey != null) {
                hasKey.setAccessible(true);
                Object hv = hasKey.invoke(compound, key);
                if (hv instanceof Boolean && !((Boolean)hv).booleanValue()) {
                    return null;
                }
            }
            if ((getTagListM = MappingUtils.getMethod("NBTTagCompound.getTagList")) != null) {
                getTagListM.setAccessible(true);
                try {
                    Object list = getTagListM.invoke(compound, key, 10);
                    if (list != null) {
                        return list;
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            for (Method m : compound.getClass().getMethods()) {
                if (m.getParameterCount() != 2 || m.getParameterTypes()[0] != String.class || m.getParameterTypes()[1] != Integer.TYPE) continue;
                try {
                    m.setAccessible(true);
                    Object list = m.invoke(compound, key, 10);
                    if (list == null || !MappingUtils.isNbtList(list)) continue;
                    return list;
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private static boolean isNbtList(Object obj) {
        if (obj == null) {
            return false;
        }
        String cn = obj.getClass().getSimpleName().toLowerCase();
        return cn.contains("list") || cn.contains("nbt");
    }

    private static void readEnchantList(Object nbtList, Map<Integer, Integer> out) {
        if (nbtList != null) {
            try {
                Method tagCount = MappingUtils.getMethod("NBTTagList.tagCount");
                Method getCompoundAt = MappingUtils.getMethod("NBTTagList.getCompoundTagAt");
                Method getInt = MappingUtils.getMethod("NBTTagCompound.getInteger");
                if (tagCount != null && getCompoundAt != null && getInt != null) {
                    tagCount.setAccessible(true);
                    getCompoundAt.setAccessible(true);
                    getInt.setAccessible(true);
                    int count = ((Number)tagCount.invoke(nbtList, new Object[0])).intValue();
                    for (int i = 0; i < count; ++i) {
                        try {
                            Object entry = getCompoundAt.invoke(nbtList, i);
                            if (entry == null) continue;
                            int id = ((Number)getInt.invoke(entry, "id")).intValue();
                            int lvl = ((Number)getInt.invoke(entry, "lvl")).intValue();
                            if (id < 0) continue;
                            out.put(id, lvl);
                            continue;
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    return;
                }
                for (Field f : nbtList.getClass().getDeclaredFields()) {
                    f.setAccessible(true);
                    Object val = f.get(nbtList);
                    if (!(val instanceof List)) continue;
                    block10: for (Object entry : (List)val) {
                        if (entry == null) continue;
                        try {
                            if (getInt != null) {
                                getInt.setAccessible(true);
                                int id = ((Number)getInt.invoke(entry, "id")).intValue();
                                int lvl = ((Number)getInt.invoke(entry, "lvl")).intValue();
                                if (id < 0) continue;
                                out.put(id, lvl);
                                continue;
                            }
                            for (Method m : entry.getClass().getMethods()) {
                                if (m.getParameterCount() != 1 || m.getParameterTypes()[0] != String.class || m.getReturnType() != Short.TYPE && m.getReturnType() != Short.class) continue;
                                m.setAccessible(true);
                                try {
                                    int id = ((Number)m.invoke(entry, "id")).intValue();
                                    int lvl = ((Number)m.invoke(entry, "lvl")).intValue();
                                    if (id < 0) continue;
                                    out.put(id, lvl);
                                    continue block10;
                                }
                                catch (Throwable throwable) {
                                    // empty catch block
                                }
                            }
                        }
                        catch (Throwable throwable) {
                        }
                    }
                    if (out.isEmpty()) continue;
                    return;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public static String enchantShortLabel(int id, int level) {
        switch (id) {
            case 0: {
                return "P" + level;
            }
            case 1: {
                return "AK" + level;
            }
            case 3: {
                return "PK" + level;
            }
            case 4: {
                return "MK" + level;
            }
            case 16: {
                return "K" + level;
            }
        }
        return null;
    }
}

