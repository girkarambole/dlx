/*
 * Decompiled with CFR 0.152.
 */
package me.ries.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.ries.mapping.AutoMapper;
import me.ries.util.Logger;

public class HardcodedUtils {
    private static final Map<String, String> CLASS_MAP = new HashMap<String, String>();
    private static final Map<String, String> FIELD_MAP = new HashMap<String, String>();
    private static final Map<String, String> METHOD_MAP = new HashMap<String, String>();

    public static void apply() {
        Class<?> c;
        String classAlias;
        int loaded = 0;
        int classesLoaded = 0;
        List<Class<?>> classes = AutoMapper.cachedClasses;
        if (classes != null && !classes.isEmpty()) {
            HashMap byName = new HashMap();
            for (Class<?> clazz : classes) {
                if (clazz == null) continue;
                byName.put(clazz.getName(), clazz);
            }
            for (Map.Entry entry : CLASS_MAP.entrySet()) {
                Class c3;
                String alias = (String)entry.getValue();
                if ("NULL".equals(entry.getKey()) || (c3 = (Class)byName.get(entry.getKey())) == null) continue;
                AutoMapper.put(alias, c3);
                ++classesLoaded;
            }
        }
        for (Map.Entry<String, String> e : FIELD_MAP.entrySet()) {
            String string = e.getKey();
            int tab = string.indexOf(9);
            classAlias = string.substring(0, tab);
            String obfField = string.substring(tab + 1);
            c = AutoMapper.get(classAlias);
            if (c == null) {
                Logger.warn("[HC] FIELD SKIP (no class): " + e.getValue());
                continue;
            }
            Field f = HardcodedUtils.findField(c, obfField);
            if (f == null) {
                Logger.warn("[HC] FIELD NOT FOUND: " + c.getName() + "." + obfField + " (" + e.getValue() + ")");
                continue;
            }
            f.setAccessible(true);
            AutoMapper.putField(e.getValue(), f);
            ++loaded;
        }
        for (Map.Entry<String, String> e : METHOD_MAP.entrySet()) {
            String string = e.getKey();
            int tab = string.indexOf(9);
            classAlias = string.substring(0, tab);
            String obfMethod = string.substring(tab + 1);
            c = AutoMapper.get(classAlias);
            if (c == null) {
                Logger.warn("[HC] METHOD SKIP (no class): " + e.getValue());
                continue;
            }
            Method m = HardcodedUtils.findMethod(c, obfMethod);
            if (m == null) {
                Logger.warn("[HC] METHOD NOT FOUND: " + c.getName() + "." + obfMethod + " (" + e.getValue() + ")");
                continue;
            }
            m.setAccessible(true);
            AutoMapper.putMethod(e.getValue(), m);
            ++loaded;
        }
        Logger.info("[HardcodedUtils] Applied " + (loaded + classesLoaded) + " hardcoded mappings (classes=" + classesLoaded + ", fields+methods=" + loaded + ").");
        HardcodedUtils.fixReturnTypeSensitiveMethods();
    }

    private static Field findField(Class<?> c, String name) {
        for (Class<?> cur = c; cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            try {
                return cur.getDeclaredField(name);
            }
            catch (NoSuchFieldException noSuchFieldException) {
                continue;
            }
        }
        return null;
    }

    private static Method findMethod(Class<?> c, String name) {
        for (Class<?> cur = c; cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            for (Method m : cur.getDeclaredMethods()) {
                if (!m.getName().equals(name)) continue;
                return m;
            }
        }
        return null;
    }

    private static Method findMethodWithReturnType(Class<?> c, String name, Class<?> returnType) {
        for (Class<?> cur = c; cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            for (Method m : cur.getDeclaredMethods()) {
                if (!m.getName().equals(name) || !m.getReturnType().equals(returnType)) continue;
                return m;
            }
        }
        return null;
    }

    public static void fixReturnTypeSensitiveMethods() {
        HardcodedUtils.fixMethod("Minecraft", "Minecraft.getRenderManager", "RenderManager");
    }

    private static void fixMethod(String classAlias, String mappingKey, String returnTypeAlias) {
        Class<?> clazz = AutoMapper.get(classAlias);
        Class<?> retType = AutoMapper.get(returnTypeAlias);
        if (clazz != null && retType != null) {
            Method m = HardcodedUtils.findMethodWithReturnType(clazz, HardcodedUtils.getObfName(mappingKey), retType);
            if (m == null) {
                Method fallback = AutoMapper.getMethod(mappingKey);
                Logger.warn("[HC] fixMethod NOT FOUND by return type: " + mappingKey + " on " + clazz.getName() + " retType=" + retType.getName() + (fallback != null ? " (fallback keeps: " + fallback.getName() + " ret=" + fallback.getReturnType().getName() + ")" : ""));
            } else {
                m.setAccessible(true);
                AutoMapper.putMethod(mappingKey, m);
                Logger.info("[HC] fixMethod OK: " + mappingKey + " -> " + m.getName() + " returns " + m.getReturnType().getName());
            }
        } else {
            Logger.warn("[HC] fixMethod SKIP (missing class): " + mappingKey + " classAlias=" + classAlias + " returnTypeAlias=" + returnTypeAlias);
        }
    }

    private static String getObfName(String mappingKey) {
        for (Map.Entry<String, String> e : METHOD_MAP.entrySet()) {
            if (!e.getValue().equals(mappingKey)) continue;
            String key = e.getKey();
            int tab = key.indexOf(9);
            return key.substring(tab + 1);
        }
        return "";
    }

    static {
        CLASS_MAP.put("crsecond.\u02a8", "ChatComponentText");
        CLASS_MAP.put("crsecond.\u0224\u03e3", "NetworkManager");
        CLASS_MAP.put("craftrise.\u042a\u01a7", "Render");
        CLASS_MAP.put("adaptive.sex.Main", "main");
        CLASS_MAP.put("crsecond.\u03a4", "ChatComponentStyle");
        CLASS_MAP.put("craftrise.\u042a\u01a9", "ICamera");
        CLASS_MAP.put("craftrise.\u042a\u02ab", "C03PacketPlayer");
        CLASS_MAP.put("craftrise.U\u0376", "KeyBinding");
        CLASS_MAP.put("craftrise.U\u0579", "DynamicTexture");
        CLASS_MAP.put("craftrise.\u0271", "EntityItem");
        CLASS_MAP.put("craftrise.\u042a\u04ad", "InventoryPlayer");
        CLASS_MAP.put("craftrise.\u056f", "Minecraft");
        CLASS_MAP.put("craftrise.\u0479", "GameSettings");
        CLASS_MAP.put("crsecond.\u0497", "ResourceLocation");
        CLASS_MAP.put("craftrise.\u0476", "ScaledResolution");
        CLASS_MAP.put("craftrise.\u017d", "World");
        CLASS_MAP.put("craftrise.\u042a\u0285", "ISaveHandler");
        CLASS_MAP.put("craftrise.US", "IBakedModel");
        CLASS_MAP.put("craftrise.\u042a\u048b", "INetHandlerPlayClient");
        CLASS_MAP.put("craftrise.\u042a\u038f", "Vec3i");
        CLASS_MAP.put("craftrise.U\u025d", "Profiler");
        CLASS_MAP.put("craftrise.U\u045c", "S0BPacketAnimation");
        CLASS_MAP.put("craftrise.O", "MotionContainer");
        CLASS_MAP.put("craftrise.P", "EntityRenderer");
        CLASS_MAP.put("craftrise.\u0555", "EntityPlayerSP");
        CLASS_MAP.put("craftrise.\u042a\u0199", "PlayerControllerMP");
        CLASS_MAP.put("craftrise.\u042a\u04a0", "Item");
        CLASS_MAP.put("craftrise.\u042a\u02ab$\u0518", "C06PacketPlayerPosLook");
        CLASS_MAP.put("crsecond.\u04e7", "ModelBiped");
        CLASS_MAP.put("craftrise.\u03aa", "RenderManager");
        CLASS_MAP.put("craftrise.U\u0533", "WorldProvider");
        CLASS_MAP.put("craftrise.\u02ac", "EffectRenderer");
        CLASS_MAP.put("craftrise.U\u00c2$\u0457", "C02PacketUseEntityAction");
        CLASS_MAP.put("craftrise.U\u0134", "NBTBase");
        CLASS_MAP.put("crsecond.\u00e5", "PacketBuffer");
        CLASS_MAP.put("craftrise.\u042al", "PotionEffect");
        CLASS_MAP.put("craftrise.\u042an", "TileEntityBase");
        CLASS_MAP.put("crsecond.\u00d9", "TextureOffset");
        CLASS_MAP.put("craftrise.\u042a\u057a", "EntityList");
        CLASS_MAP.put("craftrise.\u042a\u047c", "IBlockState");
        CLASS_MAP.put("craftrise.\u02e2$\u03ca", "MovingObjectType");
        CLASS_MAP.put("craftrise.\u00c3", "Gui");
        CLASS_MAP.put("craftrise.\u042a\u0582", "S18PacketEntityTeleport");
        CLASS_MAP.put("craftrise.\u03c0", "GuiInventory");
        CLASS_MAP.put("crsecond.\u03ce", "craftrise.Config");
        CLASS_MAP.put("craftrise.\u0585", "DataWatcher");
        CLASS_MAP.put("craftrise.\u0191", "BlockRendererDispatcher");
        CLASS_MAP.put("crsecond.\u0401", "TimerContainer");
        CLASS_MAP.put("crsecond.\u0202", "ModelPlayer");
        CLASS_MAP.put("craftrise.\u042a\u0452", "C01PacketChatMessage");
        CLASS_MAP.put("craftrise.\u048e", "Entity");
        CLASS_MAP.put("crsecond.\u0224\u0192", "BlockPos");
        CLASS_MAP.put("craftrise.U\u0429", "RenderItem");
        CLASS_MAP.put("craftrise.\u049e", "GuiChest");
        CLASS_MAP.put("craftrise.\u042a\u0261", "S12PacketEntityVelocity");
        CLASS_MAP.put("craftrise.U\u03fa$\u040d", "C07PacketPlayerDigging.Action");
        CLASS_MAP.put("craftrise.\u042a\u0226", "GlStateManager");
        CLASS_MAP.put("craftrise.\u042a\u0427", "NetHandlerPlayClient");
        CLASS_MAP.put("craftrise.\u01f1", "Block");
        CLASS_MAP.put("craftrise.U\u04f9", "NetworkPlayerInfo");
        CLASS_MAP.put("craftrise.U\u03fa", "C07PacketPlayerDigging");
        CLASS_MAP.put("craftrise.\u04ee", "GuiContainer");
        CLASS_MAP.put("craftrise.U\u01fc", "TextureManager");
        CLASS_MAP.put("craftrise.\u042a\u02ab$\u03a9", "C05PacketPlayerLook");
        CLASS_MAP.put("craftrise.\u042a\u013e", "RendererLivingEntity");
        CLASS_MAP.put("crsecond.\u0224\u026a", "Timer");
        CLASS_MAP.put("craftrise.\u0503", "GuiInGame");
        CLASS_MAP.put("craftrise.\u03fd", "Chunk");
        CLASS_MAP.put("craftrise.U\u050d", "NBTTagCompound");
        CLASS_MAP.put("craftrise.\u00c9", "AbstractClientPlayer");
        CLASS_MAP.put("craftrise.U\u03d3", "C10PacketCreativeInventoryAction");
        CLASS_MAP.put("NULL", "PlayerCapabilities");
        CLASS_MAP.put("crsecond.\u0243", "EnumPacketDirection");
        CLASS_MAP.put("craftrise.U\u01d6", "BlockModelShapes");
        CLASS_MAP.put("craftrise.\u03d4", "GuiScreen");
        CLASS_MAP.put("craftrise.\u042a\u0212", "RenderPlayer");
        CLASS_MAP.put("craftrise.U\u04e1", "ItemStack");
        CLASS_MAP.put("craftrise.U\u00e1", "Potion");
        CLASS_MAP.put("craftrise.U\u03e5", "AxisAlignedBB");
        CLASS_MAP.put("craftrise.\u042a\u01ca$\u0236", "EnumAxisDirection");
        CLASS_MAP.put("craftrise.\u042a\u02ab$\u0290", "C04PacketPlayerPosition");
        CLASS_MAP.put("craftrise.\u03e2", "C0APacketAnimation");
        CLASS_MAP.put("craftrise.\u02e2", "MovingObjectPosition");
        CLASS_MAP.put("craftrise.\u042a\u0522", "RenderBiped");
        CLASS_MAP.put("craftrise.U\u02b0", "ItemRenderer");
        CLASS_MAP.put("crsecond.\u056a", "CRGameInfo");
        CLASS_MAP.put("craftrise.\u042a\u00f2", "C08PacketPlayerBlockPlacement");
        CLASS_MAP.put("craftrise.\u0539", "EntityFishHook");
        CLASS_MAP.put("craftrise.\u023a", "IInventory");
        CLASS_MAP.put("craftrise.U\u00c2", "C02PacketUseEntity");
        CLASS_MAP.put("crsecond.P", "GameProfile");
        CLASS_MAP.put("craftrise.U\u04cf", "WorldInfo");
        CLASS_MAP.put("craftrise.\u010c", "EntityLivingBase");
        CLASS_MAP.put("crsecond.\u048a", "IChatComponent");
        CLASS_MAP.put("craftrise.\u042a\u01ca", "EnumFacing");
        CLASS_MAP.put("craftrise.\u0205", "Packet");
        CLASS_MAP.put("craftrise.U\u0296", "BlockModelRenderer");
        CLASS_MAP.put("crsecond.\u0224\u04fa", "ClientUtils");
        CLASS_MAP.put("craftrise.U\u0199", "RenderHelper");
        CLASS_MAP.put("craftrise.\u0413", "Vec3");
        CLASS_MAP.put("craftrise.\u042a\u00d2", "ModelBase");
        CLASS_MAP.put("crsecond.\u017b", "ScoreBoardUtil");
        CLASS_MAP.put("craftrise.\u042a\u00d3", "TileEntityRendererDispatcher");
        CLASS_MAP.put("craftrise.U\u01a1", "Slot");
        CLASS_MAP.put("craftrise.\u042a\u01ca$\u03f0", "EnumAxis");
        CLASS_MAP.put("craftrise.\u051c", "INetHandlerPlayServer");
        CLASS_MAP.put("craftrise.U\u02aa", "NBTTagList");
        CLASS_MAP.put("craftrise.U\u03ad", "Container");
        CLASS_MAP.put("crsecond.\u026b", "ModelRenderer");
        CLASS_MAP.put("craftrise.\u051e", "EntityPlayer");
        CLASS_MAP.put("craftrise.\u0220", "FontRenderer");
        FIELD_MAP.put("ModelPlayer\tbipedRightArmwear", "ModelPlayer.bipedRightArmwear");
        FIELD_MAP.put("KeyBinding\t\u04a8", "KeyBinding.keyCode");
        FIELD_MAP.put("AxisAlignedBB\t\u04a1", "AxisAlignedBB.minX");
        FIELD_MAP.put("CRGameInfo\tswtype", "CRGameInfo.swtype");
        FIELD_MAP.put("AxisAlignedBB\t\u038c", "AxisAlignedBB.maxX");
        FIELD_MAP.put("ModelBiped\tbipedRightLeg", "ModelBiped.bipedRightLeg");
        FIELD_MAP.put("Entity\t\u0243", "Entity.lastTickPosZ");
        FIELD_MAP.put("Minecraft\t\u03c4", "Minecraft.effectRenderer");
        FIELD_MAP.put("Container\t\u0199", "Container.inventorySlots");
        FIELD_MAP.put("RenderManager\t\u0418", "RenderManager.renderPosX");
        FIELD_MAP.put("EntityPlayer\t\u01e9", "EntityPlayer.inventory");
        FIELD_MAP.put("Entity\t\u053a", "Entity.prevPosX");
        FIELD_MAP.put("Entity\t\u053b", "Entity.lastTickPosX");
        FIELD_MAP.put("EntityLivingBase\t\u0270", "EntityLivingBase.renderYawOffset");
        FIELD_MAP.put("craftrise.Config\trenderPartialTicks", "craftrise.Config.renderPartialTicks");
        FIELD_MAP.put("MovingObjectPosition\t\u00e6", "MovingObjectPosition.hitVec");
        FIELD_MAP.put("EntityLivingBase\t\u04a4", "EntityLivingBase.prevRenderYawOffset");
        FIELD_MAP.put("NetworkPlayerInfo\t\u04ae", "NetworkPlayerInfo.responseTime");
        FIELD_MAP.put("GameProfile\t\u0213", "GameProfile.uuid");
        FIELD_MAP.put("ModelPlayer\tbipedLeftLegwear", "ModelPlayer.bipedLeftLegwear");
        FIELD_MAP.put("ItemStack\t\u0564", "ItemStack.stackSize");
        FIELD_MAP.put("InventoryPlayer\t\u017a", "InventoryPlayer.armorInventory");
        FIELD_MAP.put("ModelPlayer\tbipedLeftArmwear", "ModelPlayer.bipedLeftArmwear");
        FIELD_MAP.put("C03PacketPlayer\t\u0122", "C03PacketPlayer.y");
        FIELD_MAP.put("ModelBiped\tbipedHeadwear", "ModelBiped.bipedHeadwear");
        FIELD_MAP.put("ScaledResolution\t\u03e8", "ScaledResolution.width");
        FIELD_MAP.put("ScoreBoardUtil\t\u042c", "ScoreBoardUtil.scoreBoardInfo");
        FIELD_MAP.put("Entity\t\u015d", "Entity.motionX");
        FIELD_MAP.put("ModelPlayer\tbipedBodyWear", "ModelPlayer.bipedBodyWear");
        FIELD_MAP.put("Minecraft\t\u0419", "Minecraft.playerController");
        FIELD_MAP.put("ModelRenderer\tshowModel", "ModelRenderer.showModel");
        FIELD_MAP.put("AxisAlignedBB\t\u0258", "AxisAlignedBB.minY");
        FIELD_MAP.put("KeyBinding\t\u01ef", "KeyBinding.pressed");
        FIELD_MAP.put("InventoryPlayer\t\u00d2", "InventoryPlayer.currentItem");
        FIELD_MAP.put("ModelRenderer\trotationPointX", "ModelRenderer.rotationPointX");
        FIELD_MAP.put("EntityPlayer\t\u01b9", "EntityPlayer.inventoryContainer");
        FIELD_MAP.put("Entity\t\u0468", "Entity.motionY");
        FIELD_MAP.put("AxisAlignedBB\t\u0161", "AxisAlignedBB.maxY");
        FIELD_MAP.put("Entity\t\u0269", "Entity.isInWeb");
        FIELD_MAP.put("ModelRenderer\trotationPointZ", "ModelRenderer.rotationPointZ");
        FIELD_MAP.put("NetworkManager\t\u0168", "NetworkManager.channel");
        FIELD_MAP.put("ModelRenderer\trotationPointY", "ModelRenderer.rotationPointY");
        FIELD_MAP.put("EntityPlayer\t\u02b3", "EntityPlayer.openContainer");
        FIELD_MAP.put("Entity\t\u0580", "Entity.posZ");
        FIELD_MAP.put("EntityLivingBase\t\u023a", "EntityLivingBase.maxHurtTime");
        FIELD_MAP.put("ModelBiped\tbipedBody", "ModelBiped.bipedBody");
        FIELD_MAP.put("C03PacketPlayer\t\u023e", "C03PacketPlayer.pitch");
        FIELD_MAP.put("C03PacketPlayer\t\u0141", "C03PacketPlayer.yaw");
        FIELD_MAP.put("AxisAlignedBB\tP", "AxisAlignedBB.minZ");
        FIELD_MAP.put("Entity\t\u0179", "Entity.boundingBox");
        FIELD_MAP.put("EntityFishHook\t\u01db", "EntityFishHook.caughtEntity");
        FIELD_MAP.put("ModelBiped\tbipedRightArm", "ModelBiped.bipedRightArm");
        FIELD_MAP.put("ItemRenderer\t\u03cb", "ItemRenderer.equippedProgress");
        FIELD_MAP.put("ModelRenderer\trotateAngleX", "ModelRenderer.rotateAngleX");
        FIELD_MAP.put("Entity\t\u0392", "Entity.motionZ");
        FIELD_MAP.put("Entity\t\u0292", "Entity.rotationYaw");
        FIELD_MAP.put("ModelRenderer\trotateAngleY", "ModelRenderer.rotateAngleY");
        FIELD_MAP.put("ModelRenderer\trotateAngleZ", "ModelRenderer.rotateAngleZ");
        FIELD_MAP.put("C03PacketPlayer\t\u0172", "C03PacketPlayer.z");
        FIELD_MAP.put("Entity\t\u038c", "Entity.dataWatcher");
        FIELD_MAP.put("C03PacketPlayer\tp", "C03PacketPlayer.onGround");
        FIELD_MAP.put("CRGameInfo\tdisplayname", "CRGameInfo.displayname");
        FIELD_MAP.put("Minecraft\t\u01ee", "Minecraft.theMinecraft");
        FIELD_MAP.put("InventoryPlayer\t\u01bd", "InventoryPlayer.mainInventory");
        FIELD_MAP.put("MovingObjectPosition\tO", "MovingObjectPosition.typeOfHit");
        FIELD_MAP.put("RenderManager\t\u037d", "RenderManager.renderPosZ");
        FIELD_MAP.put("RendererLivingEntity\t\u050b", "RendererLivingEntity.NAME_TAG_RANGE_SNEAK");
        FIELD_MAP.put("MovingObjectPosition\t\u0249", "MovingObjectPosition.entityHit");
        FIELD_MAP.put("Minecraft\t\u03de", "Minecraft.currentScreen");
        FIELD_MAP.put("ItemStack\t\u010d", "ItemStack.item");
        FIELD_MAP.put("EntityLivingBase\t\u0409", "EntityLivingBase.moveForward");
        FIELD_MAP.put("Entity\t\u01ae", "Entity.rotationPitch");
        FIELD_MAP.put("Minecraft\t\u0255", "Minecraft.cps1");
        FIELD_MAP.put("Entity\t\u04ac", "Entity.height");
        FIELD_MAP.put("NetworkPlayerInfo\t\u0214", "NetworkPlayerInfo.displayName");
        FIELD_MAP.put("EntityLivingBase\t\u01ff", "EntityLivingBase.healthHelper");
        FIELD_MAP.put("C03PacketPlayer\t\u0291", "C03PacketPlayer.x");
        FIELD_MAP.put("EntityLivingBase\t\u0501", "EntityLivingBase.rotationYawHead");
        FIELD_MAP.put("NetworkPlayerInfo\t\u0519", "NetworkPlayerInfo.locationCape");
        FIELD_MAP.put("Container\t\u0222", "Container.dragMode");
        FIELD_MAP.put("Minecraft\t\u0243", "Minecraft.objectMouseOver");
        FIELD_MAP.put("Entity\t\u01ba", "Entity.onGround");
        FIELD_MAP.put("ModelRenderer\tchildModels", "ModelRenderer.childModels");
        FIELD_MAP.put("RendererLivingEntity\t\u0440", "RendererLivingEntity.NAME_TAG_RANGE");
        FIELD_MAP.put("ModelBiped\tbipedHead", "ModelBiped.bipedHead");
        FIELD_MAP.put("KeyBinding\t\u0244", "KeyBinding.keyCodeDefault");
        FIELD_MAP.put("ClientUtils\t\u025b", "ClientUtils.scoreBoard");
        FIELD_MAP.put("Container\t\u022f", "Container.windowId");
        FIELD_MAP.put("Entity\t\u04e5", "Entity.fallDistance");
        FIELD_MAP.put("CRGameInfo\tname", "CRGameInfo.name");
        FIELD_MAP.put("EntityLivingBase\t\u0117", "EntityLivingBase.attackedAtYaw");
        FIELD_MAP.put("AbstractClientPlayer\t\u0253", "AbstractClientPlayer.playerInfo");
        FIELD_MAP.put("ClientUtils\t\u014c", "ClientUtils.\u014c");
        FIELD_MAP.put("World\t\u038f", "World.loadedTileEntityList");
        FIELD_MAP.put("Entity\t\u03d8", "Entity.worldObj");
        FIELD_MAP.put("ModelBiped\tbipedLeftLeg", "ModelBiped.bipedLeftLeg");
        FIELD_MAP.put("CRGameInfo\tallGames", "CRGameInfo.allGames");
        FIELD_MAP.put("Entity\t\u01d6", "Entity.width");
        FIELD_MAP.put("ScaledResolution\t\u0556", "ScaledResolution.height");
        FIELD_MAP.put("ModelPlayer\tbipedDeadmau5Head", "ModelPlayer.bipedDeadmau5Head");
        FIELD_MAP.put("NetHandlerPlayClient\t\u01cc", "NetHandlerPlayClient.networkManager");
        FIELD_MAP.put("Entity\t\u04ef", "Entity.posX");
        FIELD_MAP.put("S12PacketEntityVelocity\t\u03e6", "S12PacketEntityVelocity.motionX");
        FIELD_MAP.put("Entity\t\u00ed", "Entity.prevPosY");
        FIELD_MAP.put("Entity\t\u03ea", "Entity.prevPosZ");
        FIELD_MAP.put("ItemRenderer\t\u0128", "ItemRenderer.itemToRender");
        FIELD_MAP.put("Entity\t\u0404", "Entity.lastTickPosY");
        FIELD_MAP.put("RenderManager\t\u02e0", "RenderManager.renderPosY");
        FIELD_MAP.put("World\t\u03e9", "World.playerEntities");
        FIELD_MAP.put("Minecraft\t\u0586", "Minecraft.cps2");
        FIELD_MAP.put("C01PacketChatMessage\t\u0524", "C01PacketChatMessage.message");
        FIELD_MAP.put("ModelPlayer\tbipedRightLegwear", "ModelPlayer.bipedRightLegwear");
        FIELD_MAP.put("Entity\t\u00fb", "Entity.ticksExisted");
        FIELD_MAP.put("EntityPlayer\t\u042b", "EntityPlayer.gameProfile");
        FIELD_MAP.put("RenderManager\t\u03d4", "RenderManager.entityRenderMap");
        FIELD_MAP.put("EntityFishHook\t\u045c", "EntityFishHook.inGround");
        FIELD_MAP.put("EntityPlayer\t\u0127", "EntityPlayer.fishEntity");
        FIELD_MAP.put("main\tSAFERUNNABLE", "main.SAFE_RUNNABLE");
        FIELD_MAP.put("ClientUtils\t\u0216", "ClientUtils.antiCheatField");
        FIELD_MAP.put("ModelBiped\tbipedLeftArm", "ModelBiped.bipedLeftArm");
        FIELD_MAP.put("Slot\t\u0576", "Slot.inventorySlots");
        FIELD_MAP.put("TileEntityRendererDispatcher\tinstance", "TileEntityRendererDispatcher.instance");
        FIELD_MAP.put("NetworkPlayerInfo\t\u03f4", "NetworkPlayerInfo.locationSkin");
        FIELD_MAP.put("ModelPlayer\tbipedCape", "ModelPlayer.bipedCape");
        FIELD_MAP.put("Entity\t\u050b", "Entity.entityId");
        FIELD_MAP.put("EntityLivingBase\t\u00de", "EntityLivingBase.moveStrafing");
        FIELD_MAP.put("GameProfile\t\u02e0", "GameProfile.name");
        FIELD_MAP.put("Entity\t\u0407", "Entity.posY");
        FIELD_MAP.put("EntityLivingBase\t\u01e2", "EntityLivingBase.hurtTime");
        FIELD_MAP.put("EntityLivingBase\t\u01d4", "EntityLivingBase.isSwingInProgress");
        FIELD_MAP.put("EntityPlayerSP\t\u03e2", "EntityPlayerSP.sendQueue");
        FIELD_MAP.put("S12PacketEntityVelocity\t\u04ef", "S12PacketEntityVelocity.motionY");
        FIELD_MAP.put("ItemRenderer\t\u0242", "ItemRenderer.prevEquippedProgress");
        FIELD_MAP.put("NetworkPlayerInfo\t\u0402", "NetworkPlayerInfo.gameProfile");
        FIELD_MAP.put("RenderBiped\t\u01f4", "RenderBiped.modelBiped");
        FIELD_MAP.put("Potion\t\u03dc", "Potion.potionTypes");
        FIELD_MAP.put("Minecraft\t\u0160", "Minecraft.ingameGUI");
        FIELD_MAP.put("AxisAlignedBB\t\u01f0", "AxisAlignedBB.maxZ");
        FIELD_MAP.put("S12PacketEntityVelocity\t\u04fa", "S12PacketEntityVelocity.motionZ");
        METHOD_MAP.put("EntityList\t\u04ef", "EntityList.addMapping1");
        METHOD_MAP.put("NBTTagCompound\t\u03ab", "NBTTagCompound.getTagList");
        METHOD_MAP.put("ModelRenderer\t\u01eb", "ModelRenderer.float1Method_1");
        METHOD_MAP.put("MovingObjectPosition\t\u04df", "MovingObjectPosition.getBlockPos");
        METHOD_MAP.put("ModelRenderer\t\u02e4", "ModelRenderer.float3Method_1");
        METHOD_MAP.put("CRGameInfo\t\u04f2", "CRGameInfo.getGameFromName");
        METHOD_MAP.put("BooleanContainer\t\u0224", "BooleanContainer.getValue");
        METHOD_MAP.put("PlayerControllerMP\t\u025c", "PlayerControllerMP.windowClick");
        METHOD_MAP.put("RenderItem\t\u013c", "RenderItem.renderModel");
        METHOD_MAP.put("ItemStack\t\u027f", "ItemStack.hasTagCompound");
        METHOD_MAP.put("RenderPlayer\t\u0118", "RenderPlayer.doRender");
        METHOD_MAP.put("Potion\t\u0103", "Potion.hasStatusIcon");
        METHOD_MAP.put("C01PacketChatMessage\t\u03e5", "C01PacketChatMessage.getMessage");
        METHOD_MAP.put("EntityPlayer\t\u01e9", "EntityPlayer.getHeldItem");
        METHOD_MAP.put("RenderItem\t\u0136", "RenderItem.renderItemAndEffectIntoGUI");
        METHOD_MAP.put("RenderManager\t\u0116", "RenderManager.getEntityRenderer");
        METHOD_MAP.put("Entity\t\u023b", "Entity.isEntityInsideOpaqueBlock");
        METHOD_MAP.put("TileEntityRendererDispatcher\trenderTileEntity", "TileEntityRendererDispatcher.renderTileEntity");
        METHOD_MAP.put("DataWatcher\t\u0548", "DataWatcher.updateObject");
        METHOD_MAP.put("ModelRenderer\t\u04cb", "ModelRenderer.addBox");
        METHOD_MAP.put("EntityPlayerSP\t\u0413", "EntityPlayerSP.addChatMessage");
        METHOD_MAP.put("ModelRenderer\t\u04ca", "ModelRenderer.float1Method_2");
        METHOD_MAP.put("S12PacketEntityVelocity\t\u0540", "S12PacketEntityVelocity.getMotionX");
        METHOD_MAP.put("NBTTagCompound\t\u0388", "NBTTagCompound.getString");
        METHOD_MAP.put("ScoreBoardUtil\t\u011e", "ScoreBoardUtil.getTitle");
        METHOD_MAP.put("DataWatcher\t\u024b", "DataWatcher.getInt");
        METHOD_MAP.put("Entity\t\u014f", "Entity.rayTrace");
        METHOD_MAP.put("EntityPlayerSP\t\u0109", "EntityPlayerSP.isCurrentViewEntity");
        METHOD_MAP.put("IBlockState\t\u051a", "IBlockState.getBlock");
        METHOD_MAP.put("ItemRenderer\t\u0284", "ItemRenderer.hurtAnim");
        METHOD_MAP.put("GuiInGame\t\u0283", "GuiInGame.renderGameOverlay");
        METHOD_MAP.put("GuiInventory\tX", "GuiInventory.drawEntityOnScreen");
        METHOD_MAP.put("NBTTagList\t\u053f", "NBTTagList.getCompoundTagAt");
        METHOD_MAP.put("EntityRenderer\t\u03df", "EntityRenderer.renderWorldPass");
        METHOD_MAP.put("FontRenderer\t\u0576", "FontRenderer.drawString");
        METHOD_MAP.put("Potion\t\u0127", "Potion.getName");
        METHOD_MAP.put("RenderManager\tC", "RenderManager.renderEntityStatic");
        METHOD_MAP.put("ItemRenderer\t\u037c", "ItemRenderer.doBlockTransform");
        METHOD_MAP.put("NetHandlerPlayClient\t\u01f9", "NetHandlerPlayClient.sendPacket");
        METHOD_MAP.put("Block\t\u0481", "Block.getStateFromMeta");
        METHOD_MAP.put("CRGameInfo\t\u03fe", "CRGameInfo.getActiveGames");
        METHOD_MAP.put("PacketBuffer\t\u0144", "PacketBuffer.writeEnumValue");
        METHOD_MAP.put("RenderHelper\tv", "RenderHelper.enableGUIStandardItemLighting");
        METHOD_MAP.put("FontRenderer\t\u054c", "FontRenderer.getStringWidth");
        METHOD_MAP.put("PlayerControllerMP\t\u021e", "PlayerControllerMP.syncCurrentPlayItem");
        METHOD_MAP.put("KeyBinding\t\u00e6", "KeyBinding.setKeyBindState");
        METHOD_MAP.put("EntityLivingBase\t\u033e", "EntityLivingBase.getHealth");
        METHOD_MAP.put("EntityPlayerSP\t\u016d", "EntityPlayerSP.setSprinting");
        METHOD_MAP.put("ItemRenderer\t\u01a7", "ItemRenderer.renderItemInFirstPerson");
        METHOD_MAP.put("Block\t\u047b", "Block.getBlockById");
        METHOD_MAP.put("ModelRenderer\t\u019e", "ModelRenderer.float3Method_2");
        METHOD_MAP.put("NBTTagList\t\u01db", "NBTTagList.tagCount");
        METHOD_MAP.put("GameProfile\t\u0144", "GameProfile.getUUID");
        METHOD_MAP.put("DataWatcher\t\u04e2", "DataWatcher.getFloat");
        METHOD_MAP.put("ModelBase\t\u00ca", "ModelBase.getTextureOffset");
        METHOD_MAP.put("S12PacketEntityVelocity\t\u0457", "S12PacketEntityVelocity.getMotionY");
        METHOD_MAP.put("RenderPlayer\tZ", "RenderPlayer.getMainModel");
        METHOD_MAP.put("World\t\u0175", "World.getChunkFromChunkCoords");
        METHOD_MAP.put("PacketBuffer\t\u0220", "PacketBuffer.writeVarIntToBuffer");
        METHOD_MAP.put("KeyBinding\t\u0511", "KeyBinding.onTick");
        METHOD_MAP.put("PacketBuffer\twriteFloat", "PacketBuffer.writeFloat");
        METHOD_MAP.put("Minecraft\t\u00ed", "Minecraft.getBlockRendererDispatcher");
        METHOD_MAP.put("EntityLivingBase\t\u0262", "EntityLivingBase.performHurtAnimation");
        METHOD_MAP.put("DataWatcher\t\u01f8", "DataWatcher.getByte");
        METHOD_MAP.put("ModelRenderer\t\u0197", "ModelRenderer.float1Method_3");
        METHOD_MAP.put("EntityLivingBase\t\u025b", "EntityLivingBase.moveEntityWithHeading");
        METHOD_MAP.put("RenderItem\t\u04da", "RenderItem.renderItemOverlayIntoGUI");
        METHOD_MAP.put("Slot\t\u0509", "Slot.getStack");
        METHOD_MAP.put("CRGameInfo\t\u0141", "CRGameInfo.getName");
        METHOD_MAP.put("GameProfile\t\u0164", "GameProfile.getName");
        METHOD_MAP.put("ItemStack\t\u0121", "ItemStack.setTagInfo");
        METHOD_MAP.put("Minecraft\t\u02e4", "Minecraft.getFontRendererObj");
        METHOD_MAP.put("NetworkPlayerInfo\t\u038a", "NetworkPlayerInfo.setDisplayName");
        METHOD_MAP.put("CRGameInfo\tH", "CRGameInfo.getAllGames");
        METHOD_MAP.put("RenderManager\t\u04ac", "RenderManager.getEntityRenderObject");
        METHOD_MAP.put("RenderHelper\t\u0413", "RenderHelper.disableStandardItemLighting");
        METHOD_MAP.put("BlockRendererDispatcher\t\u04fa", "BlockRendererDispatcher.getBlockModelRenderer");
        METHOD_MAP.put("Minecraft\t\u0551", "Minecraft.getRenderItem");
        METHOD_MAP.put("EntityList\t\u0473", "EntityList.addMapping");
        METHOD_MAP.put("DataWatcher\t\u03b3", "DataWatcher.getShort");
        METHOD_MAP.put("ItemRenderer\t\u03e9", "ItemRenderer.cameraRotate");
        METHOD_MAP.put("ItemRenderer\t\u00de", "ItemRenderer.armTransform");
        METHOD_MAP.put("NBTTagCompound\t\u0439", "NBTTagCompound.getInteger");
        METHOD_MAP.put("Gui\t\u0217", "Gui.drawScaledCustomSizeModalRect");
        METHOD_MAP.put("ModelBase\t\u0207", "ModelBase.setTextureOffset");
        METHOD_MAP.put("Entity\t\u02b6", "Entity.getFlag");
        METHOD_MAP.put("Vec3i\t\u0201", "Vec3i.getY");
        METHOD_MAP.put("RenderManager\t\u00d0", "RenderManager.renderEntityWithPosYaw");
        METHOD_MAP.put("TileEntityRendererDispatcher\tcacheActiveRenderInfo", "TileEntityRendererDispatcher.cacheActiveRenderInfo");
        METHOD_MAP.put("Gui\t\u0148", "Gui.drawModalRectWithCustomSizedTexture");
        METHOD_MAP.put("ModelBase\t\u0213", "ModelBase.render");
        METHOD_MAP.put("Entity\t\u04cf", "Entity.getDistanceToEntity");
        METHOD_MAP.put("Block\t\u0414", "Block.getMetaFromState");
        METHOD_MAP.put("Vec3i\t\u04f0", "Vec3i.getX");
        METHOD_MAP.put("NetworkPlayerInfo\t\u0438", "NetworkPlayerInfo.getGameProfile");
        METHOD_MAP.put("World\t\u0283", "World.getTileEntity");
        METHOD_MAP.put("ItemRenderer\t\u050a", "ItemRenderer.lighting");
        METHOD_MAP.put("Container\t\u012e", "Container.getSlot");
        METHOD_MAP.put("Minecraft\t\u012c", "Minecraft.getRenderManager");
        METHOD_MAP.put("Minecraft\t\u042c", "Minecraft.getTextureManager");
        METHOD_MAP.put("ModelBase\t\u021d", "ModelBase.setRotationAngles");
        METHOD_MAP.put("NetworkPlayerInfo\t\u053a", "NetworkPlayerInfo.getResponseTime");
        METHOD_MAP.put("S12PacketEntityVelocity\t\u01ae", "S12PacketEntityVelocity.getMotionZ");
        METHOD_MAP.put("Block\ttoString", "Block.getLocalizedName");
        METHOD_MAP.put("Block\t\u0102", "Block.getIdFromBlock");
        METHOD_MAP.put("Item\t\u050e", "Item.getUnlocalizedName");
        METHOD_MAP.put("RenderManager\t\u04b5", "RenderManager.shouldRender");
        METHOD_MAP.put("Entity\t\u03f4", "Entity.setPositionAndUpdate");
        METHOD_MAP.put("Chunk\t\u047b", "Chunk.getBlock");
        METHOD_MAP.put("NBTTagCompound\t\u0267", "NBTTagCompound.getCompoundTag");
        METHOD_MAP.put("C02PacketUseEntity\tf", "C02PacketUseEntity.getEntity");
        METHOD_MAP.put("ScoreBoardUtil\t\u043c", "ScoreBoardUtil.getScoreBoardInfo");
        METHOD_MAP.put("S12PacketEntityVelocity\t\u03e3", "S12PacketEntityVelocity.getEntityID");
        METHOD_MAP.put("TextureManager\t\u0174", "TextureManager.getDynamicTextureLocation");
        METHOD_MAP.put("Entity\t\u01ec", "Entity.setFlag");
        METHOD_MAP.put("Entity\t\u00ed", "Entity.getUniqueID");
        METHOD_MAP.put("EntityPlayerSP\t\u00eb", "EntityPlayerSP.swingItem");
        METHOD_MAP.put("NBTTagCompound\t\u0371", "NBTTagCompound.hasKey");
        METHOD_MAP.put("ItemStack\t\u04cb", "ItemStack.getDisplayName");
        METHOD_MAP.put("CRGameInfo\t\u03b6", "CRGameInfo.getGame");
        METHOD_MAP.put("ItemStack\t\u00c8", "ItemStack.getTagCompound");
        METHOD_MAP.put("MotionContainer\t\u00d9", "MotionContainer.getValue");
        METHOD_MAP.put("ModelBase\t\u0143", "ModelBase.setModelAttributes");
        METHOD_MAP.put("ModelRenderer\t\u0237", "ModelRenderer.addChild");
        METHOD_MAP.put("World\t\u00eb", "World.getBlockState");
        METHOD_MAP.put("ModelRenderer\t\u0231", "ModelRenderer.float1Method_4");
        METHOD_MAP.put("EntityPlayerSP\t\u00ff", "EntityPlayerSP.joinEntityItemWithWorld");
        METHOD_MAP.put("ModelBase\t\u054e", "ModelBase.copyModelAngles");
        METHOD_MAP.put("Vec3i\t\u0142", "Vec3i.getZ");
        METHOD_MAP.put("TimerContainer\t\u024b", "TimerContainer.getValue");
        METHOD_MAP.put("BlockModelRenderer\t\u049b", "BlockModelRenderer.getModelForState");
        METHOD_MAP.put("ItemRenderer\tN", "ItemRenderer.renderItem");
        METHOD_MAP.put("EntityLivingBase\t\u01e8", "EntityLivingBase.getActivePotionEffects");
        METHOD_MAP.put("ItemRenderer\t\u0152", "ItemRenderer.swingBob");
        METHOD_MAP.put("CRGameInfo\t\u00d5", "CRGameInfo.getDisplayName");
        METHOD_MAP.put("ModelBase\t\u0160", "ModelBase.setLivingAnimations");
        METHOD_MAP.put("Entity\t\u0225", "Entity.setPositionAndRotation");
        METHOD_MAP.put("Minecraft\t\u0569", "Minecraft.getThePlayer");
        METHOD_MAP.put("ModelRenderer\t\u0116", "ModelRenderer.setTextureOffset");
        METHOD_MAP.put("DataWatcher\t\u0280", "DataWatcher.getString");
        METHOD_MAP.put("ItemStack\t\u0394", "ItemStack.getEnchantmentTagList");
        METHOD_MAP.put("EntityPlayer\tF", "EntityPlayer.isSneaking");
        METHOD_MAP.put("EntityPlayer\tE", "EntityPlayer.setItemInUse");
        METHOD_MAP.put("Entity\t\u0516", "Entity.getEyeHeight");
        METHOD_MAP.put("Gui\t\u026f", "Gui.drawRect");
        METHOD_MAP.put("ItemStack\t\u0298", "ItemStack.getSubCompound");
    }
}

