/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package me.ries.util;

import org.lwjgl.opengl.GL11;

public final class GlStateManager {
    private GlStateManager() {
    }

    public static void pushMatrix() {
        GL11.glPushMatrix();
    }

    public static void popMatrix() {
        GL11.glPopMatrix();
    }

    public static void translate(float x, float y, float z) {
        GL11.glTranslatef((float)x, (float)y, (float)z);
    }

    public static void translate(double x, double y, double z) {
        GL11.glTranslated((double)x, (double)y, (double)z);
    }

    public static void scale(float x, float y, float z) {
        GL11.glScalef((float)x, (float)y, (float)z);
    }

    public static void scale(double x, double y, double z) {
        GL11.glScalef((float)((float)x), (float)((float)y), (float)((float)z));
    }

    public static void rotate(float angle, float x, float y, float z) {
        GL11.glRotatef((float)angle, (float)x, (float)y, (float)z);
    }

    public static void color(float r, float g, float b, float a) {
        GL11.glColor4f((float)r, (float)g, (float)b, (float)a);
    }

    public static void color(float r, float g, float b) {
        GL11.glColor3f((float)r, (float)g, (float)b);
    }

    public static void resetColor() {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void enableBlend() {
        GL11.glEnable((int)3042);
    }

    public static void disableBlend() {
        GL11.glDisable((int)3042);
    }

    public static void blendFunc(int src, int dst) {
        GL11.glBlendFunc((int)src, (int)dst);
    }

    public static void enableTexture2D() {
        GL11.glEnable((int)3553);
    }

    public static void disableTexture2D() {
        GL11.glDisable((int)3553);
    }

    public static void enableDepth() {
        GL11.glEnable((int)2929);
    }

    public static void disableDepth() {
        GL11.glDisable((int)2929);
    }

    public static void enableAlpha() {
        GL11.glEnable((int)3008);
    }

    public static void disableAlpha() {
        GL11.glDisable((int)3008);
    }

    public static void enableCull() {
        GL11.glEnable((int)2884);
    }

    public static void disableCull() {
        GL11.glDisable((int)2884);
    }

    public static void bindTexture(int id) {
        GL11.glBindTexture((int)3553, (int)id);
    }

    public static void colorMask(boolean r, boolean g, boolean b, boolean a) {
        GL11.glColorMask((boolean)r, (boolean)g, (boolean)b, (boolean)a);
    }

    public static void depthMask(boolean flag) {
        GL11.glDepthMask((boolean)flag);
    }

    public static void shadeModel(int mode) {
        GL11.glShadeModel((int)mode);
    }

    public static void matrixMode(int mode) {
        GL11.glMatrixMode((int)mode);
    }

    public static void loadIdentity() {
        GL11.glLoadIdentity();
    }

    public static void viewport(int x, int y, int w, int h) {
        GL11.glViewport((int)x, (int)y, (int)w, (int)h);
    }

    public static void clear(int mask) {
        GL11.glClear((int)mask);
    }

    public static int generateTexture() {
        return GL11.glGenTextures();
    }

    public static void deleteTexture(int id) {
        GL11.glDeleteTextures((int)id);
    }
}

