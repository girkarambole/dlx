/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package me.ries.util;

import me.ries.util.Logger;
import org.lwjgl.opengl.GL11;

public class GLErrorChecker {
    private static int errorCount = 0;

    public static void clear() {
        while (GL11.glGetError() != 0) {
        }
    }

    public static int check(String tag) {
        int error;
        int count = 0;
        while ((error = GL11.glGetError()) != 0) {
            ++count;
            ++errorCount;
            Logger.warn("[GL_ERROR] " + tag + " -> error=0x" + Integer.toHexString(error) + " (" + GLErrorChecker.translate(error) + ")");
        }
        if (count > 0) {
            Logger.warn("[GL_ERROR] " + tag + " -> " + count + " error(s) cleared (total=" + errorCount + ")");
        }
        return count;
    }

    public static void wrap(String tag, Runnable block) {
        GLErrorChecker.clear();
        try {
            block.run();
        }
        catch (Throwable t) {
            Logger.warn("[GL_ERROR] " + tag + " threw: " + t.getMessage());
        }
        GLErrorChecker.check(tag);
    }

    private static String translate(int error) {
        switch (error) {
            case 1280: {
                return "GL_INVALID_ENUM (0x500)";
            }
            case 1281: {
                return "GL_INVALID_VALUE (0x501)";
            }
            case 1282: {
                return "GL_INVALID_OPERATION (0x502)";
            }
            case 1283: {
                return "GL_STACK_OVERFLOW (0x503)";
            }
            case 1284: {
                return "GL_STACK_UNDERFLOW (0x504)";
            }
            case 1285: {
                return "GL_OUT_OF_MEMORY (0x505)";
            }
        }
        return "0x" + Integer.toHexString(error);
    }
}

