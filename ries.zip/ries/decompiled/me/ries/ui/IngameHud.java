/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package me.ries.ui;

import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.ries.Ries;
import me.ries.event.Render2DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.ArrayListModule;
import me.ries.module.impl.ReachModule;
import me.ries.module.impl.ScoreBoardModule;
import me.ries.module.impl.SpotifyWidget;
import me.ries.module.impl.TargetHudModule;
import me.ries.module.impl.WatermarkModule;
import me.ries.notification.NotificationManager;
import me.ries.ui.ClickGui;
import me.ries.util.FontUtil;
import me.ries.util.GLErrorChecker;
import me.ries.util.GaussianBlur;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import me.ries.util.RoundedUtil;
import me.ries.util.ScissorUtil;
import me.ries.util.animation.Animation;
import me.ries.util.animation.DecelerateAnimation;
import me.ries.util.animation.Direction;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public final class IngameHud {
    private static final Animation OPEN_ANIM = new DecelerateAnimation(350, 1.0);
    private static long lastFrameTime = 0L;
    private static float deltaTime = 0.0f;
    private static float borderPulse = 0.0f;
    private static List<Module> sortedModules = new ArrayList<Module>();
    private static long lastSortTime = 0L;
    private static final Map<String, Float> anims = new HashMap<String, Float>();
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm");
    private static String cachedTime = "";
    private static long lastTimeUpdate = 0L;
    private static long lastFpsTime = 0L;
    private static int frameCount = 0;
    private static int currentFps = 0;
    private static final String[] TEXTS = new String[]{"Massacre", "by 873"};
    private static final long HOLD_MS = 2500L;
    private static final long TRANSITION_MS = 900L;
    private static final long CHAR_DELAY_MS = 60L;
    private static int brandState = 0;
    private static long brandStateStart = System.currentTimeMillis();
    private static int brandTextIndex = 0;
    private static float[] charProgress = new float[0];
    public static float watermarkX = 8.0f;
    public static float watermarkY = 8.0f;
    private static boolean watermarkDragging = false;
    private static float watermarkDragOffX = 0.0f;
    private static float watermarkDragOffY = 0.0f;
    public static float arrayListX = 0.0f;
    public static float arrayListY = 10.0f;
    private static boolean arrayListDragging = false;
    private static float arrayListDragOffX = 0.0f;
    private static float arrayListDragOffY = 0.0f;
    private static float lastWatermarkW = 0.0f;
    private static float lastWatermarkH = 0.0f;
    public static float lastArrayListW = 0.0f;
    public static float lastArrayListH = 0.0f;
    private static volatile boolean firstRenderLogged;
    private static volatile boolean firstDrawLogged;
    private static volatile boolean mappingMissingLogged;
    private static volatile long lastWarnTime;
    private static volatile Method drawStringMethod;
    private static Field cachedDetectionFlag1;
    private static Method cachedGetInstance;
    private static boolean detectionFlagCacheTried;

    private static float computeBrandWidth(float f) {
        String string = "Massacre.vip";
        if (IngameHud.isShowPrefixEnabled()) {
            String string2 = IngameHud.getLocalPlayerName();
            String string3 = string2.isEmpty() ? string : string + " | " + string2;
            return (float)FontUtil.getStringWidth(string3) * f;
        }
        return (float)FontUtil.getStringWidth(string) * f;
    }

    private static String getLocalPlayerName() {
        try {
            Object object = MinecraftMapper.getThePlayer();
            if (object == null) {
                return "";
            }
            String string = MappingUtils.getName(object);
            if (string == null || string.equals("?") || string.isEmpty()) {
                return "";
            }
            String string2 = string.replaceAll("(?i)[\u00a7$&][0-9a-fk-or]", "").trim();
            if (string2.isEmpty()) {
                return "";
            }
            String[] stringArray = string2.split("\\s+");
            return stringArray[stringArray.length - 1];
        }
        catch (Throwable throwable) {
            return "";
        }
    }

    private static boolean isShowPrefixEnabled() {
        try {
            ArrayListModule arrayListModule = Ries.getInstance().getModuleManager().getModule(ArrayListModule.class);
            return arrayListModule == null || arrayListModule.isShowPrefix();
        }
        catch (Throwable throwable) {
            return true;
        }
    }

    public static float getWatermarkRight() {
        return watermarkX + lastWatermarkW;
    }

    private IngameHud() {
    }

    private static void resetDetectionFlags() {
        try {
            boolean bl;
            if (!detectionFlagCacheTried) {
                detectionFlagCacheTried = true;
                cachedDetectionFlag1 = MappingUtils.getField("Minecraft.detectionFlag1");
                if (cachedDetectionFlag1 != null) {
                    cachedDetectionFlag1.setAccessible(true);
                }
                if ((cachedGetInstance = MappingUtils.getMethod("Minecraft.getInstance")) != null) {
                    cachedGetInstance.setAccessible(true);
                }
            }
            if (cachedDetectionFlag1 == null || cachedGetInstance == null) {
                return;
            }
            Object object = cachedGetInstance.invoke(null, new Object[0]);
            if (object != null && (bl = cachedDetectionFlag1.getBoolean(object))) {
                Logger.warn("[DetectionFlag] detectionFlag1 was TRUE \u00c3\u00a2\u00e2\u201a\u00ac\u00e2\u20ac\u009d resetting to false! stack: " + IngameHud.getCallerStack());
                cachedDetectionFlag1.setBoolean(object, false);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static String getCallerStack() {
        StackTraceElement[] stackTraceElementArray = Thread.currentThread().getStackTrace();
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 4; i < Math.min(stackTraceElementArray.length, 10); ++i) {
            stringBuilder.append(stackTraceElementArray[i].getClassName()).append('.').append(stackTraceElementArray[i].getMethodName()).append('(').append(stackTraceElementArray[i].getLineNumber()).append(')');
            if (i >= Math.min(stackTraceElementArray.length, 10) - 1) continue;
            stringBuilder.append(" <- ");
        }
        return stringBuilder.toString();
    }

    public static void renderFrame() {
        IngameHud.resetDetectionFlags();
        try {
            Ries.getInstance().getModuleManager().handleKeyBinds();
            Ries.getInstance().getModuleManager().updateModules();
            ReachModule reachModule = Ries.getInstance().getModuleManager().getModule(ReachModule.class);
            if (reachModule != null && reachModule.isEnabled()) {
                reachModule.onUpdate();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        IngameHud.render(null, 0.0f);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void render(Object object, float f) {
        try {
            if (!firstRenderLogged) {
                firstRenderLogged = true;
                Logger.info("IngameHud renderFrame reached");
                IngameHud.markHudStatus("JAVA_RENDER_FIRST_CALL");
            }
            Object object2 = MinecraftMapper.getFontRenderer();
            Method method = IngameHud.getDrawStringMethod();
            if (object2 == null || method == null) {
                if (!mappingMissingLogged) {
                    mappingMissingLogged = true;
                    IngameHud.markHudStatus("JAVA_RENDER_MAPPING_MISSING");
                }
                IngameHud.warnThrottled("IngameHud: FontRenderer mapping is not ready");
                return;
            }
            IngameHud.pushHudState();
            try {
                GLErrorChecker.check("IngameHud.render after pushHudState");
                OPEN_ANIM.setDirection(Direction.FORWARDS);
                IngameHud.renderInternal();
                ClickGui.renderFrame();
                GLErrorChecker.check("IngameHud.render before popHudState");
                if (!firstDrawLogged) {
                    firstDrawLogged = true;
                    Logger.info("IngameHud draw completed");
                    IngameHud.markHudStatus("JAVA_RENDER_DRAW_OK");
                }
            }
            finally {
                IngameHud.popHudState();
            }
        }
        catch (Throwable throwable) {
            IngameHud.markHudStatus("JAVA_RENDER_EXCEPTION " + throwable.getClass().getName() + ": " + throwable.getMessage());
            IngameHud.warnThrottled("IngameHud render error: " + throwable.getMessage());
        }
    }

    public static void renderForEditMode(float f) {
        IngameHud.pushHudState();
        try {
            IngameHud.renderInternal(true, true, true, true);
        }
        finally {
            IngameHud.popHudState();
        }
    }

    public static void resetDragState() {
        watermarkDragging = false;
        arrayListDragging = false;
        TargetHudModule.resetDragState();
        NotificationManager.resetDragState();
        ScoreBoardModule.resetDragState();
    }

    private static void renderInternal() {
        IngameHud.renderInternal(true, true, true, true);
    }

    private static void renderInternal(boolean bl, boolean bl2, boolean bl3, boolean bl4) {
        float f = OPEN_ANIM.getOutput().floatValue();
        if (!(f < 0.01f)) {
            long l = System.currentTimeMillis();
            if (lastFrameTime == 0L) {
                lastFrameTime = l;
            }
            deltaTime = Math.min((float)(l - lastFrameTime) / 16.666666f, 3.0f);
            lastFrameTime = l;
            if (borderPulse > 0.0f) {
                borderPulse -= deltaTime * 0.05f;
                if (borderPulse < 0.0f) {
                    borderPulse = 0.0f;
                }
            }
            GaussianBlur.beginFrame();
            int n = ScissorUtil.getScaledWidth();
            int n2 = ScissorUtil.getScaledHeight();
            int n3 = ScissorUtil.mapMouseX(Mouse.getX());
            int n4 = ScissorUtil.mapMouseY(Mouse.getY());
            GL11.glPushMatrix();
            boolean bl5 = false;
            try {
                WatermarkModule watermarkModule = Ries.getInstance().getModuleManager().getModule(WatermarkModule.class);
                bl5 = watermarkModule != null && watermarkModule.isEnabled();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            boolean bl6 = false;
            try {
                ArrayListModule arrayListModule = Ries.getInstance().getModuleManager().getModule(ArrayListModule.class);
                bl6 = arrayListModule != null && arrayListModule.isEnabled();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (ClickGui.isUiEditMode() && !Mouse.isGrabbed()) {
                if (bl3 && bl5) {
                    IngameHud.handleWatermarkDrag(n3, n4, n, n2);
                }
                if (bl4 && bl6) {
                    IngameHud.handleArrayListDrag(n3, n4, n, n2);
                }
            }
            if (bl && bl5) {
                IngameHud.renderLogo(n, n2, f);
                GLErrorChecker.check("IngameHud.renderLogo");
            }
            if (bl2 && bl6) {
                IngameHud.renderArrayList(n, n2, f);
                GLErrorChecker.check("IngameHud.renderArrayList");
            }
            IngameHud.renderSpotifyWidget(f);
            GLErrorChecker.check("IngameHud.renderSpotifyWidget");
            IngameHud.renderTargetHud();
            GLErrorChecker.check("IngameHud.renderTargetHud");
            try {
                NotificationManager.render();
            }
            catch (Throwable throwable) {
                IngameHud.warnThrottled("NotificationManager render error: " + throwable.getMessage());
            }
            GLErrorChecker.check("IngameHud.renderNotifications");
            try {
                Ries.getInstance().getEventBus().post(new Render2DEvent(0.0f));
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            GL11.glPopMatrix();
            GL11.glEnable((int)3042);
            GL11.glEnable((int)2929);
            GL11.glEnable((int)3008);
            GL11.glEnable((int)3553);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GLErrorChecker.check("IngameHud after glPopMatrix");
        }
    }

    private static void renderLogo(int n, int n2, float f) {
        Color color;
        Object object;
        float f2 = 0.85f;
        float f3 = IngameHud.computeBrandWidth(f2);
        float f4 = 1.0f;
        float f5 = 4.0f + f4 + 4.0f + f3 + 8.0f;
        float f6 = 22.0f;
        float f7 = f6 / 2.0f;
        lastWatermarkW = f5;
        lastWatermarkH = f6;
        float f8 = watermarkX;
        float f9 = watermarkY + (1.0f - f) * -10.0f;
        Color color2 = new Color(15, 15, 15, (int)(130.0f * f));
        Color color3 = new Color(255, 255, 255, (int)(32.0f * f));
        GaussianBlur.renderBlurRounded(f8, f9, f5, f6, f7, 8.0f * f);
        RoundedUtil.roundedRect((double)f8, (double)f9, (double)f5, (double)f6, (double)f7, color2);
        RoundedUtil.drawRoundOutline(f8, f9, f5, f6, f7, 1.0f, color3);
        try {
            object = Ries.getInstance().getModuleManager().getModule(WatermarkModule.class);
            color = object != null ? ((WatermarkModule)object).getAccentColor() : new Color(255, 255, 255, 120);
        }
        catch (Throwable throwable) {
            color = new Color(255, 255, 255, 120);
        }
        RoundedUtil.rect((double)(f8 + 4.0f), (double)(f9 + 4.0f), (double)f4, (double)(f6 - 8.0f), new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(180.0f * f)));
        if (ClickGui.isUiEditMode()) {
            object = watermarkDragging ? new Color(0, 110, 254, (int)(255.0f * f)) : new Color(0, 110, 254, (int)(60.0f * f));
            RoundedUtil.drawRoundOutline(f8, f9, f5, f6, f7, 1.0f, (Color)object);
        }
        float f10 = f9 + (f6 - (float)FontUtil.getFontHeight() * f2) / 2.0f;
        float f11 = f8 + 4.0f + f4 + 4.0f;
        IngameHud.drawBlurText(f11, f10, f2, f);
    }

    private static float animateBounce(String string, float f, boolean bl) {
        if (!anims.containsKey(string)) {
            anims.put(string, Float.valueOf(bl ? 0.0f : 1.0f));
        }
        float f2 = anims.get(string).floatValue();
        float f3 = Math.min(deltaTime, 1.5f);
        if (bl) {
            f2 += (1.06f - f2) * 0.055f * f3;
            if (f2 > 1.06f) {
                f2 = 1.06f;
            }
            if (f2 > 1.0f) {
                f2 += (1.0f - f2) * 0.07f * f3;
            }
            f2 = Math.min(f2, 1.06f);
        } else {
            f2 += (0.0f - f2) * 0.055f * f3;
        }
        anims.put(string, Float.valueOf(f2));
        return Math.max(0.0f, f2);
    }

    private static void renderArrayList(int n, int n2, float f) {
        ArrayListModule arrayListModule;
        float f2;
        float f3;
        float f4;
        long l = System.currentTimeMillis();
        if (l - lastSortTime > 100L || sortedModules.isEmpty()) {
            List<Module> list = Ries.getInstance().getModuleManager().getModules();
            ArrayList<Module> arrayList = new ArrayList<Module>();
            for (Module module : list) {
                if (module.getName().equals("HUD") || module.isHidden()) continue;
                String string = "arr_" + module.getName();
                f4 = anims.containsKey(string) ? anims.get(string).floatValue() : 0.0f;
                f3 = f4;
                if (!module.isEnabled() && !(f4 > 0.01f)) continue;
                arrayList.add(module);
            }
            arrayList.sort(new Comparator<Module>(){

                @Override
                public int compare(Module module, Module module2) {
                    return Float.compare(IngameHud.getModuleWidth(module2), IngameHud.getModuleWidth(module));
                }
            });
            sortedModules = arrayList;
            lastSortTime = l;
        }
        arrayListModule = Ries.getInstance().getModuleManager().getModule(ArrayListModule.class);
        float f5 = 13.0f;
        float f6 = arrayListModule != null ? arrayListModule.getItemGap() : 0.0f;
        float f7 = 0.65f;
        float f8 = f7 * 0.72f;
        f4 = f8 * 0.9f;
        float f9 = 4.0f;
        f3 = 0.0f;
        for (Module module : sortedModules) {
            f2 = IngameHud.getModuleWidth(module);
            if (!(f2 > f3)) continue;
            f3 = f2;
        }
        float f10 = (float)sortedModules.size() * (f5 + f6);
        lastArrayListW = f3 + 4.0f;
        lastArrayListH = f10;
        if (ClickGui.isUiEditMode() && !sortedModules.isEmpty()) {
            float f11 = (float)n - f3 - arrayListX - 2.0f;
            f2 = arrayListY - 2.0f;
            Color color = arrayListDragging ? new Color(100, 150, 255, (int)(150.0f * f)) : new Color(100, 150, 255, (int)(40.0f * f));
            RoundedUtil.drawRoundOutline(f11, f2, f3 + 4.0f, f10 + 4.0f, 2.0f, 1.0f, color);
        }

        boolean isBgEnabled = arrayListModule == null || arrayListModule.isBackground();
        int bgAlphaVal = arrayListModule != null ? arrayListModule.getBgAlpha() : 140;
        int bgGrayVal = arrayListModule != null ? arrayListModule.getBgGrayness() : 15;
        boolean isRightBarEnabled = arrayListModule == null || arrayListModule.isRightBar();
        float barWidthVal = arrayListModule != null ? arrayListModule.getBarWidth() : 2.0f;
        boolean isBlurEnabled = arrayListModule != null && arrayListModule.isBlur();

        f2 = arrayListY;
        List<Module> visibleModules = new ArrayList<Module>();
        for (int i = 0; i < sortedModules.size(); ++i) {
            Module module = sortedModules.get(i);
            String string = module.getName();
            boolean bl2 = !module.isEnabled();
            float f17 = anims.containsKey("arr_" + string) ? anims.get("arr_" + string).floatValue() : 0.0f;
            if (f17 < 0.01f && bl2) continue;
            visibleModules.add(module);
        }
        int visibleCount = visibleModules.size();

        for (int i = 0; i < sortedModules.size(); ++i) {
            float f12;
            float f13;
            Color color;
            float f14;
            float f15;
            float f16;
            Module module = sortedModules.get(i);
            String string = module.getName();
            String string2 = module.getOptionPrefix();
            int n3 = module.getKeyBind();
            String string3 = n3 > 0 ? Keyboard.getKeyName((int)n3) : "";
            boolean bl2 = !module.isEnabled();
            float f17 = IngameHud.animateBounce("arr_" + string, bl2 ? 0.0f : 1.0f, !bl2);
            if (f17 < 0.01f && bl2) {
                anims.remove("y_" + string);
                continue;
            }
            String string4 = "y_" + string;
            if (!anims.containsKey(string4)) {
                anims.put(string4, Float.valueOf(f2));
                f16 = f2;
            } else {
                f15 = anims.get(string4).floatValue();
                f16 = f15 + (f2 - f15) * 0.12f * Math.min(deltaTime, 1.5f);
                anims.put(string4, Float.valueOf(f16));
            }
            f15 = Math.min(1.0f, f17) * f;
            float f18 = Math.min(f17, 1.06f);
            float f19 = f5 * f18;
            float f20 = f16 + (f5 - f19) * 0.5f;
            float f21 = f7 * f18;
            float f22 = f8 * f18;
            float f23 = f4 * f18;
            float f24 = string3.isEmpty() ? 0.0f : (float)FontUtil.getStringWidth(string3) * f23 + f9 * f18;
            float f25 = (float)FontUtil.getStringWidth(string) * f21;
            boolean bl3 = arrayListModule == null || arrayListModule.isShowPrefix();
            boolean bl4 = bl3 && !string2.isEmpty() && module.getCategory() != Category.RENDER;
            float f26 = bl4 ? (float)FontUtil.getStringWidth(string2) * f22 + f9 * f18 : 0.0f;
            float f27 = f9 * f18;

            float padLeft = 6.0f * f18;
            float padRight = 4.0f * f18;
            float currentBarWidth = (isRightBarEnabled ? barWidthVal : 0.0f) * f18;
            float totalBoxWidth = f24 + f25 + f26 + padLeft + padRight + currentBarWidth;

            float f30 = (1.0f - f17) * 20.0f;
            float boxX = (float)n - totalBoxWidth - arrayListX + f30;
            float boxY = f20;

            float f32 = FontUtil.getFontHeight();
            float f33 = f20 + (f19 - f32 * f21) / 2.0f;
            float f34 = f20 + (f19 - f32 * f23) / 2.0f;
            float f35 = f20 + (f19 - f32 * f22) / 2.0f;

            int visibleIndex = visibleModules.indexOf(module);
            boolean isFirst = visibleIndex == 0;
            boolean isLast = visibleIndex == visibleCount - 1;
            float cornerR = 4.0f * f18;
            float topR = isFirst ? cornerR : 0.0f;
            float botR = isLast ? cornerR : 0.0f;

            if (isBgEnabled && bgAlphaVal > 0) {
                if (isBlurEnabled) {
                    GaussianBlur.renderBlurRounded(boxX, boxY, totalBoxWidth, f19, isFirst ? 4.0f : 0.0f, 8.0f * f15);
                }
                Color bgColor = new Color(bgGrayVal, bgGrayVal, bgGrayVal, (int)((float)bgAlphaVal * f15));
                RoundedUtil.drawLeftRoundedRect((double)boxX, (double)boxY, (double)totalBoxWidth, (double)f19, 4.0 * (double)f18, bgColor);
                RoundedUtil.drawLeftRoundedOutline(boxX, boxY, totalBoxWidth, f19, 4.0f * f18, 1.0f, new Color(180, 180, 180, (int)(45.0f * f15)));
            }

            Color color3 = new Color(255, 75, 145);
            Color color4 = new Color(155, 93, 229);
            try {
                if (arrayListModule != null) {
                    color3 = arrayListModule.getColor1();
                    color4 = arrayListModule.getColor2();
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            long l2 = System.currentTimeMillis();
            float timeFactor = (float)(l2 % 2500L) / 2500.0f;
            float itemIndexOffset = (float)i * 0.45f;
            double d = (Math.sin((double)timeFactor * 2.0 * Math.PI + (double)itemIndexOffset) + 1.0) / 2.0;
            float f40 = (float)d;

            int n4 = (int)((float)color3.getRed() * (1.0f - f40) + (float)color4.getRed() * f40);
            int n5 = (int)((float)color3.getGreen() * (1.0f - f40) + (float)color4.getGreen() * f40);
            int n6 = (int)((float)color3.getBlue() * (1.0f - f40) + (float)color4.getBlue() * f40);
            Color color5 = new Color(n4, n5, n6, (int)(255.0f * f15));

            if (isRightBarEnabled && currentBarWidth > 0.0f) {
                float rightBarX = boxX + totalBoxWidth - currentBarWidth;
                RoundedUtil.rect((double)rightBarX, (double)boxY, (double)currentBarWidth, (double)f19, color5);
            }

            float textX = boxX + padLeft;
            if (!string3.isEmpty()) {
                Color color2 = new Color(120, 120, 120, (int)(180.0f * f15));
                GL11.glPushMatrix();
                GL11.glTranslatef((float)textX, (float)f34, (float)0.0f);
                GL11.glScalef((float)f23, (float)f23, (float)1.0f);
                FontUtil.drawString(string3, 0.0f, 0.0f, color2.getRGB(), false);
                GL11.glPopMatrix();
                textX += f24;
            }

            GL11.glPushMatrix();
            GL11.glTranslatef((float)textX, (float)f33, (float)0.0f);
            GL11.glScalef((float)f21, (float)f21, (float)1.0f);
            FontUtil.drawString(string, 0.0f, 0.0f, color5.getRGB(), false);
            GL11.glPopMatrix();
            textX += f25;

            if (bl4) {
                Color suffixColor = new Color(180, 180, 180, (int)(220.0f * f15));
                GL11.glPushMatrix();
                GL11.glTranslatef((float)(textX + f27), (float)f35, (float)0.0f);
                GL11.glScalef((float)f22, (float)f22, (float)1.0f);
                FontUtil.drawString(string2, 0.0f, 0.0f, suffixColor.getRGB(), false);
                GL11.glPopMatrix();
            }

            f2 += (f5 + f6) * Math.min(f17, 1.0f);
        }
        lastArrayListH = Math.max(20.0f, f2 - arrayListY);
        lastArrayListW = f3;
    }

    private static void handleWatermarkDrag(int n, int n2, int n3, int n4) {
        float f = watermarkX;
        float f2 = watermarkY;
        float f3 = lastWatermarkW > 0.0f ? lastWatermarkW : 150.0f;
        float f4 = lastWatermarkH > 0.0f ? lastWatermarkH : 20.0f;
        boolean bl = (float)n >= f && (float)n <= f + f3 && (float)n2 >= f2 && (float)n2 <= f2 + f4;
        boolean bl2 = bl;
        if (Mouse.isButtonDown((int)0)) {
            if (!watermarkDragging) {
                if (ClickGui.isDraggingAnyElement()) {
                    return;
                }
                if (bl) {
                    watermarkDragging = true;
                    watermarkDragOffX = (float)n - f;
                    watermarkDragOffY = (float)n2 - f2;
                    ClickGui.setDraggingAnyElement(true);
                }
            }
            if (watermarkDragging) {
                watermarkX = Math.max(5.0f, Math.min((float)n3 - f3 - 5.0f, (float)n - watermarkDragOffX));
                watermarkY = Math.max(5.0f, Math.min((float)n4 - f4 - 5.0f, (float)n2 - watermarkDragOffY));
            }
        } else {
            if (watermarkDragging) {
                ClickGui.setDraggingAnyElement(false);
            }
            watermarkDragging = false;
        }
    }

    private static void handleArrayListDrag(int n, int n2, int n3, int n4) {
        float f = lastArrayListW > 0.0f ? lastArrayListW : 100.0f;
        float f2 = lastArrayListH > 0.0f ? lastArrayListH : 200.0f;
        float f3 = (float)n3 - f - arrayListX;
        float f4 = arrayListY;
        boolean bl = (float)n >= f3 && (float)n <= f3 + f && (float)n2 >= f4 && (float)n2 <= f4 + f2;
        boolean bl2 = bl;
        if (Mouse.isButtonDown((int)0)) {
            if (!arrayListDragging) {
                if (ClickGui.isDraggingAnyElement()) {
                    return;
                }
                if (bl) {
                    arrayListDragging = true;
                    arrayListDragOffX = (float)n - f3;
                    arrayListDragOffY = (float)n2 - f4;
                    ClickGui.setDraggingAnyElement(true);
                }
            }
            if (arrayListDragging) {
                float f5 = (float)n - arrayListDragOffX;
                float f6 = (float)n2 - arrayListDragOffY;
                arrayListX = Math.max(0.0f, Math.min((float)n3 - f - 5.0f, (float)n3 - f - f5));
                arrayListY = Math.max(5.0f, Math.min((float)n4 - f2 - 5.0f, f6));
            }
        } else {
            if (arrayListDragging) {
                ClickGui.setDraggingAnyElement(false);
            }
            arrayListDragging = false;
        }
    }

    private static void pushHudState() {
        GLErrorChecker.clear();
        int n = Math.max(1, ScissorUtil.getScaledWidth());
        int n2 = Math.max(1, ScissorUtil.getScaledHeight());
        GL11.glMatrixMode((int)5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glOrtho((double)0.0, (double)n, (double)n2, (double)0.0, (double)1000.0, (double)3000.0);
        GL11.glMatrixMode((int)5888);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glTranslatef((float)0.0f, (float)0.0f, (float)-2000.0f);
        GL11.glDisable((int)2896);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GLErrorChecker.check("IngameHud.pushHudState");
    }

    private static void popHudState() {
        GL11.glMatrixMode((int)5888);
        GL11.glPopMatrix();
        GLErrorChecker.check("IngameHud.popHudState -> pop MODELVIEW");
        GL11.glMatrixMode((int)5889);
        GL11.glPopMatrix();
        GLErrorChecker.check("IngameHud.popHudState -> pop PROJECTION");
        GL11.glMatrixMode((int)5888);
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)3008);
        GL11.glEnable((int)3553);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GLErrorChecker.clear();
        GLErrorChecker.check("IngameHud.popHudState");
    }

    private static void updateTime() {
        long l = System.currentTimeMillis();
        if (l - lastTimeUpdate > 1000L) {
            cachedTime = TIME_FORMAT.format(new Date(l));
            lastTimeUpdate = l;
        }
    }

    private static int getFPS() {
        if (lastFpsTime == 0L) {
            lastFpsTime = System.currentTimeMillis();
        }
        ++frameCount;
        long l = System.currentTimeMillis();
        if (l - lastFpsTime >= 1000L) {
            currentFps = frameCount;
            frameCount = 0;
            lastFpsTime = l;
        }
        return currentFps;
    }

    private static void drawBlurText(float f, float f2, float f3, float f4) {
        String string;
        String string2 = "Massacre.vip";
        String string3 = string = IngameHud.isShowPrefixEnabled() ? IngameHud.getLocalPlayerName() : "";
        if (!string.isEmpty()) {
            IngameHud.drawBrandChars(string2, f, f2, f3, f4, 1.0f, true);
            float f5 = (float)FontUtil.getStringWidth(string2) * f3;
            String string4 = " | " + string;
            float f6 = 0.0f;
            int n = new Color(180, 180, 180, (int)(255.0f * f4)).getRGB();
            for (int i = 0; i < string4.length(); ++i) {
                String string5 = String.valueOf(string4.charAt(i));
                GL11.glPushMatrix();
                GL11.glTranslatef((float)(f + f5 + f6 * f3), (float)f2, (float)0.0f);
                GL11.glScalef((float)f3, (float)f3, (float)1.0f);
                FontUtil.drawString(string5, 0.0f, 0.0f, n, false);
                GL11.glPopMatrix();
                f6 += (float)FontUtil.getStringWidth(string5);
            }
        } else {
            IngameHud.drawBrandChars(string2, f, f2, f3, f4, 1.0f, true);
        }
    }

    private static void drawBrandChars(String string, float f, float f2, float f3, float f4, float f5, boolean bl) {
        long l = System.currentTimeMillis();
        float f6 = 0.0f;
        Color color = new Color(255, 75, 145);
        Color color2 = new Color(155, 93, 229);
        try {
            WatermarkModule watermarkModule = Ries.getInstance().getModuleManager().getModule(WatermarkModule.class);
            if (watermarkModule != null) {
                color = watermarkModule.getColor1();
                color2 = watermarkModule.getColor2();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        for (int i = 0; i < string.length(); ++i) {
            int n;
            float f7 = f4 * f5;
            if (i >= 8) {
                n = new Color(200, 200, 200, (int)(255.0f * f7)).getRGB();
            } else {
                float f8 = (float)(l % 4000L) / 4000.0f;
                float f9 = (float)i / 7.0f;
                float f10 = (float)(Math.sin((double)f8 * 2.0 * Math.PI + (double)f9 * 2.0) + 1.0) / 2.0f;
                int n2 = (int)((float)color.getRed() * (1.0f - f10) + (float)color2.getRed() * f10);
                int n3 = (int)((float)color.getGreen() * (1.0f - f10) + (float)color2.getGreen() * f10);
                int n4 = (int)((float)color.getBlue() * (1.0f - f10) + (float)color2.getBlue() * f10);
                n = new Color(n2, n3, n4, (int)(255.0f * f7)).getRGB();
            }
            String string2 = String.valueOf(string.charAt(i));
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(f + f6 * f3), (float)f2, (float)0.0f);
            GL11.glScalef((float)f3, (float)f3, (float)1.0f);
            FontUtil.drawString(string2, 0.0f, 0.0f, n, false);
            GL11.glPopMatrix();
            f6 += (float)FontUtil.getStringWidth(string2);
        }
    }

    private static void drawBrandChar(String string, int n, float f, float f2, float f3, float f4, float f5, boolean bl) {
        float f6 = 0.0f;
        for (int i = 0; i < n; ++i) {
            f6 += (float)FontUtil.getStringWidth(String.valueOf(string.charAt(i)));
        }
        float f7 = (1.0f - f5) * -6.0f;
        float f8 = f4 * f5;
        if (!(f8 < 0.005f)) {
            int n2 = new Color(237, 237, 237, (int)(255.0f * f8)).getRGB();
            String string2 = String.valueOf(string.charAt(n));
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(f + f6 * f3), (float)(f2 + f7 * f3), (float)0.0f);
            GL11.glScalef((float)f3, (float)f3, (float)1.0f);
            FontUtil.drawString(string2, 0.0f, 0.0f, n2, false);
            GL11.glPopMatrix();
        }
    }

    private static float easeOut(float f) {
        f = Math.max(0.0f, Math.min(1.0f, f));
        return 1.0f - (f - 1.0f) * (f - 1.0f);
    }

    private static float clamp01(float f) {
        return f < 0.0f ? 0.0f : (f > 1.0f ? 1.0f : f);
    }

    private static float getModuleWidth(Module module) {
        String string;
        float f = 0.65f;
        float f2 = f * 0.72f;
        float f3 = f2 * 0.9f;
        float f4 = 4.0f;
        int n = module.getKeyBind();
        String string2 = n > 0 ? Keyboard.getKeyName((int)n) : "";
        float f6 = string2.isEmpty() ? 0.0f : (float)FontUtil.getStringWidth(string2) * f3 + f4;
        float f7 = (float)FontUtil.getStringWidth(module.getName()) * f;
        float f8 = 0.0f;
        boolean bl = true;
        float currentBarWidth = 3.0f;
        try {
            ArrayListModule arrayListModule = Ries.getInstance().getModuleManager().getModule(ArrayListModule.class);
            if (arrayListModule != null) {
                bl = arrayListModule.isShowPrefix();
                if (arrayListModule.isRightBar()) {
                    currentBarWidth = arrayListModule.getBarWidth();
                } else {
                    currentBarWidth = 0.0f;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (bl && module.getCategory() != Category.RENDER && !(string = module.getOptionPrefix()).isEmpty()) {
            f8 = (float)FontUtil.getStringWidth(string) * f2 + f4;
        }
        return f6 + f7 + f8 + 11.0f + currentBarWidth;
    }

    private static float animate(String string, float f, float f2) {
        float f3 = anims.containsKey(string) ? anims.get(string).floatValue() : 0.0f;
        f3 += (f - f3) * f2;
        anims.put(string, Float.valueOf(f3));
        return f3;
    }

    private static Method getDrawStringMethod() {
        Method method = drawStringMethod;
        if (method != null) {
            return method;
        }
        Method method2 = MappingUtils.getMethod("FontRenderer.drawString");
        if (method2 == null) {
            return null;
        }
        method2.setAccessible(true);
        drawStringMethod = method2;
        return method2;
    }

    private static void markHudStatus(String string) {
    }

    private static void renderSpotifyWidget(float f) {
        try {
            SpotifyWidget spotifyWidget = Ries.getInstance().getModuleManager().getModule(SpotifyWidget.class);
            if (spotifyWidget == null || !spotifyWidget.isEnabled()) {
                return;
            }
            if (ClickGui.isUiEditMode()) {
                spotifyWidget.renderForEditMode();
            } else {
                spotifyWidget.render();
            }
        }
        catch (Throwable throwable) {
            IngameHud.warnThrottled("SpotifyWidget render error: " + throwable.getMessage());
        }
    }

    private static void renderTargetHud() {
        try {
            TargetHudModule targetHudModule = Ries.getInstance().getModuleManager().getModule(TargetHudModule.class);
            if (targetHudModule == null || !targetHudModule.isEnabled()) {
                return;
            }
            if (ClickGui.isUiEditMode()) {
                targetHudModule.renderForEditMode();
            } else {
                targetHudModule.render();
            }
        }
        catch (Throwable throwable) {
            IngameHud.warnThrottled("TargetHUD render error: " + throwable.getMessage());
        }
    }

    private static void warnThrottled(String string) {
        long l = System.currentTimeMillis();
        if (l - lastWarnTime >= 5000L) {
            lastWarnTime = l;
            Logger.warn(string);
        }
    }

    static {
        cachedDetectionFlag1 = null;
        cachedGetInstance = null;
        detectionFlagCacheTried = false;
    }
}
