/*
 * Decompiled with CFR 0.152.
 */
package me.ries.chat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import me.ries.Ries;
import me.ries.command.CommandManager;
import me.ries.module.impl.MassacreChatModule;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class RiesChatManager {
    private static final String SERVER = "irc.rizon.net";
    private static final int PORT = 6697;
    private static final String CHANNEL = "#massacre_chat_2026";
    private static Socket socket = null;
    private static BufferedReader reader = null;
    private static PrintWriter writer = null;
    private static Thread networkThread = null;
    private static boolean running = false;
    private static String currentNick = "";
    public static final Set<String> activeRiesUsers = ConcurrentHashMap.newKeySet();
    public static final Set<String> activeAdmins = ConcurrentHashMap.newKeySet();
    public static final Set<String> hiddenUsers = ConcurrentHashMap.newKeySet();
    public static final Map<String, String> displayNames = new ConcurrentHashMap<String, String>();
    public static final Map<String, Long> userLastSeen = new ConcurrentHashMap<String, Long>();
    private static int tickCounter = 0;
    private static long lastPresenceBroadcast = 0L;

    public static void start() {
        if (running) {
            return;
        }
        running = true;
        networkThread = new Thread(RiesChatManager::runConnectionLoop, "Ries-Chat-Thread");
        networkThread.setDaemon(true);
        networkThread.start();
    }

    public static void stop() {
        running = false;
        RiesChatManager.disconnect();
    }

    public static void tick() {
        ++tickCounter;
        long l = System.currentTimeMillis();
        if (l - lastPresenceBroadcast >= 15000L && socket != null && writer != null) {
            String string = CommandManager.getRealPlayerName();
            if (string != null && !string.isEmpty()) {
                boolean bl = RiesChatManager.isLocalPlayerAdmin();
                boolean bl2 = false;
                try {
                    MassacreChatModule massacreChatModule = Ries.getInstance().getModuleManager().getModule(MassacreChatModule.class);
                    if (massacreChatModule != null) {
                        bl2 = massacreChatModule.getHideSelfValue();
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                RiesChatManager.sendRaw("PRIVMSG #massacre_chat_2026 :[PRESENCE]" + (bl ? "1" : "0") + "|" + (bl2 ? "1" : "0") + "|" + (String)string);
            }
            lastPresenceBroadcast = l;
        }
        if (tickCounter % 200 == 0) {
            for (Map.Entry entry : userLastSeen.entrySet()) {
                if (l - (Long)entry.getValue() <= 40000L) continue;
                String string = (String)entry.getKey();
                activeRiesUsers.remove(string);
                activeAdmins.remove(string);
                hiddenUsers.remove(string);
                displayNames.remove(string);
                userLastSeen.remove(string);
            }
            RiesChatManager.updateTabListSymbols();
        }
        if (tickCounter % 400 == 0) {
            RiesChatManager.checkDynamicNickChange();
        }
    }

    public static boolean isLocalPlayerAdmin() {
        try {
            MassacreChatModule massacreChatModule = Ries.getInstance().getModuleManager().getModule(MassacreChatModule.class);
            if (massacreChatModule != null && MassacreChatModule.passwordOption != null) {
                String string = MassacreChatModule.passwordOption.getText();
                return "knutzx123321".equals(string);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private static void checkDynamicNickChange() {
        try {
            String string;
            if (socket == null || writer == null || currentNick.isEmpty()) {
                return;
            }
            String string2 = CommandManager.getRealPlayerName();
            if (string2 == null || string2.isEmpty()) {
                return;
            }
            boolean bl = RiesChatManager.isLocalPlayerAdmin();
            String string3 = string = bl ? "Massacre_Admin_" : "Massacre_";
            if (!currentNick.startsWith(string)) {
                String string4 = string + string2;
                RiesChatManager.sendRaw("NICK " + string4);
                currentNick = string4;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void runConnectionLoop() {
        while (running) {
            try {
                String string;
                String string2 = CommandManager.getRealPlayerName();
                if (string2 == null || string2.isEmpty()) {
                    Thread.sleep(3000L);
                    continue;
                }
                boolean bl = RiesChatManager.isLocalPlayerAdmin();
                currentNick = (bl ? "Massacre_Admin_" : "Massacre_") + string2;
                TrustManager[] trustManagerArray = new TrustManager[]{new X509TrustManager(){

                    @Override
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    @Override
                    public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string) {
                    }

                    @Override
                    public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string) {
                    }
                }};
                SSLContext sSLContext = SSLContext.getInstance("TLS");
                sSLContext.init(null, trustManagerArray, new SecureRandom());
                socket = sSLContext.getSocketFactory().createSocket(SERVER, 6697);
                reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                writer = new PrintWriter(socket.getOutputStream(), true);
                RiesChatManager.sendRaw("NICK " + currentNick);
                RiesChatManager.sendRaw("USER RiesUser 0 * :Ries Client User");
                while ((string = reader.readLine()) != null) {
                    RiesChatManager.parseIrcLine(string);
                }
            }
            catch (Throwable throwable) {
                Logger.warn("[MassacreChat] Connection loop error: " + throwable.getMessage());
                throwable.printStackTrace();
            }
            finally {
                RiesChatManager.disconnect();
                continue;
            }
            try {
                Thread.sleep(5000L);
            }
            catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private static void disconnect() {
        try {
            if (writer != null) {
                String string = CommandManager.getRealPlayerName();
                if (string != null) {
                    RiesChatManager.sendRaw("PRIVMSG #massacre_chat_2026 :[QUIT]" + string);
                }
                RiesChatManager.sendRaw("QUIT :Client closing");
                writer.close();
            }
            if (reader != null) {
                reader.close();
            }
            if (socket != null) {
                socket.close();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        socket = null;
        reader = null;
        writer = null;
        activeRiesUsers.clear();
        activeAdmins.clear();
        displayNames.clear();
        userLastSeen.clear();
    }

    private static void sendRaw(String string) {
        try {
            if (writer != null) {
                writer.println(string);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static void sendGlobalMessage(String string) {
        if (socket == null || writer == null) {
            CommandManager.addChatMessageToGui("\u00a7c[Massacre Chat] \u00a7fSohbet sunucusuna ba\u011fl\u0131 de\u011filsiniz!");
            return;
        }
        new Thread(() -> {
            try {
                String string2 = CommandManager.getRealPlayerName();
                boolean bl = RiesChatManager.isLocalPlayerAdmin();
                RiesChatManager.sendRaw("PRIVMSG #massacre_chat_2026 :[MSG]" + (bl ? "1" : "0") + "|" + string2 + "|" + string);
                String string3 = bl ? "\u00a7c[Admin] \u00a7e" : "\u00a7e";
                CommandManager.addChatMessageToGui("\u00a7d[Massacre Chat] " + string3 + string2 + "\u00a7f: " + string);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }).start();
    }

    private static void parseIrcLine(String string) {
        try {
            int n;
            String string2;
            if (string.startsWith("PING ")) {
                RiesChatManager.sendRaw("PONG " + string.substring(5));
                return;
            }
            String[] stringArray = string.split(" ");
            if (stringArray.length < 2) {
                return;
            }
            if ("001".equals(stringArray[1])) {
                RiesChatManager.sendRaw("JOIN #massacre_chat_2026");
                if (RiesChatManager.isChatModuleEnabled()) {
                    CommandManager.addChatMessageToGui("\u00a7d[Massacre Chat] \u00a7aGlobal Massacre sohbetine ba\u011flan\u0131ld\u0131.");
                }
                return;
            }
            if ("433".equals(stringArray[1])) {
                currentNick = currentNick + "_";
                RiesChatManager.sendRaw("NICK " + currentNick);
                return;
            }
            String string3 = "";
            if (stringArray[0].startsWith(":")) {
                int n2 = stringArray[0].indexOf("!");
                string3 = n2 != -1 ? stringArray[0].substring(1, n2) : stringArray[0].substring(1);
            }
            if ("PRIVMSG".equals(string2 = stringArray[1]) && stringArray.length > 2 && stringArray[2].equalsIgnoreCase(CHANNEL) && (n = string.indexOf(":", 1)) != -1) {
                String string4;
                String[] stringArray2;
                String string5 = string.substring(n + 1);
                if (string5.startsWith("[PRESENCE]")) {
                    String string6 = string5.substring(10);
                    String[] stringArray3 = string6.split("\\|");
                    if (stringArray3.length >= 2) {
                        String string7;
                        String string8;
                        boolean bl = "1".equals(stringArray3[0]);
                        boolean bl2 = false;
                        if (stringArray3.length >= 3) {
                            bl2 = "1".equals(stringArray3[1]);
                            string8 = stringArray3[2].trim();
                        } else {
                            string8 = stringArray3[1].trim();
                        }
                        String string9 = string8.toLowerCase();
                        if (!activeRiesUsers.contains(string9) && !string8.equalsIgnoreCase(string7 = CommandManager.getRealPlayerName()) && RiesChatManager.isChatModuleEnabled()) {
                            String string10 = bl ? "\u00a7c[Admin] \u00a77" : "\u00a77";
                            CommandManager.addChatMessageToGui("\u00a7d[Massacre Chat] " + string10 + string8 + " sohbete kat\u0131ld\u0131.");
                        }
                        activeRiesUsers.add(string9);
                        displayNames.put(string9, string8);
                        if (bl) {
                            activeAdmins.add(string9);
                        } else {
                            activeAdmins.remove(string9);
                        }
                        if (bl2) {
                            hiddenUsers.add(string9);
                        } else {
                            hiddenUsers.remove(string9);
                        }
                        userLastSeen.put(string9, System.currentTimeMillis());
                    }
                    return;
                }
                if (string5.startsWith("[QUIT]")) {
                    String string11 = string5.substring(6).trim();
                    String string12 = string11.toLowerCase();
                    if (activeRiesUsers.remove(string12)) {
                        activeAdmins.remove(string12);
                        hiddenUsers.remove(string12);
                        displayNames.remove(string12);
                        userLastSeen.remove(string12);
                        if (RiesChatManager.isChatModuleEnabled()) {
                            CommandManager.addChatMessageToGui("\u00a7d[Massacre Chat] \u00a77" + string11 + " sohbetten ayr\u0131ld\u0131.");
                        }
                    }
                    return;
                }
                if (string5.startsWith("[MSG]") && (stringArray2 = (string4 = string5.substring(5)).split("\\|", 3)).length >= 3) {
                    boolean bl = "1".equals(stringArray2[0]);
                    String string13 = stringArray2[1];
                    String string14 = stringArray2[2];
                    String string15 = CommandManager.getRealPlayerName();
                    if (!string13.equalsIgnoreCase(string15) && RiesChatManager.isChatModuleEnabled()) {
                        String string16 = bl ? "\u00a7c[Admin] \u00a7a" : "\u00a7a";
                        CommandManager.addChatMessageToGui("\u00a7d[Massacre Chat] " + string16 + string13 + "\u00a7f: " + string14);
                    }
                }
            }
        }
        catch (Throwable throwable) {
            Logger.warn("[MassacreChat] Line parsing error: " + throwable.getMessage());
        }
    }

    private static boolean isChatModuleEnabled() {
        try {
            MassacreChatModule massacreChatModule = Ries.getInstance().getModuleManager().getModule(MassacreChatModule.class);
            if (massacreChatModule != null) {
                return massacreChatModule.isEnabled();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return true;
    }

    private static String cleanUsername(String string) {
        return string;
    }

    public static void updateTabListSymbols() {
        try {
            Map<UUID, Object> map = CommandManager.getPlayerInfoMap();
            if (map == null || map.isEmpty()) {
                return;
            }
            Field field = null;
            Field field2 = null;
            Class<?> clazz = MappingUtils.get("NetworkPlayerInfo");
            if (clazz == null) {
                clazz = map.values().iterator().next().getClass();
            }
            if (clazz == null) {
                return;
            }
            Class<?> clazz2 = MappingUtils.get("IChatComponent");
            for (Field object : clazz.getDeclaredFields()) {
                if (object.getType().getName().equals("com.mojang.authlib.GameProfile")) {
                    field = object;
                    field.setAccessible(true);
                }
                if (clazz2 != null && clazz2.isAssignableFrom(object.getType())) {
                    field2 = object;
                    field2.setAccessible(true);
                    continue;
                }
                if (!object.getType().getSimpleName().equals("IChatComponent") && !object.getType().getName().contains("ChatComponent")) continue;
                field2 = object;
                field2.setAccessible(true);
            }
            if (field == null || field2 == null) {
                return;
            }
            Class<?> clazz3 = MappingUtils.get("ChatComponentText");
            if (clazz3 == null) {
                return;
            }
            Constructor constructor = clazz3.getConstructor(String.class);
            if (constructor == null) {
                return;
            }
            constructor.setAccessible(true);
            for (Object object : map.values()) {
                String string;
                Object object2;
                Object object3;
                Object object4 = field.get(object);
                if (object4 == null) continue;
                String string2 = null;
                try {
                    object3 = object4.getClass().getMethod("getName", new Class[0]);
                    ((Method)object3).setAccessible(true);
                    string2 = (String)((Method)object3).invoke(object4, new Object[0]);
                }
                catch (Throwable throwable) {
                    try {
                        object2 = object4.getClass().getDeclaredField("name");
                        ((Field)object2).setAccessible(true);
                        string2 = (String)((Field)object2).get(object4);
                    }
                    catch (Throwable throwable2) {
                        // empty catch block
                    }
                }
                if (string2 == null) continue;
                object3 = string2.toLowerCase().trim();
                object2 = field2.get(object);
                if (activeRiesUsers.contains(object3)) {
                    String string3;
                    boolean bl = activeAdmins.contains(object3);
                    String string4 = (bl ? "\u00a7c[Admin] \u00a7f" : "\u00a7d[M] \u00a7f") + string2;
                    boolean bl2 = true;
                    if (object2 != null) {
                        string3 = object2.toString();
                        if (bl && string3.contains("\u00a7c[Admin]")) {
                            bl2 = false;
                        } else if (!bl && string3.contains("\u00a7d[M]")) {
                            bl2 = false;
                        }
                    }
                    if (!bl2) continue;
                    string3 = constructor.newInstance(string4);
                    field2.set(object, string3);
                    continue;
                }
                if (object2 == null || !(string = object2.toString()).contains("\u00a7d[M]") && !string.contains("\u00a7c[Admin]")) continue;
                field2.set(object, null);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

