/*
 * Decompiled with CFR 0.152.
 */
package me.ries.command;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import me.ries.Ries;
import me.ries.chat.RiesChatManager;
import me.ries.config.ConfigManager;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.PacketReceiveEvent;
import me.ries.event.PacketSendEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Module;
import me.ries.module.impl.ChatManagerModule;
import me.ries.module.impl.ClickGuiModule;
import me.ries.module.impl.TargetManagerModule;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class CommandManager {
    public static String streamerName = "Streamer";
    public static boolean streamerEnabled = false;
    public static String targetFakeUser = "Izoly";
    public static boolean fakeUserEnabled = false;
    public static String prefixText = "Allah";
    public static String prefixColor = "4";
    public static String nameColor = "c";
    public static String customNameText = "";
    public static boolean allahPrefixEnabled = false;
    public static Object originalProfile = null;
    public static Object originalSkin = null;
    public static Object originalCape = null;
    public static Object originalDisplay = null;
    public static String originalName = "";

    public static void init() {
        Ries.getInstance().getEventBus().subscribe(PacketSendEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof PacketSendEvent) {
                    CommandManager.onPacketSend((PacketSendEvent)event);
                }
            }
        });
        Ries.getInstance().getEventBus().subscribe(PacketReceiveEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof PacketReceiveEvent) {
                    CommandManager.onPacketReceive((PacketReceiveEvent)event);
                }
            }
        });
    }

    /*
     * WARNING - void declaration
     */
    private static void onPacketSend(PacketSendEvent packetSendEvent) {
        block84: {
            Object object = packetSendEvent.getPacket();
            Class<?> clazz = MinecraftMapper.get("C01PacketChatMessage");
            if (object != null && clazz != null && clazz.isInstance(object)) {
                try {
                    int n;
                    String[] stringArray;
                    Object object2;
                    Field field;
                    String string = null;
                    Method method = MappingUtils.getMethod("C01PacketChatMessage.getMessage");
                    if (method != null) {
                        try {
                            string = (String)method.invoke(object, new Object[0]);
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    if (string == null && (field = MappingUtils.getField("C01PacketChatMessage.message")) != null) {
                        try {
                            field.setAccessible(true);
                            string = (String)field.get(object);
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    if (string == null) {
                        for (Field object3 : clazz.getDeclaredFields()) {
                            if (object3.getType() != String.class) continue;
                            try {
                                object3.setAccessible(true);
                                object2 = (String)object3.get(object);
                                if (object2 == null || ((String)object2).isEmpty()) continue;
                                string = object2;
                                break;
                            }
                            catch (Throwable string10) {
                                // empty catch block
                            }
                        }
                    }
                    if (string == null || !string.startsWith(".")) break block84;
                    try {
                        stringArray = Ries.getInstance().getModuleManager().getModule(ChatManagerModule.class);
                        if (stringArray != null && ((Module)stringArray).isEnabled()) {
                            return;
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    packetSendEvent.cancel();
                    stringArray = string.substring(1).split(" ");
                    String string2 = stringArray[0].toLowerCase();
                    if (string2.isEmpty() || "help".equals(string2) || "yardim".equals(string2) || "yard\u0131m".equals(string2)) {
                        CommandManager.addChatMessageToGui("\u00a7d[Massacre Client] \u00a7fKullan\u0131labilir Komutlar:");
                        CommandManager.addChatMessageToGui("\u00a77.m <mesaj> / .m list \u00a78- Massacre Global Sohbet");
                        CommandManager.addChatMessageToGui("\u00a77.target <isim> / s\u0131f\u0131rla \u00a78- Hedef Kilitleme");
                        CommandManager.addChatMessageToGui("\u00a77.part bot a\u00e7 <oyuncu> / kapat \u00a78- Legit PvP Botu");
                        CommandManager.addChatMessageToGui("\u00a77.streamer <isim> \u00a78- \u0130sim Gizleme (Yay\u0131nc\u0131 Modu)");
                        CommandManager.addChatMessageToGui("\u00a77.fstreamer <oyuncu> \u00a78- Oyuncu Klonlama");
                        CommandManager.addChatMessageToGui("\u00a77.prefix <yaz\u0131> [renk] \u00a78- Sohbet \u0130smi \u00d6n Ek");
                        CommandManager.addChatMessageToGui("\u00a77.config save/load <isim> \u00a78- Hile Ayarlar\u0131 Kaydet/Y\u00fckle");
                        CommandManager.addChatMessageToGui("\u00a77.friend add/remove <isim> / list \u00a78- Arkada\u015f Sistemi");
                        return;
                    }
                    if ("m".equals(string2)) {
                        if (stringArray.length > 1) {
                            if ("list".equalsIgnoreCase(stringArray[1])) {
                                Set<String> set = RiesChatManager.activeRiesUsers;
                                Set<String> set2 = RiesChatManager.activeAdmins;
                                object2 = RiesChatManager.hiddenUsers;
                                boolean bl = RiesChatManager.isLocalPlayerAdmin();
                                if (set.isEmpty()) {
                                    CommandManager.addChatMessageToGui("\u00a7d[Massacre Chat] \u00a7fAktif Massacre kullan\u0131c\u0131s\u0131 bulunamad\u0131.");
                                } else {
                                    ArrayList<String> arrayList = new ArrayList<String>();
                                    for (String string3 : set) {
                                        String string4 = string3.toLowerCase();
                                        boolean bl2 = ((Set)object2).contains(string4);
                                        if (bl2 && !bl) continue;
                                        String string5 = RiesChatManager.displayNames.getOrDefault(string4, string3);
                                        String string6 = "";
                                        String string7 = string6 = set2.contains(string4) ? "\u00a7c[Admin] " : "\u00a7e";
                                        if (bl2) {
                                            arrayList.add(string6 + "\u00a77[Gizli] " + string5 + "\u00a7a");
                                            continue;
                                        }
                                        arrayList.add(string6 + string5 + "\u00a7a");
                                    }
                                    if (arrayList.isEmpty()) {
                                        CommandManager.addChatMessageToGui("\u00a7d[Massacre Chat] \u00a7fAktif Massacre kullan\u0131c\u0131s\u0131 bulunamad\u0131.");
                                    } else {
                                        CommandManager.addChatMessageToGui("\u00a7d[Massacre Chat] \u00a7fAktif Kullan\u0131c\u0131lar (" + arrayList.size() + "): \u00a7a" + String.join((CharSequence)", ", arrayList));
                                    }
                                }
                            } else {
                                StringBuilder stringBuilder = new StringBuilder();
                                for (n = 1; n < stringArray.length; ++n) {
                                    if (n > 1) {
                                        stringBuilder.append(" ");
                                    }
                                    stringBuilder.append(stringArray[n]);
                                }
                                RiesChatManager.sendGlobalMessage(stringBuilder.toString());
                            }
                        } else {
                            CommandManager.addChatMessageToGui("\u00a7c[Massacre Chat] \u00a7fKullan\u0131m: .m <mesaj> VEYA .m list");
                        }
                        break block84;
                    }
                    if ("target".equals(string2)) {
                        try {
                            TargetManagerModule targetManagerModule = Ries.getInstance().getModuleManager().getModule(TargetManagerModule.class);
                            if (targetManagerModule == null) break block84;
                            if (stringArray.length > 1) {
                                String string8 = stringArray[1].toLowerCase();
                                if ("sifirla".equals(string8) || "s\u0131f\u0131rla".equals(string8) || "clear".equals(string8) || "kapat".equals(string8) || "reset".equals(string8)) {
                                    targetManagerModule.setTargetName("");
                                    if (targetManagerModule.isEnabled()) {
                                        targetManagerModule.toggle();
                                    }
                                    CommandManager.addChatMessageToGui("\u00a7a[TargetManager] \u00a7fHedef kilitleme kapat\u0131ld\u0131 ve hedef temizlendi.");
                                } else if ("add".equals(string8) || "ekle".equals(string8)) {
                                    if (stringArray.length > 2) {
                                        String i = stringArray[2];
                                        String string9 = targetManagerModule.getTargetName().trim();
                                        String string10 = string9.isEmpty() ? i : string9 + "," + i;
                                        targetManagerModule.setTargetName(string10);
                                        if (!targetManagerModule.isEnabled()) {
                                            targetManagerModule.toggle();
                                        }
                                        CommandManager.addChatMessageToGui("\u00a7a[TargetManager] \u00a7fHedef eklendi: \u00a7e" + i);
                                    } else {
                                        CommandManager.addChatMessageToGui("\u00a77Kullan\u0131m: .target add <isim>");
                                    }
                                } else if ("remove".equals(string8) || "sil".equals(string8) || "rm".equals(string8)) {
                                    if (stringArray.length > 2) {
                                        String string13 = stringArray[2].toLowerCase();
                                        String string11 = targetManagerModule.getTargetName().trim();
                                        StringBuilder stringBuilder = new StringBuilder();
                                        for (String string12 : string11.split(",")) {
                                            String string14 = string12.trim();
                                            if (string14.isEmpty() || string14.toLowerCase().equals(string13)) continue;
                                            if (stringBuilder.length() > 0) {
                                                stringBuilder.append(",");
                                            }
                                            stringBuilder.append(string14);
                                        }
                                        targetManagerModule.setTargetName(stringBuilder.toString());
                                        if (stringBuilder.length() == 0 && targetManagerModule.isEnabled()) {
                                            targetManagerModule.toggle();
                                        }
                                        CommandManager.addChatMessageToGui("\u00a7a[TargetManager] \u00a7fHedef silindi: \u00a7c" + stringArray[2]);
                                    } else {
                                        CommandManager.addChatMessageToGui("\u00a77Kullan\u0131m: .target remove <isim>");
                                    }
                                } else {
                                    void var11_27;
                                    object2 = new StringBuilder();
                                    boolean bl = true;
                                    while (var11_27 < stringArray.length) {
                                        if (var11_27 > true) {
                                            ((StringBuilder)object2).append(" ");
                                        }
                                        ((StringBuilder)object2).append(stringArray[var11_27]);
                                        ++var11_27;
                                    }
                                    String string15 = ((StringBuilder)object2).toString();
                                    targetManagerModule.setTargetName(string15);
                                    if (!targetManagerModule.isEnabled()) {
                                        targetManagerModule.toggle();
                                    }
                                    CommandManager.addChatMessageToGui("\u00a7a[TargetManager] \u00a7fYeni hedef belirlendi: \u00a7e" + string15);
                                }
                                break block84;
                            }
                            String string14 = targetManagerModule.getTargetName();
                            if (string14.isEmpty()) {
                                CommandManager.addChatMessageToGui("\u00a7a[TargetManager] \u00a7fAktif bir hedef belirlenmemi\u015f.");
                            } else {
                                CommandManager.addChatMessageToGui("\u00a7a[TargetManager] \u00a7fMevcut hedef: \u00a7e" + string14);
                            }
                            CommandManager.addChatMessageToGui("\u00a77Kullan\u0131m: .target <isim> | S\u0131f\u0131rlamak i\u00e7in: .target s\u0131f\u0131rla");
                        }
                        catch (Throwable throwable) {
                            Logger.warn("TargetManager command error: " + throwable.getMessage());
                        }
                        break block84;
                    }
                    if ("streamer".equals(string2)) {
                        if (stringArray.length > 1) {
                            StringBuilder stringBuilder = new StringBuilder();
                            for (n = 1; n < stringArray.length; ++n) {
                                if (n > 1) {
                                    stringBuilder.append(" ");
                                }
                                stringBuilder.append(stringArray[n]);
                            }
                            streamerName = stringBuilder.toString();
                            streamerEnabled = true;
                            CommandManager.applyStreamer();
                            CommandManager.addChatMessageToGui("\u00a7b[Streamer] \u00a7fAd\u0131n art\u0131k \u00a7e" + streamerName + " \u00a7folarak g\u00f6r\u00fcnecek.");
                        } else {
                            streamerEnabled = false;
                            CommandManager.restoreOriginals();
                            CommandManager.addChatMessageToGui("\u00a7b[Streamer] \u00a7fDevre d\u0131\u015f\u0131 b\u0131rak\u0131ld\u0131.");
                        }
                    } else if ("fstreamer".equals(string2)) {
                        if (stringArray.length > 1) {
                            targetFakeUser = stringArray[1];
                            fakeUserEnabled = true;
                            CommandManager.copyTargetUser(targetFakeUser);
                        } else {
                            fakeUserEnabled = false;
                            CommandManager.restoreOriginals();
                            CommandManager.addChatMessageToGui("\u00a7d[FakeUser] \u00a7fDevre d\u0131\u015f\u0131 b\u0131rak\u0131ld\u0131.");
                        }
                    } else if ("config".equals(string2)) {
                        if (stringArray.length > 2 && "save".equalsIgnoreCase(stringArray[1])) {
                            ConfigManager.getInstance().saveConfig(Ries.getInstance().getModuleManager(), stringArray[2]);
                            CommandManager.addChatMessageToGui("\u00a7a[Config] \u00a7f" + stringArray[2] + " kaydedildi.");
                        } else if (stringArray.length > 2 && "load".equalsIgnoreCase(stringArray[1])) {
                            ConfigManager.getInstance().loadConfig(Ries.getInstance().getModuleManager(), stringArray[2]);
                            CommandManager.addChatMessageToGui("\u00a7a[Config] \u00a7f" + stringArray[2] + " y\u00fcklendi.");
                        } else {
                            CommandManager.addChatMessageToGui("\u00a7c[Config] \u00a7fKullan\u0131m: .config save <isim> veya .config load <isim>");
                        }
                    } else if ("prefix".equals(string2)) {
                        if (stringArray.length > 1 && "sifirla".equalsIgnoreCase(stringArray[1])) {
                            prefixText = "";
                            customNameText = "";
                            CommandManager.addChatMessageToGui("\u00a7a[Prefix] \u00a7f\u0130sim prefiksi ve \u00f6zel isim kald\u0131r\u0131ld\u0131.");
                        } else if (stringArray.length > 1) {
                            prefixText = stringArray[1];
                            if (stringArray.length > 2) {
                                prefixColor = stringArray[2];
                            }
                            if (stringArray.length > 3) {
                                nameColor = stringArray[3];
                            }
                            if (stringArray.length > 4) {
                                StringBuilder stringBuilder = new StringBuilder();
                                for (n = 4; n < stringArray.length; ++n) {
                                    if (n > 4) {
                                        stringBuilder.append(" ");
                                    }
                                    stringBuilder.append(stringArray[n]);
                                }
                                customNameText = stringBuilder.toString();
                            } else {
                                customNameText = "";
                            }
                            if (!customNameText.isEmpty()) {
                                CommandManager.addChatMessageToGui("\u00a7a[Prefix] \u00a7f\u0130sim prefiksi: \u00a7" + prefixColor + prefixText + " \u00a7frenk: \u00a7" + nameColor + "\u00a7" + nameColor + nameColor + " \u00a7f(isim rengi) \u00a7fYeni \u0130sim: \u00a7a" + customNameText);
                            } else {
                                CommandManager.addChatMessageToGui("\u00a7a[Prefix] \u00a7f\u0130sim prefiksi: \u00a7" + prefixColor + prefixText + " \u00a7frenk: \u00a7" + nameColor + "\u00a7" + nameColor + nameColor + " \u00a7f(isim rengi)");
                            }
                        } else {
                            CommandManager.addChatMessageToGui("\u00a7a[Prefix] \u00a7fKullan\u0131m: \u00a77.prefix <metin> [on-renk-kodu] [isim-renk-kodu] [yeni-isim]");
                            CommandManager.addChatMessageToGui("\u00a77\u00d6rnek: .prefix Allah 4 c Ahmet | \u00a74Allah \u00a7cAhmet");
                            CommandManager.addChatMessageToGui("\u00a77Renk kodlar\u0131: 0-9, a-f");
                            CommandManager.addChatMessageToGui("\u00a77S\u0131f\u0131rlamak i\u00e7in: .prefix sifirla");
                        }
                    } else {
                        CommandManager.addChatMessageToGui("\u00a7c[Massacre] \u00a7fBilinmeyen komut. Kullan\u0131m: \u00a77.streamer, .fstreamer, .config, .prefix, .target, .m, .friend");
                    }
                }
                catch (Throwable throwable) {
                    Logger.warn("CommandManager error: " + throwable.getMessage());
                }
            }
        }
    }

    private static void onPacketReceive(PacketReceiveEvent packetReceiveEvent) {
        Object object = packetReceiveEvent.getPacket();
        Class<?> clazz = MinecraftMapper.get("S02PacketChat");
        if (object != null && clazz != null && clazz.isInstance(object)) {
            try {
                Field field = null;
                Object object2 = clazz.getDeclaredFields();
                int n = ((Field[])object2).length;
                for (int i = 0; i < n; ++i) {
                    Field field2 = object2[i];
                    if (!field2.getType().getSimpleName().contains("ChatComponent") && !field2.getType().getSimpleName().contains("IChatComponent")) continue;
                    field = field2;
                    break;
                }
                if (field == null) {
                    object2 = MinecraftMapper.get("IChatComponent");
                    for (Field field3 : clazz.getDeclaredFields()) {
                        if (object2 == null || !((Class)object2).isAssignableFrom(field3.getType())) continue;
                        field = field3;
                        break;
                    }
                }
                if (field != null) {
                    field.setAccessible(true);
                    Object object3 = field.get(object);
                    if (object3 != null && (object2 = CommandManager.getRealPlayerName()) != null && !((String)object2).isEmpty()) {
                        CommandManager.replaceTextInChatComponent(object3, (String)object2);
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private static void replaceTextInChatComponent(Object object, String string) {
        if (object == null) {
            return;
        }
        try {
            Class<?> clazz;
            Object object2;
            Object object3;
            Object object4;
            Class<?> clazz2 = MinecraftMapper.get("ChatComponentText");
            if (clazz2 != null && clazz2.isInstance(object)) {
                for (Field field : clazz2.getDeclaredFields()) {
                    if (field.getType() != String.class) continue;
                    field.setAccessible(true);
                    object4 = (String)field.get(object);
                    if (object4 == null || !((String)object4).contains(string)) continue;
                    object3 = customNameText != null && !customNameText.isEmpty() ? customNameText : string;
                    String string2 = (String)object3;
                    object2 = streamerEnabled ? streamerName : (fakeUserEnabled ? targetFakeUser : (prefixText != null && !prefixText.isEmpty() ? (((String)object4).contains(prefixText) ? "\u00a7" + nameColor + (String)object3 : "\u00a7" + prefixColor + prefixText + " \u00a7" + nameColor + (String)object3) : "\u00a7" + nameColor + (String)object3));
                    field.set(object, ((String)object4).replace(string, (CharSequence)object2));
                }
            }
            if ((clazz = MinecraftMapper.get("ChatComponentStyle")) == null) {
                clazz = object.getClass().getSuperclass();
            }
            if (clazz != null) {
                for (Field field : clazz.getDeclaredFields()) {
                    if (!List.class.isAssignableFrom(field.getType())) continue;
                    field.setAccessible(true);
                    object3 = (List)field.get(object);
                    if (object3 == null) continue;
                    object4 = object3.iterator();
                    while (((Iterator)object4).hasNext()) {
                        object2 = ((Iterator)object4).next();
                        CommandManager.replaceTextInChatComponent(object2, string);
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static void addChatMessageToGui(String string) {
        try {
            if (ClickGuiModule.chatAlerts != null && !((Boolean)ClickGuiModule.chatAlerts.getValue()).booleanValue()) {
                return;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            Object object = MappingUtils.getThePlayer();
            if (object != null) {
                Class<?> clazz = MinecraftMapper.get("ChatComponentText");
                Method method = MappingUtils.getMethod("EntityPlayerSP.addChatMessage");
                if (clazz != null && method != null) {
                    Constructor<?> constructor = clazz.getConstructor(String.class);
                    Object obj = constructor.newInstance(string);
                    method.invoke(object, obj);
                }
            } else {
                Logger.info("[Chat] " + string);
            }
        }
        catch (Throwable throwable) {
            Logger.warn("Failed to add chat message to GUI: " + throwable.getMessage());
        }
    }

    public static void backupOriginals() {
        Object object = CommandManager.getLocalPlayerInfo();
        if (object != null) {
            try {
                Field field = MappingUtils.getField("NetworkPlayerInfo.locationSkin");
                Field field2 = MappingUtils.getField("NetworkPlayerInfo.locationCape");
                Field field3 = MappingUtils.getField("NetworkPlayerInfo.gameProfile");
                Field field4 = MappingUtils.getField("NetworkPlayerInfo.displayName");
                if (originalSkin == null && field != null) {
                    originalSkin = field.get(object);
                }
                if (originalCape == null && field2 != null) {
                    originalCape = field2.get(object);
                }
                if (originalProfile == null && field3 != null && (originalProfile = field3.get(object)) != null) {
                    Field field5 = originalProfile.getClass().getDeclaredField("name");
                    field5.setAccessible(true);
                    originalName = (String)field5.get(originalProfile);
                }
                if (originalDisplay == null && field4 != null) {
                    originalDisplay = field4.get(object);
                }
            }
            catch (Throwable throwable) {
                Logger.warn("Failed to backup original player info: " + throwable.getMessage());
            }
        }
    }

    public static void restoreOriginals() {
        Object object = CommandManager.getLocalPlayerInfo();
        if (object != null) {
            try {
                Field field = MappingUtils.getField("NetworkPlayerInfo.locationSkin");
                Field field2 = MappingUtils.getField("NetworkPlayerInfo.locationCape");
                Field field3 = MappingUtils.getField("NetworkPlayerInfo.gameProfile");
                Field field4 = MappingUtils.getField("NetworkPlayerInfo.displayName");
                if (originalSkin != null && field != null) {
                    field.set(object, originalSkin);
                }
                if (originalCape != null && field2 != null) {
                    field2.set(object, originalCape);
                }
                if (originalProfile != null && field3 != null) {
                    field3.set(object, originalProfile);
                    if (!originalName.isEmpty()) {
                        Field field5 = originalProfile.getClass().getDeclaredField("name");
                        field5.setAccessible(true);
                        field5.set(originalProfile, originalName);
                    }
                }
                if (originalDisplay != null && field4 != null) {
                    field4.set(object, originalDisplay);
                }
            }
            catch (Throwable throwable) {
                Logger.warn("Failed to restore original player info: " + throwable.getMessage());
            }
        }
    }

    public static void applyStreamer() {
        CommandManager.backupOriginals();
        Object object = CommandManager.getLocalPlayerInfo();
        if (object != null && originalProfile != null) {
            try {
                Field field = originalProfile.getClass().getDeclaredField("name");
                field.setAccessible(true);
                field.set(originalProfile, streamerName);
            }
            catch (Throwable throwable) {
                Logger.warn("Failed to apply streamer name: " + throwable.getMessage());
            }
        }
    }

    public static void copyTargetUser(String string) {
        AccessibleObject accessibleObject;
        Object object;
        Object object2;
        CommandManager.backupOriginals();
        Map<UUID, Object> map = CommandManager.getPlayerInfoMap();
        if (map == null) {
            return;
        }
        Object object3 = null;
        for (Object object4 : map.values()) {
            try {
                Field field = MappingUtils.getField("NetworkPlayerInfo.gameProfile");
                if (field == null || (object2 = field.get(object4)) == null || !string.equalsIgnoreCase((String)(object = (String)((Method)(accessibleObject = object2.getClass().getMethod("getName", new Class[0]))).invoke(object2, new Object[0])))) continue;
                object3 = object4;
                break;
            }
            catch (Throwable throwable) {
            }
        }
        if (object3 == null) {
            return;
        }
        Object object5 = CommandManager.getLocalPlayerInfo();
        if (object5 != null) {
            try {
                Object object4;
                object4 = MappingUtils.getField("NetworkPlayerInfo.locationSkin");
                accessibleObject = MappingUtils.getField("NetworkPlayerInfo.locationCape");
                object = MappingUtils.getField("NetworkPlayerInfo.gameProfile");
                object2 = MappingUtils.getField("NetworkPlayerInfo.displayName");
                if (object4 != null) {
                    ((Field)object4).set(object5, ((Field)object4).get(object3));
                }
                if (accessibleObject != null) {
                    ((Field)accessibleObject).set(object5, ((Field)accessibleObject).get(object3));
                }
                if (object != null) {
                    ((Field)object).set(object5, ((Field)object).get(object3));
                }
                if (object2 != null) {
                    ((Field)object2).set(object5, ((Field)object2).get(object3));
                }
            }
            catch (Throwable throwable) {
                Logger.warn("FakeUser copy error: " + throwable.getMessage());
            }
        }
    }

    public static void applyAllahPrefix() {
        try {
            Object object = MappingUtils.getThePlayer();
            if (object == null) {
                return;
            }
            Field field = MappingUtils.getField("EntityPlayer.gameProfile");
            if (field == null) {
                return;
            }
            Object object2 = field.get(object);
            if (object2 == null) {
                return;
            }
            Field field2 = MappingUtils.getField("GameProfile.name");
            if (field2 == null) {
                for (Class<?> clazz = object2.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
                    try {
                        field2 = clazz.getDeclaredField("name");
                        break;
                    }
                    catch (NoSuchFieldException noSuchFieldException) {
                        continue;
                    }
                }
            }
            if (field2 == null) {
                return;
            }
            field2.setAccessible(true);
            String string = (String)field2.get(object2);
            if (string == null) {
                return;
            }
            if (originalName == null || originalName.isEmpty()) {
                originalName = string;
            }
            if (!streamerEnabled) {
                if (!string.equals(originalName)) {
                    field2.set(object2, originalName);
                }
                return;
            }
            String string2 = customNameText != null && !customNameText.isEmpty() ? customNameText : originalName;
            String string3 = string2;
            if (!allahPrefixEnabled || prefixText == null || prefixText.isEmpty()) {
                String string4 = "\u00a7" + nameColor + string2;
                if (!string.equals(string4)) {
                    field2.set(object2, string4);
                }
                return;
            }
            String string5 = "\u00a7" + prefixColor + prefixText + " \u00a7" + nameColor;
            String string6 = string5 + string2;
            if (!string.equals(string6)) {
                field2.set(object2, string6);
                Logger.info("[Prefix] Isim: " + originalName + " -> " + string5 + string2);
            }
        }
        catch (Throwable throwable) {
            Logger.warn("[Prefix] Hata: " + throwable.getMessage());
        }
    }

    public static Object getLocalPlayerInfo() {
        UUID uUID = CommandManager.getPlayerUUID();
        if (uUID == null) {
            return null;
        }
        Map<UUID, Object> map = CommandManager.getPlayerInfoMap();
        if (map != null) {
            return map.get(uUID);
        }
        return null;
    }

    public static UUID getPlayerUUID() {
        try {
            Method method;
            Object object = MappingUtils.getThePlayer();
            if (object != null && (method = MappingUtils.getMethod("Entity.getUniqueID")) != null) {
                return (UUID)method.invoke(object, new Object[0]);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    public static Map<UUID, Object> getPlayerInfoMap() {
        try {
            Class<?> clazz;
            Object object = MinecraftMapper.getMinecraft();
            if (object != null && (clazz = MappingUtils.get("NetHandlerPlayClient")) != null) {
                Object object2 = null;
                for (Field field : object.getClass().getDeclaredFields()) {
                    if (!clazz.isAssignableFrom(field.getType())) continue;
                    field.setAccessible(true);
                    object2 = field.get(object);
                    break;
                }
                if (object2 != null) {
                    for (Field field : clazz.getDeclaredFields()) {
                        if (!Map.class.isAssignableFrom(field.getType())) continue;
                        field.setAccessible(true);
                        return (Map)field.get(object2);
                    }
                }
            }
        }
        catch (Throwable throwable) {
            Logger.warn("Failed to get playerInfoMap: " + throwable.getMessage());
        }
        return null;
    }

    public static String getRealPlayerName() {
        if (originalName != null && !originalName.isEmpty()) {
            return originalName;
        }
        try {
            Method method;
            Object object = MappingUtils.getThePlayer();
            if (object != null && (method = MappingUtils.getMethod("EntityPlayer.getName")) != null) {
                return (String)method.invoke(object, new Object[0]);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return "";
    }
}

