/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.reflect.TypeToken
 */
package me.ries.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import me.ries.module.Module;
import me.ries.module.ModuleManager;
import me.ries.module.impl.ClickGuiModule;
import me.ries.module.impl.FriendManagerModule;
import me.ries.module.impl.ScoreBoardModule;
import me.ries.module.impl.SpotifyWidget;
import me.ries.module.impl.TargetHudModule;
import me.ries.notification.NotificationManager;
import me.ries.setting.OptionBase;
import me.ries.ui.IngameHud;
import me.ries.util.Logger;

public final class ConfigManager {
    private static final ConfigManager INSTANCE = new ConfigManager();
    private static final Type CONFIG_TYPE = new TypeToken<Map<String, Object>>(){}.getType();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final File directory = new File(System.getenv("APPDATA") != null ? System.getenv("APPDATA") + File.separator + "ries" : "C:\\ries\\configs");
    private final File fallbackDirectory = new File("C:\\ries\\configs");
    private String currentConfig = "default";

    public File getDirectory() {
        return this.directory;
    }

    private ConfigManager() {
    }

    public static ConfigManager getInstance() {
        return INSTANCE;
    }

    public String getCurrentConfig() {
        return this.currentConfig;
    }

    public List<String> getConfigList() {
        String string;
        File[] fileArray;
        this.ensureDirectory();
        ArrayList<String> arrayList = new ArrayList<String>();
        File[] fileArray2 = this.directory.listFiles();
        if (fileArray2 != null) {
            fileArray = fileArray2;
            int n = fileArray.length;
            for (int i = 0; i < n; ++i) {
                File file = fileArray[i];
                String object = file.getName();
                if (!file.isFile() || !object.toLowerCase().endsWith(".json") || arrayList.contains(string = object.substring(0, object.length() - 5))) continue;
                arrayList.add(string);
            }
        }
        if (this.fallbackDirectory.exists() && this.fallbackDirectory.isDirectory() && (fileArray = this.fallbackDirectory.listFiles()) != null) {
            for (File file : fileArray) {
                String string2;
                string = file.getName();
                if (!file.isFile() || !string.toLowerCase().endsWith(".json") || arrayList.contains(string2 = string.substring(0, string.length() - 5))) continue;
                arrayList.add(string2);
            }
        }
        if (!arrayList.contains("default")) {
            arrayList.add("default");
        }
        Collections.sort(arrayList, String.CASE_INSENSITIVE_ORDER);
        return arrayList;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void saveConfig(ModuleManager moduleManager, String string) {
        FileWriter fileWriter;
        if (moduleManager == null) return;
        String string2 = this.sanitize(string);
        this.ensureDirectory();
        HashMap<String, Object> hashMap = new HashMap<String, Object>();
        HashMap hashMap2 = new HashMap();
        for (Module object2 : moduleManager.getModules()) {
            HashMap<String, Object> throwable = new HashMap<String, Object>();
            throwable.put("enabled", object2.isEnabled());
            throwable.put("keyBind", object2.getKeyBind());
            HashMap<String, Object> hashMap3 = new HashMap<String, Object>();
            for (OptionBase<?> optionBase : object2.getOptions()) {
                hashMap3.put(optionBase.getName(), optionBase.toConfigValue());
            }
            throwable.put("options", hashMap3);
            hashMap2.put(object2.getName(), throwable);
        }
        hashMap.put("modules", hashMap2);
        HashMap hashMap5 = new HashMap();
        hashMap5.put("watermarkX", Double.valueOf(IngameHud.watermarkX));
        hashMap5.put("watermarkY", Double.valueOf(IngameHud.watermarkY));
        hashMap5.put("arrayListX", Double.valueOf(IngameHud.arrayListX));
        hashMap5.put("arrayListY", Double.valueOf(IngameHud.arrayListY));
        hashMap5.put("spotifyX", Double.valueOf(SpotifyWidget.posX));
        hashMap5.put("spotifyY", Double.valueOf(SpotifyWidget.posY));
        hashMap5.put("spotifyWidth", Double.valueOf(SpotifyWidget.width));
        hashMap5.put("spotifyHeight", Double.valueOf(SpotifyWidget.height));
        hashMap5.put("targetHudX", Double.valueOf(TargetHudModule.posX));
        hashMap5.put("targetHudY", Double.valueOf(TargetHudModule.posY));
        hashMap5.put("targetHudWidth", Double.valueOf(TargetHudModule.width));
        hashMap5.put("targetHudHeight", Double.valueOf(TargetHudModule.height));
        hashMap5.put("scoreboardX", Double.valueOf(ScoreBoardModule.posX));
        hashMap5.put("scoreboardY", Double.valueOf(ScoreBoardModule.posY));
        hashMap5.put("notificationX", Double.valueOf(NotificationManager.posX));
        hashMap5.put("notificationY", Double.valueOf(NotificationManager.posY));
        hashMap.put("ui", hashMap5);
        hashMap.put("friends", new ArrayList<String>(FriendManagerModule.friends));
        OutputStreamWriter outputStreamWriter = null;
        try {
            fileWriter = new FileWriter(this.fileFor(string2));
            this.gson.toJson(hashMap, (Appendable)fileWriter);
            this.currentConfig = string2;
            if (fileWriter == null) return;
        }
        catch (Throwable throwable) {
            try {
                Logger.warn("Config save failed: " + throwable.getMessage());
                return;
            }
            catch (Throwable throwable2) {
                throw throwable2;
            }
            finally {
                if (outputStreamWriter != null) {
                    try {
                        outputStreamWriter.close();
                    }
                    catch (Throwable throwable3) {}
                }
            }
        }
        try {
            fileWriter.close();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public void loadConfig(ModuleManager moduleManager, String string) {
        FileReader fileReader;
        block29: {
            File file;
            if (moduleManager == null) {
                return;
            }
            String string2 = this.sanitize(string);
            File file2 = new File(this.directory, string2 + ".json");
            if (!file2.isFile() && (file = new File(this.fallbackDirectory, string2 + ".json")).isFile()) {
                file2 = file;
            }
            if (!file2.isFile()) {
                this.currentConfig = string2;
                return;
            }
            fileReader = null;
            try {
                fileReader = new FileReader(file2);
                Map map = (Map)this.gson.fromJson((Reader)fileReader, CONFIG_TYPE);
                Object var7_11 = map == null ? null : map.get("modules");
                Object var9_14 = var7_11;
                if (!(var7_11 instanceof Map)) break block29;
                Map map2 = var7_11;
                for (Module object : moduleManager.getModules()) {
                    Object object2;
                    Object v;
                    Object v2 = map2.get(object.getName());
                    if (!(v2 instanceof Map)) continue;
                    Map map3 = (Map)v2;
                    Object v3 = map3.get("keyBind");
                    if (v3 instanceof Number) {
                        object.setKeyBind(((Number)v3).intValue());
                    }
                    if ((v = map3.get("options")) instanceof Map) {
                        Map map4 = (Map)v;
                        for (OptionBase<?> optionBase : object.getOptions()) {
                            if (!map4.containsKey(optionBase.getName())) continue;
                            optionBase.fromConfigValue(map4.get(optionBase.getName()));
                        }
                    }
                    if (!((object2 = map3.get("enabled")) instanceof Boolean) || object instanceof ClickGuiModule) continue;
                    boolean bl = (Boolean)object2;
                    if (bl && !object.isEnabled()) {
                        object.enable();
                        continue;
                    }
                    if (bl || !object.isEnabled()) continue;
                    object.disable();
                }
                this.currentConfig = string2;
                Iterator<Module> iterator = map.get("ui");
                if (iterator instanceof Map) {
                    Map map5 = (Map)((Object)iterator);
                    IngameHud.watermarkX = ConfigManager.getFloat(map5, "watermarkX", IngameHud.watermarkX);
                    IngameHud.watermarkY = ConfigManager.getFloat(map5, "watermarkY", IngameHud.watermarkY);
                    IngameHud.arrayListX = ConfigManager.getFloat(map5, "arrayListX", IngameHud.arrayListX);
                    IngameHud.arrayListY = ConfigManager.getFloat(map5, "arrayListY", IngameHud.arrayListY);
                    SpotifyWidget.posX = ConfigManager.getFloat(map5, "spotifyX", SpotifyWidget.posX);
                    SpotifyWidget.posY = ConfigManager.getFloat(map5, "spotifyY", SpotifyWidget.posY);
                    SpotifyWidget.width = ConfigManager.getFloat(map5, "spotifyWidth", SpotifyWidget.width);
                    SpotifyWidget.height = ConfigManager.getFloat(map5, "spotifyHeight", SpotifyWidget.height);
                    TargetHudModule.posX = ConfigManager.getFloat(map5, "targetHudX", TargetHudModule.posX);
                    TargetHudModule.posY = ConfigManager.getFloat(map5, "targetHudY", TargetHudModule.posY);
                    TargetHudModule.width = ConfigManager.getFloat(map5, "targetHudWidth", TargetHudModule.width);
                    TargetHudModule.height = ConfigManager.getFloat(map5, "targetHudHeight", TargetHudModule.height);
                    ScoreBoardModule.posX = ConfigManager.getFloat(map5, "scoreboardX", ScoreBoardModule.posX);
                    ScoreBoardModule.posY = ConfigManager.getFloat(map5, "scoreboardY", ScoreBoardModule.posY);
                    NotificationManager.posX = ConfigManager.getFloat(map5, "notificationX", NotificationManager.posX);
                    NotificationManager.posY = ConfigManager.getFloat(map5, "notificationY", NotificationManager.posY);
                }
                if ((file = map.get("friends")) instanceof List) {
                    FriendManagerModule.friends.clear();
                    for (Object object2 : (List)((Object)file)) {
                        if (!(object2 instanceof String)) continue;
                        FriendManagerModule.friends.add((String)object2);
                    }
                }
                if (fileReader == null) {
                    return;
                }
            }
            catch (Throwable throwable) {
                try {
                    Logger.warn("Config load failed: " + throwable.getMessage());
                    return;
                }
                catch (Throwable throwable2) {
                    throw throwable2;
                }
                finally {
                    if (fileReader != null) {
                        try {
                            fileReader.close();
                        }
                        catch (Throwable throwable3) {}
                    }
                }
            }
            try {
                fileReader.close();
                return;
            }
            catch (Throwable throwable) {
                return;
            }
        }
        if (fileReader == null) {
            return;
        }
        try {
            fileReader.close();
            return;
        }
        catch (Throwable throwable) {
            return;
        }
    }

    public boolean deleteConfig(String string) {
        File file;
        String string2 = this.sanitize(string);
        if ("default".equalsIgnoreCase(string2)) {
            return false;
        }
        boolean bl = false;
        File file2 = new File(this.directory, string2 + ".json");
        if (file2.isFile() && file2.delete()) {
            bl = true;
        }
        if ((file = new File(this.fallbackDirectory, string2 + ".json")).isFile() && file.delete()) {
            bl = true;
        }
        return bl;
    }

    private void ensureDirectory() {
        if (!this.directory.exists()) {
            this.directory.mkdirs();
        }
    }

    private File fileFor(String string) {
        this.ensureDirectory();
        return new File(this.directory, this.sanitize(string) + ".json");
    }

    private String sanitize(String string) {
        String string2 = string == null ? "" : string.trim().replaceAll("[^A-Za-z0-9_.-]", "_");
        return string2.length() == 0 ? "default" : string2;
    }

    private static float getFloat(Map<String, Object> map, String string, float f) {
        Object object = map.get(string);
        return object instanceof Number ? ((Number)object).floatValue() : f;
    }
}

