/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Function
 *  com.google.common.collect.HashMultimap
 *  com.google.common.collect.ImmutableSet
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Multimap
 *  com.google.common.collect.Sets
 *  com.google.gson.Gson
 *  io.netty.buffer.ByteBuf
 *  io.netty.buffer.Unpooled
 *  io.netty.channel.Channel
 *  org.apache.commons.lang3.ArrayUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.Display
 *  org.objectweb.asm.ClassReader
 *  org.objectweb.asm.ClassVisitor
 *  org.objectweb.asm.Type
 *  org.objectweb.asm.tree.AbstractInsnNode
 *  org.objectweb.asm.tree.ClassNode
 *  org.objectweb.asm.tree.FieldInsnNode
 *  org.objectweb.asm.tree.FieldNode
 *  org.objectweb.asm.tree.InsnList
 *  org.objectweb.asm.tree.JumpInsnNode
 *  org.objectweb.asm.tree.MethodInsnNode
 *  org.objectweb.asm.tree.MethodNode
 *  org.objectweb.asm.tree.TypeInsnNode
 *  org.objectweb.asm.tree.VarInsnNode
 */
package me.ries.mapping;

import com.google.common.base.Function;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.google.gson.Gson;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Executable;
import java.lang.reflect.Field;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.security.Key;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import me.ries.loader.ClassByteStore;
import me.ries.mapping.AutoMapper;
import me.ries.module.impl.ParticlesModule;
import me.ries.util.Logger;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.logging.log4j.LogManager;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;
import sun.misc.Unsafe;

public class MinecraftMapper {
    private static List<Class<?>> cachedClasses = null;
    private static final Random random = new Random();

    public static List<Class<?>> getClasses() {
        if (cachedClasses == null) {
            cachedClasses = MinecraftMapper.loadGameClasses(Collections.emptyList());
        }
        return cachedClasses;
    }

    public static void scanAndMap(List<Class<?>> classes) {
        AutoMapper.clear();
        cachedClasses = MinecraftMapper.loadGameClasses(classes);
        MinecraftMapper.syncAutoMapperClassCache();
        try {
            MinecraftMapper.startMappings();
        }
        catch (Throwable e) {
            e.printStackTrace();
        }
        MinecraftMapper.runMappingStep("mapEssentialClientMappings(pre)", () -> MinecraftMapper.mapEssentialClientMappings());
        try {
            MinecraftMapper.runFullAutomapperPass();
        }
        catch (Throwable e) {
            Logger.error("Error in full automapper pass: " + e.getMessage());
            e.printStackTrace();
        }
        MinecraftMapper.runMappingStep("mapEssentialClientMappings(post)", () -> MinecraftMapper.mapEssentialClientMappings());
        try {
            AutoMapper.exportToFile("C:\\ries\\mappings.txt");
        }
        catch (Throwable e) {
            Logger.error("Error exporting mappings: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void syncAutoMapperClassCache() {
        AutoMapper.cachedClasses.clear();
        if (cachedClasses != null) {
            AutoMapper.cachedClasses.addAll(cachedClasses);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static List<Class<?>> loadGameClasses(List<Class<?>> fallbackClasses) {
        LinkedHashMap found;
        block9: {
            found = new LinkedHashMap();
            for (Class<?> clazz : ClassByteStore.snapshot()) {
                MinecraftMapper.addGameClass(found, clazz);
            }
            try {
                ArrayList snapshot;
                Field customClassesField = ClassLoader.class.getDeclaredField("customClasses");
                customClassesField.setAccessible(true);
                Iterator customClasses = customClassesField.get(null);
                if (!(customClasses instanceof Collection)) break block9;
                Iterator iterator = customClasses;
                synchronized (iterator) {
                    snapshot = new ArrayList((Collection)((Object)customClasses));
                }
                for (Object item : snapshot) {
                    if (!(item instanceof Class)) continue;
                    MinecraftMapper.addGameClass(found, (Class)item);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        if (fallbackClasses != null) {
            for (Class<?> clazz : fallbackClasses) {
                MinecraftMapper.addGameClass(found, clazz);
            }
        }
        return new ArrayList(found.values());
    }

    private static void addGameClass(Map<String, Class<?>> classes, Class<?> clazz) {
        String name;
        if (clazz != null && MinecraftMapper.isGameRuntimeClassName(name = clazz.getName())) {
            classes.putIfAbsent(name, clazz);
        }
    }

    private static boolean isGameRuntimeClass(Class<?> clazz) {
        return clazz != null && !clazz.isPrimitive() && !clazz.isArray() && MinecraftMapper.isGameRuntimeClassName(clazz.getName());
    }

    private static boolean isGameRuntimeClassName(String className) {
        return className != null && (className.startsWith("craftrise.") || className.startsWith("crsecond.") || className.startsWith("cr.") || className.startsWith("com.craftrise."));
    }

    private static boolean isEntityPlayerSPHierarchy(Class<?> cls) {
        Class<?> current = cls;
        for (int i = 0; i < 4; ++i) {
            if (current == null) {
                return false;
            }
            if (MinecraftMapper.isGameRuntimeClass(current = current.getSuperclass())) continue;
            return false;
        }
        return true;
    }

    private static boolean isBlockPosCandidate(Class<?> clazz) {
        if (MinecraftMapper.isGameRuntimeClass(clazz) && !clazz.isInterface() && !clazz.isEnum()) {
            for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                Class<?>[] params = constructor.getParameterTypes();
                if (params.length != 3 || params[0] != Integer.TYPE || params[1] != Integer.TYPE || params[2] != Integer.TYPE) continue;
                return true;
            }
            return false;
        }
        return false;
    }

    public static void put(String name, Class<?> clazz) {
        AutoMapper.put(name, clazz);
    }

    public static void putField(String fullName, Field field) {
        AutoMapper.putField(fullName, field);
    }

    public static void putMethod(String fullName, Method method) {
        AutoMapper.putMethod(fullName, method);
    }

    public static Class<?> get(String name) {
        return AutoMapper.get(name);
    }

    public static Field getField(String fullName) {
        return AutoMapper.getField(fullName);
    }

    public static Method getMethod(String fullName) {
        return AutoMapper.getMethod(fullName);
    }

    public static boolean contains(String name) {
        return AutoMapper.contains(name);
    }

    public static byte[] getClassBytes(Class<?> clazz) {
        return AutoMapper.getClassBytes(clazz);
    }

    private static boolean missingClassBytes(String context, Class<?> clazz, byte[] bytes) {
        if (clazz == null) {
            MinecraftMapper.warnMappingSkip(context, "class is null");
            return true;
        }
        if (bytes != null && bytes.length != 0) {
            return false;
        }
        MinecraftMapper.warnMappingSkip(context, "class bytes not found for " + clazz.getName());
        return true;
    }

    private static boolean missingClassBytes(String context, byte[] bytes) {
        if (bytes != null && bytes.length != 0) {
            return false;
        }
        MinecraftMapper.warnMappingSkip(context, "class bytes not found");
        return true;
    }

    public static void saveClass(Class<?> clazz, String name) {
        AutoMapper.saveClass(clazz, name);
    }

    public static Object getMinecraft() {
        try {
            Field theMinecraft = MinecraftMapper.getField("Minecraft.theMinecraft");
            if (theMinecraft != null) {
                return theMinecraft.get(null);
            }
            Method getInstance = MinecraftMapper.getMethod("Minecraft.getInstance");
            if (getInstance != null) {
                return getInstance.invoke(null, new Object[0]);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static Object getPlayer() {
        try {
            Object mc = MinecraftMapper.getMinecraft();
            if (mc != null) {
                Method getThePlayer = MinecraftMapper.getMethod("Minecraft.getThePlayer");
                if (getThePlayer != null) {
                    return getThePlayer.invoke(mc, new Object[0]);
                }
                Field thePlayer = MinecraftMapper.getField("Minecraft.thePlayer");
                if (thePlayer != null) {
                    return thePlayer.get(mc);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static Object getThePlayer() {
        return MinecraftMapper.getPlayer();
    }

    public static Object getInventory() {
        try {
            Field inventory;
            Object player = MinecraftMapper.getPlayer();
            if (player != null && (inventory = MinecraftMapper.getField("EntityPlayer.inventory")) != null) {
                return inventory.get(player);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static boolean attackEntity(Object entity) {
        boolean entityId;
        ByteBuf packetBuffer = null;
        try {
            if (entity != null) {
                boolean var7;
                int entityId2 = MinecraftMapper.getEntityIdForAttackPacket(entity);
                if (entityId2 < 0) {
                    boolean var16;
                    MinecraftMapper.warnMappingSkip("attackEntity", "entity id could not be resolved");
                    boolean bl = var16 = false;
                    return bl;
                }
                Channel channel = MinecraftMapper.getNetworkChannel();
                if (channel == null) {
                    boolean var18;
                    MinecraftMapper.warnMappingSkip("attackEntity", "network channel is not available");
                    boolean bl = var18 = false;
                    return bl;
                }
                if (!channel.isActive()) {
                    boolean var17;
                    MinecraftMapper.warnMappingSkip("attackEntity", "network channel is not active");
                    boolean bl = var17 = false;
                    return bl;
                }
                Class<?> actionClass = MinecraftMapper.get("C02PacketUseEntityAction");
                if (actionClass == null) {
                    boolean var19;
                    MinecraftMapper.warnMappingSkip("attackEntity", "C02PacketUseEntityAction is not mapped");
                    boolean bl = var19 = false;
                    return bl;
                }
                Enum<?> attackEnum = MinecraftMapper.getAttackActionEnum(actionClass);
                if (attackEnum == null) {
                    boolean var20;
                    MinecraftMapper.warnMappingSkip("attackEntity", "ATTACK action enum is not available");
                    boolean bl = var20 = false;
                    return bl;
                }
                float hitHeight = 1.1f + (float)(Math.random() * 0.65);
                packetBuffer = Unpooled.buffer();
                packetBuffer.writeByte(2);
                MinecraftMapper.writeVarInt(packetBuffer, entityId2);
                MinecraftMapper.writeEnumValueToByteBuf(packetBuffer, attackEnum);
                packetBuffer.writeFloat(hitHeight);
                MinecraftMapper.logAttackEntityOut(entity, entityId2, attackEnum, hitHeight, channel, packetBuffer);
                channel.writeAndFlush((Object)packetBuffer);
                try {
                    ParticlesModule.onAttack(entity);
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                packetBuffer = null;
                boolean bl = var7 = true;
                return bl;
            }
            MinecraftMapper.warnMappingSkip("attackEntity", "entity is null");
            entityId = false;
        }
        catch (Throwable t) {
            boolean channel;
            MinecraftMapper.warnMappingSkip("attackEntity", String.valueOf(t.getMessage()));
            boolean bl = channel = false;
            return bl;
        }
        finally {
            if (packetBuffer != null) {
                packetBuffer.release();
            }
        }
        return entityId;
    }

    private static void logAttackEntityOut(Object entity, int entityId, Enum<?> actionEnum, float hitHeight, Channel channel, ByteBuf packetBuffer) {
        try {
            StringBuilder out = new StringBuilder();
            out.append("\n========== ATTACK ENTITY OUT ==========\n");
            out.append("source=MinecraftMapper.attackEntity\n");
            out.append("rawByteBuf=true\n");
            out.append("thread=").append(Thread.currentThread().getName()).append('\n');
            out.append("packetId=0x02\n");
            out.append("entityId=").append(entityId).append('\n');
            out.append("actionId=").append(actionEnum != null ? actionEnum.ordinal() : -1).append(" (ATTACK)\n");
            out.append("actionName=").append(actionEnum != null ? actionEnum.name() : "null").append('\n');
            out.append("hitHeight=").append(hitHeight).append('\n');
            out.append("bufferReaderIndex=").append(packetBuffer != null ? packetBuffer.readerIndex() : -1).append('\n');
            out.append("bufferWriterIndex=").append(packetBuffer != null ? packetBuffer.writerIndex() : -1).append('\n');
            out.append("bufferReadableBytes=").append(packetBuffer != null ? packetBuffer.readableBytes() : -1).append('\n');
            out.append("bufferCapacity=").append(packetBuffer != null ? packetBuffer.capacity() : -1).append('\n');
            out.append("packetBytes=").append(MinecraftMapper.byteBufToHex(packetBuffer)).append('\n');
            out.append("targetClass=").append(entity != null ? entity.getClass().getName() : "null").append('\n');
            out.append("targetName=").append(MinecraftMapper.safeEntityName(entity)).append('\n');
            out.append("targetHash=").append(entity != null ? System.identityHashCode(entity) : 0).append('\n');
            out.append("targetToString=").append(MinecraftMapper.safeToString(entity)).append('\n');
            out.append("targetPos=").append(MinecraftMapper.describeEntityPosition(entity)).append('\n');
            out.append("targetFields=").append(MinecraftMapper.describeObjectFields(entity, 64)).append('\n');
            Object player = MinecraftMapper.getThePlayer();
            out.append("playerClass=").append(player != null ? player.getClass().getName() : "null").append('\n');
            out.append("playerName=").append(MinecraftMapper.safeEntityName(player)).append('\n');
            out.append("playerPos=").append(MinecraftMapper.describeEntityPosition(player)).append('\n');
            out.append("distance=").append(MinecraftMapper.describeDistance(player, entity)).append('\n');
            if (channel != null) {
                out.append("channelClass=").append(channel.getClass().getName()).append('\n');
                out.append("channelActive=").append(channel.isActive()).append('\n');
                out.append("channelOpen=").append(channel.isOpen()).append('\n');
                out.append("channelWritable=").append(channel.isWritable()).append('\n');
                out.append("channelLocal=").append(String.valueOf(channel.localAddress())).append('\n');
                out.append("channelRemote=").append(String.valueOf(channel.remoteAddress())).append('\n');
            } else {
                out.append("channel=null\n");
            }
            out.append("=======================================\n");
            System.out.println(out.toString());
        }
        catch (Throwable t) {
            System.out.println("[ATTACK ENTITY OUT] log failed: " + t.getMessage());
        }
    }

    private static String byteBufToHex(ByteBuf buffer) {
        if (buffer == null) {
            return "null";
        }
        StringBuilder hex = new StringBuilder();
        int readerIndex = buffer.readerIndex();
        int writerIndex = buffer.writerIndex();
        for (int i = readerIndex; i < writerIndex; ++i) {
            short value;
            if (hex.length() > 0) {
                hex.append(' ');
            }
            if ((value = buffer.getUnsignedByte(i)) < 16) {
                hex.append('0');
            }
            hex.append(Integer.toHexString(value).toUpperCase(Locale.ROOT));
        }
        return hex.toString();
    }

    private static String safeEntityName(Object entity) {
        if (entity == null) {
            return "null";
        }
        try {
            return MinecraftMapper.getName(entity);
        }
        catch (Throwable var2) {
            return "unknown";
        }
    }

    private static String safeToString(Object value) {
        try {
            return String.valueOf(value);
        }
        catch (Throwable var2) {
            return "<toString failed>";
        }
    }

    private static String describeEntityPosition(Object entity) {
        if (entity == null) {
            return "null";
        }
        Double x = MinecraftMapper.readMappedDouble(entity, "Entity.posX");
        Double y = MinecraftMapper.readMappedDouble(entity, "Entity.posY");
        Double z = MinecraftMapper.readMappedDouble(entity, "Entity.posZ");
        return x != null && y != null && z != null ? "x=" + x + ", y=" + y + ", z=" + z : "unknown";
    }

    private static String describeObjectFields(Object value, int maxFields) {
        Class<?> current;
        if (value == null) {
            return "null";
        }
        StringBuilder fieldsOut = new StringBuilder("[");
        int count = 0;
        block2: for (current = value.getClass(); current != null && current != Object.class && count < maxFields; current = current.getSuperclass()) {
            Field[] fields;
            for (Field field : fields = current.getDeclaredFields()) {
                if (count >= maxFields) continue block2;
                if (Modifier.isStatic(field.getModifiers())) continue;
                if (count > 0) {
                    fieldsOut.append(", ");
                }
                fieldsOut.append(current.getSimpleName()).append('.').append(field.getName()).append('=');
                try {
                    field.setAccessible(true);
                    fieldsOut.append(MinecraftMapper.shortValue(field.get(value)));
                }
                catch (Throwable t) {
                    fieldsOut.append("<").append(t.getClass().getSimpleName()).append('>');
                }
                ++count;
            }
        }
        if (current != null && current != Object.class) {
            fieldsOut.append(", ...");
        }
        fieldsOut.append(']');
        return fieldsOut.toString();
    }

    private static String shortValue(Object value) {
        if (value == null) {
            return "null";
        }
        Class<?> valueClass = value.getClass();
        if (valueClass.isArray()) {
            return valueClass.getComponentType().getSimpleName() + "[" + Array.getLength(value) + "]";
        }
        if (!(value instanceof Number || value instanceof Boolean || value instanceof Character || value instanceof Enum)) {
            return value instanceof CharSequence ? '\"' + String.valueOf(value) + '\"' : valueClass.getName() + '@' + Integer.toHexString(System.identityHashCode(value));
        }
        return String.valueOf(value);
    }

    private static String describeDistance(Object from, Object to) {
        Double fromX = MinecraftMapper.readMappedDouble(from, "Entity.posX");
        Double fromY = MinecraftMapper.readMappedDouble(from, "Entity.posY");
        Double fromZ = MinecraftMapper.readMappedDouble(from, "Entity.posZ");
        Double toX = MinecraftMapper.readMappedDouble(to, "Entity.posX");
        Double toY = MinecraftMapper.readMappedDouble(to, "Entity.posY");
        Double toZ = MinecraftMapper.readMappedDouble(to, "Entity.posZ");
        if (fromX != null && fromY != null && fromZ != null && toX != null && toY != null && toZ != null) {
            double dx = fromX - toX;
            double dy = fromY - toY;
            double dz = fromZ - toZ;
            return String.valueOf(Math.sqrt(dx * dx + dy * dy + dz * dz));
        }
        return "unknown";
    }

    private static Double readMappedDouble(Object target, String mappingName) {
        if (target == null) {
            return null;
        }
        try {
            Field field = MinecraftMapper.getField(mappingName);
            if (field == null) {
                return null;
            }
            field.setAccessible(true);
            Object value = field.get(target);
            return value instanceof Number ? Double.valueOf(((Number)value).doubleValue()) : null;
        }
        catch (Throwable var4) {
            return null;
        }
    }

    private static int getEntityIdForAttackPacket(Object entity) throws Exception {
        int hc;
        Method getEntityId;
        Field entityIdField = MinecraftMapper.getField("Entity.entityId");
        if (entityIdField != null) {
            entityIdField.setAccessible(true);
            Object value = entityIdField.get(entity);
            if (value instanceof Number) {
                return ((Number)value).intValue();
            }
        }
        if ((getEntityId = MinecraftMapper.getMethod("Entity.getEntityId")) == null) {
            MinecraftMapper.ensureC02EntityIdMappings();
            getEntityId = MinecraftMapper.getMethod("Entity.getEntityId");
        }
        if (getEntityId != null) {
            getEntityId.setAccessible(true);
            Object value = getEntityId.invoke(entity, new Object[0]);
            if (value instanceof Number) {
                return ((Number)value).intValue();
            }
        }
        if ((hc = System.identityHashCode(entity)) > 0) {
            Logger.warn("[Mapper] Entity.getEntityId not mapped, using identityHashCode=" + hc);
            return hc;
        }
        throw new NoSuchMethodException("Entity.getEntityId");
    }

    private static void ensureC02EntityIdMappings() {
        if (MinecraftMapper.getMethod("Entity.getEntityId") == null) {
            try {
                Class<?> c02Class = MinecraftMapper.get("C02PacketUseEntity");
                Class<?> entityClass = MinecraftMapper.get("Entity");
                if (c02Class == null || entityClass == null) {
                    return;
                }
                byte[] bytes = MinecraftMapper.getClassBytes(c02Class);
                if (bytes == null || bytes.length == 0) {
                    return;
                }
                ClassNode classNode = new ClassNode();
                new ClassReader(bytes).accept((ClassVisitor)classNode, 0);
                String c02Owner = org.objectweb.asm.Type.getInternalName(c02Class);
                String entityOwner = org.objectweb.asm.Type.getInternalName(entityClass);
                for (MethodNode methodNode : classNode.methods) {
                    if (!"<init>".equals(methodNode.name)) continue;
                    MethodInsnNode getEntityIdCall = null;
                    FieldInsnNode entityIdField = null;
                    for (AbstractInsnNode insn : methodNode.instructions.toArray()) {
                        if (insn instanceof MethodInsnNode) {
                            MethodInsnNode methodInsn = (MethodInsnNode)insn;
                            if (!entityOwner.equals(methodInsn.owner) || !"()I".equals(methodInsn.desc)) continue;
                            getEntityIdCall = methodInsn;
                            continue;
                        }
                        if (!(insn instanceof FieldInsnNode)) continue;
                        FieldInsnNode fieldInsn = (FieldInsnNode)insn;
                        if (getEntityIdCall == null || !c02Owner.equals(fieldInsn.owner) || !"I".equals(fieldInsn.desc) || fieldInsn.getOpcode() != 181) continue;
                        entityIdField = fieldInsn;
                        break;
                    }
                    if (getEntityIdCall == null) continue;
                    Method reflectedGetEntityId = entityClass.getDeclaredMethod(getEntityIdCall.name, new Class[0]);
                    reflectedGetEntityId.setAccessible(true);
                    MinecraftMapper.putMethod("Entity.getEntityId", reflectedGetEntityId);
                    if (entityIdField != null) {
                        Field reflectedEntityIdField = c02Class.getDeclaredField(entityIdField.name);
                        reflectedEntityIdField.setAccessible(true);
                        MinecraftMapper.putField("C02PacketUseEntity.entityId", reflectedEntityIdField);
                    }
                    return;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public static Channel getNetworkChannel() throws Exception {
        Object netHandler = MinecraftMapper.getNetHandlerPlayClient();
        if (netHandler == null) {
            return null;
        }
        Object networkManager = MinecraftMapper.getNetworkManager(netHandler);
        if (networkManager == null) {
            return null;
        }
        Field channelField = MinecraftMapper.getField("NetworkManager.channel");
        if (channelField == null) {
            channelField = MinecraftMapper.getFieldByType(networkManager.getClass(), Channel.class);
        }
        if (channelField == null) {
            return null;
        }
        channelField.setAccessible(true);
        Object channel = channelField.get(networkManager);
        return channel instanceof Channel ? (Channel)channel : null;
    }

    private static Object getNetHandlerPlayClient() throws Exception {
        Object player = MinecraftMapper.getThePlayer();
        if (player == null) {
            return null;
        }
        Field sendQueue = MinecraftMapper.getField("EntityPlayerSP.sendQueue");
        if (sendQueue == null) {
            sendQueue = MinecraftMapper.getFieldByType(player.getClass(), MinecraftMapper.get("NetHandlerPlayClient"));
        }
        if (sendQueue == null) {
            return null;
        }
        sendQueue.setAccessible(true);
        return sendQueue.get(player);
    }

    private static Object getNetworkManager(Object netHandler) throws Exception {
        Field networkManagerField = MinecraftMapper.getField("NetHandlerPlayClient.networkManager");
        if (networkManagerField == null) {
            networkManagerField = MinecraftMapper.getFieldByType(netHandler.getClass(), MinecraftMapper.get("NetworkManager"));
        }
        if (networkManagerField == null) {
            return null;
        }
        networkManagerField.setAccessible(true);
        return networkManagerField.get(netHandler);
    }

    private static Enum<?> getAttackActionEnum(Class<?> actionClass) throws Exception {
        try {
            return Enum.valueOf(actionClass, "ATTACK");
        }
        catch (IllegalArgumentException var5) {
            Field attackField;
            try {
                attackField = actionClass.getField("ATTACK");
            }
            catch (NoSuchFieldException var4) {
                attackField = actionClass.getDeclaredField("ATTACK");
            }
            attackField.setAccessible(true);
            Object value = attackField.get(null);
            return value instanceof Enum ? (Enum)value : null;
        }
    }

    private static int getC02AttackActionId() {
        try {
            Field attackField;
            Class<?> actionClass = MinecraftMapper.get("C02PacketUseEntityAction");
            if (actionClass == null) {
                return 1;
            }
            try {
                attackField = actionClass.getField("ATTACK");
            }
            catch (NoSuchFieldException var3) {
                attackField = actionClass.getDeclaredField("ATTACK");
            }
            attackField.setAccessible(true);
            Object attack = attackField.get(null);
            if (attack instanceof Enum) {
                return ((Enum)attack).ordinal();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 1;
    }

    private static void writeEnumValueToByteBuf(ByteBuf buffer, Enum<?> value) {
        MinecraftMapper.writeVarInt(buffer, value.ordinal());
    }

    private static void writeVarInt(ByteBuf buffer, int value) {
        while ((value & 0xFFFFFF80) != 0) {
            buffer.writeByte(value & 0x7F | 0x80);
            value >>>= 7;
        }
        buffer.writeByte(value);
    }

    public static void addChatMessage(String msg) {
        Logger.info("[CHAT MOCKED] " + msg);
    }

    private static void warnMappingSkip(String section, String reason) {
    }

    private static boolean missingClass(String section, String mappingName, Class<?> clazz) {
        return clazz == null;
    }

    private static void runMappingStep(String name, MappingStep step) {
        try {
            step.run();
        }
        catch (Throwable t) {
            Logger.warn("[Mapper] Step failed: " + name + " -> " + t.getMessage());
        }
    }

    private static void mapEssentialClientMappings() {
        MinecraftMapper.ensureMinecraftClass();
        MinecraftMapper.ensureMinecraftInstanceMappings();
        MinecraftMapper.ensureDetectionFlagMappings();
        MinecraftMapper.ensureEntityPlayerSPClass();
        MinecraftMapper.ensurePlayerAccessMappings();
        MinecraftMapper.ensureChatComponentMappings();
        MinecraftMapper.ensureFontRendererMappings();
        MinecraftMapper.ensureGuiInGameMapping();
    }

    private static String mappedClassName(String name) {
        Class<?> clazz = MinecraftMapper.get(name);
        return clazz == null ? "missing" : clazz.getName();
    }

    private static void ensureMinecraftClass() {
        if (MinecraftMapper.get("Minecraft") == null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                try {
                    if (!MinecraftMapper.containsMinecraftFields(clazz)) continue;
                    MinecraftMapper.put("Minecraft", clazz);
                    return;
                }
                catch (Throwable throwable) {
                }
            }
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                if (!MinecraftMapper.isConcreteGameClass(clazz) || !MinecraftMapper.hasSelfSingletonField(clazz) || !MinecraftMapper.hasFieldType(clazz, "java.net.Proxy")) continue;
                MinecraftMapper.put("Minecraft", clazz);
                return;
            }
        }
    }

    private static void ensureMinecraftInstanceMappings() {
        Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
        if (minecraftClass != null) {
            Method getInstance;
            Field singleton;
            if (MinecraftMapper.getField("Minecraft.theMinecraft") == null && (singleton = MinecraftMapper.findStaticFieldByType(minecraftClass, minecraftClass)) != null) {
                MinecraftMapper.putField("Minecraft.theMinecraft", singleton);
            }
            if (MinecraftMapper.getMethod("Minecraft.getInstance") == null && (getInstance = MinecraftMapper.findStaticNoArgMethodByReturnType(minecraftClass, minecraftClass)) != null) {
                MinecraftMapper.putMethod("Minecraft.getInstance", getInstance);
            }
        }
    }

    private static void ensureDetectionFlagMappings() {
        Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
        if (minecraftClass != null && MinecraftMapper.getField("Minecraft.detectionFlag1") == null) {
            try {
                Field detectionFlag1 = minecraftClass.getDeclaredField("\u00c3\u008f\u00c2\u00ae");
                if (detectionFlag1.getType() == Boolean.TYPE) {
                    MinecraftMapper.putField("Minecraft.detectionFlag1", detectionFlag1);
                } else {
                    MinecraftMapper.warnMappingSkip("Minecraft.detectionFlag1", "field \\u03EE is not boolean");
                }
            }
            catch (NoSuchFieldException var2) {
                MinecraftMapper.warnMappingSkip("Minecraft.detectionFlag1", "field \\u03EE was not found");
            }
        }
    }

    private static void ensureEntityPlayerSPClass() {
        Class<?> minecraftClass;
        if (MinecraftMapper.get("EntityPlayerSP") == null && (minecraftClass = MinecraftMapper.get("Minecraft")) != null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                try {
                    if (!MinecraftMapper.isEntityPlayerSP(clazz)) continue;
                    MinecraftMapper.mapEntityPlayerHierarchy(clazz);
                    return;
                }
                catch (Throwable throwable) {
                }
            }
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                if (!MinecraftMapper.isConcreteGameClass(clazz) || !MinecraftMapper.hasProtectedFieldByType(clazz, minecraftClass) || !MinecraftMapper.isEntityPlayerSPHierarchy(clazz)) continue;
                MinecraftMapper.mapEntityPlayerHierarchy(clazz);
                for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                    Class<?>[] params = constructor.getParameterTypes();
                    if (params.length != 4 || params[0] != minecraftClass) continue;
                    if (MinecraftMapper.isGameRuntimeClass(params[1])) {
                        MinecraftMapper.put("World", params[1]);
                    }
                    if (!MinecraftMapper.isGameRuntimeClass(params[2])) break;
                    MinecraftMapper.put("NetHandlerPlayClient", params[2]);
                    break;
                }
                return;
            }
        }
    }

    private static void mapEntityPlayerHierarchy(Class<?> entityPlayerSPClass) {
        if (entityPlayerSPClass != null) {
            Class<?> entityClass;
            MinecraftMapper.put("EntityPlayerSP", entityPlayerSPClass);
            Class<?> abstractClientPlayerClass = entityPlayerSPClass.getSuperclass();
            Class<?> entityPlayerClass = abstractClientPlayerClass == null ? null : abstractClientPlayerClass.getSuperclass();
            Class<?> entityLivingBaseClass = entityPlayerClass == null ? null : entityPlayerClass.getSuperclass();
            Class<?> clazz = entityClass = entityLivingBaseClass == null ? null : entityLivingBaseClass.getSuperclass();
            if (MinecraftMapper.isGameRuntimeClass(abstractClientPlayerClass)) {
                MinecraftMapper.put("AbstractClientPlayer", abstractClientPlayerClass);
            }
            if (MinecraftMapper.isGameRuntimeClass(entityPlayerClass)) {
                MinecraftMapper.put("EntityPlayer", entityPlayerClass);
            }
            if (MinecraftMapper.isGameRuntimeClass(entityLivingBaseClass)) {
                MinecraftMapper.put("EntityLivingBase", entityLivingBaseClass);
            }
            if (MinecraftMapper.isGameRuntimeClass(entityClass)) {
                MinecraftMapper.put("Entity", entityClass);
            }
        }
    }

    private static void ensurePlayerAccessMappings() {
        Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
        Class<?> entityPlayerSPClass = MinecraftMapper.get("EntityPlayerSP");
        if (minecraftClass != null && entityPlayerSPClass != null) {
            Field playerField;
            Method getter;
            if (MinecraftMapper.getMethod("Minecraft.getThePlayer") == null && (getter = MinecraftMapper.findNoArgMethodByReturnType(minecraftClass, entityPlayerSPClass)) != null) {
                MinecraftMapper.putMethod("Minecraft.getThePlayer", getter);
            }
            if (MinecraftMapper.getField("Minecraft.thePlayer") == null && (playerField = MinecraftMapper.findFieldByType(minecraftClass, entityPlayerSPClass, false)) != null) {
                MinecraftMapper.putField("Minecraft.thePlayer", playerField);
            }
        }
    }

    private static void ensureChatComponentMappings() {
        Method method;
        if (MinecraftMapper.get("IChatComponent") == null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                try {
                    if (!MinecraftMapper.isIChatComponent(clazz)) continue;
                    MinecraftMapper.put("IChatComponent", clazz);
                    break;
                }
                catch (Throwable throwable) {
                }
            }
        }
        if (MinecraftMapper.get("IChatComponent") != null && MinecraftMapper.get("ChatComponentStyle") == null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                try {
                    if (!MinecraftMapper.isChatComponentStyle(clazz)) continue;
                    MinecraftMapper.put("ChatComponentStyle", clazz);
                    break;
                }
                catch (Throwable throwable) {
                }
            }
        }
        if (MinecraftMapper.get("ChatComponentStyle") != null && MinecraftMapper.get("ChatComponentText") == null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                try {
                    if (!MinecraftMapper.isChatComponentText(clazz)) continue;
                    MinecraftMapper.put("ChatComponentText", clazz);
                    break;
                }
                catch (Throwable throwable) {
                }
            }
        }
        Class<?> entityPlayerSPClass = MinecraftMapper.get("EntityPlayerSP");
        Class<?> chatComponentClass = MinecraftMapper.get("IChatComponent");
        if (entityPlayerSPClass != null && chatComponentClass != null && MinecraftMapper.getMethod("EntityPlayerSP.addChatMessage") == null && (method = MinecraftMapper.findSingleArgMethod(entityPlayerSPClass, chatComponentClass)) != null) {
            MinecraftMapper.putMethod("EntityPlayerSP.addChatMessage", method);
        }
    }

    private static void ensureFontRendererMappings() {
        Class<?> fontRendererClass = MinecraftMapper.get("FontRenderer");
        if (fontRendererClass == null && (fontRendererClass = MinecraftMapper.findFontRendererCandidate()) != null) {
            MinecraftMapper.put("FontRenderer", fontRendererClass);
        }
        if (fontRendererClass != null) {
            Class<?> minecraftClass;
            Method drawString;
            if (MinecraftMapper.getMethod("FontRenderer.drawString") == null && (drawString = MinecraftMapper.findDrawStringMethod(fontRendererClass)) != null) {
                MinecraftMapper.putMethod("FontRenderer.drawString", drawString);
            }
            if ((minecraftClass = MinecraftMapper.get("Minecraft")) != null) {
                Field field;
                Method getter;
                if (MinecraftMapper.getMethod("Minecraft.getFontRendererObj") == null && (getter = MinecraftMapper.findNoArgMethodByReturnType(minecraftClass, fontRendererClass)) != null) {
                    MinecraftMapper.putMethod("Minecraft.getFontRendererObj", getter);
                }
                if (MinecraftMapper.getField("Minecraft.fontRendererObj") == null && (field = MinecraftMapper.findFieldByType(minecraftClass, fontRendererClass, false)) != null) {
                    MinecraftMapper.putField("Minecraft.fontRendererObj", field);
                }
            }
        }
    }

    private static void ensureGuiInGameMapping() {
        if (MinecraftMapper.get("GuiInGame") == null && MinecraftMapper.get("Minecraft") != null) {
            Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                if (!MinecraftMapper.isConcreteGameClass(clazz)) continue;
                try {
                    boolean hasMapField = false;
                    boolean hasMinecraftField = false;
                    for (Field field : clazz.getDeclaredFields()) {
                        int mods = field.getModifiers();
                        if (Modifier.isStatic(mods) && Modifier.isFinal(mods) && Map.class.isAssignableFrom(field.getType())) {
                            hasMapField = true;
                        }
                        if (Modifier.isStatic(mods) || !Modifier.isFinal(mods) || field.getType() != minecraftClass) continue;
                        hasMinecraftField = true;
                    }
                    if (!hasMapField || !hasMinecraftField) continue;
                    Method renderMethod = null;
                    for (Method method : clazz.getDeclaredMethods()) {
                        Class<?>[] params = method.getParameterTypes();
                        if (!Modifier.isPublic(method.getModifiers()) || method.getReturnType() != Void.TYPE || params.length != 2 || params[1] != Float.TYPE) continue;
                        renderMethod = method;
                        break;
                    }
                    if (renderMethod == null) continue;
                    MinecraftMapper.put("ScaledResolution", renderMethod.getParameterTypes()[0]);
                    MinecraftMapper.put("GuiInGame", clazz);
                    return;
                }
                catch (Throwable throwable) {
                }
            }
        }
    }

    private static boolean isConcreteGameClass(Class<?> clazz) {
        return MinecraftMapper.isGameRuntimeClass(clazz) && !clazz.isInterface() && !clazz.isEnum() && !clazz.isAnnotation() && !Modifier.isAbstract(clazz.getModifiers());
    }

    private static boolean hasSelfSingletonField(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            int mods = field.getModifiers();
            if (field.getType() != clazz || !Modifier.isStatic(mods)) continue;
            return true;
        }
        return false;
    }

    private static boolean hasFieldType(Class<?> clazz, String fieldTypeName) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!fieldTypeName.equals(field.getType().getName())) continue;
            return true;
        }
        return false;
    }

    private static boolean hasProtectedFieldByType(Class<?> clazz, Class<?> type) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!Modifier.isProtected(field.getModifiers()) || field.getType() != type) continue;
            return true;
        }
        return false;
    }

    private static Field findStaticFieldByType(Class<?> owner, Class<?> type) {
        Field fallback = null;
        for (Field field : owner.getDeclaredFields()) {
            int mods = field.getModifiers();
            if (field.getType() != type || !Modifier.isStatic(mods)) continue;
            if (Modifier.isPublic(mods)) {
                return field;
            }
            fallback = field;
        }
        return fallback;
    }

    private static Field findFieldByType(Class<?> owner, Class<?> type, boolean requireStatic) {
        for (Field field : owner.getDeclaredFields()) {
            if (field.getType() != type || Modifier.isStatic(field.getModifiers()) != requireStatic) continue;
            return field;
        }
        return null;
    }

    private static Method findStaticNoArgMethodByReturnType(Class<?> owner, Class<?> returnType) {
        for (Method method : owner.getDeclaredMethods()) {
            if (!Modifier.isStatic(method.getModifiers()) || method.getParameterCount() != 0 || method.getReturnType() != returnType) continue;
            return method;
        }
        return null;
    }

    private static Method findNoArgMethodByReturnType(Class<?> owner, Class<?> returnType) {
        for (Method method : owner.getDeclaredMethods()) {
            if (method.getParameterCount() != 0 || method.getReturnType() != returnType) continue;
            return method;
        }
        for (Method method : owner.getMethods()) {
            if (method.getParameterCount() != 0 || method.getReturnType() != returnType) continue;
            return method;
        }
        return null;
    }

    private static Method findSingleArgMethod(Class<?> owner, Class<?> parameterType) {
        Class<?>[] params;
        for (Method method : owner.getDeclaredMethods()) {
            params = method.getParameterTypes();
            if (params.length != 1 || params[0] != parameterType) continue;
            return method;
        }
        for (Method method : owner.getMethods()) {
            params = method.getParameterTypes();
            if (params.length != 1 || params[0] != parameterType) continue;
            return method;
        }
        return null;
    }

    private static Class<?> findFontRendererCandidate() {
        Class<?> bestClass = null;
        int bestScore = -1;
        for (Class<?> clazz : MinecraftMapper.getClasses()) {
            if (!MinecraftMapper.isConcreteGameClass(clazz)) continue;
            int drawMethodCount = 0;
            for (Method method : clazz.getDeclaredMethods()) {
                if (!MinecraftMapper.isDrawStringMethod(method)) continue;
                ++drawMethodCount;
            }
            if (drawMethodCount == 0) continue;
            int score = drawMethodCount * 10;
            if (clazz.getInterfaces().length > 0) {
                score += 2;
            }
            for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                Class<?>[] params = constructor.getParameterTypes();
                if (params.length < 4 || params[params.length - 1] != Boolean.TYPE) continue;
                score += 3;
                break;
            }
            if (score <= bestScore) continue;
            bestScore = score;
            bestClass = clazz;
        }
        return bestClass;
    }

    private static Method findDrawStringMethod(Class<?> fontRendererClass) {
        for (Method method : fontRendererClass.getDeclaredMethods()) {
            if (!MinecraftMapper.isDrawStringMethod(method)) continue;
            return method;
        }
        return null;
    }

    private static boolean isDrawStringMethod(Method method) {
        if (Modifier.isStatic(method.getModifiers())) {
            return false;
        }
        Class<?>[] params = method.getParameterTypes();
        return params.length == 5 && params[0] == String.class && params[1] == Float.TYPE && params[2] == Float.TYPE && params[3] == Integer.TYPE && params[4] == Boolean.TYPE;
    }

    private static void runFullAutomapperPass() {
        MinecraftMapper.runMappingStep("flag", () -> MinecraftMapper.flag());
        MinecraftMapper.runMappingStep("findMathHelper", () -> MinecraftMapper.findMathHelper());
        MinecraftMapper.runMappingStep("processPacketClass", () -> MinecraftMapper.processPacketClass());
        MinecraftMapper.runMappingStep("mapNetHandlerPlayClient", () -> MinecraftMapper.mapNetHandlerPlayClient());
        MinecraftMapper.runMappingStep("findS18", () -> MinecraftMapper.findS18());
        MinecraftMapper.runMappingStep("findOnGround(S18PacketEntityTeleport)", () -> MinecraftMapper.findOnGround(MinecraftMapper.getClassBytes(MinecraftMapper.get("S18PacketEntityTeleport"))));
        MinecraftMapper.runMappingStep("findS0BPacketAnimation", () -> MinecraftMapper.findS0BPacketAnimation());
        MinecraftMapper.runMappingStep("findS12PacketVelocity", () -> MinecraftMapper.findS12PacketVelocity());
        MinecraftMapper.runMappingStep("finds0cpacket", () -> MinecraftMapper.finds0cpacket());
        MinecraftMapper.runMappingStep("finds02", () -> MinecraftMapper.finds02());
        MinecraftMapper.runMappingStep("finds33packet", () -> MinecraftMapper.finds33packet());
        MinecraftMapper.runMappingStep("finds37andstatbase", () -> MinecraftMapper.finds37andstatbase());
        MinecraftMapper.runMappingStep("findS3FPacket", () -> MinecraftMapper.findS3FPacket());
        MinecraftMapper.runMappingStep("findTitlePacket", () -> MinecraftMapper.findTitlePacket());
        MinecraftMapper.runMappingStep("findWorldBorderPacket", () -> MinecraftMapper.findWorldBorderPacket());
        MinecraftMapper.runMappingStep("findC17Custom", () -> MinecraftMapper.findC17Custom());
        MinecraftMapper.runMappingStep("findResourcePackStatusPacket", () -> MinecraftMapper.findResourcePackStatusPacket());
        MinecraftMapper.runMappingStep("findClickWindowPacket", () -> MinecraftMapper.findClickWindowPacket());
        MinecraftMapper.runMappingStep("findC10PacketCreativeInventoryAction", () -> MinecraftMapper.findC10PacketCreativeInventoryAction());
        MinecraftMapper.runMappingStep("findUpdateSignPacket", () -> MinecraftMapper.findUpdateSignPacket());
        MinecraftMapper.runMappingStep("findClientStatusPacket", () -> MinecraftMapper.findClientStatusPacket());
        MinecraftMapper.runMappingStep("findInputPacket", () -> MinecraftMapper.findInputPacket());
        MinecraftMapper.runMappingStep("findHandshakePacket", () -> MinecraftMapper.findHandshakePacket());
        MinecraftMapper.runMappingStep("findEntityActionPacket", () -> MinecraftMapper.findEntityActionPacket());
        MinecraftMapper.runMappingStep("findUpdateScorePacket", () -> MinecraftMapper.findUpdateScorePacket());
        MinecraftMapper.runMappingStep("findc09packet", () -> MinecraftMapper.findc09packet());
        MinecraftMapper.runMappingStep("findC0DPacketCloseWindow", () -> MinecraftMapper.findC0DPacketCloseWindow());
        MinecraftMapper.runMappingStep("findPlayerPosLookPacket", () -> MinecraftMapper.findPlayerPosLookPacket());
        MinecraftMapper.runMappingStep("findS39PlayerCapabilities", () -> MinecraftMapper.findS39PlayerCapabilities());
        MinecraftMapper.runMappingStep("findC13PacketPlayerAbilities", () -> MinecraftMapper.findC13PacketPlayerAbilities());
        MinecraftMapper.runMappingStep("mapC13PacketPlayerAbilitiesFields", () -> MinecraftMapper.mapC13PacketPlayerAbilitiesFields());
        MinecraftMapper.runMappingStep("mapPlayerCapabilitiesFields", () -> MinecraftMapper.mapPlayerCapabilitiesFields());
        MinecraftMapper.runMappingStep("findPlayerCap", () -> MinecraftMapper.findPlayerCap());
        MinecraftMapper.runMappingStep("findInventoryPlayerClass", () -> MinecraftMapper.findInventoryPlayerClass());
        MinecraftMapper.runMappingStep("findCurrentItem", () -> MinecraftMapper.putField("InventoryPlayer.currentItem", MinecraftMapper.findCurrentItem(MinecraftMapper.getClassBytes(MinecraftMapper.get("InventoryPlayer")), MinecraftMapper.get("InventoryPlayer"))));
        MinecraftMapper.runMappingStep("findItemStackSize", () -> MinecraftMapper.findItemStackSize());
        MinecraftMapper.runMappingStep("findItemStackItemField", () -> MinecraftMapper.findItemStackItemField());
        MinecraftMapper.runMappingStep("findItemStackDisplayName", () -> MinecraftMapper.findItemStackDisplayName());
        MinecraftMapper.runMappingStep("findGetSubCompoundMethod", () -> MinecraftMapper.findGetSubCompoundMethod());
        MinecraftMapper.runMappingStep("findSetTagInfoMethod", () -> MinecraftMapper.findSetTagInfoMethod());
        MinecraftMapper.runMappingStep("processItemClass", () -> MinecraftMapper.processItemClass());
        MinecraftMapper.runMappingStep("findEntityList", () -> MinecraftMapper.findEntityList());
        MinecraftMapper.runMappingStep("findallmobs", () -> MinecraftMapper.findallmobs());
        MinecraftMapper.runMappingStep("findEntityFields", () -> MinecraftMapper.findEntityFields());
        MinecraftMapper.runMappingStep("findTicksExisted", () -> MinecraftMapper.findTicksExisted());
        MinecraftMapper.runMappingStep("findPrevRenderYawOffset", () -> MinecraftMapper.findPrevRenderYawOffset());
        MinecraftMapper.runMappingStep("mapGetHealth", () -> MinecraftMapper.mapGetHealth());
        MinecraftMapper.runMappingStep("mapMoveEntityWithHeadingAndParams", () -> MinecraftMapper.mapMoveEntityWithHeadingAndParams());
        MinecraftMapper.runMappingStep("mapPerformHurtAnimation", () -> MinecraftMapper.mapPerformHurtAnimation());
        MinecraftMapper.runMappingStep("findEntityBoat", () -> MinecraftMapper.findEntityBoat());
        MinecraftMapper.runMappingStep("findEntityThrowable", () -> MinecraftMapper.findEntityThrowable());
        MinecraftMapper.runMappingStep("findSkin", () -> MinecraftMapper.findSkin());
        MinecraftMapper.runMappingStep("findGameProfile", () -> MinecraftMapper.findGameProfile());
        MinecraftMapper.runMappingStep("analyzeNetworkPlayerInfoField", () -> {
            Field playerInfo = MinecraftMapper.analyzeNetworkPlayerInfoField(MinecraftMapper.get("AbstractClientPlayer"));
            MinecraftMapper.putField("AbstractClientPlayer.playerInfo", playerInfo);
            if (playerInfo != null) {
                MinecraftMapper.put("NetworkPlayerInfo", playerInfo.getType());
            }
        });
        MinecraftMapper.runMappingStep("mapNetworkPlayerInfoAndPacketClasses", () -> MinecraftMapper.mapNetworkPlayerInfoAndPacketClasses());
        MinecraftMapper.runMappingStep("findAxisAligned", () -> MinecraftMapper.findAxisAligned());
        MinecraftMapper.runMappingStep("findRenderManager", () -> MinecraftMapper.findRenderManager());
        MinecraftMapper.runMappingStep("findRenderManagerFields", () -> MinecraftMapper.findRenderManagerFields());
        MinecraftMapper.runMappingStep("findRendererLivingEntity", () -> MinecraftMapper.findRendererLivingEntity());
        MinecraftMapper.runMappingStep("findItemRendererClass", () -> MinecraftMapper.findItemRendererClass());
        MinecraftMapper.runMappingStep("findEntityRenderer", () -> MinecraftMapper.findEntityRenderer());
        MinecraftMapper.runMappingStep("findEffectRenderer", () -> MinecraftMapper.findEffectRenderer());
        MinecraftMapper.runMappingStep("findGetRenderManager", () -> MinecraftMapper.findGetRenderManager());
        MinecraftMapper.runMappingStep("findRenderManagerHooks", () -> MinecraftMapper.findRenderManagerHooks());
        MinecraftMapper.runMappingStep("findTextureManagerClass", () -> MinecraftMapper.findTextureManagerClass());
        MinecraftMapper.runMappingStep("findModelManager", () -> MinecraftMapper.findModelManager());
        MinecraftMapper.runMappingStep("processModelBiped", () -> MinecraftMapper.processModelBiped());
        MinecraftMapper.runMappingStep("processModelBipedMethods", () -> MinecraftMapper.processModelBipedMethods());
        MinecraftMapper.runMappingStep("rectMethods", () -> MinecraftMapper.rectMethods());
        MinecraftMapper.runMappingStep("findTimerContainer", () -> MinecraftMapper.findTimerContainer());
        MinecraftMapper.runMappingStep("findTimerClass", () -> MinecraftMapper.findTimerClass());
        MinecraftMapper.runMappingStep("findglstatemanager", () -> MinecraftMapper.findglstatemanager(20));
        MinecraftMapper.runMappingStep("processGameSettingsClass", () -> MinecraftMapper.processGameSettingsClass());
        MinecraftMapper.runMappingStep("processKeyBindingClasses", () -> MinecraftMapper.processKeyBindingClasses());
        MinecraftMapper.runMappingStep("processMouseHelperClass", () -> MinecraftMapper.processMouseHelperClass());
        MinecraftMapper.runMappingStep("extractKeyBindings", () -> MinecraftMapper.extractKeyBindings(MinecraftMapper.get("GameSettings")));
        MinecraftMapper.runMappingStep("findThirdPersonViewField", () -> MinecraftMapper.findThirdPersonViewField());
        MinecraftMapper.runMappingStep("findsendChatMessage", () -> MinecraftMapper.findsendChatMessage());
        MinecraftMapper.runMappingStep("findGuiInventory", () -> MinecraftMapper.findGuiInventory());
        MinecraftMapper.runMappingStep("findGetChunkFromChunkCoords", () -> MinecraftMapper.findGetChunkFromChunkCoords());
        MinecraftMapper.runMappingStep("findGetBlockInChunk", () -> MinecraftMapper.findGetBlockInChunk());
        MinecraftMapper.runMappingStep("findGetIdFromBlock", () -> MinecraftMapper.findGetIdFromBlock());
        MinecraftMapper.runMappingStep("worldacces", () -> MinecraftMapper.worldacces());
        MinecraftMapper.runMappingStep("findrenderGlobal", () -> MinecraftMapper.findrenderGlobal());
        MinecraftMapper.runMappingStep("processFloatContainerClasses", () -> MinecraftMapper.processFloatContainerClasses());
        MinecraftMapper.runMappingStep("processC02PacketUseEntityMethods", () -> MinecraftMapper.processC02PacketUseEntityMethods());
        MinecraftMapper.runMappingStep("findGetSlot", () -> MinecraftMapper.putMethod("Container.getSlot", MinecraftMapper.findGetSlot()));
        MinecraftMapper.runMappingStep("findC08PacketPlayerBlockPlacement", () -> MinecraftMapper.findC08PacketPlayerBlockPlacement());
        MinecraftMapper.runMappingStep("findC06PacketPlayerPosLook", () -> MinecraftMapper.findC06PacketPlayerPosLook(MinecraftMapper.getClasses()));
        MinecraftMapper.runMappingStep("findHeldItemChangePacketReflection", () -> MinecraftMapper.findHeldItemChangePacketReflection());
        MinecraftMapper.runMappingStep("mapC03XYZFromC06", () -> MinecraftMapper.mapC03XYZFromC06());
        MinecraftMapper.runMappingStep("mapIsBlockingASM", () -> MinecraftMapper.mapIsBlockingASM());
        MinecraftMapper.runMappingStep("mapSyncCurrentPlayItemASM", () -> MinecraftMapper.mapSyncCurrentPlayItemASM());
        MinecraftMapper.runMappingStep("findJumpOpcodeBased", () -> MinecraftMapper.findJumpOpcodeBased());
        MinecraftMapper.runMappingStep("analyzeAddMappingFirstParam", () -> MinecraftMapper.analyzeAddMappingFirstParam());
    }

    public static void findAxisAligned() {
        Class<?> icameraClass = MinecraftMapper.get("ICamera");
        if (icameraClass == null) {
            System.out.println("nulaq");
        } else {
            for (Method method : icameraClass.getDeclaredMethods()) {
                Class<?>[] paramTypes = method.getParameterTypes();
                if (paramTypes.length != 1) continue;
                MinecraftMapper.put("AxisAlignedBB", paramTypes[0]);
                MinecraftMapper.putMethod("ICamera.getBoundingBox", method);
                break;
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    public static void findRenderManager() {
        Class<?> textureManagerClass = MinecraftMapper.get("TextureManager");
        Class<?> worldClass = MinecraftMapper.get("World");
        Class<?> fontRendererClass = MinecraftMapper.get("FontRenderer");
        Class<?> entityClass = MinecraftMapper.get("Entity");
        if (textureManagerClass != null && worldClass != null && fontRendererClass != null && entityClass != null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                Class<?>[] paramTypes;
                Field[] fields = clazz.getDeclaredFields();
                boolean hasTextureManager = false;
                boolean hasWorld = false;
                boolean hasFontRenderer = false;
                boolean hasEntity = false;
                for (Field field : fields) {
                    Class<?> type = field.getType();
                    if (type.equals(textureManagerClass)) {
                        hasTextureManager = true;
                        continue;
                    }
                    if (type.equals(worldClass)) {
                        hasWorld = true;
                        continue;
                    }
                    if (type.equals(fontRendererClass)) {
                        hasFontRenderer = true;
                        continue;
                    }
                    if (!type.equals(entityClass)) continue;
                    hasEntity = true;
                }
                if (!hasTextureManager || !hasWorld || !hasFontRenderer || !hasEntity) continue;
                MinecraftMapper.put("RenderManager", clazz);
                for (AccessibleObject accessibleObject : clazz.getDeclaredMethods()) {
                    paramTypes = ((Method)accessibleObject).getParameterTypes();
                    if (paramTypes.length != 5 || !paramTypes[0].equals(entityClass) || paramTypes[1] == null || paramTypes[2] != Double.TYPE || paramTypes[3] != Double.TYPE || paramTypes[4] != Double.TYPE) continue;
                    MinecraftMapper.put("ICamera", paramTypes[1]);
                    MinecraftMapper.putMethod("RenderManager.shouldRender", (Method)accessibleObject);
                    break;
                }
                for (AccessibleObject accessibleObject : clazz.getDeclaredMethods()) {
                    paramTypes = ((Method)accessibleObject).getParameterTypes();
                    if (paramTypes.length != 3 || !paramTypes[0].equals(entityClass) || paramTypes[1] != Float.TYPE || paramTypes[2] != Boolean.TYPE) continue;
                    MinecraftMapper.putMethod("RenderManager.renderEntityStatic", (Method)accessibleObject);
                    break;
                }
                Field mapField = null;
                Class renderPlayerClass = null;
                for (Method method : clazz.getDeclaredMethods()) {
                    ParameterizedType pType;
                    Type[] typeArgs;
                    Type returnType;
                    if (!method.getReturnType().equals(Map.class) || !((returnType = method.getGenericReturnType()) instanceof ParameterizedType) || (typeArgs = (pType = (ParameterizedType)returnType).getActualTypeArguments()).length != 2 || !typeArgs[0].equals(String.class) || !(typeArgs[1] instanceof Class)) continue;
                    renderPlayerClass = (Class)typeArgs[1];
                    MinecraftMapper.putMethod("RenderManager.getEntityRenderer", method);
                    break;
                }
                Object entityRenderMapField = null;
                Object var14_22 = null;
                for (Field field : clazz.getDeclaredFields()) {
                    ParameterizedType firstArgType;
                    ParameterizedType pType;
                    Type[] typeArgs;
                    if (!field.getType().equals(Map.class)) continue;
                    Type fieldType = field.getGenericType();
                    if (fieldType instanceof ParameterizedType && (typeArgs = (pType = (ParameterizedType)fieldType).getActualTypeArguments()).length == 2 && typeArgs[0] instanceof ParameterizedType && (firstArgType = (ParameterizedType)typeArgs[0]).getRawType().equals(Class.class)) {
                        void var14_25;
                        field.setAccessible(true);
                        if (typeArgs[1] instanceof Class) {
                            Class clazz2 = (Class)typeArgs[1];
                        } else if (typeArgs[1] instanceof ParameterizedType) {
                            ParameterizedType renderType = (ParameterizedType)typeArgs[1];
                            Class clazz3 = (Class)renderType.getRawType();
                        }
                        if (var14_25 != null) {
                            MinecraftMapper.put("Render", var14_25);
                        }
                        MinecraftMapper.putField("RenderManager.entityRenderMap", field);
                        break;
                    }
                    mapField = field;
                    field.setAccessible(true);
                    if (fieldType instanceof ParameterizedType && (typeArgs = (pType = (ParameterizedType)fieldType).getActualTypeArguments()).length == 2 && typeArgs[0].equals(String.class) && typeArgs[1] instanceof Class && renderPlayerClass == null) {
                        renderPlayerClass = (Class)typeArgs[1];
                    }
                    MinecraftMapper.putField("RenderManager.playerRenderer", field);
                }
                if (renderPlayerClass == null && mapField != null) {
                    try {
                        Object firstValue;
                        Object renderManagerInstance = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                        Map map = (Map)mapField.get(renderManagerInstance);
                        if (map != null && !map.isEmpty() && (firstValue = map.values().iterator().next()) != null) {
                            renderPlayerClass = firstValue.getClass();
                        }
                    }
                    catch (Exception renderManagerInstance) {
                        // empty catch block
                    }
                }
                if (renderPlayerClass != null) {
                    MinecraftMapper.put("RenderPlayer", renderPlayerClass);
                    MinecraftMapper.findRenderPlayerMainModelOpcodes(renderPlayerClass);
                }
                MinecraftMapper.findGetRenderManager();
                try {
                    MinecraftMapper.findRenderManagerHooks();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }

    public static void findPlayerCap() {
        for (Class<?> candidate : new Vector(MinecraftMapper.getClasses())) {
            Constructor<?> ctor;
            Class<?>[] params;
            Constructor<?>[] constructors;
            if (candidate.isEnum() || candidate.isInterface() || candidate.isAnnotation() || (constructors = candidate.getDeclaredConstructors()).length != 1 || (params = (ctor = constructors[0]).getParameterTypes()).length != 2 || params[0] != Boolean.TYPE || params[1] != String.class) continue;
            boolean hasThreadLocalRandomField = false;
            int threadLocalRandomFieldCount = 0;
            for (Field field : candidate.getDeclaredFields()) {
                String fieldName;
                int modifiers = field.getModifiers();
                if (!Modifier.isPrivate(modifiers) || !Modifier.isFinal(modifiers) || field.getType() != Integer.TYPE || (fieldName = field.getName()).length() != 1) continue;
                ++threadLocalRandomFieldCount;
                hasThreadLocalRandomField = true;
            }
            if (!hasThreadLocalRandomField || threadLocalRandomFieldCount < 2) continue;
            MinecraftMapper.put("CapabilitiesContainer", candidate);
            return;
        }
    }

    public static void findEntityList() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> entityClass = MinecraftMapper.get("Entity");
        Class<?> worldClass = MinecraftMapper.get("World");
        Class<?> nbtTagCompoundClass = MinecraftMapper.get("NBTTagCompound");
        if (entityClass != null && worldClass != null) {
            for (Class<?> candidate : classes) {
                if (!Modifier.isPublic(candidate.getModifiers()) || candidate.isInterface() || candidate.isEnum() || candidate.isAnonymousClass() || candidate.getEnclosingClass() != null) continue;
                Method addMappingMethod = null;
                Method addMapping1Method = null;
                int matchingMethods = 0;
                for (Method method : candidate.getDeclaredMethods()) {
                    Class<?>[] paramTypes = method.getParameterTypes();
                    Type[] genericParamTypes = method.getGenericParameterTypes();
                    if (paramTypes.length == 3 && paramTypes[1] == String.class && paramTypes[2] == Integer.TYPE && MinecraftMapper.isEntityClassType(genericParamTypes[0], entityClass)) {
                        addMappingMethod = method;
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 5 && paramTypes[1] == String.class && paramTypes[2] == Integer.TYPE && paramTypes[3] == Integer.TYPE && paramTypes[4] == Integer.TYPE && MinecraftMapper.isEntityClassType(genericParamTypes[0], entityClass)) {
                        addMapping1Method = method;
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 2 && paramTypes[0] == String.class && paramTypes[1] == worldClass) {
                        ++matchingMethods;
                        continue;
                    }
                    if (nbtTagCompoundClass == null || paramTypes.length != 2 || paramTypes[0] != nbtTagCompoundClass || paramTypes[1] != worldClass) continue;
                    ++matchingMethods;
                }
                if (matchingMethods < 3 || addMappingMethod == null) continue;
                MinecraftMapper.put("EntityList", candidate);
                MinecraftMapper.putMethod("EntityList.addMapping", addMappingMethod);
                if (addMapping1Method != null) {
                    MinecraftMapper.putMethod("EntityList.addMapping1", addMapping1Method);
                }
                return;
            }
        }
    }

    public static void analyzeAddMappingFirstParam() {
        try {
            ParameterizedType pType;
            Type[] typeArgs;
            Class<?> entityListClass = MinecraftMapper.get("EntityList");
            if (entityListClass == null) {
                System.out.println("EntityList s\u00c3\u201e\u00c2\u00b1n\u00c3\u201e\u00c2\u00b1f\u00c3\u201e\u00c2\u00b1 bulunamad\u00c3\u201e\u00c2\u00b1!");
                return;
            }
            Method addMappingMethod = MinecraftMapper.getMethod("EntityList.addMapping");
            if (addMappingMethod == null) {
                System.out.println("addMapping metodu bulunamad\u00c3\u201e\u00c2\u00b1!");
                return;
            }
            Type[] genericParamTypes = addMappingMethod.getGenericParameterTypes();
            if (genericParamTypes.length <= 0 || !(genericParamTypes[0] instanceof ParameterizedType) || (typeArgs = (pType = (ParameterizedType)genericParamTypes[0]).getActualTypeArguments()).length > 0) {
                // empty if block
            }
            MinecraftMapper.findAddMappingCalls(entityListClass);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void mapSyncCurrentPlayItemASM() throws Exception {
        byte[] bytes;
        Class<?> pcmClass = MinecraftMapper.get("PlayerControllerMP");
        if (!MinecraftMapper.missingClassBytes("mapSyncCurrentPlayItemASM", pcmClass, bytes = MinecraftMapper.getClassBytes(pcmClass))) {
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 6);
            String foundName = null;
            String foundDesc = null;
            for (MethodNode mn : cn.methods) {
                if (!mn.desc.equals("()V") || mn.instructions == null || mn.instructions.size() == 0) continue;
                int intCompareCount = 0;
                int newCount = 0;
                int putFieldCount = 0;
                int getFieldCount = 0;
                boolean hasIntCtor = false;
                for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    int op = insn.getOpcode();
                    if (op == 160 || op == 159) {
                        ++intCompareCount;
                    }
                    if (op == 187) {
                        ++newCount;
                    }
                    if (op == 181) {
                        ++putFieldCount;
                    }
                    if (op == 180) {
                        ++getFieldCount;
                    }
                    if (op != 183) continue;
                    MethodInsnNode min = (MethodInsnNode)insn;
                    if (!min.name.equals("<init>") || !min.desc.equals("(I)V")) continue;
                    hasIntCtor = true;
                }
                if (intCompareCount < true || newCount < true || !hasIntCtor || getFieldCount < true || putFieldCount < 1) continue;
                foundName = mn.name;
                foundDesc = mn.desc;
                break;
            }
            if (foundName == null) {
                throw new RuntimeException("syncCurrentPlayItem ASM not found");
            }
            for (Method m : pcmClass.getDeclaredMethods()) {
                if (!m.getName().equals(foundName) || !org.objectweb.asm.Type.getMethodDescriptor((Method)m).equals(foundDesc)) continue;
                m.setAccessible(true);
                MinecraftMapper.putMethod("PlayerControllerMP.syncCurrentPlayItem", m);
                System.out.println("[ASM] syncCurrentPlayItem FOUND -> " + m);
                return;
            }
            throw new RuntimeException("Reflection match failed");
        }
    }

    private static Method findMethod(Class<?> clazz, int modifiers, Class<?> returnType, Class<?> ... paramTypes) {
        if (clazz == null) {
            return null;
        }
        Method method = Arrays.stream(clazz.getDeclaredMethods()).filter(m -> (m.getModifiers() & modifiers) == (modifiers & 0xD) && m.getReturnType() == returnType && Arrays.equals(m.getParameterTypes(), paramTypes)).findFirst().orElse(null);
        return method;
    }

    public static void rectMethods() {
        Class<?> Gui;
        Class<?> guiClass;
        Class<?> guiScreenClass = MinecraftMapper.get("GuiScreen");
        if (guiScreenClass != null && (guiClass = guiScreenClass.getSuperclass()) != null) {
            MinecraftMapper.put("Gui", guiClass);
        }
        if ((Gui = MinecraftMapper.get("Gui")) == null && guiScreenClass != null) {
            Gui = guiScreenClass.getSuperclass();
        }
        if (Gui != null) {
            Method drawRect = MinecraftMapper.findMethod(Gui, 9, Void.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE);
            MinecraftMapper.putMethod("Gui.drawRect", drawRect);
            Method drawModalRectWithCustomSizedTexture = MinecraftMapper.findMethod(Gui, 9, Void.TYPE, Integer.TYPE, Integer.TYPE, Float.TYPE, Float.TYPE, Integer.TYPE, Integer.TYPE, Float.TYPE, Float.TYPE);
            MinecraftMapper.putMethod("Gui.drawModalRectWithCustomSizedTexture", drawModalRectWithCustomSizedTexture);
            Method drawScaledCustomSizeModalRect = MinecraftMapper.findMethod(Gui, 9, Void.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE);
            MinecraftMapper.putMethod("Gui.drawScaledCustomSizeModalRect", drawScaledCustomSizeModalRect);
        }
    }

    public static void findSkin() {
        if (MinecraftMapper.get("AbstractClientPlayer") != null && MinecraftMapper.get("ResourceLocation") != null) {
            for (Object ent : MinecraftMapper.getPlayerEntitiesInWorld()) {
                String name = MinecraftMapper.getName(ent);
                if (name == null || !name.contains("[CR]")) continue;
                Class<?> abst = MinecraftMapper.get("AbstractClientPlayer");
                Class<?> res = MinecraftMapper.get("ResourceLocation");
                if (abst == null || res == null) continue;
                for (Method m : abst.getMethods()) {
                    if (Modifier.isStatic(m.getModifiers()) || !m.getReturnType().equals(res)) continue;
                    try {
                        Object head = m.invoke(ent, new Object[0]);
                        if (head == null) continue;
                        MinecraftMapper.putMethod("AbstractClientPlayer.getLocationSkin", m);
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
            }
        } else {
            MinecraftMapper.warnMappingSkip("findSkin", "AbstractClientPlayer or ResourceLocation is not mapped");
        }
    }

    public static void mapC03XYZFromC06() {
        try {
            Class<?> c06 = MinecraftMapper.get("C06PacketPlayerPosLook");
            if (c06 == null) {
                return;
            }
            Class<?> c03 = c06.getSuperclass();
            if (c03 == null) {
                return;
            }
            byte[] bytes = MinecraftMapper.getClassBytes(c06);
            if (MinecraftMapper.missingClassBytes("mapC03XYZFromC06", c06, bytes)) {
                return;
            }
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            MethodNode ctor = null;
            for (MethodNode mn : cn.methods) {
                if (!mn.name.equals("<init>") || !mn.desc.equals("(DDDFFZ)V")) continue;
                ctor = mn;
                break;
            }
            if (ctor == null) {
                return;
            }
            ArrayList<FieldInsnNode> doublePuts = new ArrayList<FieldInsnNode>();
            for (AbstractInsnNode insn : ctor.instructions) {
                if (insn.getOpcode() != 181) continue;
                FieldInsnNode fin = (FieldInsnNode)insn;
                if (!fin.owner.equals(cn.name) || !fin.desc.equals("D")) continue;
                doublePuts.add(fin);
            }
            if (doublePuts.size() < 3) {
                return;
            }
            FieldInsnNode fx = (FieldInsnNode)doublePuts.get(0);
            FieldInsnNode fy = (FieldInsnNode)doublePuts.get(1);
            FieldInsnNode fz = (FieldInsnNode)doublePuts.get(2);
            MinecraftMapper.putField("C03PacketPlayer.x", c03.getDeclaredField(fx.name));
            MinecraftMapper.putField("C03PacketPlayer.y", c03.getDeclaredField(fy.name));
            MinecraftMapper.putField("C03PacketPlayer.z", c03.getDeclaredField(fz.name));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void findEntityRenderer() {
        for (Class<?> clazz : MinecraftMapper.getClasses()) {
            int ifjMethodCount = 0;
            Method targetMethod = null;
            for (Method method : clazz.getDeclaredMethods()) {
                Class<?>[] params = method.getParameterTypes();
                if (params.length != 3 || params[0] != Integer.TYPE || params[1] != Float.TYPE || params[2] != Long.TYPE || method.getReturnType() != Void.TYPE) continue;
                ++ifjMethodCount;
                targetMethod = method;
            }
            if (ifjMethodCount != true) continue;
            MinecraftMapper.put("EntityRenderer", clazz);
            MinecraftMapper.putMethod("EntityRenderer.renderWorldPass", targetMethod);
            return;
        }
    }

    public static Field findInventoryContainer(byte[] classBytes) throws Exception {
        if (classBytes != null && classBytes.length != 0 && MinecraftMapper.get("Container") != null && MinecraftMapper.get("EntityPlayer") != null) {
            ClassReader cr = new ClassReader(classBytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            Class<?> containerClass = MinecraftMapper.get("Container");
            String containerDesc = org.objectweb.asm.Type.getDescriptor(containerClass);
            for (MethodNode m : cn.methods) {
                if (!m.name.equals("<init>")) continue;
                InsnList insns = m.instructions;
                for (int i = 0; i < insns.size(); ++i) {
                    AbstractInsnNode insn = insns.get(i);
                    if (insn.getOpcode() != 181) continue;
                    FieldInsnNode f = (FieldInsnNode)insn;
                    if (!f.desc.equals(containerDesc)) continue;
                    return MinecraftMapper.asmFieldToReflectionField(MinecraftMapper.get("EntityPlayer"), f.name, f.desc);
                }
            }
            return null;
        }
        MinecraftMapper.warnMappingSkip("findInventoryContainer", "EntityPlayer bytes or Container mapping is missing");
        return null;
    }

    public static Class<?> findContainerClassFromEntityPlayer(Class<?> entityPlayerClass) {
        if (entityPlayerClass == null) {
            MinecraftMapper.warnMappingSkip("findContainerClassFromEntityPlayer", "EntityPlayer is not mapped");
            return null;
        }
        Field[] fields = entityPlayerClass.getDeclaredFields();
        HashMap<Class, List> typeToFields = new HashMap<Class, List>();
        for (Field field : fields) {
            Class<?> fieldType = field.getType();
            if (fieldType.getName().contains("java.") || fieldType.getName().contains("javax.") || fieldType.isPrimitive()) continue;
            typeToFields.computeIfAbsent(fieldType, k -> new ArrayList()).add(field);
        }
        for (Map.Entry entry : typeToFields.entrySet()) {
            List fieldList = (List)entry.getValue();
            if (fieldList.size() != 2) continue;
            return (Class)entry.getKey();
        }
        return null;
    }

    private static Field getFieldOfType(Class<?> clazz, Class<?> type) {
        if (clazz != null && type != null) {
            for (Field f : clazz.getDeclaredFields()) {
                if (f.getType() != type) continue;
                return f;
            }
            return null;
        }
        return null;
    }

    private static Class<?> getProtectedMethodSingleParam(Class<?> clazz) {
        if (clazz == null) {
            return null;
        }
        for (Method m : clazz.getDeclaredMethods()) {
            if (!Modifier.isProtected(m.getModifiers()) || m.getParameterCount() != 1) continue;
            return m.getParameterTypes()[0];
        }
        return null;
    }

    private static Field getListFieldOfType(Class<?> clazz, Class<?> type) {
        if (clazz != null && type != null) {
            for (Field f : clazz.getDeclaredFields()) {
                ParameterizedType pt;
                Type[] args;
                Type genType;
                if (!List.class.isAssignableFrom(f.getType()) || !((genType = f.getGenericType()) instanceof ParameterizedType) || (args = (pt = (ParameterizedType)genType).getActualTypeArguments()).length != 1 || !(args[0] instanceof Class) || args[0] != type) continue;
                f.setAccessible(true);
                return f;
            }
            return null;
        }
        return null;
    }

    private static Method findGetStackMethod(Class<?> slotClass) {
        if (slotClass == null) {
            return null;
        }
        for (Method m : slotClass.getDeclaredMethods()) {
            Class<?> returnType;
            if (m.getParameterCount() != 0 || (returnType = m.getReturnType()).isPrimitive() || returnType == String.class) continue;
            m.setAccessible(true);
            return m;
        }
        return null;
    }

    public static Method findGetSlot() {
        try {
            Class<?> containerClass = MinecraftMapper.get("Container");
            Class<?> slotClass = MinecraftMapper.get("Slot");
            if (containerClass == null || slotClass == null) {
                MinecraftMapper.warnMappingSkip("findGetSlot", "Container or Slot is not mapped");
                return null;
            }
            for (Method method : containerClass.getMethods()) {
                Class<?>[] params = method.getParameterTypes();
                if (params.length != 1 || params[0] != Integer.TYPE || method.getReturnType() != slotClass || !Modifier.isPublic(method.getModifiers())) continue;
                return method;
            }
        }
        catch (Exception e) {
            MinecraftMapper.warnMappingSkip("findGetSlot", e.getMessage());
        }
        return null;
    }

    public static void findTextureManagerClass() {
        for (Class<?> clazz : MinecraftMapper.getClasses()) {
            boolean bl;
            if (clazz.isInterface() || clazz.getInterfaces().length < 2 || clazz.getSuperclass() != Object.class) continue;
            Field[] fields = clazz.getDeclaredFields();
            boolean hasLogger = false;
            int finalPrivateMapCount = 0;
            boolean hasFinalPrivateList = false;
            for (Field field : fields) {
                int mods = field.getModifiers();
                Class<?> type = field.getType();
                if (Modifier.isPrivate(mods) && Modifier.isStatic(mods) && Modifier.isFinal(mods) && type.getName().equals("org.apache.logging.log4j.Logger")) {
                    hasLogger = true;
                }
                if (Modifier.isPrivate(mods) && Modifier.isFinal(mods) && Map.class.isAssignableFrom(type)) {
                    ++finalPrivateMapCount;
                }
                if (!Modifier.isPrivate(mods) || !Modifier.isFinal(mods) || !List.class.isAssignableFrom(type)) continue;
                hasFinalPrivateList = true;
            }
            if (!hasLogger || finalPrivateMapCount < 2 || !hasFinalPrivateList) continue;
            Method[] methods = clazz.getDeclaredMethods();
            int publicVoidCount = 0;
            boolean hasPublicBooleanMethod = false;
            for (Method m : methods) {
                if (!Modifier.isPublic(m.getModifiers())) continue;
                if (m.getReturnType() == Void.TYPE) {
                    ++publicVoidCount;
                }
                if (m.getReturnType() != Boolean.TYPE) continue;
                hasPublicBooleanMethod = true;
            }
            if (publicVoidCount < 4 || !hasPublicBooleanMethod) continue;
            boolean bl2 = false;
            for (Constructor<?> c : clazz.getDeclaredConstructors()) {
                Class<?> paramType;
                if (c.getParameterCount() != 1 || (paramType = c.getParameterTypes()[0]).isPrimitive()) continue;
                bl = true;
                break;
            }
            if (!bl) continue;
            MinecraftMapper.put("TextureManager", clazz);
            break;
        }
    }

    public static void findSwingMethod(byte[] classBytes) throws IOException {
        Class<?> packetClass = MinecraftMapper.get("C0APacketAnimation");
        if (packetClass != null && !MinecraftMapper.missingClassBytes("findSwingMethod", classBytes)) {
            String targetInternalName = org.objectweb.asm.Type.getInternalName(packetClass);
            ClassReader reader = new ClassReader(classBytes);
            ClassNode classNode = new ClassNode();
            reader.accept((ClassVisitor)classNode, 0);
            for (MethodNode method : classNode.methods) {
                for (AbstractInsnNode insn : method.instructions) {
                    if (insn.getOpcode() != 187 || !(insn instanceof TypeInsnNode)) continue;
                    TypeInsnNode typeInsn = (TypeInsnNode)insn;
                    if (!typeInsn.desc.equals(targetInternalName)) continue;
                    Method methodObj = MinecraftMapper.asmMethodToReflectionMethod(MinecraftMapper.get("EntityPlayerSP"), method.name, method.desc);
                    MinecraftMapper.putMethod("EntityPlayerSP.swingItem", methodObj);
                    return;
                }
            }
        }
    }

    public static Field analyzeNetworkPlayerInfoField(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            int mod = field.getModifiers();
            Object instance = MinecraftMapper.getThePlayer();
            if (!Modifier.isPrivate(mod) || Modifier.isStatic(mod) || Modifier.isFinal(mod) || field.getType().isPrimitive() || field.getType() == String.class) continue;
            try {
                field.setAccessible(true);
                Object value = field.get(instance);
                if (value == null) continue;
                return field;
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public static void mapNetworkPlayerInfoAndPacketClasses() {
        try {
            Class<?> clazz = MinecraftMapper.get("NetworkPlayerInfo");
            if (clazz == null) {
                return;
            }
            Constructor<?>[] constructors = clazz.getDeclaredConstructors();
            if (constructors.length != 2) {
                return;
            }
            Class<?> gameProfileClass = MinecraftMapper.get("GameProfile");
            Constructor<?> targetConstructor = null;
            for (Constructor<?> c : constructors) {
                Class<?>[] params = c.getParameterTypes();
                if (params.length != 1 || params[0].equals(gameProfileClass)) continue;
                targetConstructor = c;
                break;
            }
            if (targetConstructor == null) {
                return;
            }
            Class<?> addPlayerDataClass = targetConstructor.getParameterTypes()[0];
            MinecraftMapper.put("S38PacketPlayerListItemAddPlayerData", addPlayerDataClass);
            MinecraftMapper.put("S38PacketPlayerListItem", targetConstructor.getDeclaringClass());
            Field responseTimeField = null;
            for (Field f : clazz.getDeclaredFields()) {
                if (!Modifier.isPrivate(f.getModifiers()) || f.getType() != Integer.TYPE) continue;
                f.setAccessible(true);
                Object defaultValue = null;
                try {
                    defaultValue = f.get(clazz);
                }
                catch (Exception exception) {
                    // empty catch block
                }
                if (defaultValue != null && defaultValue instanceof Integer) continue;
                responseTimeField = f;
                break;
            }
            if (responseTimeField != null) {
                MinecraftMapper.putField("NetworkPlayerInfo.responseTime", responseTimeField);
                Method getter = null;
                byte[] bytes = MinecraftMapper.getClassBytes(clazz);
                if (MinecraftMapper.missingClassBytes("mapNetworkPlayerInfoAndPacketClasses", clazz, bytes)) {
                    return;
                }
                ClassReader cr = new ClassReader(bytes);
                ClassNode cn = new ClassNode();
                cr.accept((ClassVisitor)cn, 0);
                for (MethodNode mn : cn.methods) {
                    if (mn.desc.equals("()I")) {
                        InsnList insns = mn.instructions;
                        if (insns == null) continue;
                        for (AbstractInsnNode insn : insns) {
                            if (insn.getOpcode() != 180) continue;
                            FieldInsnNode fin = (FieldInsnNode)insn;
                            if (!fin.name.equals(responseTimeField.getName()) || !fin.desc.equals("I")) continue;
                            getter = clazz.getDeclaredMethod(mn.name, new Class[0]);
                            getter.setAccessible(true);
                            break;
                        }
                    }
                    if (getter == null) continue;
                }
                if (getter != null) {
                    MinecraftMapper.putMethod("NetworkPlayerInfo.getResponseTime", getter);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isTargetTextureClass(Class<?> clazz) {
        if (!Modifier.isAbstract(clazz.getModifiers())) {
            return false;
        }
        if (clazz.getInterfaces().length == 0) {
            return false;
        }
        int booleanFieldCount = 0;
        boolean hasMinusOneIntField = false;
        for (Field f : clazz.getDeclaredFields()) {
            if (f.getType() == Boolean.TYPE) {
                ++booleanFieldCount;
            }
            if (f.getType() != Integer.TYPE) continue;
            f.setAccessible(true);
            try {
                if (Modifier.isStatic(f.getModifiers())) {
                    Object v = f.get(null);
                    if (!(v instanceof Integer) || (Integer)v != -1) continue;
                    hasMinusOneIntField = true;
                    continue;
                }
                hasMinusOneIntField = true;
            }
            catch (Throwable v) {
                // empty catch block
            }
        }
        if (booleanFieldCount < 4) {
            return false;
        }
        if (!hasMinusOneIntField) {
            return false;
        }
        int boolBoolVoidMethods = 0;
        for (Method m : clazz.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (p.length != 2 || p[0] != Boolean.TYPE || p[1] != Boolean.TYPE || m.getReturnType() != Void.TYPE) continue;
            ++boolBoolVoidMethods;
        }
        return boolBoolVoidMethods >= 2;
    }

    public static Method findGetGlTextureId(Class<?> clazz) {
        try {
            byte[] bytes = MinecraftMapper.getClassBytes(clazz);
            if (MinecraftMapper.missingClassBytes("findGetGlTextureId", clazz, bytes)) {
                return null;
            }
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            for (MethodNode mn : cn.methods) {
                if (!mn.desc.equals("()I")) continue;
                boolean hasMinusOneCheck = false;
                boolean hasStaticIntCall = false;
                boolean hasPutField = false;
                String intFieldName = null;
                for (AbstractInsnNode insn : mn.instructions) {
                    FieldInsnNode fin;
                    if (insn.getOpcode() == 180) {
                        fin = (FieldInsnNode)insn;
                        if (fin.desc.equals("I")) {
                            intFieldName = fin.name;
                        }
                    }
                    if (insn.getOpcode() == 2) {
                        hasMinusOneCheck = true;
                    }
                    if (insn.getOpcode() == 184) {
                        MethodInsnNode min = (MethodInsnNode)insn;
                        if (min.desc.equals("()I")) {
                            hasStaticIntCall = true;
                        }
                    }
                    if (insn.getOpcode() != 181) continue;
                    fin = (FieldInsnNode)insn;
                    if (!fin.desc.equals("I") || !fin.name.equals(intFieldName)) continue;
                    hasPutField = true;
                }
                if (!hasMinusOneCheck || !hasStaticIntCall || !hasPutField) continue;
                Method m = clazz.getDeclaredMethod(mn.name, new Class[0]);
                m.setAccessible(true);
                return m;
            }
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
        return null;
    }

    public static void findHeldItemChangePacketReflection() {
        List<Class<?>> classes = MinecraftMapper.getClasses();
        Class<?> targetInterface = MinecraftMapper.get("INetHandlerPlayServer");
        if (targetInterface == null) {
            System.out.println("INetHandlerPlayServer interface'i bulunamad\u00c3\u201e\u00c2\u00b1");
        } else {
            for (Class<?> clazz : classes) {
                if (!targetInterface.isAssignableFrom(clazz)) continue;
                Field publicIntField = null;
                for (Field field : clazz.getDeclaredFields()) {
                    if (!Modifier.isPublic(field.getModifiers()) || field.getType() != Integer.TYPE) continue;
                    publicIntField = field;
                    break;
                }
                if (publicIntField == null) continue;
                boolean hasDefaultConstructor = false;
                boolean hasIntConstructor = false;
                for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                    Class<?>[] params = constructor.getParameterTypes();
                    if (params.length == 0) {
                        hasDefaultConstructor = true;
                        continue;
                    }
                    if (params.length != 1 || params[0] != Integer.TYPE) continue;
                    hasIntConstructor = true;
                    try {
                        Object instance = constructor.newInstance(123);
                        int value = publicIntField.getInt(instance);
                        if (value == 123) continue;
                        hasIntConstructor = false;
                    }
                    catch (Exception var14) {
                        hasIntConstructor = false;
                    }
                }
                if (!hasDefaultConstructor || !hasIntConstructor) continue;
                MinecraftMapper.put("C09PacketHeldItemChange", clazz);
                break;
            }
        }
    }

    public static void finds0cpacket() {
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> handlerClass = MinecraftMapper.get("INetHandlerPlayClient");
        Class<?> entityPlayerClass = MinecraftMapper.get("EntityPlayer");
        if (packetIfc != null && handlerClass != null && entityPlayerClass != null) {
            for (Class<?> cls : MinecraftMapper.getClasses()) {
                Constructor<?>[] ctors;
                Type[] args22;
                ParameterizedType pt;
                Object raw;
                if (cls.isInterface() || cls.isEnum() || cls.isAnonymousClass() || cls.isMemberClass() || cls.isLocalClass()) continue;
                boolean matchesGeneric = false;
                Type superType = cls.getGenericSuperclass();
                if (superType instanceof ParameterizedType && (raw = (pt = (ParameterizedType)superType).getRawType()) instanceof Class && raw.equals(packetIfc) && (args22 = pt.getActualTypeArguments()).length > 0 && args22[0] instanceof Class && args22[0].equals(handlerClass)) {
                    matchesGeneric = true;
                }
                Type[] interfaces = cls.getGenericInterfaces();
                raw = interfaces;
                int args22 = ((Type[])raw).length;
                for (int i = 0; i < args22; ++i) {
                    Type[] args;
                    ParameterizedType pt2;
                    Type raw2;
                    Object iface = raw[i];
                    if (!(iface instanceof ParameterizedType) || !((raw2 = (pt2 = (ParameterizedType)iface).getRawType()) instanceof Class) || !raw2.equals(packetIfc) || (args = pt2.getActualTypeArguments()).length <= 0 || !(args[0] instanceof Class) || !args[0].equals(handlerClass)) continue;
                    matchesGeneric = true;
                    break;
                }
                if (!matchesGeneric) continue;
                boolean hasNoArg = false;
                boolean hasEntityPlayerCtor = false;
                for (Constructor<?> ctor : ctors = cls.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArg = true;
                    }
                    if (params.length != 1 || !params[0].equals(entityPlayerClass)) continue;
                    hasEntityPlayerCtor = true;
                }
                if (!hasNoArg || !hasEntityPlayerCtor) continue;
                MinecraftMapper.put("S0CPacketSpawnPlayer", cls);
                return;
            }
        }
    }

    public static void findS39PlayerCapabilities() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayClient");
        Class<?> floatContainer = MinecraftMapper.get("FloatContainer");
        if (packetIfc != null && iNetHandlerPlayServer != null && floatContainer != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Constructor<?>[] paramType2;
                Type[] genericInterfaces;
                if (candidate.isAnonymousClass() || candidate.isMemberClass() || candidate.isLocalClass() || candidate.isSynthetic() || candidate.getName().contains("$") || candidate.getDeclaredAnnotations().length > 0 || candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (Constructor<?>[])genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasSingleParamConstructor = false;
                Class<?> singleParamType = null;
                int constructorCount = 0;
                paramType2 = candidate.getDeclaredConstructors();
                int rawType2 = paramType2.length;
                for (int typeArgs2 = 0; typeArgs2 < rawType2; ++typeArgs2) {
                    Constructor<?> ctor = paramType2[typeArgs2];
                    ++constructorCount;
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 1) continue;
                    hasSingleParamConstructor = true;
                    singleParamType = params[0];
                }
                if (constructorCount != 2 || !hasNoArgConstructor || !hasSingleParamConstructor) continue;
                int floatContainerFieldCount = 0;
                int floatFieldCount = 0;
                int booleanFieldCount = 0;
                for (Field field : candidate.getDeclaredFields()) {
                    Class<?> fieldType = field.getType();
                    if (fieldType == floatContainer) {
                        ++floatContainerFieldCount;
                        continue;
                    }
                    if (fieldType == Float.TYPE) {
                        ++floatFieldCount;
                        continue;
                    }
                    if (fieldType != Boolean.TYPE) continue;
                    ++booleanFieldCount;
                }
                if (floatContainerFieldCount < 2) continue;
                MinecraftMapper.put("S39PacketPlayerAbilities", candidate);
                return;
            }
        }
    }

    public static void mapC13PacketPlayerAbilitiesFields() {
        try {
            Class<?> c13Class = MinecraftMapper.get("C13PacketPlayerAbilities");
            if (c13Class == null) {
                System.out.println("C13PacketPlayerAbilities bulunamad\u00c3\u201e\u00c2\u00b1.");
                return;
            }
            LinkedHashMap<Integer, String> methodOrder = new LinkedHashMap<Integer, String>();
            methodOrder.put(0, "setInvulnerable");
            methodOrder.put(1, "setFlying");
            methodOrder.put(2, "setAllowFlying");
            methodOrder.put(3, "setCreativeMode");
            methodOrder.put(4, "setFlySpeed");
            methodOrder.put(5, "setWalkSpeed");
            byte[] bytes = MinecraftMapper.getClassBytes(c13Class);
            if (MinecraftMapper.missingClassBytes("mapC13PacketPlayerAbilitiesFields", c13Class, bytes)) {
                return;
            }
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            MethodNode capabilitiesCtor = null;
            for (MethodNode mn : cn.methods) {
                if (!mn.name.equals("<init>") || !mn.desc.contains("L" + MinecraftMapper.get("PlayerCapabilities").getName().replace('.', '/') + ";")) continue;
                capabilitiesCtor = mn;
                break;
            }
            if (capabilitiesCtor == null) {
                System.out.println("PlayerCapabilities constructor bulunamad\u00c3\u201e\u00c2\u00b1.");
                return;
            }
            ArrayList<FieldInsnNode> fieldPuts = new ArrayList<FieldInsnNode>();
            ArrayList<MethodInsnNode> methodCalls = new ArrayList<MethodInsnNode>();
            for (AbstractInsnNode insn : capabilitiesCtor.instructions) {
                if (insn.getOpcode() == 181) {
                    FieldInsnNode fin = (FieldInsnNode)insn;
                    if (!fin.owner.equals(cn.name)) continue;
                    fieldPuts.add(fin);
                    continue;
                }
                if (insn.getType() != 5) continue;
                MethodInsnNode min = (MethodInsnNode)insn;
                if (!min.owner.equals(cn.name) || min.getOpcode() != 182) continue;
                methodCalls.add(min);
            }
            if (!fieldPuts.isEmpty()) {
                try {
                    Field field = c13Class.getDeclaredField(((FieldInsnNode)fieldPuts.get((int)0)).name);
                    field.setAccessible(true);
                    MinecraftMapper.putField("C13PacketPlayerAbilities.flySpeed", field);
                    System.out.println("Mapped field: " + ((FieldInsnNode)fieldPuts.get((int)0)).name + " -> flySpeed");
                }
                catch (NoSuchFieldException var16) {
                    System.out.println("Field bulunamad\u00c3\u201e\u00c2\u00b1: " + ((FieldInsnNode)fieldPuts.get((int)0)).name);
                }
            }
            if (methodCalls.size() >= 6) {
                String[] methodNames = new String[methodCalls.size()];
                for (int i = 0; i < methodCalls.size(); ++i) {
                    methodNames[i] = ((MethodInsnNode)methodCalls.get((int)i)).name;
                }
                try {
                    Method method1 = c13Class.getDeclaredMethod(methodNames[0], Boolean.TYPE);
                    MinecraftMapper.putMethod("C13PacketPlayerAbilities.setInvulnerable", method1);
                    System.out.println("Mapped method 0: " + methodNames[0] + " -> setInvulnerable");
                    Method method2 = c13Class.getDeclaredMethod(methodNames[1], Boolean.TYPE);
                    MinecraftMapper.putMethod("C13PacketPlayerAbilities.setFlying", method2);
                    System.out.println("Mapped method 1: " + methodNames[1] + " -> setFlying");
                    Method method3 = c13Class.getDeclaredMethod(methodNames[2], Boolean.TYPE);
                    MinecraftMapper.putMethod("C13PacketPlayerAbilities.setAllowFlying", method3);
                    System.out.println("Mapped method 2: " + methodNames[2] + " -> setAllowFlying");
                    Method method4 = c13Class.getDeclaredMethod(methodNames[3], Boolean.TYPE);
                    MinecraftMapper.putMethod("C13PacketPlayerAbilities.setCreativeMode", method4);
                    System.out.println("Mapped method 3: " + methodNames[3] + " -> setCreativeMode");
                    Method method5 = c13Class.getDeclaredMethod(methodNames[4], Float.TYPE);
                    MinecraftMapper.putMethod("C13PacketPlayerAbilities.setFlySpeed", method5);
                    System.out.println("Mapped method 4: " + methodNames[4] + " -> setFlySpeed");
                    Method method6 = c13Class.getDeclaredMethod(methodNames[5], Float.TYPE);
                    MinecraftMapper.putMethod("C13PacketPlayerAbilities.setWalkSpeed", method6);
                    System.out.println("Mapped method 5: " + methodNames[5] + " -> setWalkSpeed");
                }
                catch (NoSuchMethodException e) {
                    System.out.println("Method bulunamad\u00c3\u201e\u00c2\u00b1: " + e.getMessage());
                    e.printStackTrace();
                }
            } else {
                System.out.println("Yeterli method call bulunamad\u00c3\u201e\u00c2\u00b1: " + methodCalls.size());
                System.out.println("\nBulunan methodlar:");
                for (int i = 0; i < methodCalls.size(); ++i) {
                    System.out.println(i + ": " + ((MethodInsnNode)methodCalls.get((int)i)).name + " - " + ((MethodInsnNode)methodCalls.get((int)i)).desc);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void mapPlayerCapabilitiesFields() {
        try {
            Class<?> capClass = MinecraftMapper.get("PlayerCapabilities");
            if (capClass == null) {
                System.out.println("PlayerCapabilities bulunamad\u00c3\u201e\u00c2\u00b1.");
                return;
            }
            byte[] bytes = MinecraftMapper.getClassBytes(capClass);
            if (MinecraftMapper.missingClassBytes("mapPlayerCapabilitiesFields", capClass, bytes)) {
                return;
            }
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            MethodNode ctor = null;
            for (MethodNode mn : cn.methods) {
                if (!mn.name.equals("<init>")) continue;
                ctor = mn;
                break;
            }
            if (ctor == null) {
                return;
            }
            ArrayList<FieldInsnNode> puts = new ArrayList<FieldInsnNode>();
            for (AbstractInsnNode insn : ctor.instructions) {
                if (insn.getOpcode() != 181) continue;
                FieldInsnNode fin = (FieldInsnNode)insn;
                if (!fin.owner.equals(cn.name)) continue;
                puts.add(fin);
            }
            if (puts.size() < 7) {
                System.out.println("Beklenen 7 PUTFIELD yok. Bulunan: " + puts.size());
                return;
            }
            FieldInsnNode f_disableDamage = (FieldInsnNode)puts.get(0);
            FieldInsnNode f_isFlying = (FieldInsnNode)puts.get(1);
            FieldInsnNode f_allowFlying = (FieldInsnNode)puts.get(2);
            FieldInsnNode f_isCreativeMode = (FieldInsnNode)puts.get(3);
            FieldInsnNode f_allowEdit = (FieldInsnNode)puts.get(4);
            FieldInsnNode f_flySpeed = (FieldInsnNode)puts.get(5);
            FieldInsnNode f_walkSpeed = (FieldInsnNode)puts.get(6);
            MinecraftMapper.putField("PlayerCapabilities.disableDamage", capClass.getDeclaredField(f_disableDamage.name));
            MinecraftMapper.putField("PlayerCapabilities.isFlying", capClass.getDeclaredField(f_isFlying.name));
            MinecraftMapper.putField("PlayerCapabilities.allowFlying", capClass.getDeclaredField(f_allowFlying.name));
            MinecraftMapper.putField("PlayerCapabilities.isCreativeMode", capClass.getDeclaredField(f_isCreativeMode.name));
            MinecraftMapper.putField("PlayerCapabilities.allowEdit", capClass.getDeclaredField(f_allowEdit.name));
            MinecraftMapper.putField("PlayerCapabilities.flySpeed", capClass.getDeclaredField(f_flySpeed.name));
            MinecraftMapper.putField("PlayerCapabilities.walkSpeed", capClass.getDeclaredField(f_walkSpeed.name));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void findC13PacketPlayerAbilities() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
        Class<?> floatContainer = MinecraftMapper.get("FloatContainer");
        if (packetIfc != null && iNetHandlerPlayServer != null && floatContainer != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Constructor<?>[] paramType2;
                Type[] genericInterfaces;
                if (candidate.isAnonymousClass() || candidate.isMemberClass() || candidate.isLocalClass() || candidate.isSynthetic() || candidate.getName().contains("$") || candidate.getDeclaredAnnotations().length > 0 || candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (Constructor<?>[])genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasSingleParamConstructor = false;
                Class<?> singleParamType = null;
                int constructorCount = 0;
                paramType2 = candidate.getDeclaredConstructors();
                int rawType2 = paramType2.length;
                for (int typeArgs2 = 0; typeArgs2 < rawType2; ++typeArgs2) {
                    Constructor<?> ctor = paramType2[typeArgs2];
                    ++constructorCount;
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 1) continue;
                    hasSingleParamConstructor = true;
                    singleParamType = params[0];
                }
                if (constructorCount != 2 || !hasNoArgConstructor || !hasSingleParamConstructor) continue;
                int floatContainerFieldCount = 0;
                int floatFieldCount = 0;
                int booleanFieldCount = 0;
                for (Field field : candidate.getDeclaredFields()) {
                    Class<?> fieldType = field.getType();
                    if (fieldType == floatContainer) {
                        ++floatContainerFieldCount;
                        continue;
                    }
                    if (fieldType == Float.TYPE) {
                        ++floatFieldCount;
                        continue;
                    }
                    if (fieldType != Boolean.TYPE) continue;
                    ++booleanFieldCount;
                }
                if (floatContainerFieldCount < 2) continue;
                MinecraftMapper.put("C13PacketPlayerAbilities", candidate);
                if (singleParamType != null) {
                    MinecraftMapper.put("PlayerCapabilities", singleParamType);
                }
                return;
            }
        }
    }

    public static void findGetChunkFromChunkCoords() {
        Class<?> worldClass = MinecraftMapper.get("World");
        if (worldClass != null) {
            for (Method method : worldClass.getDeclaredMethods()) {
                Class<?>[] params;
                int mods = method.getModifiers();
                if (!Modifier.isPublic(mods) || Modifier.isStatic(mods) || (params = method.getParameterTypes()).length != 2 || params[0] != Integer.TYPE || params[1] != Integer.TYPE || method.getReturnType().isPrimitive()) continue;
                MinecraftMapper.put("Chunk", method.getReturnType());
                MinecraftMapper.putMethod("World.getChunkFromChunkCoords", method);
                MinecraftMapper.findBlockInChunk(method.getReturnType());
                try {
                    Class<?> chunkClass = method.getReturnType();
                    byte[] classBytes = MinecraftMapper.getClassBytes(chunkClass);
                    if (classBytes == null) break;
                    ClassReader cr = new ClassReader(classBytes);
                    ClassNode cn = new ClassNode();
                    cr.accept((ClassVisitor)cn, 0);
                    for (MethodNode mn : cn.methods) {
                        if ((mn.access & 2) == 0 || !mn.desc.equals("(III)I")) continue;
                        boolean hasShiftRight = false;
                        boolean hasTryCatch = mn.tryCatchBlocks != null && !mn.tryCatchBlocks.isEmpty();
                        for (AbstractInsnNode insn : mn.instructions.toArray()) {
                            if (insn.getOpcode() != 122) continue;
                            hasShiftRight = true;
                            break;
                        }
                        if (!hasShiftRight || !hasTryCatch) continue;
                        try {
                            Method m = chunkClass.getDeclaredMethod(mn.name, Integer.TYPE, Integer.TYPE, Integer.TYPE);
                            m.setAccessible(true);
                            MinecraftMapper.putMethod("Chunk.getBlockMetadata", m);
                        }
                        catch (NoSuchMethodException eFont) {
                            eFont.printStackTrace();
                            continue;
                        }
                        return;
                    }
                }
                catch (Throwable t) {
                    t.printStackTrace();
                }
                break;
            }
        }
    }

    public static boolean isPacketBuffer(Class<?> clazz) {
        if (!ByteBuf.class.isAssignableFrom(clazz)) {
            return false;
        }
        boolean hasValidConstructor = false;
        for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
            Class<?>[] params = constructor.getParameterTypes();
            if (params.length != 1 || !ByteBuf.class.isAssignableFrom(params[0])) continue;
            hasValidConstructor = true;
            break;
        }
        if (!hasValidConstructor) {
            return false;
        }
        for (Executable executable : clazz.getDeclaredMethods()) {
            if (!Modifier.isPublic(((Method)executable).getModifiers()) || !Modifier.isStatic(((Method)executable).getModifiers()) || ((Method)executable).getReturnType() != Integer.TYPE) continue;
            MinecraftMapper.analyze(clazz);
            return true;
        }
        return false;
    }

    public static void analyze(Class<?> clazz) {
        Method writeFloatMethod = null;
        Method writeEnumValueMethod = null;
        Method writeVarIntMethod = null;
        for (Method method : clazz.getDeclaredMethods()) {
            method.setAccessible(true);
            if (method.getReturnType() == ByteBuf.class && method.getParameterCount() == 1 && method.getParameterTypes()[0] == Float.TYPE) {
                writeFloatMethod = method;
            }
            if (method.getParameterCount() == 1 && Enum.class.isAssignableFrom(method.getParameterTypes()[0])) {
                writeEnumValueMethod = method;
            }
            if (method.getReturnType() != Void.TYPE || method.getParameterCount() != 1 || method.getParameterTypes()[0] != Integer.TYPE) continue;
            writeVarIntMethod = method;
        }
        if (writeFloatMethod != null && writeEnumValueMethod != null && writeVarIntMethod != null) {
            MinecraftMapper.putMethod("PacketBuffer.writeFloat", writeFloatMethod);
            MinecraftMapper.putMethod("PacketBuffer.writeEnumValue", writeEnumValueMethod);
            MinecraftMapper.putMethod("PacketBuffer.writeVarIntToBuffer", writeVarIntMethod);
        }
    }

    public static void findC05PacketPlayerLook(List<Class<?>> classes) {
        Class<?> c03 = MinecraftMapper.get("C03PacketPlayer");
        if (c03 == null) {
            System.out.println("C03PacketPlayer bulunamad\u00c3\u201e\u00c2\u00b1.");
        } else {
            for (Class<?> clazz : classes) {
                if (clazz.getSuperclass() != c03) continue;
                int constructorMatchCount = 0;
                for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                    Class<?>[] params = constructor.getParameterTypes();
                    if (params.length == 0) {
                        ++constructorMatchCount;
                        continue;
                    }
                    if (params.length != 3 || params[0] != Float.TYPE || params[1] != Float.TYPE || params[2] != Boolean.TYPE) continue;
                    ++constructorMatchCount;
                }
                if (constructorMatchCount != 2) continue;
                MinecraftMapper.put("C05PacketPlayerLook", clazz);
                try {
                    MinecraftMapper.detectC05Fields(MinecraftMapper.getClassBytes(clazz), c03);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                return;
            }
            System.out.println("C05PacketPlayerLook bulunamad\u00c3\u201e\u00c2\u00b1.");
        }
    }

    public static void findC08PacketPlayerBlockPlacement() throws Exception {
        Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
        Class<?> blockPosClass = MinecraftMapper.get("BlockPos");
        if (itemStackClass != null && blockPosClass != null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                Constructor<?>[] constructors = clazz.getDeclaredConstructors();
                if (constructors.length != 3) continue;
                boolean hasNoParam = false;
                boolean hasOneParamItemStack = false;
                boolean hasSixParamMatching = false;
                for (Constructor<?> ctor : constructors) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoParam = true;
                        continue;
                    }
                    if (params.length == 1 && params[0].equals(itemStackClass)) {
                        hasOneParamItemStack = true;
                        continue;
                    }
                    if (params.length != 6 || !params[0].equals(blockPosClass) || params[1] != Integer.TYPE || !params[2].equals(itemStackClass) || params[3] != Float.TYPE || params[4] != Float.TYPE || params[5] != Float.TYPE) continue;
                    hasSixParamMatching = true;
                }
                if (!hasNoParam || !hasOneParamItemStack || !hasSixParamMatching) continue;
                MinecraftMapper.put("C08PacketPlayerBlockPlacement", clazz);
                break;
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    public static void startMappings() {
        block193: {
            Class<?> entityClass;
            block184: {
                for (Class<?> clazz : MinecraftMapper.getClasses()) {
                    if (!MinecraftMapper.containsMinecraftFields(clazz)) continue;
                    MinecraftMapper.put("Minecraft", clazz);
                    break;
                }
                for (Class<?> clazz : MinecraftMapper.getClasses()) {
                    if (!MinecraftMapper.isPacketBuffer(clazz)) continue;
                    MinecraftMapper.put("PacketBuffer", clazz);
                    break;
                }
                if (MinecraftMapper.get("Minecraft") != null) {
                    for (Field field : MinecraftMapper.get("Minecraft").getDeclaredFields()) {
                        if (field.getType() != MinecraftMapper.get("Minecraft") || !Modifier.isPublic(field.getModifiers()) || !Modifier.isStatic(field.getModifiers())) continue;
                        MinecraftMapper.putField("Minecraft.theMinecraft", field);
                        break;
                    }
                }
                if (MinecraftMapper.get("Minecraft") != null) {
                    for (Class clazz : MinecraftMapper.getClasses()) {
                        if (!MinecraftMapper.isEntityPlayerSP(clazz)) continue;
                        Class abstractClientPlayerClazz = clazz.getSuperclass();
                        Class clazz2 = abstractClientPlayerClazz.getSuperclass();
                        Class entityLivingBaseClazz = clazz2.getSuperclass();
                        Class clazz3 = entityLivingBaseClazz.getSuperclass();
                        MinecraftMapper.put("EntityPlayerSP", clazz);
                        for (Method m : clazz.getDeclaredMethods()) {
                            if (!Modifier.isProtected(m.getModifiers()) || m.getReturnType() != Boolean.TYPE || m.getParameterCount() != 0) continue;
                            m.setAccessible(true);
                            MinecraftMapper.putMethod("EntityPlayerSP.isCurrentViewEntity", m);
                            break;
                        }
                        MinecraftMapper.put("AbstractClientPlayer", abstractClientPlayerClazz);
                        MinecraftMapper.put("EntityPlayer", clazz2);
                        MinecraftMapper.put("EntityLivingBase", entityLivingBaseClazz);
                        MinecraftMapper.put("Entity", clazz3);
                        List candidateMethods = Arrays.stream(clazz.getDeclaredMethods()).filter(mx -> Modifier.isProtected(mx.getModifiers()) && mx.getReturnType() == Void.TYPE && mx.getParameterCount() == 1 && !mx.getParameterTypes()[0].isPrimitive()).collect(Collectors.toList());
                        if (candidateMethods.isEmpty()) break;
                        Method method = (Method)candidateMethods.get(0);
                        Class<?> entityItemClass = method.getParameterTypes()[0];
                        MinecraftMapper.put("EntityItem", entityItemClass);
                        MinecraftMapper.putMethod("EntityPlayerSP.joinEntityItemWithWorld", method);
                        if (candidateMethods.size() <= 1) break;
                        for (int i = 1; i < candidateMethods.size(); ++i) {
                            Executable[] executableArray = (Constructor<?>[])candidateMethods.get(i);
                        }
                    }
                }
                if (MinecraftMapper.get("Minecraft") != null && MinecraftMapper.get("EntityPlayerSP") != null) {
                    for (Method method : MinecraftMapper.get("Minecraft").getMethods()) {
                        if (!Modifier.isPublic(method.getModifiers()) || method.getReturnType() != MinecraftMapper.get("EntityPlayerSP") || method.getParameterCount() != 0) continue;
                        MinecraftMapper.putMethod("Minecraft.getThePlayer", method);
                        break;
                    }
                    for (Field field : MinecraftMapper.get("Minecraft").getDeclaredFields()) {
                        if (field.getType() != MinecraftMapper.get("EntityPlayerSP")) continue;
                        MinecraftMapper.putField("Minecraft.thePlayer", field);
                        break;
                    }
                }
                if ((entityClass = MinecraftMapper.get("Entity")) != null) {
                    void var3_23;
                    Method[] methodArray = entityClass.getMethods();
                    int abstractClientPlayerClazz = methodArray.length;
                    boolean bl = false;
                    while (var3_23 < abstractClientPlayerClazz) {
                        Class<?>[] classArray;
                        Method method = methodArray[var3_23];
                        if (method.getReturnType() == Void.TYPE && (classArray = method.getParameterTypes()).length == 5 && classArray[0] == Double.TYPE && classArray[1] == Double.TYPE && classArray[2] == Double.TYPE && classArray[3] == Float.TYPE && classArray[4] == Float.TYPE) {
                            MinecraftMapper.putMethod("Entity.setPositionAndRotation", method);
                            break;
                        }
                        ++var3_23;
                    }
                } else {
                    MinecraftMapper.warnMappingSkip("Entity.setPositionAndRotation", "Entity is not mapped");
                }
                if (entityClass != null) {
                    Field[] fieldArray;
                    for (Field field : fieldArray = entityClass.getFields()) {
                        if (field.getType() != MinecraftMapper.get("World") || !Modifier.isPublic(field.getModifiers())) continue;
                        MinecraftMapper.putField("EntityPlayerSP.worldObj", field);
                    }
                }
                MinecraftMapper.putMethod("Entity.getDistanceToEntity", Arrays.stream(MinecraftMapper.getAllMethods(entityClass)).filter(methodx -> methodx.toString().contains("public float") && methodx.getParameterCount() == 1 && methodx.getParameterTypes()[0].equals(entityClass)).findFirst().orElse(null));
                MinecraftMapper.putField("EntityPlayerSP.sendQueue", MinecraftMapper.getFieldByType(MinecraftMapper.get("EntityPlayerSP"), MinecraftMapper.get("NetHandlerPlayClient")));
                MinecraftMapper.putField("World.playerEntities", MinecraftMapper.findListUsingParam(MinecraftMapper.get("World"), MinecraftMapper.get("EntityPlayer")));
                MinecraftMapper.put("C02PacketUseEntityAction", MinecraftMapper.findClassUsingFieldNames("ATTACK", "INTERACT_AT"));
                Class<?> clazz = MinecraftMapper.get("C02PacketUseEntityAction");
                if (clazz != null) {
                    MinecraftMapper.put("C02PacketUseEntity", MinecraftMapper.findClassByName(MinecraftMapper.getOuterClassName(clazz.getName())));
                } else {
                    MinecraftMapper.warnMappingSkip("C02PacketUseEntity", "C02PacketUseEntityAction is not mapped");
                }
                Class<?> c02PacketUseEntity = MinecraftMapper.get("C02PacketUseEntity");
                if (c02PacketUseEntity != null) {
                    Class<?>[] classArray = c02PacketUseEntity.getInterfaces();
                    Class<?> firstInterface = classArray.length > 0 ? classArray[0] : null;
                    MinecraftMapper.put("Packet", firstInterface);
                } else {
                    MinecraftMapper.warnMappingSkip("Packet", "C02PacketUseEntity is not mapped");
                }
                MinecraftMapper.putMethod("NetHandlerPlayClient.sendPacket", MinecraftMapper.findSpecificMethod(MinecraftMapper.get("NetHandlerPlayClient"), MinecraftMapper.get("Packet")));
                Class<?> clazz4 = MinecraftMapper.get("NetHandlerPlayClient");
                if (clazz4 != null) {
                    Constructor<?>[] constructors;
                    for (Constructor<?> ctor : constructors = clazz4.getDeclaredConstructors()) {
                        if (ctor.getParameterCount() != 4) continue;
                        Class<?> thirdParamType = ctor.getParameterTypes()[2];
                        MinecraftMapper.put("NetworkManager", thirdParamType);
                        MinecraftMapper.putField("NetHandlerPlayClient.networkManager", MinecraftMapper.getFieldByType(clazz4, MinecraftMapper.get("NetworkManager")));
                        MinecraftMapper.putField("NetworkManager.channel", MinecraftMapper.getFieldByType(MinecraftMapper.get("NetworkManager"), Channel.class));
                        for (Constructor<?> constructor : thirdParamType.getDeclaredConstructors()) {
                            if (constructor.getParameterCount() != 1) continue;
                            Class<?> firstParamType = constructor.getParameterTypes()[0];
                            MinecraftMapper.put("EnumPacketDirection", firstParamType);
                            break block184;
                        }
                        break;
                    }
                } else {
                    MinecraftMapper.warnMappingSkip("NetworkManager", "NetHandlerPlayClient is not mapped");
                }
            }
            if (MinecraftMapper.get("Packet") != null) {
                MinecraftMapper.put("C0APacketAnimation", MinecraftMapper.findSwingPacket(MinecraftMapper.get("Packet")));
            }
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                if (!MinecraftMapper.isIChatComponent(clazz)) continue;
                MinecraftMapper.put("IChatComponent", clazz);
                break;
            }
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                if (!MinecraftMapper.isChatComponentStyle(clazz)) continue;
                MinecraftMapper.put("ChatComponentStyle", clazz);
                break;
            }
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                if (!MinecraftMapper.isChatComponentText(clazz)) continue;
                MinecraftMapper.put("ChatComponentText", clazz);
                break;
            }
            if (MinecraftMapper.get("EntityPlayerSP") != null && MinecraftMapper.get("IChatComponent") != null) {
                for (Method method : MinecraftMapper.get("EntityPlayerSP").getDeclaredMethods()) {
                    Class<?>[] params = method.getParameterTypes();
                    if (params.length != 1 || params[0] != MinecraftMapper.get("IChatComponent")) continue;
                    MinecraftMapper.putMethod("EntityPlayerSP.addChatMessage", method);
                    break;
                }
            }
            Class<?> velocityPacket = MinecraftMapper.findS12PacketVelocity();
            MinecraftMapper.put("S12PacketEntityVelocity", velocityPacket);
            if (velocityPacket != null) {
                MinecraftMapper.mapVelocityFields(velocityPacket);
                MinecraftMapper.mapVelocityMethods(velocityPacket);
                for (Method m : velocityPacket.getDeclaredMethods()) {
                    if (!Modifier.isPublic(m.getModifiers()) || m.getReturnType() != Integer.TYPE || m.getParameterCount() != 0) continue;
                    m.setAccessible(true);
                    MinecraftMapper.putMethod("S12PacketEntityVelocity.getEntityID", m);
                    break;
                }
                MinecraftMapper.findMotionFields(MinecraftMapper.getClassBytes(velocityPacket));
            } else {
                MinecraftMapper.warnMappingSkip("S12PacketEntityVelocity", "velocity packet class was not found");
            }
            try {
                Class<?> guiClass;
                Class<?> entityPlayerClass;
                block190: {
                    block187: {
                        block185: {
                            Method foundMethod;
                            MinecraftMapper.put("S0BPacketAnimation", MinecraftMapper.findS0BPacketAnimation());
                            try {
                                MinecraftMapper.findSwingMethod(MinecraftMapper.getClassBytes(MinecraftMapper.get("EntityPlayerSP")));
                            }
                            catch (Throwable throwable) {
                                Logger.warn("EntityPlayerSP.swingItem mapping skipped: " + throwable.getMessage());
                            }
                            Object object = MinecraftMapper.getThePlayer();
                            Class<?> entityClazz = MinecraftMapper.get("Entity");
                            if (object != null && entityClazz != null) {
                                Method[] methods = entityClazz.getMethods();
                                Executable matchedMethod = null;
                                int matchedCount = 0;
                                for (Executable executable : methods) {
                                    if (!Modifier.isPublic(((Method)executable).getModifiers()) || ((Method)executable).getParameterCount() != 0 || ((Method)executable).getReturnType() != Float.TYPE) continue;
                                    try {
                                        float val = ((Float)((Method)executable).invoke(object, new Object[0])).floatValue();
                                        if (val <= 0.0f || val < 1.0f || val >= 3.0f || val == 0.0f || val == 1.0f || val == 0.1f) continue;
                                        ++matchedCount;
                                        matchedMethod = executable;
                                    }
                                    catch (Exception val) {
                                        // empty catch block
                                    }
                                }
                                if (matchedCount == 1) {
                                    MinecraftMapper.putMethod("Entity.getEyeHeight", matchedMethod);
                                }
                            } else {
                                MinecraftMapper.warnMappingSkip("Entity.getEyeHeight", "player instance or Entity class is not available");
                            }
                            Class<?> c02PacketUseEntityForVec = MinecraftMapper.get("C02PacketUseEntity");
                            Class<?> c02PacketUseEntityActionForVec = MinecraftMapper.get("C02PacketUseEntityAction");
                            if (c02PacketUseEntityForVec != null && c02PacketUseEntityActionForVec != null) {
                                Constructor<?>[] c12 = c02PacketUseEntityForVec.getDeclaredConstructors();
                                for (Executable executable : c12) {
                                    Class<?> secondParam;
                                    Class<?>[] paramTypes = ((Constructor)executable).getParameterTypes();
                                    if (paramTypes.length != 2 || (secondParam = paramTypes[1]).equals(c02PacketUseEntityActionForVec)) continue;
                                    MinecraftMapper.put("Vec3", secondParam);
                                    break;
                                }
                            }
                            block53: for (Class<?> clazz : MinecraftMapper.getClasses()) {
                                ?[] enumConstants;
                                if (!clazz.isEnum() || (enumConstants = clazz.getEnumConstants()) == null || enumConstants.length == 0) continue;
                                boolean looksLikeEnumFacing = false;
                                for (Object obj : enumConstants) {
                                    try {
                                        Method nameMethod = obj.getClass().getMethod("name", new Class[0]);
                                        String name = (String)nameMethod.invoke(obj, new Object[0]);
                                        if (!name.equalsIgnoreCase("DOWN") && !name.equalsIgnoreCase("UP") && !name.equalsIgnoreCase("NORTH")) continue;
                                        looksLikeEnumFacing = true;
                                        break;
                                    }
                                    catch (Exception nameMethod) {
                                        // empty catch block
                                    }
                                }
                                if (!looksLikeEnumFacing) continue;
                                MinecraftMapper.put("EnumFacing", clazz);
                                for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                                    Class<?>[] params = constructor.getParameterTypes();
                                    if (params.length != 11 || params[0] != String.class || params[1] != Integer.TYPE || params[2] != String.class || params[3] != Integer.TYPE || params[4] != Integer.TYPE || params[5] != Integer.TYPE || params[6] != Integer.TYPE || params[7] != String.class) continue;
                                    MinecraftMapper.put("EnumAxisDirection", params[8]);
                                    MinecraftMapper.put("EnumAxis", params[9]);
                                    MinecraftMapper.put("Vec3i", params[10]);
                                    MinecraftMapper.put("EnumFacing", clazz);
                                    break block53;
                                }
                            }
                            block56: for (Class<?> clazz : MinecraftMapper.getClasses()) {
                                boolean bl;
                                Constructor<?>[] constructorsv;
                                if (clazz.isInterface() || clazz.isEnum() || (constructorsv = clazz.getDeclaredConstructors()).length != 5) continue;
                                Class<?> movingObjectTypeClass = MinecraftMapper.get("MovingObjectType");
                                Class<?> clazz5 = MinecraftMapper.get("Vec3");
                                Class<?> enumFacingClass = MinecraftMapper.get("EnumFacing");
                                Class<?> blockPosClass = MinecraftMapper.get("BlockPos");
                                boolean bl2 = false;
                                Class<?> discoveredMovingObjectType = null;
                                Class<?> discoveredBlockPos = null;
                                for (Constructor<?> ctor : constructorsv) {
                                    Class<?>[] params = ctor.getParameterTypes();
                                    if (params.length != 4) continue;
                                    if (clazz5 == null || enumFacingClass == null) break;
                                    if (!params[1].equals(clazz5) || !params[2].equals(enumFacingClass) || movingObjectTypeClass != null && params[0] != movingObjectTypeClass || movingObjectTypeClass == null && (!params[0].isEnum() || !MinecraftMapper.isGameRuntimeClass(params[0])) || blockPosClass != null && params[3] != blockPosClass || blockPosClass == null && !MinecraftMapper.isBlockPosCandidate(params[3])) continue;
                                    discoveredMovingObjectType = params[0];
                                    discoveredBlockPos = params[3];
                                    bl = true;
                                    break;
                                }
                                if (!bl) continue;
                                if (movingObjectTypeClass == null) {
                                    movingObjectTypeClass = discoveredMovingObjectType;
                                }
                                if (blockPosClass == null) {
                                    blockPosClass = discoveredBlockPos;
                                }
                                boolean hasPrivateBlockPosField = false;
                                for (Field f : clazz.getDeclaredFields()) {
                                    if (f.getType() != blockPosClass) continue;
                                    hasPrivateBlockPosField = true;
                                    break;
                                }
                                if (!hasPrivateBlockPosField) continue;
                                MinecraftMapper.put("MovingObjectType", movingObjectTypeClass);
                                MinecraftMapper.put("BlockPos", blockPosClass);
                                MinecraftMapper.put("MovingObjectPosition", clazz);
                                for (Field field : clazz.getDeclaredFields()) {
                                    if (!Modifier.isPublic(field.getModifiers()) || movingObjectTypeClass == null || field.getType() != movingObjectTypeClass) continue;
                                    MinecraftMapper.putField("MovingObjectPosition.typeOfHit", field);
                                    break block56;
                                }
                            }
                            Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
                            Class<?> movingObjectPositionClass = MinecraftMapper.get("MovingObjectPosition");
                            if (minecraftClass != null && movingObjectPositionClass != null) {
                                void var13_95;
                                Field[] constructorsv = minecraftClass.getDeclaredFields();
                                int movingObjectTypeClass = constructorsv.length;
                                boolean bl = false;
                                while (var13_95 < movingObjectTypeClass) {
                                    Field field = constructorsv[var13_95];
                                    if (field.getType() == movingObjectPositionClass) {
                                        MinecraftMapper.putField("Minecraft.objectMouseOver", field);
                                        break;
                                    }
                                    ++var13_95;
                                }
                            }
                            Class<?> entityClass2 = MinecraftMapper.get("Entity");
                            Class<?> vec3Class = MinecraftMapper.get("Vec3");
                            if (movingObjectPositionClass != null) {
                                for (Field field : movingObjectPositionClass.getDeclaredFields()) {
                                    if (field.getType() == entityClass2) {
                                        MinecraftMapper.putField("MovingObjectPosition.entityHit", field);
                                        continue;
                                    }
                                    if (field.getType() != vec3Class) continue;
                                    MinecraftMapper.putField("MovingObjectPosition.hitVec", field);
                                }
                            }
                            MinecraftMapper.flag();
                            Class<?> clazz = MinecraftMapper.findClassUsingFieldNames("START_DESTROY_BLOCK", "ABORT_DESTROY_BLOCK", "STOP_DESTROY_BLOCK");
                            MinecraftMapper.put("C07PacketPlayerDigging.Action", clazz);
                            if (clazz != null) {
                                Class<?> C07DiggingPacket = MinecraftMapper.findClassByName(MinecraftMapper.getOuterClassName(clazz.getName()));
                                MinecraftMapper.put("C07PacketPlayerDigging", C07DiggingPacket);
                            } else {
                                MinecraftMapper.warnMappingSkip("C07PacketPlayerDigging", "digging action enum was not found");
                            }
                            Class<?> entityPlayerSP = MinecraftMapper.get("EntityPlayerSP");
                            if (entityPlayerSP != null) {
                                for (Method method : entityPlayerSP.getDeclaredMethods()) {
                                    if (!Modifier.isPublic(method.getModifiers()) || method.getReturnType() != Void.TYPE || method.getParameterCount() != 1 || method.getParameterTypes()[0] != Boolean.TYPE) continue;
                                    MinecraftMapper.putMethod("EntityPlayerSP.setSprinting", method);
                                    break;
                                }
                            }
                            Class<?> iChatComponentClass = MinecraftMapper.get("IChatComponent");
                            Object var16_120 = null;
                            try {
                                Class<?> clazz6 = Class.forName("com.google.common.base.Splitter");
                            }
                            catch (ClassNotFoundException var51) {
                                MinecraftMapper.warnMappingSkip("GuiNewChat discovery", "Splitter class is not available");
                            }
                            Class<?> loggerClass = null;
                            try {
                                loggerClass = Class.forName("org.apache.logging.log4j.Logger");
                            }
                            catch (ClassNotFoundException var50) {
                                MinecraftMapper.warnMappingSkip("GuiNewChat discovery", "Log4j Logger class is not available");
                            }
                            Class<?> uriClass = null;
                            try {
                                uriClass = Class.forName("java.net.URI");
                            }
                            catch (ClassNotFoundException var49) {
                                MinecraftMapper.warnMappingSkip("GuiNewChat discovery", "URI class is not available");
                            }
                            for (Class<?> clazz7 : MinecraftMapper.getClasses()) {
                                void var27_195;
                                int hasProtectedBooleanMethodWithIChatComponent = 0;
                                for (Method m : clazz7.getDeclaredMethods()) {
                                    if (!Modifier.isProtected(m.getModifiers()) || m.getReturnType() != Boolean.TYPE || m.getParameterCount() != 1 || m.getParameterTypes()[0] != iChatComponentClass) continue;
                                    hasProtectedBooleanMethodWithIChatComponent = 1;
                                    break;
                                }
                                if (hasProtectedBooleanMethodWithIChatComponent == 0) continue;
                                boolean hasSplitterField = false;
                                for (Field f : clazz7.getDeclaredFields()) {
                                    void var16_122;
                                    if (f.getType() != var16_122) continue;
                                    hasSplitterField = true;
                                    break;
                                }
                                if (!hasSplitterField) continue;
                                int publicIntFieldCount = 0;
                                for (Field field : clazz7.getDeclaredFields()) {
                                    if (!Modifier.isPublic(field.getModifiers()) || field.getType() != Integer.TYPE) continue;
                                    ++publicIntFieldCount;
                                }
                                if (publicIntFieldCount < 2) continue;
                                boolean hasLoggerField = false;
                                Field[] m = clazz7.getDeclaredFields();
                                int f = m.length;
                                boolean bl = false;
                                while (var27_195 < f) {
                                    Field f2 = m[var27_195];
                                    if (f2.getType() == loggerClass) {
                                        hasLoggerField = true;
                                        break;
                                    }
                                    ++var27_195;
                                }
                                if (!hasLoggerField) continue;
                                boolean hasURIField = false;
                                for (Field f3 : clazz7.getDeclaredFields()) {
                                    if (f3.getType() != uriClass) continue;
                                    hasURIField = true;
                                    break;
                                }
                                if (!hasURIField) continue;
                                boolean has3IntParamsThrowsIOExceptionMethod = false;
                                for (Method method : clazz7.getDeclaredMethods()) {
                                    Class<?>[] params = method.getParameterTypes();
                                    if (params.length != 3 || params[0] != Integer.TYPE || params[1] != Integer.TYPE || params[2] != Integer.TYPE) continue;
                                    Class<?>[] exTypes = method.getExceptionTypes();
                                    boolean throwsIOException = false;
                                    for (Class<?> exType : exTypes) {
                                        if (exType != IOException.class) continue;
                                        throwsIOException = true;
                                        break;
                                    }
                                    if (!throwsIOException) continue;
                                    has3IntParamsThrowsIOExceptionMethod = true;
                                    break;
                                }
                                if (!has3IntParamsThrowsIOExceptionMethod) continue;
                                MinecraftMapper.put("GuiScreen", clazz7);
                                break;
                            }
                            if (entityClass != null) {
                                for (Method method : entityClass.getDeclaredMethods()) {
                                    if (Modifier.isPublic(method.getModifiers()) && !Modifier.isStatic(method.getModifiers()) && method.getReturnType() == Void.TYPE && method.getParameterCount() != 0) continue;
                                }
                                for (Method method : entityClass.getDeclaredMethods()) {
                                    Class<?>[] params;
                                    if (!Modifier.isPublic(method.getModifiers()) || method.getReturnType() != Void.TYPE || method.getParameterCount() != 3 || (params = method.getParameterTypes())[0] != Double.TYPE || params[1] != Double.TYPE || params[2] != Double.TYPE) continue;
                                    MinecraftMapper.putMethod("Entity.setPositionAndUpdate", method);
                                    break;
                                }
                            }
                            if (MinecraftMapper.get("Minecraft") != null && MinecraftMapper.get("GuiScreen") != null) {
                                for (Field field : MinecraftMapper.get("Minecraft").getDeclaredFields()) {
                                    if (field.getType() != MinecraftMapper.get("GuiScreen") || !Modifier.isPublic(field.getModifiers())) continue;
                                    MinecraftMapper.putField("Minecraft.currentScreen", field);
                                    break;
                                }
                            }
                            for (Class clazz8 : MinecraftMapper.getClasses()) {
                                Constructor<?>[] constructors6;
                                if (clazz8.getSuperclass() == null || clazz8.getSuperclass().getName().equals("java.lang.Object")) continue;
                                for (Constructor<?> ctor : constructors6 = clazz8.getDeclaredConstructors()) {
                                    Class<?>[] params = ctor.getParameterTypes();
                                    if (constructors6.length != 2 || params.length != 2 || params[0] != params[1] || params[0].isPrimitive() || params[0].getName().startsWith("java.")) continue;
                                    MinecraftMapper.put("GuiChest", clazz8);
                                    MinecraftMapper.put("IInventory", params[0]);
                                    break;
                                }
                                if (MinecraftMapper.get("GuiChest") != clazz8) continue;
                                break;
                            }
                            entityPlayerClass = MinecraftMapper.get("EntityPlayer");
                            Class<?> clazz9 = MinecraftMapper.get("GuiChest");
                            Class<?> guiContainer = null;
                            Class<?> containerCls = null;
                            if (clazz9 != null && entityPlayerClass != null) {
                                guiContainer = clazz9.getSuperclass();
                                MinecraftMapper.put("GuiChest", clazz9);
                                MinecraftMapper.put("GuiContainer", guiContainer);
                                containerCls = MinecraftMapper.findContainerClassFromEntityPlayer(entityPlayerClass);
                                MinecraftMapper.put("Container", containerCls);
                                MinecraftMapper.putField("Container.windowId", MinecraftMapper.findWindowID(containerCls));
                                Field inventorySlots = MinecraftMapper.getFieldOfType(guiContainer, containerCls);
                                MinecraftMapper.putField("Container.inventorySlots", inventorySlots);
                                Class<?> slotClass = MinecraftMapper.getProtectedMethodSingleParam(containerCls);
                                MinecraftMapper.put("Slot", slotClass);
                                MinecraftMapper.putMethod("Container.getSlot", MinecraftMapper.findGetSlot());
                                Field slotsField = MinecraftMapper.getListFieldOfType(containerCls, slotClass);
                                MinecraftMapper.putField("Slot.inventorySlots", slotsField);
                                Method getStackMethod = MinecraftMapper.findGetStackMethod(slotClass);
                                MinecraftMapper.putMethod("Slot.getStack", getStackMethod);
                                if (getStackMethod != null) {
                                    MinecraftMapper.put("ItemStack", getStackMethod.getReturnType());
                                }
                            } else {
                                MinecraftMapper.warnMappingSkip("GuiContainer/Container", "GuiChest or EntityPlayer is not mapped");
                            }
                            for (Class<?> clazz10 : MinecraftMapper.getClasses()) {
                                if (!MinecraftMapper.isPlayerControllerMP(clazz10)) continue;
                                MinecraftMapper.put("PlayerControllerMP", clazz10);
                            }
                            Class<?> playerControllerMP = MinecraftMapper.get("PlayerControllerMP");
                            if (playerControllerMP != null) {
                                for (Method method : playerControllerMP.getDeclaredMethods()) {
                                    Class<?>[] params = method.getParameterTypes();
                                    if (params.length != 5 || params[0] != Integer.TYPE || params[1] != Integer.TYPE || params[2] != Integer.TYPE || params[3] != Integer.TYPE || params[4] != entityPlayerClass) continue;
                                    MinecraftMapper.putMethod("PlayerControllerMP.windowClick", method);
                                    break;
                                }
                                if (minecraftClass != null) {
                                    for (AccessibleObject accessibleObject : minecraftClass.getDeclaredFields()) {
                                        if (((Field)accessibleObject).getType() != playerControllerMP) continue;
                                        MinecraftMapper.putField("Minecraft.playerController", (Field)accessibleObject);
                                        break;
                                    }
                                }
                            }
                            Class[] paramTypes = new Class[]{MinecraftMapper.get("EntityPlayer"), MinecraftMapper.get("World"), MinecraftMapper.get("ItemStack"), Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, MinecraftMapper.get("Vec3")};
                            if (playerControllerMP != null && (foundMethod = MinecraftMapper.findMethodFromParam(playerControllerMP, paramTypes)) != null) {
                                MinecraftMapper.putMethod("PlayerControllerMP.onPlayerRightClick", foundMethod);
                            }
                            try {
                                Field sa = entityPlayerClass == null ? null : MinecraftMapper.findInventoryContainer(MinecraftMapper.getClassBytes(entityPlayerClass));
                                MinecraftMapper.putField("EntityPlayer.inventoryContainer", sa);
                                if (entityPlayerClass == null || MinecraftMapper.get("Container") == null) break block185;
                                for (Field f : entityPlayerClass.getDeclaredFields()) {
                                    if (!f.getType().equals(MinecraftMapper.get("Container")) || f.equals(sa)) continue;
                                    MinecraftMapper.putField("EntityPlayer.openContainer", f);
                                    break;
                                }
                            }
                            catch (Exception e) {
                                MinecraftMapper.warnMappingSkip("EntityPlayer container fields", e.getMessage());
                            }
                        }
                        Method rayTraceMethod = MinecraftMapper.getMethodByParamAndReturnTypeAndVisibility(MinecraftMapper.get("Entity"), new Class[]{Double.TYPE, Float.TYPE}, MinecraftMapper.get("MovingObjectPosition"), "public");
                        if (rayTraceMethod != null) {
                            MinecraftMapper.putMethod("Entity.rayTrace", rayTraceMethod);
                        }
                        HashMap requiredFields = new HashMap();
                        requiredFields.put("OF_NAME", String.class);
                        requiredFields.put("MC_VERSION", String.class);
                        requiredFields.put("OF_EDITION", String.class);
                        requiredFields.put("OF_RELEASE", String.class);
                        requiredFields.put("VERSION", String.class);
                        requiredFields.put("renderPartialTicks", Float.TYPE);
                        Class<?> clazz = MinecraftMapper.findClassWithFieldsAndExactTypes(requiredFields, MinecraftMapper.getClasses());
                        MinecraftMapper.put("craftrise.Config", clazz);
                        if (clazz != null) {
                            Field renderPartialTicksField = clazz.getDeclaredField("renderPartialTicks");
                            MinecraftMapper.putField("craftrise.Config.renderPartialTicks", renderPartialTicksField);
                        } else {
                            MinecraftMapper.warnMappingSkip("craftrise.Config.renderPartialTicks", "Config class was not found");
                        }
                        try {
                            Class<?> entityLivingBase = MinecraftMapper.get("EntityLivingBase");
                            if (entityLivingBase != null) {
                                Field swingField = MinecraftMapper.findPublicBooleanDeclaredField(entityLivingBase);
                                if (swingField != null) {
                                    MinecraftMapper.putField("EntityLivingBase.isSwingInProgress", swingField);
                                }
                            } else {
                                MinecraftMapper.warnMappingSkip("EntityLivingBase.isSwingInProgress", "EntityLivingBase is not mapped");
                            }
                        }
                        catch (Exception e) {
                            MinecraftMapper.warnMappingSkip("EntityLivingBase.isSwingInProgress", e.getMessage());
                        }
                        try {
                            Class<?> mcClass2 = MinecraftMapper.get("Minecraft");
                            Object mcInstance = MinecraftMapper.getMinecraft();
                            if (mcClass2 != null && mcInstance != null) {
                                Object var30_217 = null;
                                Field cps2 = null;
                                Field[] hasStringFloatFloatIntBoolMethod = mcClass2.getDeclaredFields();
                                int mt = hasStringFloatFloatIntBoolMethod.length;
                                int var328 = 0;
                                while (true) {
                                    block186: {
                                        void var30_218;
                                        if (var328 < mt) {
                                            Field field = hasStringFloatFloatIntBoolMethod[var328];
                                            try {
                                                if (field.getType() != Integer.TYPE || !Modifier.isPrivate(field.getModifiers()) || Modifier.isStatic(field.getModifiers())) break block186;
                                                field.setAccessible(true);
                                                int val = field.getInt(mcInstance);
                                                if (val != 0) break block186;
                                                if (var30_218 == null) {
                                                    Field field2 = field;
                                                    MinecraftMapper.putField("Minecraft.cps1", field);
                                                    break block186;
                                                }
                                                if (cps2 != null) break block186;
                                                cps2 = field;
                                                MinecraftMapper.putField("Minecraft.cps2", field);
                                            }
                                            catch (Exception e) {
                                                System.err.println("Field okunurken hata:");
                                                e.printStackTrace();
                                                break block186;
                                            }
                                        }
                                        if (var30_218 != null && cps2 == null) {
                                            // empty if block
                                        }
                                        break block187;
                                    }
                                    ++var328;
                                }
                            }
                            throw new IllegalStateException("Minecraft class or instance is null");
                        }
                        catch (Exception ex) {
                            System.err.println("Genel hata:");
                            ex.printStackTrace();
                        }
                    }
                    Class<?> fontRendererClass = null;
                    for (Class<?> clazz : MinecraftMapper.getClasses()) {
                        try {
                            void var35_284;
                            if (clazz.getInterfaces().length == 0) continue;
                            boolean hasCtor = false;
                            for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                                Class<?>[] params = constructor.getParameterTypes();
                                if (params.length != 4 || params[3] != Boolean.TYPE) continue;
                                hasCtor = true;
                                break;
                            }
                            if (!hasCtor) continue;
                            boolean hasStringFloatFloatIntBoolMethod = false;
                            Method[] mt = clazz.getDeclaredMethods();
                            int var328 = mt.length;
                            boolean bl = false;
                            while (var35_284 < var328) {
                                Method m = mt[var35_284];
                                Class<?>[] p = m.getParameterTypes();
                                if (p.length == 5 && p[0] == String.class && p[1] == Float.TYPE && p[2] == Float.TYPE && p[3] == Integer.TYPE && p[4] == Boolean.TYPE) {
                                    hasStringFloatFloatIntBoolMethod = true;
                                }
                                ++var35_284;
                            }
                            if (!hasStringFloatFloatIntBoolMethod) continue;
                            fontRendererClass = clazz;
                            break;
                        }
                        catch (Exception eFontClass) {
                            eFontClass.printStackTrace();
                        }
                    }
                    if (fontRendererClass != null) {
                        MinecraftMapper.put("FontRenderer", fontRendererClass);
                    } else {
                        System.out.println("FontRenderer bulunamad\u00c3\u201e\u00c2\u00b1.");
                    }
                    if (fontRendererClass != null) {
                        for (Method m : fontRendererClass.getDeclaredMethods()) {
                            if (!Modifier.isStatic(m.getModifiers()) || !Modifier.isPublic(m.getModifiers()) || m.getParameterCount() != 0 || m.getReturnType() != String.class) continue;
                            MinecraftMapper.putMethod("FontRenderer.getTitle", m);
                            break;
                        }
                    } else {
                        System.out.println("FontRenderer bulunamad\u00c3\u201e\u00c2\u00b1.");
                    }
                    if (fontRendererClass != null) {
                        void var30_227;
                        Object var30_225 = null;
                        for (Method m : fontRendererClass.getDeclaredMethods()) {
                            Class<?>[] classArray = m.getParameterTypes();
                            if (classArray.length != 5 || classArray[0] != String.class || classArray[1] != Float.TYPE || classArray[2] != Float.TYPE || classArray[3] != Integer.TYPE || classArray[4] != Boolean.TYPE) {
                                continue;
                            }
                            Method method = m;
                            break;
                        }
                        if (var30_227 != null) {
                            MinecraftMapper.putMethod("FontRenderer.drawString", (Method)var30_227);
                        } else {
                            System.out.println("drawString metodu bulunamad\u00c3\u201e\u00c2\u00b1.");
                        }
                    }
                    try {
                        Class<?> clazz = MinecraftMapper.get("Minecraft");
                        if (clazz != null && fontRendererClass != null) {
                            Method targetMethod = null;
                            Method[] var299 = clazz.getDeclaredMethods();
                            int var310 = var299.length;
                            int var320 = 0;
                            while (true) {
                                block189: {
                                    if (var320 < var310) {
                                        Method method = var299[var320];
                                        try {
                                            if (!Modifier.isPublic(method.getModifiers()) || method.getReturnType() != fontRendererClass || method.getParameterCount() != 0) break block189;
                                            targetMethod = method;
                                        }
                                        catch (Exception eTarget) {
                                            eTarget.printStackTrace();
                                            break block189;
                                        }
                                    }
                                    if (targetMethod != null) {
                                        MinecraftMapper.putMethod("Minecraft.getFontRendererObj", targetMethod);
                                    } else {
                                        System.out.println("getFontRendererObj metodu bulunamad\u00c3\u201e\u00c2\u00b1.");
                                    }
                                    break block190;
                                }
                                ++var320;
                            }
                        }
                        throw new IllegalStateException("Minecraft or FontRenderer class is not mapped");
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
                for (Class<?> clazz : MinecraftMapper.getClasses()) {
                    Optional<Method> targetMethod;
                    boolean hasMapField = Arrays.stream(clazz.getDeclaredFields()).anyMatch(fx -> Modifier.isPrivate(fx.getModifiers()) && Modifier.isStatic(fx.getModifiers()) && Modifier.isFinal(fx.getModifiers()) && Map.class.isAssignableFrom(fx.getType()));
                    if (!hasMapField || !Arrays.stream(clazz.getDeclaredFields()).anyMatch(fx -> Modifier.isProtected(fx.getModifiers()) && Modifier.isFinal(fx.getModifiers()) && fx.getType() == MinecraftMapper.get("Minecraft")) || !(targetMethod = Arrays.stream(clazz.getDeclaredMethods()).filter(mx -> Modifier.isPublic(mx.getModifiers()) && mx.getParameterCount() == 2 && mx.getParameterTypes()[1] == Float.TYPE).findFirst()).isPresent()) continue;
                    Method method = targetMethod.get();
                    Class<?> clazz11 = method.getParameterTypes()[0];
                    MinecraftMapper.put("ScaledResolution", clazz11);
                    MinecraftMapper.put("GuiInGame", clazz);
                    break;
                }
                try {
                    Class<?> clazz = MinecraftMapper.get("Minecraft");
                    Class<?> guiIngameClass = MinecraftMapper.get("GuiInGame");
                    if (clazz == null || guiIngameClass == null) {
                        throw new IllegalStateException("Minecraft or GuiInGame class is not mapped");
                    }
                    for (Field field : clazz.getDeclaredFields()) {
                        if (field.getType() != guiIngameClass || !Modifier.isPublic(field.getModifiers())) continue;
                        MinecraftMapper.putField("Minecraft.ingameGUI", field);
                        break;
                    }
                }
                catch (Exception exception) {
                    System.err.println("Minecraft.ingameGUI field'\u00c3\u201e\u00c2\u00b1 al\u00c3\u201e\u00c2\u00b1n\u00c3\u201e\u00c2\u00b1rken hata:");
                    exception.printStackTrace();
                }
                MinecraftMapper.rectMethods();
                Method method = Arrays.stream(MinecraftMapper.getAllMethods(MinecraftMapper.get("FontRenderer"))).filter(mx -> mx.getReturnType() == Integer.TYPE && mx.getParameterCount() == 1 && mx.getParameterTypes()[0].equals(String.class) && Modifier.isPublic(mx.getModifiers())).filter(mx -> {
                    try {
                        Object fontRenderer = MinecraftMapper.getFontRenderer();
                        int result = (Integer)mx.invoke(fontRenderer, "alperenamigotudagitti");
                        return result == 105;
                    }
                    catch (Exception var3) {
                        return false;
                    }
                }).findFirst().orElse(null);
                if (method != null) {
                    MinecraftMapper.putMethod("FontRenderer.getStringWidth", method);
                }
                MinecraftMapper.findTextureManagerClass();
                MinecraftMapper.putMethod("Minecraft.getTextureManager", MinecraftMapper.findMethod(MinecraftMapper.get("Minecraft"), 1, MinecraftMapper.get("TextureManager"), new Class[0]));
                for (Method mt : MinecraftMapper.getAllMethods(MinecraftMapper.get("TextureManager"))) {
                    Class<?>[] classArray = mt.getParameterTypes();
                    if (classArray.length != 3 || classArray[0].isPrimitive() || classArray[1] != Integer.TYPE || classArray[2] != Integer.TYPE) continue;
                    MinecraftMapper.putMethod("TextureManager.bindTexture", mt);
                    break;
                }
                if ((guiClass = MinecraftMapper.get("Gui")) == null) {
                    MinecraftMapper.warnMappingSkip("Gui ResourceLocation discovery", "Gui class is not mapped");
                } else {
                    Field[] fields = guiClass.getDeclaredFields();
                    HashMap typeCount = new HashMap();
                    for (Field f : fields) {
                        Class<?> clazz = f.getType();
                        if (clazz.isPrimitive() || List.class.isAssignableFrom(clazz)) continue;
                        typeCount.put(clazz, typeCount.getOrDefault(clazz, 0) + 1);
                    }
                    for (Map.Entry entry : typeCount.entrySet()) {
                        if ((Integer)entry.getValue() < 3) continue;
                        MinecraftMapper.put("ResourceLocation", (Class)entry.getKey());
                        break;
                    }
                }
                Class<?> textureManager = MinecraftMapper.get("TextureManager");
                Class<?> resourceLocationClass = MinecraftMapper.get("ResourceLocation");
                if (textureManager != null && resourceLocationClass != null) {
                    for (Method m : textureManager.getDeclaredMethods()) {
                        Class<?>[] classArray;
                        if (!m.getReturnType().equals(resourceLocationClass) || (classArray = m.getParameterTypes()).length < 2 || !classArray[0].equals(String.class)) continue;
                        MinecraftMapper.putMethod("TextureManager.getDynamicTextureLocation", m);
                        MinecraftMapper.put("DynamicTexture", classArray[1]);
                        break;
                    }
                } else {
                    MinecraftMapper.warnMappingSkip("TextureManager.getDynamicTextureLocation", "TextureManager or ResourceLocation is not mapped");
                }
                MinecraftMapper.findS18();
                MinecraftMapper.findOnGround(MinecraftMapper.getClassBytes(MinecraftMapper.get("S18PacketEntityTeleport")));
                MinecraftMapper.findInventoryPlayerClass();
                Class<?> inventoryPlayerClass = MinecraftMapper.get("InventoryPlayer");
                if (entityPlayerClass != null && inventoryPlayerClass != null) {
                    for (Field field : entityPlayerClass.getDeclaredFields()) {
                        int mods = field.getModifiers();
                        if (!Modifier.isPublic(mods) || !field.getType().equals(inventoryPlayerClass)) continue;
                        MinecraftMapper.putField("EntityPlayer.inventory", field);
                        break;
                    }
                    Field field = MinecraftMapper.findCurrentItem(MinecraftMapper.getClassBytes(inventoryPlayerClass), inventoryPlayerClass);
                    MinecraftMapper.putField("InventoryPlayer.currentItem", field);
                    Class<?> clazz = MinecraftMapper.get("InventoryPlayer");
                    Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
                    Object object = MinecraftMapper.getInventory();
                    if (clazz != null && itemStackClass != null && object != null) {
                        for (Field field3 : clazz.getDeclaredFields()) {
                            if (!field3.getType().isArray() || !field3.getType().getComponentType().equals(itemStackClass)) continue;
                            field3.setAccessible(true);
                            try {
                                Object arrayInstance = field3.get(object);
                                if (arrayInstance == null) continue;
                                int length = Array.getLength(arrayInstance);
                                if (length == 36) {
                                    MinecraftMapper.putField("InventoryPlayer.mainInventory", field3);
                                    continue;
                                }
                                if (length != 4) continue;
                                MinecraftMapper.putField("InventoryPlayer.armorInventory", field3);
                            }
                            catch (IllegalAccessException eInv) {
                                eInv.printStackTrace();
                            }
                        }
                    } else {
                        MinecraftMapper.warnMappingSkip("InventoryPlayer array fields", "InventoryPlayer, ItemStack, or inventory instance is not available");
                    }
                } else {
                    MinecraftMapper.warnMappingSkip("InventoryPlayer fields", "EntityPlayer or InventoryPlayer is not mapped");
                }
                MinecraftMapper.findSkin();
                MinecraftMapper.findGuiInventory();
                MinecraftMapper.findGetChunkFromChunkCoords();
                MinecraftMapper.findEffectRenderer();
                MinecraftMapper.findRenderManager();
                MinecraftMapper.processItemClass();
                MinecraftMapper.findMathHelper();
                Field field = MinecraftMapper.analyzeNetworkPlayerInfoField(MinecraftMapper.get("AbstractClientPlayer"));
                if (field == null) {
                    MinecraftMapper.warnMappingSkip("NetworkPlayerInfo", "AbstractClientPlayer.playerInfo field was not found");
                } else {
                    MinecraftMapper.putField("AbstractClientPlayer.playerInfo", field);
                    MinecraftMapper.put("NetworkPlayerInfo", field.getType());
                }
                MinecraftMapper.mapNetworkPlayerInfoAndPacketClasses();
                MinecraftMapper.findC08PacketPlayerBlockPlacement();
                MinecraftMapper.findC06PacketPlayerPosLook(MinecraftMapper.getClasses());
                MinecraftMapper.findItemStackSize();
                MinecraftMapper.findRenderManagerFields();
                MinecraftMapper.findEntityFields();
                MinecraftMapper.processPacketClass();
                MinecraftMapper.findItemStackDisplayName();
                MinecraftMapper.findItemStackItemField();
                MinecraftMapper.findGameProfile();
                MinecraftMapper.findAxisAligned();
                MinecraftMapper.processGameSettingsClass();
                MinecraftMapper.findTimerContainer();
                MinecraftMapper.processKeyBindingClasses();
                MinecraftMapper.processMouseHelperClass();
                MinecraftMapper.extractKeyBindings(MinecraftMapper.get("GameSettings"));
                MinecraftMapper.findThirdPersonViewField();
                MinecraftMapper.findsendChatMessage();
                MinecraftMapper.processModelBiped();
                MinecraftMapper.findItemRendererClass();
                MinecraftMapper.findTimerClass();
                MinecraftMapper.findglstatemanager(20);
                MinecraftMapper.processModelBipedMethods();
                MinecraftMapper.findEntityRenderer();
                MinecraftMapper.mapC03XYZFromC06();
                MinecraftMapper.findSetTagInfoMethod();
                MinecraftMapper.processFloatContainerClasses();
                MinecraftMapper.findHeldItemChangePacketReflection();
                MinecraftMapper.finds33packet();
                MinecraftMapper.processC02PacketUseEntityMethods();
                MinecraftMapper.findEntityBoat();
                MinecraftMapper.findPlayerCap();
                MinecraftMapper.findC13PacketPlayerAbilities();
                MinecraftMapper.finds02();
                MinecraftMapper.findEntityList();
                MinecraftMapper.findallmobs();
                MinecraftMapper.analyzeAddMappingFirstParam();
                MinecraftMapper.findWorldBorderPacket();
                MinecraftMapper.findTitlePacket();
                MinecraftMapper.findS3FPacket();
                MinecraftMapper.findC17Custom();
                MinecraftMapper.finds37andstatbase();
                MinecraftMapper.findUpdateSignPacket();
                MinecraftMapper.findResourcePackStatusPacket();
                MinecraftMapper.findClickWindowPacket();
                MinecraftMapper.findC10PacketCreativeInventoryAction();
                MinecraftMapper.findClientStatusPacket();
                MinecraftMapper.findInputPacket();
                MinecraftMapper.findHandshakePacket();
                MinecraftMapper.findEntityActionPacket();
                MinecraftMapper.findUpdateScorePacket();
                MinecraftMapper.findc09packet();
                MinecraftMapper.findGetSubCompoundMethod();
                MinecraftMapper.findModelManager();
                MinecraftMapper.worldacces();
                MinecraftMapper.findrenderGlobal();
                MinecraftMapper.findRendererLivingEntity();
                MinecraftMapper.finds0cpacket();
                Class<?> playerClass = MinecraftMapper.get("EntityPlayer");
                MinecraftMapper.findPrevRenderYawOffset();
                MinecraftMapper.findPlayerPosLookPacket();
                MinecraftMapper.findC0DPacketCloseWindow();
                MinecraftMapper.mapGetHealth();
                MinecraftMapper.findS39PlayerCapabilities();
                MinecraftMapper.findPlayerCapabilitiesMethods(MinecraftMapper.get("NetHandlerPlayClient"), MinecraftMapper.get("S39PacketPlayerAbilities"), MinecraftMapper.get("PlayerCapabilities"));
                MinecraftMapper.mapPlayerCapabilitiesFields();
                MinecraftMapper.mapMoveEntityWithHeadingAndParams();
                MinecraftMapper.mapC13PacketPlayerAbilitiesFields();
                MinecraftMapper.findEntityThrowable();
                MinecraftMapper.mapIsBlockingASM();
                MinecraftMapper.mapSyncCurrentPlayItemASM();
                MinecraftMapper.findJumpOpcodeBased();
                for (Class clazz : MinecraftMapper.getClasses()) {
                    Method getGlTextureId;
                    if (!MinecraftMapper.isTargetTextureClass(clazz) || (getGlTextureId = MinecraftMapper.findGetGlTextureId(clazz)) == null) continue;
                    MinecraftMapper.put("AbstractTexture", clazz);
                    MinecraftMapper.putMethod("AbstractTexture.getGlTextureId", getGlTextureId);
                    break;
                }
                MinecraftMapper.mapPerformHurtAnimation();
                if (playerClass == null) {
                    MinecraftMapper.warnMappingSkip("EntityPlayer.setItemInUse", "EntityPlayer is not mapped");
                } else {
                    for (Method m : playerClass.getDeclaredMethods()) {
                        Class<?>[] params;
                        if (!Modifier.isPublic(m.getModifiers()) || !m.getReturnType().equals(Void.TYPE) || (params = m.getParameterTypes()).length != 2 || !params[0].equals(MinecraftMapper.get("ItemStack")) || !params[1].equals(Integer.TYPE)) continue;
                        MinecraftMapper.putMethod("EntityPlayer.setItemInUse", m);
                    }
                }
                for (Class clazz : MinecraftMapper.getClasses()) {
                    byte[] classBytes = MinecraftMapper.getClassBytes(clazz);
                    if (classBytes == null || classBytes.length == 0) continue;
                    ClassNode cn = new ClassNode();
                    new ClassReader(classBytes).accept((ClassVisitor)cn, 0);
                    int staticFieldCount = 0;
                    for (Object f : cn.fields) {
                        if ((((FieldNode)f).access & 8) == 0) continue;
                        ++staticFieldCount;
                    }
                    if (staticFieldCount <= 55 || staticFieldCount >= 80) continue;
                    boolean hasGsonMethod = false;
                    for (MethodNode m : cn.methods) {
                        if ((m.access & 1) == 0 || (m.access & 8) == 0 || !m.desc.equals("()Lcom/google/gson/Gson;")) continue;
                        hasGsonMethod = true;
                        break;
                    }
                    if (!hasGsonMethod) continue;
                    MinecraftMapper.put("ClientUtils", clazz);
                    break;
                }
                for (Class clazz : MinecraftMapper.getClasses()) {
                    byte[] classBytes = MinecraftMapper.getClassBytes(clazz);
                    if (classBytes == null || classBytes.length == 0) continue;
                    ClassReader cr = new ClassReader(classBytes);
                    ClassNode cn = new ClassNode();
                    cr.accept((ClassVisitor)cn, 0);
                    boolean hasNoArgConstructor = false;
                    boolean hasMapConstructor = false;
                    Field mapField = null;
                    for (MethodNode m : cn.methods) {
                        if (!m.name.equals("<init>")) continue;
                        org.objectweb.asm.Type[] args = org.objectweb.asm.Type.getArgumentTypes((String)m.desc);
                        if (args.length == 0) {
                            hasNoArgConstructor = true;
                            continue;
                        }
                        if (args.length != 1 || !args[0].getClassName().equals("it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap")) continue;
                        hasMapConstructor = true;
                    }
                    for (FieldNode f : cn.fields) {
                        if ((f.access & 2) == 0 || !f.desc.equals("Lit/unimi/dsi/fastutil/ints/Int2ObjectOpenHashMap;")) continue;
                        try {
                            mapField = clazz.getDeclaredField(f.name);
                            break;
                        }
                        catch (NoSuchFieldException noSuchFieldException) {
                        }
                    }
                    if (!hasNoArgConstructor || !hasMapConstructor || mapField == null) continue;
                    MinecraftMapper.put("ScoreBoardUtil", clazz);
                    MinecraftMapper.putField("ScoreBoardUtil.scoreBoardInfo", mapField);
                    break;
                }
                Class<?> clientUtilsClass = MinecraftMapper.get("ClientUtils");
                Class<?> clazz = MinecraftMapper.get("ScoreBoardUtil");
                if (clientUtilsClass != null && clazz != null) {
                    for (Field field4 : clientUtilsClass.getDeclaredFields()) {
                        int mods = field4.getModifiers();
                        if (!Modifier.isPrivate(mods) || !Modifier.isStatic(mods) || !field4.getType().equals(clazz)) continue;
                        field4.setAccessible(true);
                        MinecraftMapper.putField("ClientUtils.scoreBoard", field4);
                        break block193;
                    }
                    break block193;
                }
                MinecraftMapper.warnMappingSkip("ClientUtils.scoreBoard", "ClientUtils or ScoreBoardUtil is not mapped");
            }
            catch (Exception exception) {
                Logger.error("startMappings failed: " + exception.getMessage());
                exception.printStackTrace();
            }
        }
    }

    public static void mapGetHealth() {
        try {
            Class<?> clazz = MinecraftMapper.get("EntityLivingBase");
            if (clazz == null) {
                System.out.println("[mapGetHealth] EntityLivingBase bulunamad\u00c3\u201e\u00c2\u00b1!");
                return;
            }
            System.out.println("[mapGetHealth] EntityLivingBase=" + clazz.getName());
            System.out.println("[mapGetHealth] Reflection scan for ()F methods:");
            for (Class<?> scan = clazz; scan != null && !scan.equals(Object.class); scan = scan.getSuperclass()) {
                for (Method m : scan.getDeclaredMethods()) {
                    if (m.getParameterCount() != 0 || m.getReturnType() != Float.TYPE || (m.getModifiers() & 8) != 0) continue;
                    System.out.println("[mapGetHealth]   " + scan.getSimpleName() + "." + m.getName() + "()F");
                }
            }
            byte[] bytes = MinecraftMapper.getClassBytes(clazz);
            if (bytes == null) {
                String[] knownNames;
                System.out.println("[mapGetHealth] class bytes NULL \u00c3\u00a2\u00e2\u201a\u00ac\u00e2\u20ac\u009d reflection-only path");
                for (String name : knownNames = new String[]{"getHealth", "func_110143_aJ"}) {
                    try {
                        Method m = clazz.getDeclaredMethod(name, new Class[0]);
                        if (m.getReturnType() != Float.TYPE) continue;
                        m.setAccessible(true);
                        MinecraftMapper.putMethod("EntityLivingBase.getHealth", m);
                        System.out.println("[mapGetHealth] reflection found: " + name);
                        return;
                    }
                    catch (NoSuchMethodException m) {
                        // empty catch block
                    }
                }
                System.out.println("[mapGetHealth] reflection fallback failed");
                return;
            }
            System.out.println("[mapGetHealth] class bytes OK size=" + bytes.length);
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            System.out.println("[mapGetHealth] ASM ()F methods:");
            for (Object mn : cn.methods) {
                if (!"()F".equals(((MethodNode)mn).desc) || (((MethodNode)mn).access & 8) != 0) continue;
                System.out.println("[mapGetHealth]   " + ((MethodNode)mn).name + " insns=" + ((MethodNode)mn).instructions.size());
            }
            Object target = null;
            for (Object mn : cn.methods) {
                InsnList insns = ((MethodNode)mn).instructions;
                if (insns.size() < 6) continue;
                try {
                    if (insns.get(0).getOpcode() != 25 || insns.get(1).getOpcode() != 180 || insns.get(2).getOpcode() != 178 || insns.get(3).getOpcode() != 182 || insns.get(4).getOpcode() != 182 || insns.get(5).getOpcode() != 174) continue;
                    target = mn;
                    System.out.println("[mapGetHealth] Pass1 matched: " + ((MethodNode)mn).name);
                    break;
                }
                catch (Exception exception) {
                }
            }
            if (target == null) {
                FieldInsnNode fin;
                System.out.println("[mapGetHealth] Pass1 failed, trying Pass2...");
                LinkedHashSet<String> floatFields = new LinkedHashSet<String>();
                for (FieldNode fn : cn.fields) {
                    if (!"F".equals(fn.desc) || (fn.access & 8) != 0) continue;
                    floatFields.add(fn.name);
                }
                System.out.println("[mapGetHealth] float fields: " + floatFields);
                System.out.println("[mapGetHealth] (F)V setter candidates:");
                for (MethodNode mn : cn.methods) {
                    if (!"(F)V".equals(mn.desc) || (mn.access & 8) != 0) continue;
                    System.out.println("[mapGetHealth]   " + mn.name);
                }
                String healthField = null;
                for (MethodNode mn : cn.methods) {
                    if (!"(F)V".equals(mn.desc) || (mn.access & 8) != 0) continue;
                    for (AbstractInsnNode insn : mn.instructions.toArray()) {
                        if (insn.getOpcode() != 181) continue;
                        fin = (FieldInsnNode)insn;
                        if (!"F".equals(fin.desc) || !floatFields.contains(fin.name)) continue;
                        healthField = fin.name;
                        System.out.println("[mapGetHealth] health field: " + healthField + " via setter=" + mn.name);
                        break;
                    }
                    if (healthField == null) continue;
                    break;
                }
                if (healthField != null) {
                    for (MethodNode mn : cn.methods) {
                        if (!"()F".equals(mn.desc) || (mn.access & 8) != 0) continue;
                        for (AbstractInsnNode insn : mn.instructions.toArray()) {
                            if (insn.getOpcode() != 180) continue;
                            fin = (FieldInsnNode)insn;
                            if (!healthField.equals(fin.name)) continue;
                            target = mn;
                            System.out.println("[mapGetHealth] Pass2 matched: " + mn.name);
                            break;
                        }
                        if (target == null) continue;
                        break;
                    }
                }
            }
            if (target == null) {
                String[] knownNames;
                System.out.println("[mapGetHealth] Pass2 failed, trying Pass3...");
                for (String name : knownNames = new String[]{"getHealth", "func_110143_aJ"}) {
                    try {
                        Method m = clazz.getDeclaredMethod(name, new Class[0]);
                        if (m.getReturnType() != Float.TYPE) continue;
                        m.setAccessible(true);
                        MinecraftMapper.putMethod("EntityLivingBase.getHealth", m);
                        System.out.println("[mapGetHealth] Pass3 found: " + name);
                        return;
                    }
                    catch (NoSuchMethodException noSuchMethodException) {
                        // empty catch block
                    }
                }
                System.out.println("[mapGetHealth] all passes failed");
                return;
            }
            Method real = clazz.getDeclaredMethod(((MethodNode)target).name, new Class[0]);
            real.setAccessible(true);
            MinecraftMapper.putMethod("EntityLivingBase.getHealth", real);
            System.out.println("[mapGetHealth] SUCCESS -> " + ((MethodNode)target).name);
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static Field findCurrentItem(byte[] classBytes, Class<?> clazz) throws Exception {
        if (MinecraftMapper.missingClassBytes("findCurrentItem", clazz, classBytes)) {
            return null;
        }
        ClassReader cr = new ClassReader(classBytes);
        ClassNode cn = new ClassNode();
        cr.accept((ClassVisitor)cn, 6);
        HashSet<String> initializedInCtor = new HashSet<String>();
        for (MethodNode mn : cn.methods) {
            if (!"<init>".equals(mn.name)) continue;
            for (AbstractInsnNode insn : mn.instructions.toArray()) {
                FieldInsnNode fin;
                if (!(insn instanceof FieldInsnNode) || (fin = (FieldInsnNode)insn).getOpcode() != 181 || cn.name == null || !cn.name.equals(fin.owner) || !"I".equals(fin.desc)) continue;
                initializedInCtor.add(fin.name);
            }
        }
        for (FieldNode fn : cn.fields) {
            boolean hasConstantValue;
            boolean isStatic = (fn.access & 8) != 0;
            boolean isPublic = (fn.access & 1) != 0;
            boolean isInt = "I".equals(fn.desc) || "Ljava/lang/Integer;".equals(fn.desc);
            boolean bl = hasConstantValue = fn.value != null;
            if (isStatic || !isInt || hasConstantValue || initializedInCtor.contains(fn.name)) continue;
            try {
                Field f = clazz.getDeclaredField(fn.name);
                f.setAccessible(true);
                return f;
            }
            catch (NoSuchFieldException noSuchFieldException) {
            }
            catch (SecurityException securityException) {
            }
        }
        return null;
    }

    public static Field findWindowID(Class<?> clazz) throws Exception {
        byte[] bytes = MinecraftMapper.getClassBytes(clazz);
        if (MinecraftMapper.missingClassBytes("findWindowID", clazz, bytes)) {
            return null;
        }
        ClassReader cr = new ClassReader(bytes);
        ClassNode cn = new ClassNode();
        cr.accept((ClassVisitor)cn, 0);
        HashSet<String> initializedInCtor = new HashSet<String>();
        for (MethodNode mn : cn.methods) {
            if (!"<init>".equals(mn.name)) continue;
            for (AbstractInsnNode insn : mn.instructions) {
                if (insn.getOpcode() != 181) continue;
                FieldInsnNode fin = (FieldInsnNode)insn;
                if (!"I".equals(fin.desc)) continue;
                initializedInCtor.add(fin.name);
            }
        }
        for (FieldNode fn : cn.fields) {
            boolean hasConstantValue;
            boolean isPublic = (fn.access & 1) != 0;
            boolean isInt = "I".equals(fn.desc);
            boolean bl = hasConstantValue = fn.value != null;
            if (!isPublic || !isInt || hasConstantValue || initializedInCtor.contains(fn.name)) continue;
            Field f = clazz.getDeclaredField(fn.name);
            f.setAccessible(true);
            return f;
        }
        return null;
    }

    public static void findGuiInventory() throws Exception {
        Class<?> guiContainerClass = MinecraftMapper.get("GuiContainer");
        Class<?> entityPlayerClass = MinecraftMapper.get("EntityPlayer");
        if (guiContainerClass != null && entityPlayerClass != null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                Constructor<?> ctor;
                Class<?>[] params;
                Constructor<?>[] constructors;
                Class<?> super2;
                Class<?> super1 = clazz.getSuperclass();
                if (super1 == null || !Modifier.isAbstract(super1.getModifiers()) || (super2 = super1.getSuperclass()) == null || !super2.equals(guiContainerClass) || (constructors = clazz.getDeclaredConstructors()).length != 1 || (params = (ctor = constructors[0]).getParameterTypes()).length != 1 || !params[0].equals(entityPlayerClass)) continue;
                MinecraftMapper.put("GuiInventory", clazz);
                for (Method method : clazz.getDeclaredMethods()) {
                    Class<?> entityLivingBaseClass;
                    Class<?>[] paramTypes;
                    int mods = method.getModifiers();
                    if (!Modifier.isPublic(mods) || !Modifier.isStatic(mods) || method.getReturnType() != Void.TYPE || method.getParameterCount() != 6 || (paramTypes = method.getParameterTypes())[0] != Integer.TYPE || paramTypes[1] != Integer.TYPE || paramTypes[2] != Integer.TYPE || paramTypes[3] != Float.TYPE || paramTypes[4] != Float.TYPE || (entityLivingBaseClass = MinecraftMapper.get("EntityLivingBase")) == null || !paramTypes[5].equals(entityLivingBaseClass)) continue;
                    MinecraftMapper.putMethod("GuiInventory.drawEntityOnScreen", method);
                    return;
                }
            }
        }
    }

    public static void findOnGround(byte[] classBytes) {
        try {
            if (MinecraftMapper.missingClassBytes("findOnGround", classBytes)) {
                return;
            }
            ClassReader cr = new ClassReader(classBytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            Class<?> entityClass = MinecraftMapper.get("Entity");
            if (entityClass == null) {
                return;
            }
            String entityDesc = "L" + org.objectweb.asm.Type.getInternalName(entityClass) + ";";
            for (MethodNode mn : cn.methods) {
                if (!mn.name.equals("<init>") || !mn.desc.equals("(" + entityDesc + ")V")) continue;
                List<AbstractInsnNode> insns = Arrays.asList(mn.instructions.toArray());
                for (int i = 0; i < insns.size(); ++i) {
                    AbstractInsnNode insn = insns.get(i);
                    if (insn.getOpcode() != 181 || !(insn instanceof FieldInsnNode)) continue;
                    FieldInsnNode putFieldInsn = (FieldInsnNode)insn;
                    if (i < 3) continue;
                    AbstractInsnNode insn1 = insns.get(i - 1);
                    AbstractInsnNode insn2 = insns.get(i - 2);
                    AbstractInsnNode insn3 = insns.get(i - 3);
                    if (insn1.getOpcode() != 182 || !(insn1 instanceof MethodInsnNode) || insn2.getOpcode() != 180 || !(insn2 instanceof FieldInsnNode) || insn3.getOpcode() != 25 || ((VarInsnNode)insn3).var != 1) continue;
                    MethodInsnNode invokeVirtualInsn = (MethodInsnNode)insn1;
                    FieldInsnNode getFieldInsn = (FieldInsnNode)insn2;
                    Field f = MinecraftMapper.findField(entityClass, getFieldInsn.name, getFieldInsn.desc);
                    if (f == null) continue;
                    MinecraftMapper.putField("Entity.onGround", f);
                    MinecraftMapper.put("BooleanContainer", f.getType());
                    Method m = f.getType().getDeclaredMethod(invokeVirtualInsn.name, new Class[0]);
                    if (m.getReturnType() != Boolean.TYPE) continue;
                    MinecraftMapper.putMethod("BooleanContainer.getValueBoolean", m);
                }
            }
        }
        catch (Exception e) {
            System.out.println("[ERROR] findOnGround: " + e.getMessage());
        }
    }

    public static void findInventoryPlayerClass() {
        Class<?> iInventoryClass = MinecraftMapper.get("IInventory");
        Class<?> entityPlayerClass = MinecraftMapper.get("EntityPlayer");
        Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
        if (iInventoryClass != null && entityPlayerClass != null && itemStackClass != null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                boolean implementsIInventory = false;
                for (Class<?> iface : clazz.getInterfaces()) {
                    if (!iface.equals(iInventoryClass)) continue;
                    implementsIInventory = true;
                    break;
                }
                if (!implementsIInventory) continue;
                Constructor<?>[] constructors = clazz.getConstructors();
                boolean hasEntityPlayerConstructor = false;
                for (Constructor<?> c : constructors) {
                    Class<?>[] params = c.getParameterTypes();
                    if (params.length != 1 || !params[0].equals(entityPlayerClass)) continue;
                    hasEntityPlayerConstructor = true;
                    break;
                }
                if (!hasEntityPlayerConstructor) continue;
                MinecraftMapper.put("InventoryPlayer", clazz);
                break;
            }
        }
    }

    public static Class<?> findS18() {
        List<Class<?>> classes = MinecraftMapper.getClasses();
        Class<?> packetClass = MinecraftMapper.get("Packet");
        for (Class<?> clazz : classes) {
            Constructor<?>[] constructors;
            if (!packetClass.isAssignableFrom(clazz) || (constructors = clazz.getDeclaredConstructors()).length < 3) continue;
            for (Constructor<?> constructor : constructors) {
                Class<?>[] parameterTypes = constructor.getParameterTypes();
                if (parameterTypes.length != 7 || parameterTypes[0] != Integer.TYPE || parameterTypes[1] != Integer.TYPE || parameterTypes[2] != Integer.TYPE || parameterTypes[3] != Integer.TYPE || parameterTypes[4] != Byte.TYPE || parameterTypes[5] != Byte.TYPE || parameterTypes[6] != Boolean.TYPE) continue;
                MinecraftMapper.put("S18PacketEntityTeleport", clazz);
                return clazz;
            }
        }
        return null;
    }

    public static void findTitlePacket() {
        Class<?> titleTypeEnum = MinecraftMapper.findClassUsingFieldNames("SUBTITLE");
        if (titleTypeEnum != null && titleTypeEnum.isEnum()) {
            Vector classes = new Vector(MinecraftMapper.getClasses());
            Class<?> packetIfc = MinecraftMapper.get("Packet");
            Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayClient");
            if (packetIfc != null && iNetHandlerPlayClient != null) {
                for (Class<?> candidate : classes) {
                    Class<?>[] declaredClasses;
                    Type[] typeArgs;
                    ParameterizedType paramType;
                    Type rawType;
                    Type genericSuperclass;
                    Type[] genericInterfaces;
                    if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                    boolean implementsCorrectGeneric = false;
                    for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                        Type[] typeArgs2;
                        ParameterizedType paramType2;
                        Type rawType2;
                        if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayClient)) continue;
                        implementsCorrectGeneric = true;
                        break;
                    }
                    if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayClient)) {
                        implementsCorrectGeneric = true;
                    }
                    if (!implementsCorrectGeneric) continue;
                    boolean containsEnum = false;
                    for (Class<?> innerClass : declaredClasses = candidate.getDeclaredClasses()) {
                        if (!innerClass.equals(titleTypeEnum)) continue;
                        containsEnum = true;
                        break;
                    }
                    if (!containsEnum) continue;
                    MinecraftMapper.put("S45PacketTitle", candidate);
                    MinecraftMapper.put("S45PacketTitle.Type", titleTypeEnum);
                    break;
                }
            }
        } else {
            System.out.println("SUBTITLE field'\u00c3\u201e\u00c2\u00b1na sahip enum bulunamad\u00c3\u201e\u00c2\u00b1.");
        }
    }

    public static void findHandshakePacket() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<Integer> intClass = Integer.TYPE;
        Class<String> stringClass = String.class;
        if (packetIfc == null) {
            System.out.println("Packet interface bulunamad\u00c3\u201e\u00c2\u00b1.");
        } else {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean hasGenericInterface = false;
                Class genericHandlerClass = null;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class)) continue;
                    hasGenericInterface = true;
                    genericHandlerClass = (Class)typeArgs2[0];
                    break;
                }
                if (!hasGenericInterface && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class) {
                    hasGenericInterface = true;
                    genericHandlerClass = (Class)typeArgs[0];
                }
                if (!hasGenericInterface || genericHandlerClass == null) continue;
                boolean hasNoArgConstructor = false;
                boolean hasHandshakeConstructor = false;
                Class<?> enumConnectionStateClass = null;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 4 || params[0] != intClass && params[0] != Integer.class || params[1] != stringClass || params[2] != intClass && params[2] != Integer.class || !params[3].isEnum()) continue;
                    enumConnectionStateClass = params[3];
                    hasHandshakeConstructor = true;
                }
                if (!hasNoArgConstructor || !hasHandshakeConstructor || enumConnectionStateClass == null) continue;
                MinecraftMapper.put("C00Handshake", candidate);
                MinecraftMapper.put("INetHandlerHandshakeServer", genericHandlerClass);
                MinecraftMapper.put("EnumConnectionState", enumConnectionStateClass);
                break;
            }
        }
    }

    public static void findc09packet() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
        Class<Integer> intClass = Integer.TYPE;
        if (packetIfc != null && iNetHandlerPlayServer != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasIntConstructor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 1 || params[0] != intClass && params[0] != Integer.class) continue;
                    hasIntConstructor = true;
                }
                if (!hasNoArgConstructor || !hasIntConstructor) continue;
                MinecraftMapper.put("C09PacketHeldItemChange", candidate);
                break;
            }
        }
    }

    public static void findUpdateScorePacket() {
        Class<?> actionEnum = MinecraftMapper.findClassUsingFieldNames("REMOVE", "CHANGE");
        if (actionEnum != null && actionEnum.isEnum()) {
            Vector classes = new Vector(MinecraftMapper.getClasses());
            Class<?> packetIfc = MinecraftMapper.get("Packet");
            Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayClient");
            if (packetIfc != null && iNetHandlerPlayClient != null) {
                for (Class<?> candidate : classes) {
                    Class<?>[] declaredClasses;
                    Type[] typeArgs;
                    ParameterizedType paramType;
                    Type rawType;
                    Type genericSuperclass;
                    Type[] genericInterfaces;
                    if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                    boolean implementsCorrectGeneric = false;
                    for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                        Type[] typeArgs2;
                        ParameterizedType paramType2;
                        Type rawType2;
                        if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayClient)) continue;
                        implementsCorrectGeneric = true;
                        break;
                    }
                    if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayClient)) {
                        implementsCorrectGeneric = true;
                    }
                    if (!implementsCorrectGeneric) continue;
                    boolean containsEnum = false;
                    for (Class<?> innerClass : declaredClasses = candidate.getDeclaredClasses()) {
                        if (!innerClass.equals(actionEnum)) continue;
                        containsEnum = true;
                        break;
                    }
                    if (!containsEnum) continue;
                    MinecraftMapper.put("S3CPacketUpdateScore", candidate);
                    MinecraftMapper.put("S3CPacketUpdateScore.Action", actionEnum);
                    break;
                }
            }
        } else {
            System.out.println("Score Action enum'u bulunamad\u00c3\u201e\u00c2\u00b1.");
        }
    }

    public static void findEntityActionPacket() {
        Class<?> actionEnum = MinecraftMapper.findClassUsingFieldNames("RIDING_JUMP", "STOP_SPRINTING", "OPEN_INVENTORY", "STOP_SNEAKING");
        if (actionEnum != null && actionEnum.isEnum()) {
            Vector classes = new Vector(MinecraftMapper.getClasses());
            Class<?> packetIfc = MinecraftMapper.get("Packet");
            Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
            if (packetIfc != null && iNetHandlerPlayServer != null) {
                for (Class<?> candidate : classes) {
                    Class<?>[] declaredClasses;
                    Type[] typeArgs;
                    ParameterizedType paramType;
                    Type rawType;
                    Type genericSuperclass;
                    Type[] genericInterfaces;
                    if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                    boolean implementsCorrectGeneric = false;
                    for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                        Type[] typeArgs2;
                        ParameterizedType paramType2;
                        Type rawType2;
                        if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                        implementsCorrectGeneric = true;
                        break;
                    }
                    if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                        implementsCorrectGeneric = true;
                    }
                    if (!implementsCorrectGeneric) continue;
                    boolean containsEnum = false;
                    for (Class<?> innerClass : declaredClasses = candidate.getDeclaredClasses()) {
                        if (!innerClass.equals(actionEnum)) continue;
                        containsEnum = true;
                        break;
                    }
                    if (!containsEnum) continue;
                    MinecraftMapper.put("C0BPacketEntityAction", candidate);
                    MinecraftMapper.put("C0BPacketEntityAction.Action", actionEnum);
                    break;
                }
            }
        }
    }

    public static void findInputPacket() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
        Class<Float> floatClass = Float.TYPE;
        Class<Boolean> booleanClass = Boolean.TYPE;
        if (packetIfc != null && iNetHandlerPlayServer != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasInputConstructor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 4 || params[0] != floatClass && params[0] != Float.class || params[1] != floatClass && params[1] != Float.class || params[2] != booleanClass && params[2] != Boolean.class || params[3] != booleanClass && params[3] != Boolean.class) continue;
                    hasInputConstructor = true;
                }
                if (!hasNoArgConstructor || !hasInputConstructor) continue;
                MinecraftMapper.put("C0CPacketInput", candidate);
                break;
            }
        }
    }

    public static Object getFontRenderer() {
        try {
            Object minecraftInstance = MinecraftMapper.getMinecraft();
            Method getFontRendererMethod = MinecraftMapper.getMethod("Minecraft.getFontRendererObj");
            if (minecraftInstance == null) {
                return null;
            }
            if (getFontRendererMethod != null) {
                return getFontRendererMethod.invoke(minecraftInstance, new Object[0]);
            }
            Field fontRendererField = MinecraftMapper.getField("Minecraft.fontRendererObj");
            return fontRendererField != null ? fontRendererField.get(minecraftInstance) : null;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static Field findPublicBooleanDeclaredField(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!Modifier.isPublic(field.getModifiers()) || field.getType() != Boolean.TYPE) continue;
            return field;
        }
        return null;
    }

    public static Class<?> findClassWithFieldsAndExactTypes(Map<String, Class<?>> fieldsAndTypes, List<Class<?>> list) {
        for (Class<?> clazz : list) {
            Field[] fields = clazz.getDeclaredFields();
            boolean allMatch = true;
            for (Map.Entry<String, Class<?>> entry : fieldsAndTypes.entrySet()) {
                try {
                    Field f = clazz.getDeclaredField(entry.getKey());
                    if (f.getType().equals(entry.getValue())) continue;
                    allMatch = false;
                }
                catch (NoSuchFieldException var9) {
                    allMatch = false;
                }
                break;
            }
            if (!allMatch) continue;
            return clazz;
        }
        return null;
    }

    public static void mapIsBlockingASM() throws Exception {
        byte[] bytes;
        Class<?> playerClass = MinecraftMapper.get("EntityPlayer");
        if (!MinecraftMapper.missingClassBytes("mapIsBlockingASM", playerClass, bytes = MinecraftMapper.getClassBytes(playerClass))) {
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 6);
            String foundName = null;
            String foundDesc = null;
            for (MethodNode mn : cn.methods) {
                if (!mn.desc.equals("()Z") || mn.instructions == null || mn.instructions.size() == 0) continue;
                int jumpCount = 0;
                int booleanInvokeCount = 0;
                boolean hasObjectCompare = false;
                boolean hasShortCircuit = false;
                for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    int op = insn.getOpcode();
                    if (insn instanceof JumpInsnNode) {
                        ++jumpCount;
                    }
                    if (op == 165 || op == 166) {
                        hasObjectCompare = true;
                    }
                    if (op == 182) {
                        MethodInsnNode min = (MethodInsnNode)insn;
                        if (min.desc.equals("()Z")) {
                            ++booleanInvokeCount;
                        }
                    }
                    if (op != 153 && op != 154) continue;
                    hasShortCircuit = true;
                }
                if (jumpCount < 2 || booleanInvokeCount < true || !hasObjectCompare || !hasShortCircuit) continue;
                foundName = mn.name;
                foundDesc = mn.desc;
                break;
            }
            if (foundName == null) {
                throw new RuntimeException("isBlocking ASM not found");
            }
            for (Method m : playerClass.getDeclaredMethods()) {
                if (!m.getName().equals(foundName) || !org.objectweb.asm.Type.getMethodDescriptor((Method)m).equals(foundDesc)) continue;
                m.setAccessible(true);
                MinecraftMapper.putMethod("EntityPlayer.isBlocking", m);
                System.out.println("[ASM FINAL] isBlocking FOUND -> " + m);
                return;
            }
            throw new RuntimeException("Reflection match failed");
        }
    }

    public static Method findMethodFromParam(Class<?> clazz, Class<?>[] paramTypes) {
        if (clazz != null && paramTypes != null) {
            for (Class<?> clazz2 : paramTypes) {
                if (clazz2 != null) continue;
                return null;
            }
            for (GenericDeclaration genericDeclaration : clazz.getDeclaredMethods()) {
                Class<?>[] params = ((Method)genericDeclaration).getParameterTypes();
                if (params.length != paramTypes.length) continue;
                boolean match = true;
                for (int i = 0; i < params.length; ++i) {
                    if (params[i] == paramTypes[i]) continue;
                    match = false;
                    break;
                }
                if (!match) continue;
                return genericDeclaration;
            }
            return null;
        }
        return null;
    }

    public static void flag() {
        Class<?> entity = MinecraftMapper.get("Entity");
        if (entity == null) {
            MinecraftMapper.warnMappingSkip("flag", "Entity is not mapped");
        } else {
            Method getFlag = null;
            Method setFlag = null;
            for (Method m : MinecraftMapper.getAllMethods(entity)) {
                if (Modifier.isProtected(m.getModifiers())) {
                    if (m.getReturnType() == Boolean.TYPE && m.getParameterCount() == 1 && m.getParameterTypes()[0] == Integer.TYPE) {
                        getFlag = m;
                    } else if (m.getReturnType() == Void.TYPE && m.getParameterCount() == 2 && m.getParameterTypes()[0] == Integer.TYPE && m.getParameterTypes()[1] == Boolean.TYPE) {
                        setFlag = m;
                    }
                }
                if (getFlag != null && setFlag != null) break;
            }
            if (getFlag != null) {
                MinecraftMapper.putMethod("Entity.getFlag", getFlag);
            }
            if (setFlag != null) {
                setFlag.setAccessible(true);
                MinecraftMapper.putMethod("Entity.setFlag", setFlag);
            }
        }
    }

    public static void mapMoveEntityWithHeadingAndParams() {
        try {
            Class<?> clazz = MinecraftMapper.get("EntityLivingBase");
            byte[] bytes = MinecraftMapper.getClassBytes(clazz);
            if (MinecraftMapper.missingClassBytes("mapMoveEntityWithHeadingAndParams", clazz, bytes)) {
                return;
            }
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            MethodNode moveNode = null;
            String moveName = null;
            for (Object mn : cn.methods) {
                if ((((MethodNode)mn).access & 1) == 0 || !((MethodNode)mn).desc.equals("(FF)V")) continue;
                boolean override = false;
                try {
                    clazz.getSuperclass().getDeclaredMethod(((MethodNode)mn).name, Float.TYPE, Float.TYPE);
                    override = true;
                }
                catch (Exception exception) {
                    // empty catch block
                }
                if (override) continue;
                moveNode = mn;
                moveName = ((MethodNode)mn).name;
                break;
            }
            if (moveNode == null) {
                return;
            }
            MinecraftMapper.putMethod("EntityLivingBase.moveEntityWithHeading", clazz.getDeclaredMethod(moveName, Float.TYPE, Float.TYPE));
            MethodInsnNode callInsn = null;
            block5: for (MethodNode mn : cn.methods) {
                AbstractInsnNode i = mn.instructions.getFirst();
                while (true) {
                    block34: {
                        block33: {
                            if (i == null) break block33;
                            if (i.getOpcode() != 182) break block34;
                            MethodInsnNode min = (MethodInsnNode)i;
                            if (!min.name.equals(moveName) || !min.desc.equals("(FF)V")) break block34;
                            callInsn = min;
                        }
                        if (callInsn == null) continue block5;
                        break block5;
                    }
                    i = i.getNext();
                }
            }
            if (callInsn == null) {
                return;
            }
            FieldInsnNode f1 = null;
            FieldInsnNode f2 = null;
            AbstractInsnNode ins = callInsn.getPrevious();
            int found = 0;
            while (ins != null && found < 2) {
                if (ins.getOpcode() == 182) {
                    AbstractInsnNode prev;
                    MethodInsnNode getter = (MethodInsnNode)ins;
                    if (getter.desc.equals("()F") && (prev = ins.getPrevious()) != null && prev.getOpcode() == 180) {
                        if (found == 0) {
                            f2 = (FieldInsnNode)prev;
                        } else {
                            f1 = (FieldInsnNode)prev;
                        }
                        ++found;
                        ins = prev.getPrevious();
                        continue;
                    }
                }
                ins = ins.getPrevious();
            }
            if (f1 == null || f2 == null) {
                return;
            }
            MinecraftMapper.putField("EntityLivingBase.moveStrafing", clazz.getDeclaredField(f1.name));
            MinecraftMapper.putField("EntityLivingBase.moveForward", clazz.getDeclaredField(f2.name));
            Class<?> floatContainer = MinecraftMapper.get("FloatContainer");
            Field jumpMovementFactor = null;
            Field landMovementFactor = null;
            Field randomYawVelocity = null;
            for (Field f : clazz.getDeclaredFields()) {
                if (f.getType() != floatContainer) continue;
                int mod = f.getModifiers();
                if (Modifier.isPublic(mod) && Modifier.isFinal(mod)) {
                    jumpMovementFactor = f;
                    continue;
                }
                if (Modifier.isPrivate(mod)) {
                    landMovementFactor = f;
                    continue;
                }
                if (!Modifier.isProtected(mod)) continue;
                randomYawVelocity = f;
            }
            if (jumpMovementFactor != null) {
                MinecraftMapper.putField("EntityLivingBase.jumpMovementFactor", jumpMovementFactor);
            }
            if (landMovementFactor != null) {
                MinecraftMapper.putField("EntityLivingBase.landMovementFactor", landMovementFactor);
            }
            if (randomYawVelocity != null) {
                MinecraftMapper.putField("EntityLivingBase.randomYawVelocity", randomYawVelocity);
            }
            if (landMovementFactor == null) {
                return;
            }
            Method getLand = null;
            Method setLand = null;
            String fcOwner = floatContainer.getName().replace('.', '/');
            block9: for (MethodNode mn : cn.methods) {
                FieldInsnNode fin;
                AbstractInsnNode ain;
                if ((mn.access & 1) == 0) continue;
                if (mn.desc.equals("()F")) {
                    for (ain = mn.instructions.getFirst(); ain != null; ain = ain.getNext()) {
                        if (ain.getOpcode() != 180) continue;
                        fin = (FieldInsnNode)ain;
                        if (!fin.name.equals(landMovementFactor.getName())) continue;
                        getLand = clazz.getDeclaredMethod(mn.name, new Class[0]);
                        break;
                    }
                }
                if (!mn.desc.equals("(F)V")) continue;
                for (ain = mn.instructions.getFirst(); ain != null; ain = ain.getNext()) {
                    AbstractInsnNode invoke;
                    AbstractInsnNode fload;
                    if (ain.getOpcode() != 180) continue;
                    fin = (FieldInsnNode)ain;
                    if (!fin.name.equals(landMovementFactor.getName()) || (fload = fin.getNext()) == null || fload.getOpcode() != 23 || (invoke = fload.getNext()) == null || invoke.getOpcode() != 182) continue;
                    MethodInsnNode min = (MethodInsnNode)invoke;
                    if (!min.owner.equals(fcOwner) || !min.desc.equals("(F)F")) continue;
                    setLand = clazz.getDeclaredMethod(mn.name, Float.TYPE);
                    continue block9;
                }
            }
            if (getLand != null) {
                MinecraftMapper.putMethod("EntityLivingBase.getLandMovementFactor", getLand);
            }
            if (setLand != null) {
                MinecraftMapper.putMethod("EntityLivingBase.setLandMovementFactor", setLand);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static String opcodeName(int op) {
        if (op == -1) {
            return "NONOP";
        }
        switch (op) {
            case 0: {
                return "NOP";
            }
            case 11: {
                return "FCONST_0";
            }
            case 12: {
                return "FCONST_1";
            }
            case 23: {
                return "FLOAD";
            }
            case 25: {
                return "ALOAD";
            }
            case 89: {
                return "DUP";
            }
            case 174: {
                return "FRETURN";
            }
            case 177: {
                return "RETURN";
            }
            case 180: {
                return "GETFIELD";
            }
            case 181: {
                return "PUTFIELD";
            }
            case 182: {
                return "INVOKEVIRTUAL";
            }
            case 184: {
                return "INVOKESTATIC";
            }
        }
        return "OP_" + op;
    }

    public static void mapPerformHurtAnimation() {
        try {
            Class<?> clazz = MinecraftMapper.get("EntityLivingBase");
            byte[] bytes = MinecraftMapper.getClassBytes(clazz);
            if (MinecraftMapper.missingClassBytes("mapPerformHurtAnimation", clazz, bytes)) {
                return;
            }
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            MethodNode target = null;
            FieldInsnNode hurtTime = null;
            FieldInsnNode maxHurtTime = null;
            FieldInsnNode attackedAtYaw = null;
            for (MethodNode mn : cn.methods) {
                if (!mn.desc.equals("()V")) continue;
                ArrayList<FieldInsnNode> putFields = new ArrayList<FieldInsnNode>();
                boolean writesZeroFloat = false;
                for (AbstractInsnNode ain = mn.instructions.getFirst(); ain != null; ain = ain.getNext()) {
                    AbstractInsnNode next;
                    if (ain.getOpcode() == 181) {
                        putFields.add((FieldInsnNode)ain);
                    }
                    if (ain.getOpcode() != 11 || (next = ain.getNext()) == null || next.getOpcode() != 181) continue;
                    writesZeroFloat = true;
                    attackedAtYaw = (FieldInsnNode)next;
                }
                if (putFields.size() != 3 || !writesZeroFloat) continue;
                for (FieldInsnNode fin : putFields) {
                    String desc = fin.desc;
                    if (!desc.equals("I")) continue;
                    if (hurtTime == null) {
                        hurtTime = fin;
                        continue;
                    }
                    maxHurtTime = fin;
                }
                if (hurtTime == null || maxHurtTime == null || attackedAtYaw == null) continue;
                target = mn;
                break;
            }
            if (target == null) {
                return;
            }
            MinecraftMapper.putMethod("EntityLivingBase.performHurtAnimation", clazz.getDeclaredMethod(target.name, new Class[0]));
            MinecraftMapper.putField("EntityLivingBase.hurtTime", clazz.getDeclaredField(maxHurtTime.name));
            MinecraftMapper.putField("EntityLivingBase.maxHurtTime", clazz.getDeclaredField(hurtTime.name));
            MinecraftMapper.putField("EntityLivingBase.attackedAtYaw", clazz.getDeclaredField(attackedAtYaw.name));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static Class<?> findS0BPacketAnimation() {
        Class<?> entityClass = MinecraftMapper.get("Entity");
        if (entityClass == null) {
            System.out.println("\u00c3\u00a2\u00c2\u009d\u00c5\u2019 Entity s\u00c3\u201e\u00c2\u00b1n\u00c3\u201e\u00c2\u00b1f\u00c3\u201e\u00c2\u00b1 tan\u00c3\u201e\u00c2\u00b1ml\u00c3\u201e\u00c2\u00b1 de\u00c3\u201e\u00c5\u00b8il, \u00c3\u0192\u00c2\u00b6nce Entity bulunmal\u00c3\u201e\u00c2\u00b1.");
            return null;
        }
        for (Class<?> clazz : MinecraftMapper.getClasses()) {
            try {
                byte[] bytes;
                long ioExceptionCount;
                Constructor<?>[] constructors = clazz.getDeclaredConstructors();
                Field[] fields = clazz.getDeclaredFields();
                Method[] methods = clazz.getDeclaredMethods();
                long privateIntFields = Arrays.stream(fields).filter(f -> Modifier.isPrivate(f.getModifiers()) && f.getType() == Integer.TYPE).count();
                if (privateIntFields != 2L) continue;
                boolean hasEmptyConstructor = false;
                boolean hasEntityIntConstructor = false;
                for (Constructor<?> ctor : constructors) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasEmptyConstructor = true;
                        continue;
                    }
                    if (params.length != 2 || params[0] != entityClass || params[1] != Integer.TYPE) continue;
                    hasEntityIntConstructor = true;
                }
                if (!hasEmptyConstructor || !hasEntityIntConstructor || (ioExceptionCount = Arrays.stream(methods).filter(m -> Arrays.asList(m.getExceptionTypes()).contains(IOException.class)).count()) != 2L || MinecraftMapper.missingClassBytes("findProtocolClass", clazz, bytes = MinecraftMapper.getClassBytes(clazz))) continue;
                ClassReader cr = new ClassReader(bytes);
                ClassNode cn = new ClassNode();
                cr.accept((ClassVisitor)cn, 0);
                MethodNode ctor = null;
                for (MethodNode mn : cn.methods) {
                    org.objectweb.asm.Type[] args;
                    if (!mn.name.equals("<init>") || (args = org.objectweb.asm.Type.getArgumentTypes((String)mn.desc)).length != 2 || !args[0].getClassName().equals(entityClass.getName()) || args[1].getSort() != 5) continue;
                    ctor = mn;
                    break;
                }
                if (ctor == null) continue;
                ArrayList<FieldInsnNode> intPuts = new ArrayList<FieldInsnNode>();
                MethodInsnNode getEntityIdCall = null;
                for (AbstractInsnNode insn : ctor.instructions) {
                    if (insn.getOpcode() == 181) {
                        FieldInsnNode fin = (FieldInsnNode)insn;
                        if (!fin.owner.equals(cn.name) || !fin.desc.equals("I")) continue;
                        intPuts.add(fin);
                        continue;
                    }
                    if (insn.getOpcode() != 182) continue;
                    MethodInsnNode min = (MethodInsnNode)insn;
                    if (!min.owner.equals(org.objectweb.asm.Type.getInternalName(entityClass)) || !min.desc.equals("()I")) continue;
                    getEntityIdCall = min;
                }
                if (intPuts.size() != 2 || getEntityIdCall == null) continue;
                FieldInsnNode entityIdField = (FieldInsnNode)intPuts.get(0);
                FieldInsnNode typeField = (FieldInsnNode)intPuts.get(1);
                MinecraftMapper.putField("S0BPacketAnimation.entityId", clazz.getDeclaredField(entityIdField.name));
                MinecraftMapper.putField("S0BPacketAnimation.type", clazz.getDeclaredField(typeField.name));
                Method getEntityId = entityClass.getDeclaredMethod(getEntityIdCall.name, new Class[0]);
                MinecraftMapper.putMethod("Entity.getEntityId", getEntityId);
                MinecraftMapper.findAndSaveINetHandlerPlayClient(clazz);
                return clazz;
            }
            catch (Throwable throwable) {
            }
        }
        return null;
    }

    private static void findAndSaveINetHandlerPlayClient(Class<?> packetClass) {
        Class<?> packetInterface = MinecraftMapper.get("Packet");
        if (packetInterface == null) {
            System.out.println("Packet interface'i bulunamad\u00c3\u201e\u00c2\u00b1");
        } else {
            Type[] typeArgs;
            ParameterizedType paramType;
            Type rawType;
            Type[] genericInterfaces;
            for (Type genericInterface : genericInterfaces = packetClass.getGenericInterfaces()) {
                Type firstArg;
                Type[] typeArgs2;
                ParameterizedType paramType2;
                Type rawType2;
                if (!(genericInterface instanceof ParameterizedType) || !(rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()).equals(packetInterface) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !MinecraftMapper.extractAndSaveHandlerClientClass(firstArg = typeArgs2[0])) continue;
                return;
            }
            Type genericSuperclass = packetClass.getGenericSuperclass();
            if (genericSuperclass instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && packetInterface.isAssignableFrom((Class)rawType) && (typeArgs = paramType.getActualTypeArguments()).length > 0) {
                Type firstArg = typeArgs[0];
                MinecraftMapper.extractAndSaveHandlerClientClass(firstArg);
            }
        }
    }

    public static void mapVelocityFields(Class<?> velocityPacket) {
        try {
            String owner = velocityPacket.getName().replace('.', '/');
            byte[] classBytes = MinecraftMapper.getClassBytes(velocityPacket);
            if (classBytes == null) {
                MinecraftMapper.mapVelocityFieldsFallback(velocityPacket);
                return;
            }
            ClassReader cr = new ClassReader(classBytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            ArrayList fieldNames = new ArrayList();
            for (MethodNode mn : cn.methods) {
                if (!"<init>".equals(mn.name)) continue;
                ArrayList<String> candidates = new ArrayList<String>();
                for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    if (insn.getOpcode() != 181) continue;
                    FieldInsnNode f = (FieldInsnNode)insn;
                    if (!f.owner.equals(owner) || !"I".equals(f.desc)) continue;
                    candidates.add(f.name);
                }
                if (candidates.size() <= fieldNames.size()) continue;
                fieldNames = candidates;
            }
            if (fieldNames.size() < 3) {
                MinecraftMapper.mapVelocityFieldsFallback(velocityPacket);
                return;
            }
            int startIdx = fieldNames.size() >= 4 ? 1 : 0;
            Field fx = velocityPacket.getDeclaredField((String)fieldNames.get(startIdx));
            Field fy = velocityPacket.getDeclaredField((String)fieldNames.get(startIdx + 1));
            Field fz = velocityPacket.getDeclaredField((String)fieldNames.get(startIdx + 2));
            fx.setAccessible(true);
            fy.setAccessible(true);
            fz.setAccessible(true);
            MinecraftMapper.putField("S12PacketEntityVelocity.motionX", fx);
            MinecraftMapper.putField("S12PacketEntityVelocity.motionY", fy);
            MinecraftMapper.putField("S12PacketEntityVelocity.motionZ", fz);
            Logger.info("[VelocityMap] Mapped motionX=" + fx.getName() + " motionY=" + fy.getName() + " motionZ=" + fz.getName());
        }
        catch (Throwable var10) {
            Logger.warn("[VelocityMap] mapVelocityFields failed: " + var10.getMessage());
            MinecraftMapper.mapVelocityFieldsFallback(velocityPacket);
        }
    }

    private static void mapVelocityFieldsFallback(Class<?> velocityPacket) {
        try {
            ArrayList<Field> intFields = new ArrayList<Field>();
            for (Field f : velocityPacket.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || f.getType() != Integer.TYPE) continue;
                f.setAccessible(true);
                intFields.add(f);
            }
            if (intFields.size() >= 4) {
                MinecraftMapper.putField("S12PacketEntityVelocity.motionX", (Field)intFields.get(1));
                MinecraftMapper.putField("S12PacketEntityVelocity.motionY", (Field)intFields.get(2));
                MinecraftMapper.putField("S12PacketEntityVelocity.motionZ", (Field)intFields.get(3));
                Logger.info("[VelocityMap] Fallback mapped motionX=" + ((Field)intFields.get(1)).getName() + " motionY=" + ((Field)intFields.get(2)).getName() + " motionZ=" + ((Field)intFields.get(3)).getName());
            } else if (intFields.size() == 3) {
                MinecraftMapper.putField("S12PacketEntityVelocity.motionX", (Field)intFields.get(0));
                MinecraftMapper.putField("S12PacketEntityVelocity.motionY", (Field)intFields.get(1));
                MinecraftMapper.putField("S12PacketEntityVelocity.motionZ", (Field)intFields.get(2));
                Logger.info("[VelocityMap] Fallback(3) mapped motionX=" + ((Field)intFields.get(0)).getName() + " motionY=" + ((Field)intFields.get(1)).getName() + " motionZ=" + ((Field)intFields.get(2)).getName());
            } else {
                Logger.warn("[VelocityMap] Cannot map velocity fields: only " + intFields.size() + " int fields found");
            }
        }
        catch (Throwable t) {
            Logger.warn("[VelocityMap] mapVelocityFieldsFallback failed: " + t.getMessage());
        }
    }

    public static void mapVelocityMethods(Class<?> velocityPacket) {
        try {
            String owner = velocityPacket.getName().replace('.', '/');
            byte[] classBytes = MinecraftMapper.getClassBytes(velocityPacket);
            if (classBytes == null) {
                return;
            }
            ClassReader cr = new ClassReader(classBytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            Field fx = MinecraftMapper.getField("S12PacketEntityVelocity.motionX");
            Field fy = MinecraftMapper.getField("S12PacketEntityVelocity.motionY");
            Field fz = MinecraftMapper.getField("S12PacketEntityVelocity.motionZ");
            if (fx == null || fy == null || fz == null) {
                return;
            }
            String xName = fx.getName();
            String yName = fy.getName();
            String zName = fz.getName();
            block4: for (MethodNode mn : cn.methods) {
                if (!"()D".equals(mn.desc)) continue;
                for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    Method m;
                    if (insn.getOpcode() != 180) continue;
                    FieldInsnNode fin = (FieldInsnNode)insn;
                    if (!fin.owner.equals(owner)) continue;
                    try {
                        m = velocityPacket.getDeclaredMethod(mn.name, new Class[0]);
                        m.setAccessible(true);
                    }
                    catch (Throwable var17) {
                        continue block4;
                    }
                    if (fin.name.equals(xName)) {
                        MinecraftMapper.putMethod("S12PacketEntityVelocity.getMotionX", m);
                        continue block4;
                    }
                    if (fin.name.equals(yName)) {
                        MinecraftMapper.putMethod("S12PacketEntityVelocity.getMotionY", m);
                        continue block4;
                    }
                    if (!fin.name.equals(zName)) continue block4;
                    MinecraftMapper.putMethod("S12PacketEntityVelocity.getMotionZ", m);
                    continue block4;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static void findS3FPacket() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayClient");
        Class<?> packetBufferClass = MinecraftMapper.get("PacketBuffer");
        if (packetIfc != null && iNetHandlerPlayClient != null && packetBufferClass != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayClient)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayClient)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasStringPacketBufferConstructor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 2 || params[0] != String.class || params[1] != packetBufferClass) continue;
                    hasStringPacketBufferConstructor = true;
                }
                if (!hasNoArgConstructor || !hasStringPacketBufferConstructor) continue;
                MinecraftMapper.put("S3FPacketCustomPayload", candidate);
            }
        }
    }

    public static void findC17Custom() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayServer");
        Class<?> packetBufferClass = MinecraftMapper.get("PacketBuffer");
        if (packetIfc != null && iNetHandlerPlayClient != null && packetBufferClass != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayClient)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayClient)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasStringPacketBufferConstructor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 2 || params[0] != String.class || params[1] != packetBufferClass) continue;
                    hasStringPacketBufferConstructor = true;
                }
                if (!hasNoArgConstructor || !hasStringPacketBufferConstructor) continue;
                MinecraftMapper.put("C17PacketCustomPayload", candidate);
            }
        }
    }

    public static void findWorldBorderPacket() {
        Class<?> actionEnum = MinecraftMapper.findClassUsingFieldNames("SET_SIZE", "LERP_SIZE", "SET_CENTER", "SET_WARNING_TIME");
        if (actionEnum != null && actionEnum.isEnum()) {
            Vector classes = new Vector(MinecraftMapper.getClasses());
            Class<?> packetIfc = MinecraftMapper.get("Packet");
            Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayClient");
            if (packetIfc != null && iNetHandlerPlayClient != null) {
                for (Class<?> candidate : classes) {
                    Class<?>[] declaredClasses;
                    Type[] typeArgs;
                    ParameterizedType paramType;
                    Type rawType;
                    Type genericSuperclass;
                    Type[] genericInterfaces;
                    if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                    boolean implementsCorrectGeneric = false;
                    for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                        Type[] typeArgs2;
                        ParameterizedType paramType2;
                        Type rawType2;
                        if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayClient)) continue;
                        implementsCorrectGeneric = true;
                        break;
                    }
                    if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayClient)) {
                        implementsCorrectGeneric = true;
                    }
                    if (!implementsCorrectGeneric) continue;
                    boolean containsEnum = false;
                    for (Class<?> innerClass : declaredClasses = candidate.getDeclaredClasses()) {
                        if (!innerClass.equals(actionEnum)) continue;
                        containsEnum = true;
                        break;
                    }
                    if (!containsEnum) continue;
                    MinecraftMapper.put("S44PacketWorldBorder", candidate);
                    MinecraftMapper.put("S44PacketWorldBorder$Action", actionEnum);
                    break;
                }
            }
        } else {
            System.out.println("WorldBorder Action enum'u bulunamad\u00c3\u201e\u00c2\u00b1.");
        }
    }

    public static void finds33packet() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayClient");
        Class<?> worldClass = MinecraftMapper.get("World");
        Class<?> blockPosClass = MinecraftMapper.get("BlockPos");
        Class<?> iChatComponentClass = MinecraftMapper.get("IChatComponent");
        if (packetIfc != null && iNetHandlerPlayClient != null && worldClass != null && blockPosClass != null && iChatComponentClass != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayClient)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayClient)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasWorldBlockPosIChatComponentConstructor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 3) continue;
                    if (params[0] == worldClass && params[1] == blockPosClass && params[2] == iChatComponentClass) {
                        hasWorldBlockPosIChatComponentConstructor = true;
                    }
                    if (params[0] != worldClass || params[1] != blockPosClass || !params[2].isArray() || params[2].getComponentType() != iChatComponentClass) continue;
                    hasWorldBlockPosIChatComponentConstructor = true;
                }
                if (!hasNoArgConstructor || !hasWorldBlockPosIChatComponentConstructor) continue;
                MinecraftMapper.put("S33PacketUpdateSign", candidate);
            }
        }
    }

    public static void findC0DPacketCloseWindow() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
        if (packetIfc != null && iNetHandlerPlayServer != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasIntField = false;
                for (Field field : candidate.getDeclaredFields()) {
                    if (field.getType() != Integer.TYPE) continue;
                    hasIntField = true;
                    break;
                }
                if (!hasIntField) continue;
                Constructor<?> voidConstructor = null;
                Constructor<?> intConstructor = null;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        voidConstructor = ctor;
                    }
                    if (params.length != 1 || params[0] != Integer.TYPE) continue;
                    intConstructor = ctor;
                    boolean hasIntFieldAssignment = false;
                    try {
                        ctor.setAccessible(true);
                        Object instance = ctor.newInstance(123);
                        for (Field field : candidate.getDeclaredFields()) {
                            if (field.getType() != Integer.TYPE) continue;
                            field.setAccessible(true);
                            int value = field.getInt(instance);
                            if (value != 123) continue;
                            hasIntFieldAssignment = true;
                            break;
                        }
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    if (hasIntFieldAssignment) continue;
                    intConstructor = null;
                }
                if (voidConstructor == null || intConstructor == null) continue;
                MinecraftMapper.put("C0DPacketCloseWindow", candidate);
                break;
            }
        }
    }

    public static void findEntityThrowable() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> entityClass = MinecraftMapper.get("Entity");
        Class<?> worldClass = MinecraftMapper.get("World");
        Class<?> livingClass = MinecraftMapper.get("EntityLivingBase");
        if (entityClass != null && worldClass != null && livingClass != null) {
            for (Class<?> candidate : classes) {
                Class<?>[] interfaces;
                if (!Modifier.isAbstract(candidate.getModifiers()) || candidate.getSuperclass() != entityClass || (interfaces = candidate.getInterfaces()).length != 1) continue;
                Class<?> projectileInterface = interfaces[0];
                MinecraftMapper.put("IProjectile", projectileInterface);
                boolean hasWorldCtor = false;
                boolean hasWorldLivingCtor = false;
                boolean hasWorldXYZCtor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] p = ctor.getParameterTypes();
                    if (p.length == 1 && p[0] == worldClass) {
                        hasWorldCtor = true;
                    }
                    if (p.length == 2 && p[0] == worldClass && p[1] == livingClass) {
                        hasWorldLivingCtor = true;
                    }
                    if (p.length != 4 || p[0] != worldClass || p[1] != Double.TYPE || p[2] != Double.TYPE || p[3] != Double.TYPE) continue;
                    hasWorldXYZCtor = true;
                }
                if (!hasWorldCtor || !hasWorldLivingCtor || !hasWorldXYZCtor) continue;
                MinecraftMapper.put("EntityThrowable", candidate);
                return;
            }
        }
    }

    public static void worldacces() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> blockPosClass = MinecraftMapper.get("BlockPos");
        Class<?> entityPlayerClass = MinecraftMapper.get("EntityPlayer");
        Class<?> entityClass = MinecraftMapper.get("Entity");
        if (blockPosClass != null && entityPlayerClass != null && entityClass != null) {
            for (Class<?> candidate : classes) {
                if (!candidate.isInterface()) continue;
                boolean hasRequiredMethod = false;
                int matchingMethods = 0;
                for (Method method : candidate.getDeclaredMethods()) {
                    Class<?>[] paramTypes = method.getParameterTypes();
                    if (paramTypes.length == 3 && paramTypes[0] == Integer.TYPE && paramTypes[1] == blockPosClass && paramTypes[2] == Integer.TYPE) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 4 && paramTypes[0] == entityPlayerClass && paramTypes[1] == Integer.TYPE && paramTypes[2] == blockPosClass && paramTypes[3] == Integer.TYPE) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 1 && paramTypes[0] == entityClass) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 2 && paramTypes[0] == String.class && paramTypes[1] == blockPosClass) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 9 && paramTypes[0] == Integer.TYPE && paramTypes[1] == Boolean.TYPE && paramTypes[2] == Double.TYPE && paramTypes[3] == Double.TYPE && paramTypes[4] == Double.TYPE && paramTypes[5] == Double.TYPE && paramTypes[6] == Double.TYPE && paramTypes[7] == Double.TYPE && paramTypes[8] == int[].class) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 7 && paramTypes[0] == entityPlayerClass && paramTypes[1] == String.class && paramTypes[2] == Double.TYPE && paramTypes[3] == Double.TYPE && paramTypes[4] == Double.TYPE && paramTypes[5] == Float.TYPE && paramTypes[6] == Float.TYPE) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 6 && paramTypes[0] == Integer.TYPE && paramTypes[1] == Integer.TYPE && paramTypes[2] == Integer.TYPE && paramTypes[3] == Integer.TYPE && paramTypes[4] == Integer.TYPE && paramTypes[5] == Integer.TYPE) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 1 && paramTypes[0] == blockPosClass) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length == 3 && paramTypes[0] == Integer.TYPE && paramTypes[1] == blockPosClass && paramTypes[2] == Integer.TYPE) {
                        ++matchingMethods;
                        continue;
                    }
                    if (paramTypes.length != 6 || paramTypes[0] != String.class || paramTypes[1] != Double.TYPE || paramTypes[2] != Double.TYPE || paramTypes[3] != Double.TYPE || paramTypes[4] != Float.TYPE || paramTypes[5] != Float.TYPE) continue;
                    ++matchingMethods;
                }
                if (matchingMethods >= 5) {
                    hasRequiredMethod = true;
                }
                if (!hasRequiredMethod) continue;
                MinecraftMapper.put("IWorldAccess", candidate);
                break;
            }
        }
    }

    public static void findrenderGlobal() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> iWorldAccess = MinecraftMapper.get("IWorldAccess");
        Class<?> iResourceManagerReloadListener = MinecraftMapper.get("IResourceManagerReloadListener");
        if (iWorldAccess != null && iResourceManagerReloadListener != null) {
            for (Class<?> candidate : classes) {
                boolean implementsIWorldAccess = iWorldAccess.isAssignableFrom(candidate);
                boolean implementsIResourceManagerReloadListener = iResourceManagerReloadListener.isAssignableFrom(candidate);
                if (!implementsIWorldAccess || !implementsIResourceManagerReloadListener) continue;
                MinecraftMapper.put("RenderGlobal", candidate);
                return;
            }
        }
    }

    public static void findTimerClass() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> timerContainerClass = MinecraftMapper.get("TimerContainer");
        if (timerContainerClass != null) {
            for (Class<?> candidate : classes) {
                if (candidate.isEnum() || candidate.isInterface() || candidate.isAnnotation()) continue;
                boolean hasTimerContainerField = false;
                String timerContainerFieldName = null;
                for (Field field : candidate.getDeclaredFields()) {
                    Class<?> fieldType = field.getType();
                    if (!fieldType.getName().equals(timerContainerClass.getName())) continue;
                    hasTimerContainerField = true;
                    timerContainerFieldName = field.getName();
                    break;
                }
                if (!hasTimerContainerField) continue;
                int constructorCount = 0;
                boolean hasSingleFloatConstructor = false;
                Object targetConstructor = null;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    ++constructorCount;
                    Class<?>[] params = ctor.getParameterTypes();
                    StringBuilder paramInfo = new StringBuilder();
                    for (Class<?> param : params) {
                        paramInfo.append(param.getSimpleName()).append(", ");
                    }
                    if (paramInfo.length() > 0) {
                        paramInfo.setLength(paramInfo.length() - 2);
                    }
                    if (params.length != 1 || params[0] != Float.TYPE) continue;
                    hasSingleFloatConstructor = true;
                }
                boolean bl = hasTimerContainerField && constructorCount == 1 && hasSingleFloatConstructor;
                if (!bl) continue;
                MinecraftMapper.put("Timer", candidate);
                return;
            }
        }
    }

    public static void findEntityBoat() {
        for (Class<?> candidate : new Vector(MinecraftMapper.getClasses())) {
            if (!candidate.getName().equals("crsecond.\u00c3\u2022\u00c2\u00a7\u00c3\u2019\u00c5\u2019")) continue;
            MinecraftMapper.put("teiste", candidate);
            return;
        }
    }

    /*
     * WARNING - void declaration
     */
    public static void findTimerContainer() {
        for (Class<?> candidate : new Vector(MinecraftMapper.getClasses())) {
            void var13_17;
            if (candidate.isEnum() || candidate.isInterface() || candidate.isAnnotation()) continue;
            int nonStaticLongFieldCount = 0;
            int staticLongFieldCount = 0;
            int booleanFieldCount = 0;
            int totalLongFields = 0;
            for (Field field : candidate.getDeclaredFields()) {
                Constructor<?>[] fieldType = field.getType();
                int isStatic = Modifier.isStatic(field.getModifiers());
                if (fieldType == Long.TYPE) {
                    ++totalLongFields;
                    if (isStatic != 0) {
                        ++staticLongFieldCount;
                    } else {
                        ++nonStaticLongFieldCount;
                    }
                }
                if (fieldType != Boolean.TYPE || isStatic != 0) continue;
                ++booleanFieldCount;
            }
            boolean hasBooleanField = booleanFieldCount >= 1;
            int constructorCount = 0;
            boolean hasDoubleBooleanConstructor = false;
            boolean hasDoubleConstructor = false;
            for (Constructor<?> constructor : candidate.getDeclaredConstructors()) {
                ++constructorCount;
                Class<?>[] params = constructor.getParameterTypes();
                StringBuilder paramInfo = new StringBuilder();
                for (Class<?> param : params) {
                    paramInfo.append(param.getSimpleName()).append(", ");
                }
                if (paramInfo.length() > 0) {
                    paramInfo.setLength(paramInfo.length() - 2);
                }
                if (params.length == 2) {
                    boolean hasDouble = false;
                    boolean hasBoolean = false;
                    for (Class<?> param : params) {
                        if (param == Double.TYPE) {
                            hasDouble = true;
                        }
                        if (param != Boolean.TYPE) continue;
                        hasBoolean = true;
                    }
                    if (hasDouble && hasBoolean) {
                        hasDoubleBooleanConstructor = true;
                    }
                }
                if (params.length != 1 || params[0] != Double.TYPE) continue;
                hasDoubleConstructor = true;
            }
            boolean foundTargetMethod = false;
            boolean hasHashCodeMethod = false;
            Method targetMethod = null;
            for (Method method : candidate.getDeclaredMethods()) {
                boolean isPublic = Modifier.isPublic(method.getModifiers());
                Class<?> returnType = method.getReturnType();
                Class<?>[] paramTypes = method.getParameterTypes();
                if (method.getName().equals("hashCode") && returnType == Integer.TYPE && paramTypes.length == 0) {
                    hasHashCodeMethod = true;
                    continue;
                }
                if (!isPublic || returnType != Void.TYPE || paramTypes.length != 1 || paramTypes[0] != Double.TYPE) continue;
                foundTargetMethod = true;
                targetMethod = method;
            }
            boolean bl = false;
            for (Field field : candidate.getDeclaredFields()) {
                if (!Modifier.isStatic(field.getModifiers())) continue;
                ++var13_17;
            }
            boolean hasReasonableStaticFields = var13_17 <= 5;
            boolean allCriteriaMet = totalLongFields >= 3 && hasBooleanField && constructorCount == 2 && hasDoubleBooleanConstructor && hasDoubleConstructor && foundTargetMethod && hasHashCodeMethod && hasReasonableStaticFields;
            if (!allCriteriaMet) continue;
            if (targetMethod != null) {
                MinecraftMapper.putMethod("TimerContainer.getValue", targetMethod);
            }
            MinecraftMapper.put("TimerContainer", candidate);
            return;
        }
    }

    public static void finds37andstatbase() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayClient");
        Class<?> worldClass = MinecraftMapper.get("World");
        Class<?> blockPosClass = MinecraftMapper.get("BlockPos");
        Class<?> iChatComponentClass = MinecraftMapper.get("IChatComponent");
        if (packetIfc != null && iNetHandlerPlayClient != null && worldClass != null && blockPosClass != null && iChatComponentClass != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayClient)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayClient)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasMapConstructor = false;
                Class statBaseClass = null;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    ParameterizedType mapType;
                    Type[] mapTypeArgs;
                    Type[] genericParameterTypes;
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 1 || !Map.class.isAssignableFrom(params[0]) || (genericParameterTypes = ctor.getGenericParameterTypes()).length <= 0 || !(genericParameterTypes[0] instanceof ParameterizedType) || (mapTypeArgs = (mapType = (ParameterizedType)genericParameterTypes[0]).getActualTypeArguments()).length != 2 || !(mapTypeArgs[0] instanceof Class) || !(mapTypeArgs[1] instanceof Class) || !mapTypeArgs[1].equals(Integer.class)) continue;
                    statBaseClass = (Class)mapTypeArgs[0];
                    hasMapConstructor = true;
                }
                if (!hasNoArgConstructor || !hasMapConstructor || statBaseClass == null) continue;
                MinecraftMapper.put("S37PacketStatistics", candidate);
                MinecraftMapper.put("StatBase", statBaseClass);
                break;
            }
        }
    }

    public static void finds02() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayClient");
        Class<?> iChatComponentClass = MinecraftMapper.get("IChatComponent");
        if (packetIfc != null && iNetHandlerPlayClient != null && iChatComponentClass != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayClient)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayClient)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasIChatComponentConstructor = false;
                boolean hasIChatComponentByteConstructor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length == 1 && params[0] == iChatComponentClass) {
                        hasIChatComponentConstructor = true;
                    }
                    if (params.length != 2 || params[0] != iChatComponentClass || params[1] != Byte.TYPE) continue;
                    hasIChatComponentByteConstructor = true;
                }
                if (!hasNoArgConstructor || !hasIChatComponentConstructor || !hasIChatComponentByteConstructor) continue;
                MinecraftMapper.put("S02PacketChat", candidate);
                MinecraftMapper.findAndPutChatComponentMethod(candidate, iChatComponentClass);
                break;
            }
        }
    }

    private static void findAndPutChatComponentMethod(Class<?> packetClass, Class<?> iChatComponentClass) {
        for (Method method : packetClass.getDeclaredMethods()) {
            if (!Modifier.isPublic(method.getModifiers()) || method.getReturnType() != iChatComponentClass || method.getParameterCount() != 0) continue;
            MinecraftMapper.putMethod("S02PacketChat.getChatComponent", method);
            return;
        }
        for (Method method : packetClass.getDeclaredMethods()) {
            if (method.getReturnType() != iChatComponentClass || method.getParameterCount() != 0) continue;
            MinecraftMapper.putMethod("S02PacketChat.getChatComponent", method);
            return;
        }
    }

    public static void findResourcePackStatusPacket() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
        Class<String> stringClass = String.class;
        if (packetIfc != null && iNetHandlerPlayServer != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasStringAndEnumConstructor = false;
                Class<?> actionEnumClass = null;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 2 || params[0] != stringClass || !params[1].isEnum()) continue;
                    actionEnumClass = params[1];
                    Class<?> foundEnumClass = MinecraftMapper.findClassUsingFieldNames("SUCCESSFULLY_LOADED", "DECLINED", "FAILED_DOWNLOAD", "ACCEPTED");
                    if (foundEnumClass == null || !foundEnumClass.equals(actionEnumClass)) continue;
                    hasStringAndEnumConstructor = true;
                }
                if (!hasNoArgConstructor || !hasStringAndEnumConstructor || actionEnumClass == null) continue;
                MinecraftMapper.put("C19PacketResourcePackStatus", candidate);
                MinecraftMapper.put("C19PacketResourcePackStatus.Action", actionEnumClass);
                break;
            }
        }
    }

    public static void findClickWindowPacket() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
        Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
        Class<Integer> intClass = Integer.TYPE;
        Class<Short> shortClass = Short.TYPE;
        if (packetIfc != null && iNetHandlerPlayServer != null && itemStackClass != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasComplexConstructor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 6 || params[0] != intClass || params[1] != intClass || params[2] != intClass || params[3] != intClass || params[4] != itemStackClass || params[5] != shortClass) continue;
                    hasComplexConstructor = true;
                }
                if (!hasNoArgConstructor || !hasComplexConstructor) continue;
                MinecraftMapper.put("C0EPacketClickWindow", candidate);
                break;
            }
        }
    }

    public static void findC10PacketCreativeInventoryAction() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
        Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
        if (packetIfc != null && iNetHandlerPlayServer != null && itemStackClass != null) {
            for (Class<?> candidate : classes) {
                Class<?> c0e;
                Object[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgCtor = false;
                boolean hasC10Ctor = false;
                boolean hasSixParamCtor = false;
                typeArgs = candidate.getDeclaredConstructors();
                int n = typeArgs.length;
                for (int i = 0; i < n; ++i) {
                    Constructor<?> ctor = typeArgs[i];
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgCtor = true;
                    }
                    if (params.length == 2 && params[0] == Integer.TYPE && params[1] == itemStackClass) {
                        hasC10Ctor = true;
                    }
                    if (params.length != 6) continue;
                    hasSixParamCtor = true;
                }
                if (!hasNoArgCtor || !hasC10Ctor || hasSixParamCtor || (c0e = MinecraftMapper.get("C0EPacketClickWindow")) != null && c0e.equals(candidate)) continue;
                MinecraftMapper.put("C10PacketCreativeInventoryAction", candidate);
                System.out.println("[C10] C10PacketCreativeInventoryAction bulundu: " + candidate.getName());
                break;
            }
        } else {
            System.out.println("[C10] Gerekli classlar bulunamad\u00c3\u201e\u00c2\u00b1!");
        }
    }

    public static void findUpdateSignPacket() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
        Class<?> blockPosClass = MinecraftMapper.get("BlockPos");
        Class<?> iChatComponentClass = MinecraftMapper.get("IChatComponent");
        if (packetIfc != null && iNetHandlerPlayServer != null && blockPosClass != null && iChatComponentClass != null) {
            for (Class<?> candidate : classes) {
                Type[] typeArgs;
                ParameterizedType paramType;
                Type rawType;
                Type genericSuperclass;
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                boolean implementsCorrectGeneric = false;
                for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs2;
                    ParameterizedType paramType2;
                    Type rawType2;
                    if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                    implementsCorrectGeneric = true;
                    break;
                }
                if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                    implementsCorrectGeneric = true;
                }
                if (!implementsCorrectGeneric) continue;
                boolean hasNoArgConstructor = false;
                boolean hasBlockPosAndIChatComponentConstructor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        hasNoArgConstructor = true;
                    }
                    if (params.length != 2 || params[0] != blockPosClass || !params[1].isArray() || params[1].getComponentType() != iChatComponentClass) continue;
                    hasBlockPosAndIChatComponentConstructor = true;
                }
                if (!hasNoArgConstructor || !hasBlockPosAndIChatComponentConstructor) continue;
                Field blockPosField = null;
                Field chatComponentsField = null;
                for (Field field : candidate.getDeclaredFields()) {
                    if (field.getType() == blockPosClass) {
                        blockPosField = field;
                        continue;
                    }
                    if (!field.getType().isArray() || field.getType().getComponentType() != iChatComponentClass) continue;
                    chatComponentsField = field;
                }
                if (blockPosField == null || chatComponentsField == null) continue;
                MinecraftMapper.put("C12PacketUpdateSign", candidate);
                break;
            }
        }
    }

    public static void processPacketClass() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> packetBufferClass = MinecraftMapper.get("PacketBuffer");
        if (packetIfc != null && packetBufferClass != null) {
            for (Class<?> candidate : classes) {
                boolean bl;
                if (candidate.isEnum() || candidate.isInterface() || candidate.getSuperclass() != Object.class) continue;
                boolean implementsPacket = false;
                for (Class<?> clazz : candidate.getInterfaces()) {
                    if (!packetIfc.isAssignableFrom(clazz)) continue;
                    implementsPacket = true;
                    break;
                }
                if (!implementsPacket) continue;
                Field[] fields = candidate.getDeclaredFields();
                int stringFieldCount = 0;
                boolean hasRemove = false;
                for (Field f : fields) {
                    f.setAccessible(true);
                    if (f.getName().toUpperCase().contains("REMOVE")) {
                        hasRemove = true;
                        break;
                    }
                    if (f.getType() != String.class) continue;
                    ++stringFieldCount;
                }
                if (hasRemove || stringFieldCount != true) continue;
                boolean bl2 = false;
                boolean hasStringCtor = false;
                for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                    Class<?>[] params = ctor.getParameterTypes();
                    if (params.length == 0) {
                        bl = true;
                    }
                    if (params.length != 1 || params[0] != String.class) continue;
                    hasStringCtor = true;
                }
                if (!bl || !hasStringCtor) continue;
                Method[] methods = candidate.getDeclaredMethods();
                int packetBufferMethodCount = 0;
                for (Method m : methods) {
                    if (m.getName().toUpperCase().contains("REMOVE")) {
                        hasRemove = true;
                        return;
                    }
                    Class<?>[] params = m.getParameterTypes();
                    if (params.length != 1 || params[0] != packetBufferClass) continue;
                    ++packetBufferMethodCount;
                }
                if (packetBufferMethodCount < 2) continue;
                MinecraftMapper.put("C01PacketChatMessage", candidate);
                MinecraftMapper.findAndSaveINetHandlerPlayServer(candidate);
                Method getMessageMethod = null;
                for (Method m : candidate.getDeclaredMethods()) {
                    if (m.getReturnType() != String.class || m.getParameterCount() != 0) continue;
                    m.setAccessible(true);
                    getMessageMethod = m;
                    MinecraftMapper.putMethod("C01PacketChatMessage.getMessage", m);
                    break;
                }
                if (getMessageMethod == null) break;
                Field messageField = null;
                for (Field f : candidate.getDeclaredFields()) {
                    if (f.getType() != String.class) continue;
                    f.setAccessible(true);
                    try {
                        Object instance = candidate.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                        Object fieldValue = f.get(instance);
                        Object methodValue = getMessageMethod.invoke(instance, new Object[0]);
                        if (fieldValue != null || methodValue != null) continue;
                        messageField = f;
                        break;
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
                if (messageField == null) {
                    for (Field f : candidate.getDeclaredFields()) {
                        if (f.getType() != String.class) continue;
                        messageField = f;
                        break;
                    }
                }
                if (messageField == null) break;
                MinecraftMapper.putField("C01PacketChatMessage.message", messageField);
                break;
            }
        }
    }

    private static void findAndSaveINetHandlerPlayServer(Class<?> packetClass) {
        Class<?> packetInterface = MinecraftMapper.get("Packet");
        if (packetInterface == null) {
            System.out.println("Packet interface'i bulunamad\u00c3\u201e\u00c2\u00b1");
        } else {
            Type[] typeArgs;
            ParameterizedType paramType;
            Type rawType;
            Type[] genericInterfaces;
            for (Type genericInterface : genericInterfaces = packetClass.getGenericInterfaces()) {
                Type firstArg;
                Type[] typeArgs2;
                ParameterizedType paramType2;
                Type rawType2;
                if (!(genericInterface instanceof ParameterizedType) || !(rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()).equals(packetInterface) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !MinecraftMapper.extractAndSaveHandlerClass(firstArg = typeArgs2[0])) continue;
                return;
            }
            Type genericSuperclass = packetClass.getGenericSuperclass();
            if (genericSuperclass instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && packetInterface.isAssignableFrom((Class)rawType) && (typeArgs = paramType.getActualTypeArguments()).length > 0) {
                Type firstArg = typeArgs[0];
                MinecraftMapper.extractAndSaveHandlerClass(firstArg);
            }
        }
    }

    public static void findMotionFields(byte[] classBytes) {
        try {
            if (MinecraftMapper.missingClassBytes("findMotionFields", classBytes)) {
                return;
            }
            ClassReader cr = new ClassReader(classBytes);
            ClassNode classNode = new ClassNode();
            cr.accept((ClassVisitor)classNode, 0);
            Class<?> entityClass = MinecraftMapper.get("Entity");
            if (entityClass == null) {
                return;
            }
            String entityInternalName = org.objectweb.asm.Type.getInternalName(entityClass);
            for (MethodNode method : classNode.methods) {
                if (!method.name.equals("<init>")) continue;
                List<AbstractInsnNode> insns = Arrays.asList(method.instructions.toArray());
                int motionFieldCount = 0;
                for (int i = 0; i < insns.size(); ++i) {
                    AbstractInsnNode nextInsn;
                    Field f;
                    AbstractInsnNode insn = insns.get(i);
                    if (insn.getOpcode() != 180 || !(insn instanceof FieldInsnNode)) continue;
                    FieldInsnNode fin = (FieldInsnNode)insn;
                    if (!fin.owner.equals(entityInternalName) || (f = MinecraftMapper.findField(entityClass, fin.name, fin.desc)) == null || i + 1 >= insns.size() || (nextInsn = insns.get(i + 1)).getOpcode() != 182 || !(nextInsn instanceof MethodInsnNode)) continue;
                    MethodInsnNode min = (MethodInsnNode)nextInsn;
                    if (!"()D".equals(min.desc)) continue;
                    MinecraftMapper.put("MotionContainer", f.getType());
                    switch (motionFieldCount) {
                        case 0: {
                            MinecraftMapper.putField("Entity.motionX", f);
                            break;
                        }
                        case 1: {
                            MinecraftMapper.putField("Entity.motionY", f);
                            Field unsafeField = Unsafe.class.getDeclaredField("theUnsafe");
                            unsafeField.setAccessible(true);
                            Unsafe unsafe = (Unsafe)unsafeField.get(null);
                            f.setAccessible(true);
                            long offset = unsafe.objectFieldOffset(f);
                            MinecraftMapper.addChatMessage(String.format("motionY offset: 0x%X", offset));
                            break;
                        }
                        case 2: {
                            MinecraftMapper.putField("Entity.motionZ", f);
                        }
                    }
                    Method m = f.getType().getDeclaredMethod(min.name, new Class[0]);
                    if (m.getReturnType() == Double.TYPE) {
                        MinecraftMapper.putMethod("MotionContainer.getDoubleValue", m);
                    }
                    if (++motionFieldCount < 3) continue;
                    return;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static Field findField(Class<?> cls, String name, String descriptor) {
        for (Field field : cls.getDeclaredFields()) {
            if (!field.getName().equals(name) || !MinecraftMapper.getDescriptor(field).equals(descriptor)) continue;
            return field;
        }
        return null;
    }

    public static Method findSpecificMethod(Class<?> clazz, Class<?> param) {
        if (clazz != null && param != null) {
            for (Method method : clazz.getDeclaredMethods()) {
                Class<?>[] params;
                if (!Modifier.isPublic(method.getModifiers()) || !method.getReturnType().equals(Void.TYPE) || (params = method.getParameterTypes()).length != 1 || !params[0].equals(param)) continue;
                return method;
            }
            return null;
        }
        return null;
    }

    public static Field getFieldByType(Class<?> clazz, Class<?> type) {
        if (clazz != null && type != null) {
            Field[] fields;
            for (Field field : fields = clazz.getDeclaredFields()) {
                if (field.getType() != type) continue;
                return field;
            }
            return null;
        }
        return null;
    }

    public static Field findListUsingParam(Class<?> cls, Class<?> listType) {
        if (cls != null && listType != null) {
            Field[] fields;
            for (Field field : fields = cls.getFields()) {
                ParameterizedType pType;
                Type[] typeArguments;
                Type fieldType;
                if (!List.class.isAssignableFrom(field.getType()) || !((fieldType = field.getGenericType()) instanceof ParameterizedType) || (typeArguments = (pType = (ParameterizedType)fieldType).getActualTypeArguments()).length != 1 || !typeArguments[0].equals(listType)) continue;
                return field;
            }
            return null;
        }
        return null;
    }

    public static Class<?> findClassUsingFieldNames(String ... names) {
        for (Class<?> clazz : MinecraftMapper.getClasses()) {
            HashSet<String> fieldNamesSet = new HashSet<String>();
            for (Field field : clazz.getDeclaredFields()) {
                fieldNamesSet.add(field.getName());
            }
            boolean allMatch = true;
            for (String name : names) {
                if (fieldNamesSet.contains(name)) continue;
                allMatch = false;
                break;
            }
            if (!allMatch) continue;
            return clazz;
        }
        return null;
    }

    public static void findClientStatusPacket() {
        Class<?> statusEnumClass = MinecraftMapper.findClassUsingFieldNames("PERFORM_RESPAWN", "REQUEST_STATS", "OPEN_INVENTORY_ACHIEVEMENT");
        if (statusEnumClass != null && statusEnumClass.isEnum()) {
            Vector classes = new Vector(MinecraftMapper.getClasses());
            Class<?> packetIfc = MinecraftMapper.get("Packet");
            Class<?> iNetHandlerPlayServer = MinecraftMapper.get("INetHandlerPlayServer");
            if (packetIfc != null && iNetHandlerPlayServer != null) {
                for (Class<?> candidate : classes) {
                    Type[] typeArgs;
                    ParameterizedType paramType;
                    Type rawType;
                    Type genericSuperclass;
                    Type[] genericInterfaces;
                    if (candidate.isEnum() || candidate.isInterface() || !packetIfc.isAssignableFrom(candidate)) continue;
                    boolean implementsCorrectGeneric = false;
                    for (Type genericInterface : genericInterfaces = candidate.getGenericInterfaces()) {
                        Type[] typeArgs2;
                        ParameterizedType paramType2;
                        Type rawType2;
                        if (!(genericInterface instanceof ParameterizedType) || !((rawType2 = (paramType2 = (ParameterizedType)genericInterface).getRawType()) instanceof Class) || !((Class)rawType2).equals(packetIfc) || (typeArgs2 = paramType2.getActualTypeArguments()).length <= 0 || !(typeArgs2[0] instanceof Class) || !((Class)typeArgs2[0]).equals(iNetHandlerPlayServer)) continue;
                        implementsCorrectGeneric = true;
                        break;
                    }
                    if (!implementsCorrectGeneric && (genericSuperclass = candidate.getGenericSuperclass()) instanceof ParameterizedType && (rawType = (paramType = (ParameterizedType)genericSuperclass).getRawType()) instanceof Class && ((Class)rawType).equals(packetIfc) && (typeArgs = paramType.getActualTypeArguments()).length > 0 && typeArgs[0] instanceof Class && ((Class)typeArgs[0]).equals(iNetHandlerPlayServer)) {
                        implementsCorrectGeneric = true;
                    }
                    if (!implementsCorrectGeneric) continue;
                    boolean hasNoArgConstructor = false;
                    boolean hasEnumConstructor = false;
                    for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                        Class<?>[] params = ctor.getParameterTypes();
                        if (params.length == 0) {
                            hasNoArgConstructor = true;
                        }
                        if (params.length != 1 || params[0] != statusEnumClass) continue;
                        hasEnumConstructor = true;
                    }
                    if (!hasNoArgConstructor || !hasEnumConstructor) continue;
                    MinecraftMapper.put("C16PacketClientStatus", candidate);
                    MinecraftMapper.put("C16PacketClientStatus.EnumState", statusEnumClass);
                    break;
                }
            }
        }
    }

    public static void findPlayerPosLookPacket() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packetIfc = MinecraftMapper.get("Packet");
        Class<?> iNetHandlerPlayClient = MinecraftMapper.get("INetHandlerPlayClient");
        if (packetIfc != null && iNetHandlerPlayClient != null) {
            for (Class<?> candidate : classes) {
                Type[] genericInterfaces;
                if (candidate.isEnum() || candidate.isInterface()) continue;
                boolean implementsCorrectInterface = false;
                for (Type type : genericInterfaces = candidate.getGenericInterfaces()) {
                    Type[] typeArgs;
                    ParameterizedType pt;
                    if (!(type instanceof ParameterizedType) || (pt = (ParameterizedType)type).getRawType() != packetIfc || (typeArgs = pt.getActualTypeArguments()).length != 1 || typeArgs[0] != iNetHandlerPlayClient) continue;
                    implementsCorrectInterface = true;
                    break;
                }
                if (!implementsCorrectInterface) continue;
                Class<?>[] declaredClasses = candidate.getDeclaredClasses();
                Class<?> targetInnerClass = null;
                for (Class<?> innerClass : declaredClasses) {
                    if (!innerClass.isEnum()) continue;
                    targetInnerClass = innerClass;
                    break;
                }
                if (targetInnerClass == null) continue;
                boolean hasCorrectConstructor = false;
                try {
                    Constructor<?>[] constructors;
                    for (Constructor<?> constructor : constructors = candidate.getDeclaredConstructors()) {
                        Class<?>[] paramTypes = constructor.getParameterTypes();
                        if (paramTypes.length != 6 || paramTypes[0] != Double.TYPE || paramTypes[1] != Double.TYPE || paramTypes[2] != Double.TYPE || paramTypes[3] != Float.TYPE || paramTypes[4] != Float.TYPE || !Set.class.isAssignableFrom(paramTypes[5])) continue;
                        hasCorrectConstructor = true;
                        break;
                    }
                }
                catch (Exception var16) {
                    continue;
                }
                if (!hasCorrectConstructor) continue;
                MinecraftMapper.put("S08PacketPlayerPosLook", candidate);
                MinecraftMapper.put("S08PacketPlayerPosLook.EnumFlags", targetInnerClass);
                return;
            }
        } else {
            System.out.println("Packet veya INetHandlerPlayClient interface'i bulunamad\u00c3\u201e\u00c2\u00b1");
        }
    }

    public static Class<?> findClassByName(String className) {
        if (className == null) {
            return null;
        }
        for (Class<?> clazz : MinecraftMapper.getClasses()) {
            if (!clazz.getName().equals(className)) continue;
            return clazz;
        }
        return null;
    }

    public static String getOuterClassName(String className) {
        if (className == null) {
            return null;
        }
        int innerClassDelimiter = className.indexOf(36);
        return innerClassDelimiter != -1 ? className.substring(0, innerClassDelimiter) : className;
    }

    public static Method[] getAllMethods(Class<?> clazz) {
        ArrayList<Method> methods = new ArrayList<Method>();
        if (clazz == null) {
            return new Method[0];
        }
        block0: for (Method method : clazz.getDeclaredMethods()) {
            if (clazz.getSuperclass() != null && !clazz.getSuperclass().getName().equals("java.lang.Object")) {
                for (Method declaredMethod : clazz.getSuperclass().getDeclaredMethods()) {
                    if (method.toString().equals(declaredMethod.toString())) continue block0;
                }
            }
            methods.add(method);
        }
        return methods.toArray(new Method[0]);
    }

    public static void findJumpOpcodeBased() {
        try {
            Class<?> clazz = MinecraftMapper.get("EntityLivingBase");
            byte[] bytes = MinecraftMapper.getClassBytes(clazz);
            if (MinecraftMapper.missingClassBytes("findJumpOpcodeBased", clazz, bytes)) {
                return;
            }
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 4);
            for (Method m : clazz.getDeclaredMethods()) {
                if (!m.getName().equals("\u00c3\u2019\u00e2\u201a\u00ac") || m.getReturnType() != Void.TYPE || m.getParameterCount() != 0) continue;
                m.setAccessible(true);
                MinecraftMapper.putMethod("EntityLivingBase.jump", m);
                return;
            }
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static boolean isPlayerControllerMP(Class<?> clazz) {
        Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
        Class<?> netHandlerClass = MinecraftMapper.get("NetHandlerPlayClient");
        Constructor<?>[] constructors = clazz.getDeclaredConstructors();
        if (constructors.length != 1) {
            return false;
        }
        Constructor<?> constructor = constructors[0];
        Class<?>[] params = constructor.getParameterTypes();
        if (params.length != 2) {
            return false;
        }
        if (!params[0].equals(minecraftClass)) {
            return false;
        }
        if (!params[1].equals(netHandlerClass)) {
            return false;
        }
        boolean hasFinalMinecraft = false;
        boolean hasPublicNetHandler = false;
        boolean hasPrivateBoolean = false;
        for (Field field : clazz.getDeclaredFields()) {
            int mods = field.getModifiers();
            Class<?> type = field.getType();
            if (Modifier.isPrivate(mods) && Modifier.isFinal(mods) && type.equals(minecraftClass)) {
                hasFinalMinecraft = true;
            }
            if (Modifier.isPublic(mods) && !Modifier.isFinal(mods) && type.equals(netHandlerClass)) {
                hasPublicNetHandler = true;
            }
            if (!Modifier.isPrivate(mods) || !type.equals(Boolean.TYPE)) continue;
            hasPrivateBoolean = true;
        }
        return hasFinalMinecraft && hasPublicNetHandler && hasPrivateBoolean;
    }

    public static Class<?> findS12PacketVelocity() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> packet = MinecraftMapper.get("Packet");
        if (packet == null) {
            return null;
        }
        for (Class<?> clazz : classes) {
            if (!packet.isAssignableFrom(clazz)) continue;
            for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                Class<?>[] classArray = constructor.getParameterTypes();
                if (classArray.length != 4 || classArray[0] != Integer.TYPE || classArray[1] != Double.TYPE || classArray[2] != Double.TYPE || classArray[3] != Double.TYPE) continue;
                return clazz;
            }
        }
        for (Class<?> clazz : classes) {
            if (!packet.isAssignableFrom(clazz)) continue;
            for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                Class<?>[] classArray = constructor.getParameterTypes();
                if (classArray.length != 4 || classArray[0] != Integer.TYPE || classArray[1] != Integer.TYPE || classArray[2] != Integer.TYPE || classArray[3] != Integer.TYPE) continue;
                int intFieldCount = 0;
                for (Field f : clazz.getDeclaredFields()) {
                    if (f.getType() != Integer.TYPE) continue;
                    ++intFieldCount;
                }
                if (intFieldCount < 4) continue;
                return clazz;
            }
        }
        for (Class<?> clazz : classes) {
            if (!packet.isAssignableFrom(clazz) || clazz.isInterface() || clazz.isEnum()) continue;
            int intFieldCount = 0;
            for (Field field : clazz.getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers()) || field.getType() != Integer.TYPE) continue;
                ++intFieldCount;
            }
            if (intFieldCount != 4) continue;
            for (AccessibleObject accessibleObject : clazz.getDeclaredMethods()) {
                if (((Method)accessibleObject).getReturnType() != Integer.TYPE || ((Method)accessibleObject).getParameterCount() != 0 || !Modifier.isPublic(((Method)accessibleObject).getModifiers())) continue;
                return clazz;
            }
        }
        return null;
    }

    public static void findMathHelper() {
        List<Class<?>> loadedClasses = MinecraftMapper.getClasses();
        HashSet targetValues = new HashSet();
        Collections.addAll(targetValues, Float.valueOf(11.377778f), Float.valueOf(651.8986f), Float.valueOf(1.5707964f), 0.7853981633974483);
        for (Class<?> clazz : loadedClasses) {
            int matchCount = 0;
            for (Field field : clazz.getDeclaredFields()) {
                try {
                    if (!MinecraftMapper.isStaticFinal(field)) continue;
                    field.setAccessible(true);
                    Object value = field.get(null);
                    if (!targetValues.contains(value) || ++matchCount < 3) continue;
                    MinecraftMapper.put("MathHelper", clazz);
                    return;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
    }

    private static boolean isStaticFinal(Field field) {
        int modifiers = field.getModifiers();
        return Modifier.isStatic(modifiers) && Modifier.isFinal(modifiers);
    }

    public static void processItemClass() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Object[] requiredClasses = new Class[]{MinecraftMapper.get("Block"), MinecraftMapper.get("MovingObjectPosition"), MinecraftMapper.get("EnumFacing"), MinecraftMapper.get("EntityPlayer"), MinecraftMapper.get("Gui"), MinecraftMapper.get("Entity"), MinecraftMapper.get("EntityLivingBase"), MinecraftMapper.get("ItemStack"), MinecraftMapper.get("Vec3"), MinecraftMapper.get("World"), MinecraftMapper.get("ResourceLocation"), MinecraftMapper.get("BlockPos")};
        Object[] extraClasses = new Class[]{List.class, Map.class, HashMap.class, HashSet.class, ArrayList.class, Random.class, UUID.class, Function.class, HashMultimap.class, Maps.class, Multimap.class};
        HashSet requiredSet = Sets.newHashSet((Object[])requiredClasses);
        HashSet extraSet = Sets.newHashSet((Object[])extraClasses);
        for (Class<?> candidate : classes) {
            if (candidate.isEnum() || candidate.isInterface() || candidate.getSuperclass() != Object.class) continue;
            boolean has64 = false;
            for (Field f : candidate.getDeclaredFields()) {
                f.setAccessible(true);
                int n = f.getModifiers();
                try {
                    int value;
                    if (!Modifier.isProtected(n) || Modifier.isStatic(n) || f.getType() != Integer.TYPE || (value = f.getInt(candidate.newInstance())) != 64 || f.getName().equals("MASK_POTION_EXTENDED")) continue;
                    has64 = true;
                    break;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if (!has64) continue;
            boolean usedRequiredOrExtra = false;
            block4: for (Constructor<?> constructor : candidate.getDeclaredConstructors()) {
                for (Class<?> param : constructor.getParameterTypes()) {
                    if (!requiredSet.contains(param) && !extraSet.contains(param)) continue;
                    usedRequiredOrExtra = true;
                    break block4;
                }
            }
            if (!usedRequiredOrExtra) {
                block6: for (Executable executable : candidate.getDeclaredMethods()) {
                    if (requiredSet.contains(((Method)executable).getReturnType()) || extraSet.contains(((Method)executable).getReturnType())) {
                        usedRequiredOrExtra = true;
                        break;
                    }
                    for (Class<?> param : ((Method)executable).getParameterTypes()) {
                        if (!requiredSet.contains(param) && !extraSet.contains(param)) continue;
                        usedRequiredOrExtra = true;
                        break block6;
                    }
                }
            }
            if (!usedRequiredOrExtra) continue;
            MinecraftMapper.put("Item", candidate);
            break;
        }
    }

    public static void findModelManager() {
        Class<?> renderItemClass = MinecraftMapper.get("RenderItem");
        if (renderItemClass != null) {
            Class<?> modelManagerClass = null;
            for (Constructor<?> constructor : renderItemClass.getDeclaredConstructors()) {
                Class<?> textureManagerClass;
                Class<?>[] paramTypes = constructor.getParameterTypes();
                if (paramTypes.length != 2 || (textureManagerClass = MinecraftMapper.get("TextureManager")) == null || !paramTypes[0].equals(textureManagerClass)) continue;
                modelManagerClass = paramTypes[1];
                MinecraftMapper.put("ModelManager", modelManagerClass);
                break;
            }
            if (modelManagerClass != null) {
                Class<?>[] interfaces = modelManagerClass.getInterfaces();
                if (interfaces.length > 0) {
                    Class<?> interfaceClass = interfaces[0];
                    MinecraftMapper.put("IResourceManagerReloadListener", interfaceClass);
                }
                for (Constructor<?> constructor : modelManagerClass.getDeclaredConstructors()) {
                    Class<?>[] paramTypes = constructor.getParameterTypes();
                    if (paramTypes.length != 1) continue;
                    Class<?> textureMapClass = paramTypes[0];
                    MinecraftMapper.put("TextureMap", textureMapClass);
                    return;
                }
            }
        }
    }

    public static void findallmobs() {
        Field[] fields;
        Constructor<?>[] constructors;
        Class<?> renderManagerClass = MinecraftMapper.get("RenderManager");
        for (Constructor<?> constructor : constructors = renderManagerClass.getDeclaredConstructors()) {
            Class<?>[] paramTypes = constructor.getParameterTypes();
            if (paramTypes.length != 2) continue;
            String renderItemClassName = paramTypes[1].getSimpleName();
            MinecraftMapper.put("RenderItem", paramTypes[1]);
            break;
        }
        Object entityRenderMapField = null;
        for (Field field : fields = renderManagerClass.getDeclaredFields()) {
            if (Map.class.isAssignableFrom(field.getType())) break;
        }
    }

    public static void processModelBiped() {
        Class<?> modelBipedClass = MinecraftMapper.findClassUsingFieldNames("bipedHead", "bipedBody", "bipedRightArm", "bipedLeftArm", "bipedRightLeg", "bipedLeftLeg");
        if (modelBipedClass != null) {
            Class<?> fieldType;
            MinecraftMapper.put("ModelBiped", modelBipedClass);
            Class<?> superClass = modelBipedClass.getSuperclass();
            if (superClass != null && !superClass.equals(Object.class)) {
                MinecraftMapper.put("ModelBase", superClass);
                MinecraftMapper.resolveModelBaseMethods(superClass);
            }
            boolean modelRendererFound = false;
            for (Field field : modelBipedClass.getDeclaredFields()) {
                if (!field.getName().equals("bipedHead")) continue;
                fieldType = field.getType();
                if (MinecraftMapper.get("ModelRenderer") == null) {
                    MinecraftMapper.put("ModelRenderer", fieldType);
                    MinecraftMapper.resolveModelRendererMethods(fieldType);
                }
                MinecraftMapper.putField("ModelBiped." + field.getName(), field);
                modelRendererFound = true;
                break;
            }
            if (!modelRendererFound) {
                for (Field field : modelBipedClass.getDeclaredFields()) {
                    if (!field.getName().startsWith("biped") || (fieldType = field.getType()).isPrimitive()) continue;
                    if (MinecraftMapper.get("ModelRenderer") == null) {
                        MinecraftMapper.put("ModelRenderer", fieldType);
                        MinecraftMapper.resolveModelRendererMethods(fieldType);
                    }
                    MinecraftMapper.putField("ModelBiped." + field.getName(), field);
                    break;
                }
            }
        }
    }

    public static void resolveModelBaseMethods(Class<?> modelBaseClass) {
        Class<?> ENTITY = MinecraftMapper.get("Entity");
        Class<?> ENTITY_LIVING = MinecraftMapper.get("EntityLivingBase");
        Class<?> MODEL_RENDERER = MinecraftMapper.get("ModelRenderer");
        Class<?> MODEL_BASE = modelBaseClass;
        Class<Random> RANDOM = Random.class;
        Class<String> STRING = String.class;
        for (Method m : modelBaseClass.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (MinecraftMapper.matchParams(m, ENTITY, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE)) {
                MinecraftMapper.putMethod("ModelBase.render", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE, ENTITY)) {
                MinecraftMapper.putMethod("ModelBase.setRotationAngles", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, ENTITY_LIVING, Float.TYPE, Float.TYPE, Float.TYPE)) {
                MinecraftMapper.putMethod("ModelBase.setLivingAnimations", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, RANDOM)) {
                MinecraftMapper.putMethod("ModelBase.getRandomModelBox", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, STRING, Integer.TYPE, Integer.TYPE)) {
                MinecraftMapper.putMethod("ModelBase.setTextureOffset", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, STRING)) {
                Class<?> returnType = m.getReturnType();
                if (returnType != null && !returnType.isPrimitive()) {
                    MinecraftMapper.put("TextureOffset", returnType);
                }
                MinecraftMapper.putMethod("ModelBase.getTextureOffset", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, MODEL_RENDERER, MODEL_RENDERER)) {
                MinecraftMapper.putMethod("ModelBase.copyModelAngles", m);
                continue;
            }
            if (!MinecraftMapper.matchParams(m, MODEL_BASE)) continue;
            MinecraftMapper.putMethod("ModelBase.setModelAttributes", m);
        }
    }

    public static void resolveModelRendererMethods(Class<?> modelRendererClass) {
        Class<String> STRING = String.class;
        Class<?> MODEL_RENDERER = MinecraftMapper.get("ModelRenderer");
        for (Method m : modelRendererClass.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (MinecraftMapper.matchParams(m, STRING, Float.TYPE, Float.TYPE, Float.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE)) {
                Class<?> returnType = m.getReturnType();
                if (returnType != null && !returnType.isPrimitive() && MinecraftMapper.get("ModelRenderer") == null) {
                    MinecraftMapper.put("ModelRenderer", returnType);
                }
                MinecraftMapper.putMethod("ModelRenderer.addBox", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, Float.TYPE, Float.TYPE, Float.TYPE)) {
                MinecraftMapper.putMethod("ModelRenderer.setRotationPoint", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, MODEL_RENDERER)) {
                MinecraftMapper.putMethod("ModelRenderer.addChild", m);
                continue;
            }
            if (MinecraftMapper.matchParams(m, Integer.TYPE, Integer.TYPE)) {
                MinecraftMapper.putMethod("ModelRenderer.setTextureOffset", m);
                continue;
            }
            if (!m.getName().equals("\u00c3\u02c6\u00cb\u0153")) continue;
            MinecraftMapper.putMethod("ModelRenderer.render", m);
        }
    }

    public static void findglstatemanager(int minInnerClassCount) {
        for (Class<?> clazz : MinecraftMapper.getClasses()) {
            if (clazz.getDeclaredClasses().length < minInnerClassCount) continue;
            MinecraftMapper.put("GlStateManager", clazz);
            try {
                byte[] bytes = MinecraftMapper.getClassBytes(clazz);
                if (bytes == null) {
                    return;
                }
                ClassReader cr = new ClassReader(bytes);
                ClassNode cn = new ClassNode();
                cr.accept((ClassVisitor)cn, 0);
                for (MethodNode mn : cn.methods) {
                    int getStatic = 0;
                    int putStatic = 0;
                    int ifCmp = 0;
                    int methodCalls = 0;
                    for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                        int op;
                        if (insn instanceof FieldInsnNode) {
                            FieldInsnNode f = (FieldInsnNode)insn;
                            if (f.getOpcode() == 178) {
                                ++getStatic;
                            }
                            if (f.getOpcode() == 179) {
                                ++putStatic;
                            }
                        }
                        if (insn instanceof JumpInsnNode && (op = insn.getOpcode()) >= 159 && op <= 164) {
                            ++ifCmp;
                        }
                        if (!(insn instanceof MethodInsnNode)) continue;
                        ++methodCalls;
                    }
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }
    }

    public static void processC02PacketUseEntityMethods() {
        Class<?> clazz = MinecraftMapper.get("C02PacketUseEntity");
        if (clazz != null) {
            for (Method method : clazz.getDeclaredMethods()) {
                Class<?>[] params = method.getParameterTypes();
                if (params.length != 1 || params[0] != MinecraftMapper.get("World")) continue;
                method.setAccessible(true);
                MinecraftMapper.putMethod("C02PacketUseEntity.getEntity", method);
                break;
            }
        }
    }

    public static void processModelBipedMethods() {
        Class<?> clazz = MinecraftMapper.get("ModelBiped");
        if (clazz != null) {
            for (Method method : clazz.getDeclaredMethods()) {
                Class<?>[] classArray = method.getParameterTypes();
                if (classArray.length != 7 || classArray[0] != Float.TYPE || classArray[1] != Float.TYPE || classArray[2] != Float.TYPE || classArray[3] != Float.TYPE || classArray[4] != Float.TYPE || classArray[5] != Float.TYPE || classArray[6] != MinecraftMapper.get("Entity")) continue;
                method.setAccessible(true);
                MinecraftMapper.putMethod("ModelBiped.setRotationAngles", method);
                break;
            }
        }
    }

    public static void findGetSubCompoundMethod() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
        if (itemStackClass == null) {
            System.out.println("ItemStack s\u00c3\u201e\u00c2\u00b1n\u00c3\u201e\u00c2\u00b1f\u00c3\u201e\u00c2\u00b1 bulunamad\u00c3\u201e\u00c2\u00b1");
        } else {
            for (Class<?> candidate : classes) {
                if (!candidate.equals(itemStackClass)) continue;
                for (Method method : candidate.getDeclaredMethods()) {
                    Class<?>[] params;
                    if (method.getParameterCount() != 2 || (params = method.getParameterTypes())[0] != String.class || params[1] != Boolean.TYPE) continue;
                    Class<?> returnType = method.getReturnType();
                    MinecraftMapper.put("NBTTagCompound", returnType);
                    MinecraftMapper.putMethod("ItemStack.getSubCompound", method);
                    return;
                }
            }
        }
    }

    public static void findSetTagInfoMethod() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
        if (itemStackClass == null) {
            System.out.println("ItemStack s\u00c3\u201e\u00c2\u00b1n\u00c3\u201e\u00c2\u00b1f\u00c3\u201e\u00c2\u00b1 bulunamad\u00c3\u201e\u00c2\u00b1");
        } else {
            for (Class<?> candidate : classes) {
                if (!candidate.equals(itemStackClass)) continue;
                for (Method method : candidate.getDeclaredMethods()) {
                    Class<?>[] params;
                    if (method.getParameterCount() != 2 || (params = method.getParameterTypes())[0] != String.class) continue;
                    Class<?> nbtBaseClass = params[1];
                    MinecraftMapper.put("NBTBase", nbtBaseClass);
                    MinecraftMapper.putMethod("ItemStack.setTagInfo", method);
                    return;
                }
            }
        }
    }

    public static void processKeyBindingClasses() {
        for (Class<?> candidate : new Vector(MinecraftMapper.getClasses())) {
            if (candidate.isEnum() || candidate.isInterface() || candidate.getSuperclass() != Object.class) continue;
            boolean hasTargetCtor = false;
            for (Constructor<?> ctor : candidate.getDeclaredConstructors()) {
                Class<?>[] params = ctor.getParameterTypes();
                if (params.length != 3 || params[0] != String.class || params[1] != Integer.TYPE || params[2] != String.class) continue;
                hasTargetCtor = true;
                break;
            }
            if (!hasTargetCtor) continue;
            boolean implementsComparable = false;
            for (Class<?> iface : candidate.getInterfaces()) {
                if (!Comparable.class.isAssignableFrom(iface)) continue;
                implementsComparable = true;
                break;
            }
            if (!implementsComparable) continue;
            MinecraftMapper.put("KeyBinding", candidate);
            try {
                byte[] classBytes = MinecraftMapper.getClassBytes(candidate);
                if (!MinecraftMapper.missingClassBytes("findKeyBinding fields", candidate, classBytes)) {
                    Method setKeyBindState;
                    HashSet<String> assignedIntFields = new HashSet<String>();
                    ClassNode cn = new ClassNode();
                    new ClassReader(classBytes).accept((ClassVisitor)cn, 0);
                    for (MethodNode mn : cn.methods) {
                        if (!"<init>".equals(mn.name) || !"(Ljava/lang/String;ILjava/lang/String;)V".equals(mn.desc)) continue;
                        for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                            if (insn.getOpcode() != 181) continue;
                            FieldInsnNode fin = (FieldInsnNode)insn;
                            assignedIntFields.add(fin.name);
                        }
                    }
                    Field keyCodeDefaultField = null;
                    Field keyCodeField = null;
                    Field pressedField = null;
                    for (Field f : candidate.getDeclaredFields()) {
                        f.setAccessible(true);
                        if (f.getType() != Boolean.TYPE || Modifier.isStatic(f.getModifiers())) continue;
                        pressedField = f;
                        break;
                    }
                    for (Field f : candidate.getDeclaredFields()) {
                        f.setAccessible(true);
                        if (f.getType() != Integer.TYPE || !assignedIntFields.contains(f.getName())) continue;
                        if (Modifier.isFinal(f.getModifiers())) {
                            keyCodeDefaultField = f;
                            continue;
                        }
                        keyCodeField = f;
                    }
                    if (keyCodeDefaultField == null || keyCodeField == null) {
                        ArrayList<Field> intFields = new ArrayList<Field>();
                        for (Field f : candidate.getDeclaredFields()) {
                            if (f.getType() != Integer.TYPE) continue;
                            intFields.add(f);
                        }
                        if (keyCodeDefaultField == null && intFields.size() > 0) {
                            keyCodeDefaultField = (Field)intFields.get(0);
                        }
                        if (keyCodeField == null && intFields.size() > 1) {
                            keyCodeField = (Field)intFields.get(1);
                        }
                    }
                    if (keyCodeDefaultField != null) {
                        MinecraftMapper.putField("KeyBinding.keyCodeDefault", keyCodeDefaultField);
                    }
                    if (keyCodeField != null) {
                        MinecraftMapper.putField("KeyBinding.keyCode", keyCodeField);
                    }
                    if (pressedField != null) {
                        MinecraftMapper.putField("KeyBinding.pressed", pressedField);
                    }
                    if ((setKeyBindState = MinecraftMapper.findMethod(candidate, 9, Void.TYPE, MinecraftMapper.get("Minecraft"), Integer.TYPE, Boolean.TYPE)) != null) {
                        MinecraftMapper.putMethod("KeyBinding.setKeyBindState", setKeyBindState);
                    }
                    for (Method m : candidate.getDeclaredMethods()) {
                        Class<?>[] params = m.getParameterTypes();
                        if (m.getReturnType() != Void.TYPE || params.length != 1 || params[0] != Integer.TYPE || !Modifier.isStatic(m.getModifiers()) || !Modifier.isPublic(m.getModifiers())) continue;
                        MinecraftMapper.putMethod("KeyBinding.onTick", m);
                        return;
                    }
                    break;
                }
                System.out.println("Class bytes al\u00c3\u201e\u00c2\u00b1namad\u00c3\u201e\u00c2\u00b1: " + candidate.getName());
            }
            catch (Throwable t) {
                t.printStackTrace();
                break;
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    public static void processMouseHelperClass() {
        for (Class<?> candidate : new Vector(MinecraftMapper.getClasses())) {
            try {
                void var6_9;
                if (candidate.isEnum() || candidate.isInterface()) continue;
                boolean onlyMouseOrDisplay = true;
                for (Field field : candidate.getDeclaredFields()) {
                    Class<?>[] t = field.getType();
                    if (t == Mouse.class || t == Display.class) continue;
                    onlyMouseOrDisplay = false;
                    break;
                }
                block4: for (AccessibleObject accessibleObject : candidate.getDeclaredMethods()) {
                    if (((Method)accessibleObject).getReturnType() != Boolean.TYPE && ((Method)accessibleObject).getReturnType() != Mouse.class && ((Method)accessibleObject).getReturnType() != Display.class) {
                        onlyMouseOrDisplay = false;
                        break;
                    }
                    for (Class<?> p : ((Method)accessibleObject).getParameterTypes()) {
                        if (p == Mouse.class || p == Display.class) continue;
                        onlyMouseOrDisplay = false;
                        continue block4;
                    }
                }
                boolean hasBooleanMethod = false;
                Method[] methodArray = candidate.getDeclaredMethods();
                int n = methodArray.length;
                boolean bl = false;
                while (var6_9 < n) {
                    Method m = methodArray[var6_9];
                    if (m.getReturnType() == Boolean.TYPE) {
                        hasBooleanMethod = true;
                        break;
                    }
                    ++var6_9;
                }
                if (!onlyMouseOrDisplay || !hasBooleanMethod) continue;
                MinecraftMapper.put("MouseHelper", candidate);
                break;
            }
            catch (Throwable throwable) {
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    public static void findGameProfile() {
        Class<?> abstractClientPlayerClass = MinecraftMapper.get("AbstractClientPlayer");
        for (Constructor<?> constructor : abstractClientPlayerClass.getDeclaredConstructors()) {
            void var11_18;
            void var11_16;
            Class<?> worldClass;
            Class<?>[] paramTypes = constructor.getParameterTypes();
            if (paramTypes.length != 2 || (worldClass = MinecraftMapper.get("World")) == null || !paramTypes[0].equals(worldClass)) continue;
            Class<?> gameProfileClass = paramTypes[1];
            MinecraftMapper.put("GameProfile", gameProfileClass);
            for (Field field : gameProfileClass.getDeclaredFields()) {
                if (!field.getType().equals(UUID.class)) continue;
                MinecraftMapper.putField("GameProfile.uuid", field);
                break;
            }
            for (AccessibleObject accessibleObject : gameProfileClass.getDeclaredMethods()) {
                if (!((Method)accessibleObject).getReturnType().equals(UUID.class) || ((Method)accessibleObject).getParameterCount() != 0) continue;
                MinecraftMapper.putMethod("GameProfile.getUUID", (Method)accessibleObject);
                break;
            }
            Class<?> entityPlayerClass = MinecraftMapper.get("EntityPlayer");
            AccessibleObject[] accessibleObjectArray = entityPlayerClass.getDeclaredFields();
            int n = accessibleObjectArray.length;
            boolean bl = false;
            while (var11_16 < n) {
                Field field = accessibleObjectArray[var11_16];
                if (field.getType().equals(gameProfileClass)) {
                    MinecraftMapper.putField("EntityPlayer.gameProfile", field);
                    break;
                }
                ++var11_16;
            }
            accessibleObjectArray = entityPlayerClass.getDeclaredMethods();
            n = accessibleObjectArray.length;
            boolean bl2 = false;
            while (var11_18 < n) {
                AccessibleObject accessibleObject = accessibleObjectArray[var11_18];
                if (((Method)accessibleObject).getReturnType().equals(UUID.class) && ((Method)accessibleObject).getParameterCount() == 0) {
                    MinecraftMapper.putMethod("EntityPlayer.getGameProfile", (Method)accessibleObject);
                    break;
                }
                ++var11_18;
            }
            return;
        }
    }

    public static void processGameSettingsClass() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Object[] requiredClasses = new Class[]{MinecraftMapper.get("Minecraft"), MinecraftMapper.get("World"), MinecraftMapper.get("Gui"), MinecraftMapper.get("Packet"), MinecraftMapper.get("EntityPlayer"), MinecraftMapper.get("craftrise.Config")};
        Object[] extraClasses = new Class[]{BufferedReader.class, File.class, FileInputStream.class, FileOutputStream.class, InputStream.class, InputStreamReader.class, OutputStream.class, OutputStreamWriter.class, PrintWriter.class, CallSite.class, MethodHandle.class, MethodHandles.class, MethodType.class, MutableCallSite.class, ParameterizedType.class, Key.class, Arrays.class, HashMap.class, Iterator.class, LinkedList.class, List.class, Map.class, Set.class, Collectors.class, Cipher.class, SecretKey.class, SecretKeyFactory.class, DESKeySpec.class, IvParameterSpec.class, ArrayUtils.class, LogManager.class, org.apache.logging.log4j.Logger.class, ImmutableSet.class, Lists.class, Maps.class, Sets.class, Gson.class};
        HashSet requiredSet = Sets.newHashSet((Object[])requiredClasses);
        HashSet extraSet = Sets.newHashSet((Object[])extraClasses);
        for (Class<?> candidate : classes) {
            try {
                if (candidate.isEnum() || candidate.isInterface() || candidate.getSuperclass() != Object.class) continue;
                Constructor<?>[] ctors = candidate.getDeclaredConstructors();
                boolean hasDefaultCtor = false;
                boolean hasMinecraftFileCtor = false;
                for (Constructor<?> ctor : ctors) {
                    Class<?>[] classArray = ctor.getParameterTypes();
                    if (classArray.length == 0) {
                        hasDefaultCtor = true;
                        continue;
                    }
                    if (classArray.length != 2 || !classArray[0].equals(MinecraftMapper.get("Minecraft")) || !classArray[1].equals(File.class)) continue;
                    hasMinecraftFileCtor = true;
                }
                if (!hasDefaultCtor || !hasMinecraftFileCtor) continue;
                boolean usedRequiredOrExtra = false;
                block4: for (Method method : candidate.getDeclaredMethods()) {
                    if (requiredSet.contains(method.getReturnType()) || extraSet.contains(method.getReturnType())) {
                        usedRequiredOrExtra = true;
                        break;
                    }
                    for (Class<?> param : method.getParameterTypes()) {
                        if (!requiredSet.contains(param) && !extraSet.contains(param)) continue;
                        usedRequiredOrExtra = true;
                        break block4;
                    }
                }
                if (!usedRequiredOrExtra) {
                    for (AccessibleObject accessibleObject : candidate.getDeclaredFields()) {
                        Class<?> t = ((Field)accessibleObject).getType();
                        if (!t.isArray() && !List.class.isAssignableFrom(t)) continue;
                        usedRequiredOrExtra = true;
                        break;
                    }
                }
                if (!usedRequiredOrExtra) continue;
                MinecraftMapper.put("GameSettings", candidate);
                break;
            }
            catch (Throwable throwable) {
            }
        }
    }

    public static void findEntityInsideOpaqueBlock(Class<?> clazz) throws Exception {
        byte[] classBytes = MinecraftMapper.getClassBytes(clazz);
        if (!MinecraftMapper.missingClassBytes("findEntityInsideOpaqueBlock", clazz, classBytes)) {
            ClassReader cr = new ClassReader(classBytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            for (MethodNode mn : cn.methods) {
                if ((mn.access & 1) == 0 || !mn.desc.equals("()Z")) continue;
                int tryCatchCount = mn.tryCatchBlocks.size();
                int methodInsnCount = 0;
                int iconstCount = 0;
                boolean intInsnCount = false;
                int loopIndicator = 0;
                for (AbstractInsnNode insn : mn.instructions) {
                    int opcode = insn.getOpcode();
                    if (opcode == 3 || opcode == 4 || opcode == 5 || opcode == 6 || opcode == 7 || opcode == 8 || opcode == 16 || opcode == 17) {
                        ++iconstCount;
                    }
                    if (insn instanceof MethodInsnNode) {
                        ++methodInsnCount;
                    }
                    if (opcode != 132 && opcode != 21 && opcode != 162 && opcode != 161 && opcode != 167) continue;
                    ++loopIndicator;
                }
                if (tryCatchCount < 2 || methodInsnCount < 5 || iconstCount < 10 || loopIndicator < 5) continue;
                Method method = clazz.getDeclaredMethod(mn.name, new Class[0]);
                method.setAccessible(true);
                MinecraftMapper.putMethod("Entity.isEntityInsideOpaqueBlock", method);
                return;
            }
        }
    }

    public static void findFallDistanceAndInWeb(Class<?> clazz) throws Exception {
        byte[] bytes = MinecraftMapper.getClassBytes(clazz);
        if (!MinecraftMapper.missingClassBytes("findFallDistanceAndInWeb", clazz, bytes)) {
            MinecraftMapper.mapEntityGetUniqueID(clazz);
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            for (MethodNode mn : cn.methods) {
                if ((mn.access & 1) == 0 || !mn.desc.equals("()V")) continue;
                String floatFieldName = null;
                String booleanFieldName = null;
                boolean callsOtherMethod = false;
                for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    FieldInsnNode fin;
                    AbstractInsnNode next;
                    if (insn instanceof MethodInsnNode) {
                        callsOtherMethod = true;
                        break;
                    }
                    if (insn.getOpcode() == 4 && (next = insn.getNext()) instanceof FieldInsnNode && (fin = (FieldInsnNode)next).getOpcode() == 181 && "Z".equals(fin.desc) && fin.owner.equals(cn.name)) {
                        booleanFieldName = fin.name;
                    }
                    if (insn.getOpcode() != 11 || !((next = insn.getNext()) instanceof FieldInsnNode) || (fin = (FieldInsnNode)next).getOpcode() != 181 || !"F".equals(fin.desc) || !fin.owner.equals(cn.name)) continue;
                    floatFieldName = fin.name;
                }
                if (callsOtherMethod || floatFieldName == null || booleanFieldName == null) continue;
                MinecraftMapper.putField("Entity.fallDistance", clazz.getDeclaredField(floatFieldName));
                MinecraftMapper.putField("Entity.isInWeb", clazz.getDeclaredField(booleanFieldName));
                return;
            }
        }
    }

    public static void mapEntityGetUniqueID(Class<?> clazz) {
        try {
            for (Method m : clazz.getDeclaredMethods()) {
                if (m.getParameterCount() != 0 || !m.getReturnType().equals(UUID.class)) continue;
                MinecraftMapper.putMethod("Entity.getUniqueID", m);
                break;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void mapLastTickFields(Class<?> clazz) throws Exception {
        byte[] bytes = MinecraftMapper.getClassBytes(clazz);
        if (!MinecraftMapper.missingClassBytes("mapLastTickFields", clazz, bytes)) {
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            String owner = cn.name;
            for (MethodNode mn : cn.methods) {
                if (!mn.desc.equals("(DDDFF)V")) continue;
                ArrayList<FieldInsnNode> doubles = new ArrayList<FieldInsnNode>();
                for (AbstractInsnNode insn : mn.instructions.toArray()) {
                    if (!(insn instanceof FieldInsnNode)) continue;
                    FieldInsnNode f = (FieldInsnNode)insn;
                    if (!f.owner.equals(owner) || f.getOpcode() != 181 || !f.desc.equals("D")) continue;
                    doubles.add(f);
                }
                if (doubles.size() != 9) continue;
                Field prevX = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)1)).name);
                Field posX = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)0)).name);
                Field lastX = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)2)).name);
                Field prevY = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)4)).name);
                Field posY = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)3)).name);
                Field lastY = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)5)).name);
                Field prevZ = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)7)).name);
                Field posZ = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)6)).name);
                Field lastZ = clazz.getDeclaredField(((FieldInsnNode)doubles.get((int)8)).name);
                MinecraftMapper.putField("Entity.prevPosX", prevX);
                MinecraftMapper.putField("Entity.prevPosY", prevY);
                MinecraftMapper.putField("Entity.prevPosZ", prevZ);
                MinecraftMapper.putField("Entity.posX", posX);
                MinecraftMapper.putField("Entity.posY", posY);
                MinecraftMapper.putField("Entity.posZ", posZ);
                MinecraftMapper.putField("Entity.lastTickPosX", lastX);
                MinecraftMapper.putField("Entity.lastTickPosY", lastY);
                MinecraftMapper.putField("Entity.lastTickPosZ", lastZ);
                return;
            }
        }
    }

    public static void findEntityFields(Class<?> clazz) throws Exception {
        byte[] bytes = MinecraftMapper.getClassBytes(clazz);
        if (!MinecraftMapper.missingClassBytes("findEntityFields", clazz, bytes)) {
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            for (MethodNode mn : cn.methods) {
                if ((mn.access & 1) == 0 || !mn.desc.equals("(L" + cn.name + ";)V")) continue;
                ArrayList<FieldInsnNode> fields = new ArrayList<FieldInsnNode>();
                for (AbstractInsnNode insn : mn.instructions) {
                    if (insn.getOpcode() != 180) continue;
                    FieldInsnNode fin = (FieldInsnNode)insn;
                    if (!fin.owner.equals(cn.name)) continue;
                    fields.add(fin);
                }
                if (fields.size() < 5 || !"D".equals(((FieldInsnNode)fields.get((int)0)).desc) || !"D".equals(((FieldInsnNode)fields.get((int)1)).desc) || !"D".equals(((FieldInsnNode)fields.get((int)2)).desc) || !"F".equals(((FieldInsnNode)fields.get((int)3)).desc) || !"F".equals(((FieldInsnNode)fields.get((int)4)).desc)) continue;
                clazz.getDeclaredField(((FieldInsnNode)fields.get((int)0)).name);
                clazz.getDeclaredField(((FieldInsnNode)fields.get((int)1)).name);
                clazz.getDeclaredField(((FieldInsnNode)fields.get((int)2)).name);
                Field rotationYaw = clazz.getDeclaredField(((FieldInsnNode)fields.get((int)3)).name);
                Field rotationPitch = clazz.getDeclaredField(((FieldInsnNode)fields.get((int)4)).name);
                MinecraftMapper.putField("Entity.rotationYaw", rotationYaw);
                MinecraftMapper.putField("Entity.rotationPitch", rotationPitch);
                return;
            }
        }
    }

    public static void mapRotationYawHeadField(Class<?> clazz) throws Exception {
        byte[] bytes = MinecraftMapper.getClassBytes(clazz);
        if (!MinecraftMapper.missingClassBytes("mapRotationYawHeadField", clazz, bytes)) {
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            String owner = cn.name;
            Field renderYawOffsetField = MinecraftMapper.getField("EntityLivingBase.renderYawOffset");
            for (MethodNode mn : cn.methods) {
                if ((mn.access & 1) == 0 || !mn.desc.equals("(F)V")) continue;
                boolean callsOtherMethods = false;
                Field fieldSet = null;
                for (AbstractInsnNode insn : mn.instructions.toArray()) {
                    if (insn instanceof MethodInsnNode) {
                        callsOtherMethods = true;
                        break;
                    }
                    if (insn instanceof JumpInsnNode) {
                        callsOtherMethods = true;
                        break;
                    }
                    if (!(insn instanceof FieldInsnNode)) continue;
                    FieldInsnNode fin = (FieldInsnNode)insn;
                    if (!fin.owner.equals(owner) || !fin.desc.equals("F") || fin.getOpcode() != 181) continue;
                    fieldSet = clazz.getDeclaredField(fin.name);
                }
                if (callsOtherMethods || fieldSet == null || fieldSet.equals(renderYawOffsetField)) continue;
                fieldSet.setAccessible(true);
                MinecraftMapper.putField("EntityLivingBase.rotationYawHead", fieldSet);
                return;
            }
        }
    }

    public static void mapRenderYawOffsetField(Class<?> clazz) throws Exception {
        byte[] bytes = MinecraftMapper.getClassBytes(clazz);
        if (!MinecraftMapper.missingClassBytes("mapRenderYawOffsetField", clazz, bytes)) {
            ClassReader cr = new ClassReader(bytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            String owner = cn.name;
            for (MethodNode mn : cn.methods) {
                if ((mn.access & 4) == 0 || !mn.desc.equals("(FF)F")) continue;
                for (AbstractInsnNode insn : mn.instructions.toArray()) {
                    if (!(insn instanceof FieldInsnNode)) continue;
                    FieldInsnNode fin = (FieldInsnNode)insn;
                    if (!fin.owner.equals(owner) || !fin.desc.equals("F") || fin.getOpcode() != 181) continue;
                    Field field = clazz.getDeclaredField(fin.name);
                    field.setAccessible(true);
                    MinecraftMapper.putField("EntityLivingBase.renderYawOffset", field);
                    return;
                }
            }
        }
    }

    public static void findEntityFields() {
        try {
            Class<?> entityClass = MinecraftMapper.get("Entity");
            Class<?> entityLivingBaseClass = MinecraftMapper.get("EntityLivingBase");
            if (entityClass == null) {
                System.out.println("Entity class\u00c3\u201e\u00c2\u00b1 bulunamad\u00c3\u201e\u00c2\u00b1!");
                return;
            }
            if (entityLivingBaseClass == null) {
                MinecraftMapper.warnMappingSkip("EntityLivingBase fields", "EntityLivingBase class is not mapped");
            } else {
                MinecraftMapper.mapRenderYawOffsetField(entityLivingBaseClass);
                MinecraftMapper.mapRotationYawHeadField(entityLivingBaseClass);
            }
            MinecraftMapper.mapLastTickFields(entityClass);
            MinecraftMapper.findEntityInsideOpaqueBlock(entityClass);
            MinecraftMapper.findFallDistanceAndInWeb(entityClass);
            MinecraftMapper.findEntityFields(entityClass);
            MinecraftMapper.findTicksExisted();
        }
        catch (Exception e) {
            System.out.println("Entity alanlar\u00c3\u201e\u00c2\u00b1 aran\u00c3\u201e\u00c2\u00b1rken hata:");
            e.printStackTrace();
        }
    }

    public static void findTicksExisted() {
        try {
            Class<?> entityClass = MinecraftMapper.get("Entity");
            Class<?> worldClass = MinecraftMapper.get("World");
            if (entityClass == null || worldClass == null) {
                return;
            }
            ArrayList<Field> entityIntFields = new ArrayList<Field>();
            for (Field field : entityClass.getDeclaredFields()) {
                if (field.getType() != Integer.TYPE || Modifier.isStatic(field.getModifiers())) continue;
                entityIntFields.add(field);
            }
            Field ticksExistedField = MinecraftMapper.findFieldWithIncrementPattern(entityIntFields, worldClass);
            if (ticksExistedField != null) {
                MinecraftMapper.putField("Entity.ticksExisted", ticksExistedField);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static Field findFieldWithIncrementPattern(List<Field> candidateFields, Class<?> worldClass) {
        try {
            byte[] worldBytes = MinecraftMapper.getClassBytes(worldClass);
            if (MinecraftMapper.missingClassBytes("findFieldWithIncrementPattern", worldClass, worldBytes)) {
                return null;
            }
            ClassNode worldNode = new ClassNode();
            ClassReader worldReader = new ClassReader(worldBytes);
            worldReader.accept((ClassVisitor)worldNode, 2);
            for (Field candidate : candidateFields) {
                String fieldName = candidate.getName();
                if (!MinecraftMapper.hasIncrementPatternInWorld(worldNode, fieldName)) continue;
                return candidate;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    private static boolean hasIncrementPatternInWorld(ClassNode worldNode, String fieldName) {
        for (MethodNode method : worldNode.methods) {
            for (AbstractInsnNode insn : method.instructions) {
                if (!(insn instanceof FieldInsnNode)) continue;
                FieldInsnNode fieldInsn = (FieldInsnNode)insn;
                if (!fieldInsn.name.equals(fieldName) || fieldInsn.getOpcode() != 181) continue;
                AbstractInsnNode current = insn.getPrevious();
                boolean foundIADD = false;
                boolean foundICONST1 = false;
                boolean foundGETFIELD = false;
                for (int i = 0; i < 10 && current != null; current = current.getPrevious(), ++i) {
                    if (current.getOpcode() == 96) {
                        foundIADD = true;
                    } else if (current.getOpcode() == 4) {
                        foundICONST1 = true;
                    } else if (current instanceof FieldInsnNode) {
                        FieldInsnNode prevField = (FieldInsnNode)current;
                        if (prevField.name.equals(fieldName) && prevField.getOpcode() == 180) {
                            foundGETFIELD = true;
                        }
                    }
                    if (!foundIADD || !foundICONST1 || !foundGETFIELD) continue;
                    return true;
                }
            }
        }
        return false;
    }

    public static void findPrevRenderYawOffset() {
        try {
            Class<?> entityLivingBaseClass = MinecraftMapper.get("EntityLivingBase");
            if (entityLivingBaseClass == null) {
                return;
            }
            ArrayList<Field> allFloatFields = new ArrayList<Field>();
            for (Field field : entityLivingBaseClass.getDeclaredFields()) {
                if (field.getType() != Float.TYPE || Modifier.isStatic(field.getModifiers())) continue;
                allFloatFields.add(field);
            }
            Field prevRenderYawOffsetField = MinecraftMapper.findFieldByOpcodePatterns(entityLivingBaseClass, allFloatFields);
            if (prevRenderYawOffsetField != null) {
                MinecraftMapper.putField("EntityLivingBase.prevRenderYawOffset", prevRenderYawOffsetField);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Field findFieldByOpcodePatterns(Class<?> targetClass, List<Field> candidateFields) {
        try {
            byte[] classBytes = MinecraftMapper.getClassBytes(targetClass);
            if (MinecraftMapper.missingClassBytes("findFieldByOpcodePatterns", targetClass, classBytes)) {
                return null;
            }
            ClassNode classNode = new ClassNode();
            ClassReader classReader = new ClassReader(classBytes);
            classReader.accept((ClassVisitor)classNode, 2);
            HashMap<Field, Integer> fieldScores = new HashMap<Field, Integer>();
            for (Field candidate : candidateFields) {
                String fieldName = candidate.getName();
                int score = MinecraftMapper.calculatePatternScore(classNode, fieldName);
                fieldScores.put(candidate, score);
            }
            Field bestField = null;
            int highestScore = 0;
            for (Map.Entry entry : fieldScores.entrySet()) {
                if ((Integer)entry.getValue() <= highestScore) continue;
                highestScore = (Integer)entry.getValue();
                bestField = (Field)entry.getKey();
            }
            if (highestScore >= 3) {
                return bestField;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static int calculatePatternScore(ClassNode classNode, String fieldName) {
        int score = 0;
        for (MethodNode method : classNode.methods) {
            AbstractInsnNode insn2;
            AbstractInsnNode insn1;
            int i;
            ListIterator iterator = method.instructions.iterator();
            ArrayList<AbstractInsnNode> instructions = new ArrayList<AbstractInsnNode>();
            while (iterator.hasNext()) {
                instructions.add((AbstractInsnNode)iterator.next());
            }
            for (i = 0; i < instructions.size(); ++i) {
                AbstractInsnNode insn = (AbstractInsnNode)instructions.get(i);
                if (!(insn instanceof FieldInsnNode)) continue;
                FieldInsnNode fieldInsn = (FieldInsnNode)insn;
                if (!fieldInsn.name.equals(fieldName) || fieldInsn.getOpcode() != 181) continue;
                boolean foundGetFieldBefore = false;
                boolean foundAload = false;
                for (int j = 1; j <= 5 && i - j >= 0; ++j) {
                    AbstractInsnNode prev = (AbstractInsnNode)instructions.get(i - j);
                    if (prev instanceof FieldInsnNode) {
                        FieldInsnNode prevField = (FieldInsnNode)prev;
                        if (prevField.getOpcode() != 180 || prevField.name.equals(fieldName)) continue;
                        foundGetFieldBefore = true;
                        continue;
                    }
                    if (prev.getOpcode() != 25) continue;
                    foundAload = true;
                }
                if (!foundGetFieldBefore || !foundAload) continue;
                score += 2;
            }
            for (i = 0; i < instructions.size() - 3; ++i) {
                insn1 = (AbstractInsnNode)instructions.get(i);
                insn2 = (AbstractInsnNode)instructions.get(i + 1);
                AbstractInsnNode insn3 = (AbstractInsnNode)instructions.get(i + 2);
                if (!(insn1 instanceof FieldInsnNode) || insn2.getOpcode() != 102 || !(insn3 instanceof FieldInsnNode)) continue;
                FieldInsnNode fieldInsn1 = (FieldInsnNode)insn1;
                FieldInsnNode fieldInsn3 = (FieldInsnNode)insn3;
                if (!fieldInsn1.name.equals(fieldName) || fieldInsn1.getOpcode() != 180 || fieldInsn3.getOpcode() != 178) continue;
                score += 3;
            }
            for (i = 0; i < instructions.size() - 2; ++i) {
                insn1 = (AbstractInsnNode)instructions.get(i);
                insn2 = (AbstractInsnNode)instructions.get(i + 1);
                AbstractInsnNode insn3 = (AbstractInsnNode)instructions.get(i + 2);
                if (insn1.getOpcode() != 25 || insn2.getOpcode() != 89 || !(insn3 instanceof FieldInsnNode)) continue;
                FieldInsnNode fieldInsn = (FieldInsnNode)insn3;
                if (!fieldInsn.name.equals(fieldName) || fieldInsn.getOpcode() != 180) continue;
                score += 2;
            }
            for (i = 0; i < instructions.size() - 3; ++i) {
                insn1 = (AbstractInsnNode)instructions.get(i);
                insn2 = (AbstractInsnNode)instructions.get(i + 1);
                AbstractInsnNode insn3 = (AbstractInsnNode)instructions.get(i + 2);
                if (!(insn1 instanceof MethodInsnNode) || insn2.getOpcode() != 102 && insn2.getOpcode() != 98 || !(insn3 instanceof FieldInsnNode)) continue;
                FieldInsnNode fieldInsn = (FieldInsnNode)insn3;
                if (!fieldInsn.name.equals(fieldName) || fieldInsn.getOpcode() != 181) continue;
                score += 3;
            }
            int fieldReferences = MinecraftMapper.countFieldReferences(method, fieldName);
            if (fieldReferences < 4) continue;
            score += 2;
        }
        return score;
    }

    private static int countFieldReferences(MethodNode method, String fieldName) {
        int count = 0;
        for (AbstractInsnNode insn : method.instructions) {
            if (!(insn instanceof FieldInsnNode)) continue;
            FieldInsnNode fieldInsn = (FieldInsnNode)insn;
            if (!fieldInsn.name.equals(fieldName)) continue;
            ++count;
        }
        return count;
    }

    public static void findRenderManagerFields() {
    }

    public static void findRendererLivingEntity() {
        Class<?> entityLivingBaseClass = MinecraftMapper.get("EntityLivingBase");
        Class<?> renderClass = MinecraftMapper.get("Render");
        if (entityLivingBaseClass != null && renderClass != null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                ParameterizedType pType;
                Type[] typeArgs;
                Type genericSuperclass;
                if (!renderClass.isAssignableFrom(clazz) || clazz.equals(renderClass) || !((genericSuperclass = clazz.getGenericSuperclass()) instanceof ParameterizedType) || (typeArgs = (pType = (ParameterizedType)genericSuperclass).getActualTypeArguments()).length < 1) continue;
                Type firstTypeArg = typeArgs[0];
                if (firstTypeArg instanceof TypeVariable) {
                    Type[] bounds;
                    TypeVariable typeVar = (TypeVariable)firstTypeArg;
                    for (Type bound : bounds = typeVar.getBounds()) {
                        if (!(bound instanceof Class) || !entityLivingBaseClass.isAssignableFrom((Class)bound)) continue;
                        MinecraftMapper.put("RendererLivingEntity", clazz);
                        MinecraftMapper.findLayerRendererClass(clazz);
                        return;
                    }
                    continue;
                }
                if (!(firstTypeArg instanceof Class) || !entityLivingBaseClass.isAssignableFrom((Class)firstTypeArg)) continue;
                MinecraftMapper.put("RendererLivingEntity", clazz);
                MinecraftMapper.findLayerRendererClass(clazz);
                return;
            }
            System.out.println("RendererLivingEntity bulunamad\u00c3\u201e\u00c2\u00b1!");
        } else {
            System.out.println("EntityLivingBase veya Render class bulunamad\u00c3\u201e\u00c2\u00b1!");
        }
    }

    public static void findLayerRendererClass(Class<?> rendererLivingEntityClass) {
        Type rawType;
        for (Method method : rendererLivingEntityClass.getDeclaredMethods()) {
            Type[] genericParamTypes = method.getGenericParameterTypes();
            if (genericParamTypes.length < 1) continue;
            for (Type paramType : genericParamTypes) {
                ParameterizedType secondPType;
                ParameterizedType pType;
                Type[] typeArgs;
                if (!(paramType instanceof ParameterizedType) || (typeArgs = (pType = (ParameterizedType)paramType).getActualTypeArguments()).length < 2) continue;
                Type secondArg = typeArgs[1];
                if (secondArg instanceof TypeVariable) {
                    Type[] boundsU;
                    TypeVariable typeVarU = (TypeVariable)secondArg;
                    for (Type boundU : boundsU = typeVarU.getBounds()) {
                        ParameterizedType boundPType;
                        Type rawType2;
                        if (!(boundU instanceof ParameterizedType) || !((rawType2 = (boundPType = (ParameterizedType)boundU).getRawType()) instanceof Class)) continue;
                        MinecraftMapper.put("LayerRenderer", (Class)rawType2);
                        return;
                    }
                    continue;
                }
                if (!(secondArg instanceof ParameterizedType) || !((rawType = (secondPType = (ParameterizedType)secondArg).getRawType()) instanceof Class)) continue;
                MinecraftMapper.put("LayerRenderer", (Class)rawType);
                return;
            }
        }
        for (Method method : rendererLivingEntityClass.getDeclaredMethods()) {
            Type[] boundsU;
            TypeVariable<Method>[] typeParams = method.getTypeParameters();
            if (typeParams.length < 2) continue;
            TypeVariable<Method> V = typeParams[0];
            TypeVariable<Method> U = typeParams[1];
            for (Type boundU : boundsU = U.getBounds()) {
                ParameterizedType pType;
                if (!(boundU instanceof ParameterizedType) || !((rawType = (pType = (ParameterizedType)boundU).getRawType()) instanceof Class)) continue;
                MinecraftMapper.put("LayerRenderer", (Class)rawType);
                return;
            }
        }
    }

    public static void findItemRendererClass() {
        Vector classes = new Vector(MinecraftMapper.getClasses());
        Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
        Class<?> entityLivingBaseClass = MinecraftMapper.get("EntityLivingBase");
        Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
        Iterator<Class<?>> var4 = classes.iterator();
        block4: while (var4.hasNext()) {
            Class<?> declaringClass;
            Class<?> transformsType;
            int n;
            Object instance;
            AccessibleObject[] ctor;
            Class<?>[] params232;
            Constructor<?>[] ctors;
            Class<?> candidate = var4.next();
            if (candidate.isEnum() || candidate.isInterface() || candidate.getSuperclass() != Object.class || (ctors = candidate.getDeclaredConstructors()).length != 1 || (params232 = (ctor = ctors[0]).getParameterTypes()).length != 1 || params232[0] != minecraftClass) continue;
            try {
                ctor.setAccessible(true);
                instance = ctor.newInstance(MinecraftMapper.getMinecraft());
            }
            catch (Exception exception) {
                continue;
            }
            boolean hasMagicInt = false;
            ctor = candidate.getDeclaredFields();
            int params232 = ctor.length;
            for (n = 0; n < params232; ++n) {
                Field field = ctor[n];
                if (field.getType() != Integer.TYPE) continue;
                try {
                    field.setAccessible(true);
                    if (field.getInt(instance) != -1) continue;
                    hasMagicInt = true;
                    break;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if (!hasMagicInt) continue;
            ctor = candidate.getDeclaredMethods();
            params232 = ctor.length;
            for (n = 0; n < params232; ++n) {
                AccessibleObject accessibleObject = ctor[n];
                Class<?>[] paramTypes = ((Method)accessibleObject).getParameterTypes();
                if (paramTypes.length != 3) continue;
                boolean hasEntityLivingBase = false;
                boolean hasItemStack = false;
                boolean hasUnknown = false;
                Class<?> unknownClass = null;
                for (Class<?> paramType : paramTypes) {
                    if (paramType == entityLivingBaseClass) {
                        hasEntityLivingBase = true;
                        continue;
                    }
                    if (paramType == itemStackClass) {
                        hasItemStack = true;
                        continue;
                    }
                    if (paramType == minecraftClass || paramType == Float.TYPE) continue;
                    hasUnknown = true;
                    unknownClass = paramType;
                }
                if (!hasEntityLivingBase || !hasItemStack || !hasUnknown) continue;
                MinecraftMapper.putMethod("ItemRenderer.renderItem", (Method)accessibleObject);
                if (unknownClass == null) break;
                if (unknownClass.isEnum()) {
                    MinecraftMapper.put("ItemCameraTransformsType", unknownClass);
                    Class<?> declaringClass2 = unknownClass.getDeclaringClass();
                    if (declaringClass2 == null) break;
                    MinecraftMapper.put("ItemCameraTransforms", declaringClass2);
                    break;
                }
                MinecraftMapper.put("ItemCameraTransforms", unknownClass);
                break;
            }
            if (MinecraftMapper.get("ItemCameraTransforms") == null && (transformsType = MinecraftMapper.get("ItemCameraTransformsType")) != null && transformsType.isEnum() && (declaringClass = transformsType.getDeclaringClass()) != null) {
                MinecraftMapper.put("ItemCameraTransforms", declaringClass);
            }
            for (Method method : candidate.getDeclaredMethods()) {
                if (!Modifier.isPrivate(method.getModifiers()) || method.getReturnType() != Void.TYPE || method.getParameterCount() != 0) continue;
                MinecraftMapper.putMethod("ItemRenderer.doBlockTransform", method);
                break;
            }
            for (Method method : candidate.getDeclaredMethods()) {
                if (!Modifier.isPublic(method.getModifiers()) || method.getReturnType() != Void.TYPE || method.getParameterCount() != 1 || method.getParameterTypes()[0] != Float.TYPE) continue;
                MinecraftMapper.put("ItemRenderer", candidate);
                MinecraftMapper.putMethod("ItemRenderer.renderItemInFirstPerson", method);
            }
            Method[] methodArray = candidate.getDeclaredMethods();
            int n2 = methodArray.length;
            n = 0;
            while (true) {
                if (n >= n2) continue block4;
                Method method = methodArray[n];
                if (method.getName().equals("\u00c3\u201d\u00c2\u00b5")) {
                    method.setAccessible(true);
                    MinecraftMapper.putMethod("ItemRenderer.transformFirstPersonItem", method);
                    continue block4;
                }
                ++n;
            }
            break;
        }
        return;
    }

    public static Class<?> findSwingPacket(Class<?> packetClass) {
        if (packetClass == null) {
            return null;
        }
        List<Class<?>> classes = MinecraftMapper.getClasses();
        ArrayList matchingClasses = new ArrayList();
        for (Class<?> clazz : classes) {
            if (!packetClass.isAssignableFrom(clazz) || clazz == packetClass) continue;
            Constructor<?>[] constructors = clazz.getDeclaredConstructors();
            boolean hasOnlyParameterlessConstructors = true;
            for (Constructor<?> constructor : constructors) {
                if (constructor.getParameterCount() <= 0) continue;
                hasOnlyParameterlessConstructors = false;
                break;
            }
            if (!hasOnlyParameterlessConstructors) continue;
            matchingClasses.add(clazz);
        }
        if (matchingClasses.size() < 2) {
            return null;
        }
        Class secondClass = (Class)matchingClasses.get(1);
        return secondClass;
    }

    public static void findItemStackSize() {
        try {
            Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
            if (itemStackClass == null) {
                return;
            }
            for (Field f : itemStackClass.getDeclaredFields()) {
                int mods = f.getModifiers();
                if (Modifier.isStatic(mods) || f.getType() != Integer.TYPE) continue;
                f.setAccessible(true);
                Class<?> itemClass = MinecraftMapper.get("Item");
                if (itemClass == null) {
                    // empty if block
                }
                try {
                    Constructor<?> itemCtor = itemClass.getDeclaredConstructor(new Class[0]);
                    itemCtor.setAccessible(true);
                    Object dummyItem = itemCtor.newInstance(new Object[0]);
                    Constructor<?> itemStackCtor = itemStackClass.getDeclaredConstructor(itemClass, Integer.TYPE, Integer.TYPE);
                    itemStackCtor.setAccessible(true);
                    Object itemStackInstance = itemStackCtor.newInstance(dummyItem, 3, 0);
                    if (f.getInt(itemStackInstance) != 3) continue;
                    MinecraftMapper.putField("ItemStack.stackSize", f);
                    return;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void findsendChatMessage() {
        try {
            Class<?> playerClass = MinecraftMapper.get("EntityPlayerSP");
            if (playerClass == null) {
                return;
            }
            for (Method m : playerClass.getDeclaredMethods()) {
                int mods = m.getModifiers();
                if (!Modifier.isPublic(mods) || m.getReturnType() != Void.TYPE || m.getParameterCount() != 1 || m.getParameterTypes()[0] != String.class || !m.getName().equals("i")) continue;
                m.setAccessible(true);
                MinecraftMapper.putMethod("EntityPlayerSP.sendChatMessage", m);
                return;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void findItemStackItemField() {
        try {
            Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
            if (itemStackClass == null) {
                return;
            }
            Class<?> itemClass = MinecraftMapper.get("Item");
            if (itemClass == null) {
                return;
            }
            for (Field f : itemStackClass.getDeclaredFields()) {
                int mods = f.getModifiers();
                if (Modifier.isStatic(mods) || f.getType() != itemClass) continue;
                f.setAccessible(true);
                try {
                    Constructor<?> itemCtor = itemClass.getDeclaredConstructor(new Class[0]);
                    itemCtor.setAccessible(true);
                    Object dummyItem = itemCtor.newInstance(new Object[0]);
                    Constructor<?> itemStackCtor = itemStackClass.getDeclaredConstructor(itemClass, Integer.TYPE, Integer.TYPE);
                    itemStackCtor.setAccessible(true);
                    Object itemStackInstance = itemStackCtor.newInstance(dummyItem, 1, 0);
                    if (f.get(itemStackInstance) != dummyItem) continue;
                    MinecraftMapper.putField("ItemStack.item", f);
                    return;
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void findItemStackDisplayName() {
        try {
            Class<?> itemStackClass = MinecraftMapper.get("ItemStack");
            if (itemStackClass == null) {
                System.out.println("ItemStack class\u00c3\u201e\u00c2\u00b1 bulunamad\u00c3\u201e\u00c2\u00b1!");
                return;
            }
            Class<?> itemClass = MinecraftMapper.get("Item");
            if (itemClass == null) {
                System.out.println("Item class\u00c3\u201e\u00c2\u00b1 bulunamad\u00c3\u201e\u00c2\u00b1!");
                return;
            }
            Constructor<?> itemCtor = itemClass.getDeclaredConstructor(new Class[0]);
            itemCtor.setAccessible(true);
            Object dummyItem = itemCtor.newInstance(new Object[0]);
            Constructor<?> itemStackCtor = itemStackClass.getDeclaredConstructor(itemClass, Integer.TYPE, Integer.TYPE);
            itemStackCtor.setAccessible(true);
            Object dummyStack = itemStackCtor.newInstance(dummyItem, 1, 0);
            for (Method m : itemStackClass.getDeclaredMethods()) {
                if (m.getReturnType() != String.class || m.getParameterCount() != 0 || m.getName().equals("toString")) continue;
                m.setAccessible(true);
                try {
                    String str;
                    Object result = m.invoke(dummyStack, new Object[0]);
                    if (!(result instanceof String) || (str = (String)result).length() != 1 && !str.contains("k")) continue;
                    MinecraftMapper.putMethod("ItemStack.getDisplayName", m);
                    return;
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void findThirdPersonViewField() {
        try {
            Class<?> renderManagerClass = MinecraftMapper.get("RenderManager");
            Class<?> worldClass = MinecraftMapper.get("World");
            Class<?> fontRendererClass = MinecraftMapper.get("FontRenderer");
            Class<?> entityClass = MinecraftMapper.get("Entity");
            Class<?> gameSettingsClass = MinecraftMapper.get("GameSettings");
            if (renderManagerClass == null || worldClass == null || fontRendererClass == null || entityClass == null || gameSettingsClass == null) {
                MinecraftMapper.warnMappingSkip("findThirdPersonViewField", "required class mapping is missing");
                return;
            }
            for (Field field : gameSettingsClass.getDeclaredFields()) {
                if (!Modifier.isPublic(field.getModifiers()) || field.getType() != Integer.TYPE) continue;
                MinecraftMapper.putField("GameSettings.publicIntField", field);
            }
            for (AccessibleObject accessibleObject : renderManagerClass.getDeclaredMethods()) {
                Field[] paramFields;
                Class<?>[] params;
                if (!Modifier.isPublic(((Method)accessibleObject).getModifiers()) || ((Method)accessibleObject).getReturnType() != Void.TYPE || (params = ((Method)accessibleObject).getParameterTypes()).length != 6 || params[0] != worldClass || params[1] != fontRendererClass || params[2] != entityClass || params[3] != entityClass || params[4] != gameSettingsClass || params[5] != Float.TYPE) continue;
                ((Method)accessibleObject).setAccessible(true);
                Object dummyWorld = worldClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                Object dummyFont = fontRendererClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                Object dummyEntity1 = entityClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                Object dummyEntity2 = entityClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                Object dummySettings = gameSettingsClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                try {
                    ((Method)accessibleObject).invoke(renderManagerClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]), dummyWorld, dummyFont, dummyEntity1, dummyEntity2, dummySettings, Float.valueOf(0.0f));
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                for (Field f : paramFields = dummySettings.getClass().getDeclaredFields()) {
                    if (!Modifier.isPublic(f.getModifiers()) || f.getType() != Integer.TYPE) continue;
                    MinecraftMapper.putField("GameSettings.methodIntField", f);
                    return;
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void detectC05Fields(byte[] classBytes, Class<?> clazz) throws Exception {
        if (!MinecraftMapper.missingClassBytes("detectC05Fields", clazz, classBytes)) {
            ClassNode classNode = new ClassNode();
            ClassReader reader = new ClassReader(classBytes);
            reader.accept((ClassVisitor)classNode, 0);
            String[] found = new String[2];
            for (MethodNode method : classNode.methods) {
                if (!method.name.equals("<init>") || !method.desc.equals("(FFZ)V")) continue;
                int putIndex = 0;
                for (AbstractInsnNode insn : method.instructions) {
                    if (insn.getOpcode() != 181) continue;
                    FieldInsnNode fin = (FieldInsnNode)insn;
                    if (!"F".equals(fin.desc) || putIndex >= 2) continue;
                    found[putIndex] = fin.name;
                    ++putIndex;
                }
            }
            if (found[0] != null && found[1] != null) {
                Field yaw = clazz.getDeclaredField(found[0]);
                yaw.setAccessible(true);
                Field pitch = clazz.getDeclaredField(found[1]);
                pitch.setAccessible(true);
                MinecraftMapper.putField("C03PacketPlayer.yaw", yaw);
                MinecraftMapper.putField("C03PacketPlayer.pitch", pitch);
            } else {
                throw new IllegalStateException("Yaw ve Pitch alanlar\u00c3\u201e\u00c2\u00b1 bulunamad\u00c3\u201e\u00c2\u00b1.");
            }
        }
    }

    public static void mapNetHandlerPlayClient() {
        try {
            Class<?> clazz = MinecraftMapper.get("NetHandlerPlayClient");
            if (clazz == null) {
                MinecraftMapper.warnMappingSkip("mapNetHandlerPlayClient", "NetHandlerPlayClient is not mapped");
                return;
            }
            for (Method m : clazz.getDeclaredMethods()) {
                Class<?>[] params = m.getParameterTypes();
                if (params.length != 1 || !params[0].equals(UUID.class)) continue;
                MinecraftMapper.putMethod("NetHandlerPlayClient.getPlayerInfo", m);
                break;
            }
        }
        catch (Exception e) {
            MinecraftMapper.warnMappingSkip("mapNetHandlerPlayClient", e.getMessage());
        }
    }

    public static boolean isFloatContainerMethod(MethodNode mn) {
        if (!"(F)F".equals(mn.desc)) {
            return false;
        }
        boolean hasMonitor = false;
        boolean hasFload1 = false;
        boolean hasDoubleInvoke = false;
        boolean hasPutField = false;
        AbstractInsnNode prevInvoke = null;
        for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
            int op = insn.getOpcode();
            if (op == 194 || op == 195) {
                hasMonitor = true;
            }
            if (op == 23 && ((VarInsnNode)insn).var == 1) {
                hasFload1 = true;
            }
            if (op == 181) {
                hasPutField = true;
            }
            if (op != 182) continue;
            if (prevInvoke != null && prevInvoke.getOpcode() == 182) {
                MethodInsnNode m1 = (MethodInsnNode)prevInvoke;
                MethodInsnNode m2 = (MethodInsnNode)insn;
                if ("()F".equals(m1.desc) && "(F)F".equals(m2.desc)) {
                    hasDoubleInvoke = true;
                }
            }
            prevInvoke = insn;
        }
        return hasMonitor && hasFload1 && hasDoubleInvoke && hasPutField;
    }

    public static void processFloatContainerClasses() {
        new Vector(MinecraftMapper.getClasses());
        Class<?> entityLivingBase = MinecraftMapper.get("EntityLivingBase");
        if (entityLivingBase == null) {
            System.out.println("EntityLivingBase class bulunamad\u00c3\u201e\u00c2\u00b1!");
        } else {
            HashMap<Class, List> fieldTypes = new HashMap<Class, List>();
            for (Field field : entityLivingBase.getDeclaredFields()) {
                field.setAccessible(true);
                Class<?> fieldType = field.getType();
                if (!fieldType.getName().startsWith("craftrise.")) continue;
                fieldTypes.computeIfAbsent(fieldType, k -> new ArrayList()).add(field);
            }
            Class targetType = null;
            for (Map.Entry entry : fieldTypes.entrySet()) {
                if (((List)entry.getValue()).size() < 4) continue;
                targetType = (Class)entry.getKey();
                break;
            }
            if (targetType != null) {
                boolean fieldsSetInConstructor = false;
                int newInstanceCount = 0;
                try {
                    byte[] classBytes = MinecraftMapper.getClassBytes(entityLivingBase);
                    if (classBytes != null) {
                        ClassNode cn = new ClassNode();
                        new ClassReader(classBytes).accept((ClassVisitor)cn, 0);
                        for (MethodNode method : cn.methods) {
                            if (!"<init>".equals(method.name)) continue;
                            for (AbstractInsnNode insn = method.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                                if (insn.getOpcode() != 187) continue;
                                TypeInsnNode tin = (TypeInsnNode)insn;
                                if (!tin.desc.equals(org.objectweb.asm.Type.getInternalName((Class)targetType))) continue;
                                ++newInstanceCount;
                            }
                        }
                        if (newInstanceCount >= 4) {
                            fieldsSetInConstructor = true;
                        }
                    }
                }
                catch (Exception classBytes) {
                    // empty catch block
                }
                if (fieldsSetInConstructor) {
                    Method floatMethod;
                    MinecraftMapper.put("FloatContainer", targetType);
                    Method setValueMethod = MinecraftMapper.findFloatSetValueMethod(targetType);
                    if (setValueMethod != null) {
                        MinecraftMapper.putMethod("FloatContainer.setValue", setValueMethod);
                    }
                    if ((floatMethod = MinecraftMapper.findRealFloatGetter(targetType)) != null) {
                        MinecraftMapper.putMethod("FloatContainer.getFloatValue", floatMethod);
                    }
                }
            }
        }
    }

    private static Method findFloatSetValueMethod(Class<?> cls) {
        try {
            byte[] bytes = MinecraftMapper.getClassBytes(cls);
            if (bytes == null) {
                return null;
            }
            ClassNode cn = new ClassNode();
            new ClassReader(bytes).accept((ClassVisitor)cn, 0);
            for (MethodNode mn : cn.methods) {
                if (!"(F)F".equals(mn.desc)) continue;
                boolean monitor = false;
                boolean fload1 = false;
                boolean putfield = false;
                boolean doubleInvoke = false;
                AbstractInsnNode lastInvoke = null;
                for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    int op = insn.getOpcode();
                    if (op == 194 || op == 195) {
                        monitor = true;
                    }
                    if (op == 23 && ((VarInsnNode)insn).var == 1) {
                        fload1 = true;
                    }
                    if (op == 181) {
                        putfield = true;
                    }
                    if (op != 182) continue;
                    if (lastInvoke != null) {
                        MethodInsnNode m1 = (MethodInsnNode)lastInvoke;
                        MethodInsnNode m2 = (MethodInsnNode)insn;
                        if ("()F".equals(m1.desc) && "(F)F".equals(m2.desc)) {
                            doubleInvoke = true;
                        }
                    }
                    lastInvoke = insn;
                }
                if (!monitor || !fload1 || !putfield || !doubleInvoke) continue;
                for (Method m : cls.getDeclaredMethods()) {
                    if (!m.getName().equals(mn.name) || !org.objectweb.asm.Type.getMethodDescriptor((Method)m).equals(mn.desc)) continue;
                    m.setAccessible(true);
                    return m;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static Method findRealFloatGetter(Class<?> targetType) {
        try {
            byte[] classBytes = MinecraftMapper.getClassBytes(targetType);
            if (classBytes == null) {
                return null;
            }
            ClassReader cr = new ClassReader(classBytes);
            ClassNode cn = new ClassNode();
            cr.accept((ClassVisitor)cn, 0);
            for (MethodNode mn : cn.methods) {
                if ((mn.access & 1) == 0 || !"()F".equals(mn.desc)) continue;
                boolean looksLikeRealGetter = false;
                if ((mn.access & 0x20) != 0) {
                    looksLikeRealGetter = true;
                } else {
                    for (AbstractInsnNode insn = mn.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                        int op = insn.getOpcode();
                        if (op == 194 || op == 195) {
                            looksLikeRealGetter = true;
                            break;
                        }
                        if (!(insn instanceof MethodInsnNode)) continue;
                        MethodInsnNode min = (MethodInsnNode)insn;
                        if (min.owner.equals("java/lang/Runtime") && min.name.equals("halt")) {
                            looksLikeRealGetter = true;
                            break;
                        }
                        if (!min.owner.equals("java/io/PrintStream") || !min.name.equals("println")) continue;
                        looksLikeRealGetter = true;
                        break;
                    }
                }
                if (!looksLikeRealGetter) continue;
                try {
                    Method m = targetType.getDeclaredMethod(mn.name, new Class[0]);
                    m.setAccessible(true);
                    return m;
                }
                catch (Exception var12) {
                    for (Method mm : targetType.getDeclaredMethods()) {
                        if (!mm.getName().equals(mn.name) || mm.getParameterCount() != 0 || mm.getReturnType() != Float.TYPE) continue;
                        mm.setAccessible(true);
                        return mm;
                    }
                }
            }
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
        return null;
    }

    public static void extractKeyBindings(Class<?> gameSettingsClass) {
        try {
            if (gameSettingsClass == null) {
                MinecraftMapper.warnMappingSkip("extractKeyBindings", "GameSettings is not mapped");
                return;
            }
            Object gsInstance = gameSettingsClass.getConstructor(MinecraftMapper.get("Minecraft"), File.class).newInstance(MinecraftMapper.getMinecraft(), new File("dummy"));
            Field keyCodeField = MinecraftMapper.getField("KeyBinding.keyCode");
            if (keyCodeField == null) {
                MinecraftMapper.warnMappingSkip("extractKeyBindings", "KeyBinding.keyCode is not mapped");
                return;
            }
            keyCodeField.setAccessible(true);
            for (Field f : gameSettingsClass.getDeclaredFields()) {
                f.setAccessible(true);
                Object fieldValue = f.get(gsInstance);
                if (fieldValue == null) continue;
                Class<?> fieldType = fieldValue.getClass();
                if (fieldType.equals(MinecraftMapper.get("KeyBinding"))) {
                    int code = keyCodeField.getInt(fieldValue);
                    switch (code) {
                        case 17: {
                            MinecraftMapper.putField("GameSettings.keyBindForward", f);
                            break;
                        }
                        case 29: {
                            MinecraftMapper.putField("GameSettings.keyBindSprint", f);
                            break;
                        }
                        case 30: {
                            MinecraftMapper.putField("GameSettings.keyBindLeft", f);
                            break;
                        }
                        case 31: {
                            MinecraftMapper.putField("GameSettings.keyBindBack", f);
                            break;
                        }
                        case 32: {
                            MinecraftMapper.putField("GameSettings.keyBindRight", f);
                            break;
                        }
                        case 42: {
                            MinecraftMapper.putField("GameSettings.keyBindSneak", f);
                            break;
                        }
                        case 57: {
                            MinecraftMapper.putField("GameSettings.keyBindJump", f);
                        }
                    }
                }
                if (!fieldType.isArray() || !fieldType.getComponentType().equals(MinecraftMapper.get("KeyBinding"))) continue;
                Object[] arr = (Object[])fieldValue;
                for (int i = 0; i < arr.length; ++i) {
                    Object keyBind = arr[i];
                    keyCodeField.getInt(keyBind);
                }
            }
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static void findRenderPlayerMainModelOpcodes(Class<?> renderPlayerClass) {
        if (renderPlayerClass != null) {
            MinecraftMapper.put("RenderPlayer", renderPlayerClass);
            try {
                byte[] classBytes = MinecraftMapper.getClassBytes(renderPlayerClass);
                if (MinecraftMapper.missingClassBytes("findRenderPlayerMainModelOpcodes", renderPlayerClass, classBytes)) {
                    return;
                }
                ClassReader reader = new ClassReader(classBytes);
                ClassNode classNode = new ClassNode();
                reader.accept((ClassVisitor)classNode, 0);
                for (MethodNode mn : classNode.methods) {
                    if ((mn.access & 1) == 0 || !mn.desc.startsWith("()")) continue;
                    InsnList insns = mn.instructions;
                    boolean callsSuper = false;
                    for (AbstractInsnNode insn : insns) {
                        MethodInsnNode mi;
                        if (!(insn instanceof MethodInsnNode) || (mi = (MethodInsnNode)insn).getOpcode() != 183 || !mi.owner.equals(org.objectweb.asm.Type.getInternalName(renderPlayerClass.getSuperclass()))) continue;
                        callsSuper = true;
                        break;
                    }
                    if (!callsSuper) continue;
                    Method method = renderPlayerClass.getDeclaredMethod(mn.name, new Class[0]);
                    MinecraftMapper.putMethod("RenderPlayer.getMainModel", method);
                    break;
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void findGetRenderManager() {
        Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
        Class<?> renderManagerClass = MinecraftMapper.get("RenderManager");
        if (minecraftClass != null && renderManagerClass != null) {
            for (Method method : minecraftClass.getDeclaredMethods()) {
                if (!Modifier.isPublic(method.getModifiers()) || !method.getReturnType().equals(renderManagerClass) || method.getParameterCount() != 0) continue;
                MinecraftMapper.putMethod("Minecraft.getRenderManager", method);
                break;
            }
        }
    }

    public static void findRenderManagerHooks() throws IOException {
        Class<?> renderManagerClass = MinecraftMapper.get("RenderManager");
        if (renderManagerClass != null) {
            byte[] classBytes = MinecraftMapper.getClassBytes(renderManagerClass);
            if (classBytes != null) {
                ClassReader cr = new ClassReader(classBytes);
                ClassNode classNode = new ClassNode();
                cr.accept((ClassVisitor)classNode, 0);
                List methods = classNode.methods;
                Method targetMethod = null;
                for (Method method : methods) {
                    if ((((MethodNode)method).access & 1) == 0 || !((MethodNode)method).desc.equals("(DDD)V")) continue;
                    targetMethod = method;
                    break;
                }
                if (targetMethod != null) {
                    InsnList insns = ((MethodNode)targetMethod).instructions;
                    ArrayList<FieldInsnNode> doubleFields = new ArrayList<FieldInsnNode>();
                    for (AbstractInsnNode insn = insns.getFirst(); insn != null; insn = insn.getNext()) {
                        if (insn.getOpcode() != 181) continue;
                        FieldInsnNode fin = (FieldInsnNode)insn;
                        if (!fin.desc.equals("D")) continue;
                        doubleFields.add(fin);
                    }
                    if (doubleFields.size() >= 3) {
                        try {
                            Field fieldX = renderManagerClass.getDeclaredField(((FieldInsnNode)doubleFields.get((int)0)).name);
                            Field fieldY = renderManagerClass.getDeclaredField(((FieldInsnNode)doubleFields.get((int)1)).name);
                            Field fieldZ = renderManagerClass.getDeclaredField(((FieldInsnNode)doubleFields.get((int)2)).name);
                            MinecraftMapper.putField("RenderManager.renderPosX", fieldX);
                            MinecraftMapper.putField("RenderManager.renderPosY", fieldY);
                            MinecraftMapper.putField("RenderManager.renderPosZ", fieldZ);
                        }
                        catch (NoSuchFieldException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            Class<?> entityClass = MinecraftMapper.get("Entity");
            Class<?> renderClass = MinecraftMapper.get("Render");
            if (entityClass != null && renderClass != null) {
                for (Method method : renderManagerClass.getDeclaredMethods()) {
                    Class<?>[] params;
                    if (!Modifier.isPublic(method.getModifiers()) || (params = method.getParameterTypes()).length != 1 || !params[0].equals(entityClass) || !renderClass.isAssignableFrom(method.getReturnType())) continue;
                    method.setAccessible(true);
                    MinecraftMapper.putMethod("RenderManager.getEntityRenderObject", method);
                    break;
                }
            }
        }
    }

    public static void findAddMappingCalls(Class<?> entityListClass) {
        try {
            for (Class<?> clazz : new Vector(MinecraftMapper.getClasses())) {
                try {
                    Method clinit = clazz.getDeclaredMethod("<clinit>", new Class[0]);
                    clinit.setAccessible(true);
                    MinecraftMapper.analyzeClassForEntityRegistrations(clazz);
                }
                catch (NoSuchMethodException noSuchMethodException) {}
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static List<Object> getPlayerEntitiesInWorld() {
        List<Object> emptyList = Collections.emptyList();
        try {
            Object player = MinecraftMapper.getThePlayer();
            Object worldObj = MinecraftMapper.getWorldObj();
            Field playerEntitiesField = MinecraftMapper.getField("World.playerEntities");
            if (player != null && worldObj != null && playerEntitiesField != null) {
                Object entityList = playerEntitiesField.get(worldObj);
                if (!(entityList instanceof List)) {
                    return emptyList;
                }
                ArrayList<Object> entities = new ArrayList<Object>();
                for (Object entity : (List)entityList) {
                    if (entity == null || entity == player || MinecraftMapper.isEntityDead(entity)) continue;
                    entities.add(entity);
                }
                return entities;
            }
            return emptyList;
        }
        catch (Exception e) {
            Logger.debug("[Mapper] getPlayerEntitiesInWorld error: " + e.getMessage());
            return emptyList;
        }
    }

    private static boolean isEntityDead(Object entity) {
        if (entity == null) {
            return false;
        }
        try {
            Field f = MinecraftMapper.getField("Entity.isDead");
            if (f == null) {
                f = MinecraftMapper.getField("Entity.dead");
            }
            if (f != null) {
                f.setAccessible(true);
                Object val = f.get(entity);
                if (val instanceof Boolean) {
                    return (Boolean)val;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    public static String getName(Object entity) {
        try {
            String s = String.valueOf(entity);
            int start = s.indexOf(39) + 1;
            int end = s.indexOf(39, start);
            if (start > 0 && end > start) {
                return s.substring(start, end);
            }
        }
        catch (Exception e) {
            System.out.println("\u00c3\u201e\u00c2\u00b0sim ay\u00c3\u201e\u00c2\u00b1klanamad\u00c3\u201e\u00c2\u00b1: " + e.getMessage());
        }
        return "Bilinmiyor";
    }

    public static Field asmFieldToReflectionField(Class<?> clazz, String fieldName, String fieldDesc) {
        try {
            Class<Object> fieldType;
            String className;
            switch (className = org.objectweb.asm.Type.getType((String)fieldDesc).getClassName()) {
                case "boolean": {
                    fieldType = Boolean.TYPE;
                    break;
                }
                case "byte": {
                    fieldType = Byte.TYPE;
                    break;
                }
                case "char": {
                    fieldType = Character.TYPE;
                    break;
                }
                case "short": {
                    fieldType = Short.TYPE;
                    break;
                }
                case "int": {
                    fieldType = Integer.TYPE;
                    break;
                }
                case "long": {
                    fieldType = Long.TYPE;
                    break;
                }
                case "float": {
                    fieldType = Float.TYPE;
                    break;
                }
                case "double": {
                    fieldType = Double.TYPE;
                    break;
                }
                case "void": {
                    fieldType = Void.TYPE;
                    break;
                }
                default: {
                    fieldType = Class.forName(className, false, clazz.getClassLoader());
                }
            }
            Field field = clazz.getDeclaredField(fieldName);
            return field.getType().equals(fieldType) ? field : null;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Method asmMethodToReflectionMethod(Class<?> clazz, String methodName, String methodDesc) {
        try {
            org.objectweb.asm.Type[] argTypes = org.objectweb.asm.Type.getArgumentTypes((String)methodDesc);
            Class[] paramClasses = new Class[argTypes.length];
            ClassLoader loader = clazz.getClassLoader();
            for (int i = 0; i < argTypes.length; ++i) {
                paramClasses[i] = Class.forName(argTypes[i].getClassName(), false, loader);
            }
            return clazz.getDeclaredMethod(methodName, paramClasses);
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void findBlockInChunk(Class<?> chunkClass) {
        Class<?> blockPosClass = MinecraftMapper.get("BlockPos");
        if (chunkClass != null && blockPosClass != null) {
            Class<?> returnType;
            Class<?>[] params;
            int mods;
            HashMap returnTypeCount = new HashMap();
            Object targetMethod = null;
            for (Method method : chunkClass.getDeclaredMethods()) {
                mods = method.getModifiers();
                params = method.getParameterTypes();
                returnType = method.getReturnType();
                if (!Modifier.isPublic(mods) || Modifier.isStatic(mods) || params.length != 1 || !blockPosClass.equals(params[0]) || blockPosClass.equals(returnType) || returnType.isPrimitive()) continue;
                returnTypeCount.put(returnType, returnTypeCount.getOrDefault(returnType, 0) + 1);
            }
            for (Method method : chunkClass.getDeclaredMethods()) {
                mods = method.getModifiers();
                params = method.getParameterTypes();
                returnType = method.getReturnType();
                if (!Modifier.isPublic(mods) || Modifier.isStatic(mods) || params.length != 1 || !blockPosClass.equals(params[0]) || blockPosClass.equals(returnType) || returnType.isPrimitive() || (Integer)returnTypeCount.get(returnType) != 1) continue;
                MinecraftMapper.put("Block", returnType);
                MinecraftMapper.findGetBlockInChunk();
                break;
            }
        } else {
            MinecraftMapper.warnMappingSkip("findBlockInChunk", "Chunk or BlockPos mapping is missing");
        }
    }

    public static boolean containsMinecraftFields(Class<?> cls) {
        boolean hasLogger = false;
        boolean hasProxy = false;
        boolean hasDisplay = false;
        for (Field f : cls.getDeclaredFields()) {
            f.setAccessible(true);
            String name = f.getType().getName();
            int mod = f.getModifiers();
            if (name.equals("org.apache.logging.log4j.Logger") && Modifier.isStatic(mod) && Modifier.isFinal(mod)) {
                hasLogger = true;
            }
            if (name.equals("java.net.Proxy") && Modifier.isFinal(mod)) {
                hasProxy = true;
            }
            if (!name.equals("java.util.List") || !f.getGenericType().getTypeName().contains("DisplayMode") || !Modifier.isStatic(mod) || !Modifier.isFinal(mod)) continue;
            hasDisplay = true;
        }
        return hasLogger && hasProxy && hasDisplay;
    }

    public static boolean isEntityPlayerSP(Class<?> cls) {
        Class<?> minecraftClass = MinecraftMapper.get("Minecraft");
        if (cls != null && minecraftClass != null && MinecraftMapper.isGameRuntimeClass(cls)) {
            boolean hasField = false;
            for (Field field : cls.getDeclaredFields()) {
                if (!Modifier.isProtected(field.getModifiers()) || !field.getType().equals(minecraftClass)) continue;
                hasField = true;
                break;
            }
            if (hasField && MinecraftMapper.isEntityPlayerSPHierarchy(cls)) {
                for (AccessibleObject accessibleObject : cls.getDeclaredConstructors()) {
                    Class<?>[] p = ((Constructor)accessibleObject).getParameterTypes();
                    if (p.length != 4 || !p[0].equals(minecraftClass) || !MinecraftMapper.isGameRuntimeClass(p[1]) || !MinecraftMapper.isGameRuntimeClass(p[2])) continue;
                    MinecraftMapper.put("World", p[1]);
                    MinecraftMapper.put("NetHandlerPlayClient", p[2]);
                    MinecraftMapper.mapNetHandlerPlayClient();
                    for (Constructor<?> worldConstructor : p[1].getDeclaredConstructors()) {
                        Class<?>[] worldParams = worldConstructor.getParameterTypes();
                        if (worldParams.length != 5 || !MinecraftMapper.isGameRuntimeClass(worldParams[0]) || !MinecraftMapper.isGameRuntimeClass(worldParams[1]) || !MinecraftMapper.isGameRuntimeClass(worldParams[2]) || !MinecraftMapper.isGameRuntimeClass(worldParams[3])) continue;
                        MinecraftMapper.put("ISaveHandler", worldParams[0]);
                        MinecraftMapper.put("WorldInfo", worldParams[1]);
                        MinecraftMapper.put("WorldProvider", worldParams[2]);
                        MinecraftMapper.put("Profiler", worldParams[3]);
                        break;
                    }
                    return true;
                }
                return false;
            }
            return false;
        }
        return false;
    }

    public static boolean isIChatComponent(Class<?> clazz) {
        if (!clazz.isInterface()) {
            return false;
        }
        Type[] interfaces = clazz.getGenericInterfaces();
        boolean extendsIterableOfSelf = false;
        for (Type iface : interfaces) {
            Type[] typeArgs;
            ParameterizedType pt;
            if (!(iface instanceof ParameterizedType) || (pt = (ParameterizedType)iface).getRawType() != Iterable.class || (typeArgs = pt.getActualTypeArguments()).length != 1 || typeArgs[0] != clazz) continue;
            extendsIterableOfSelf = true;
            break;
        }
        if (!extendsIterableOfSelf) {
            return false;
        }
        for (Method method : clazz.getMethods()) {
            if (method.getReturnType() != clazz || method.getParameterCount() != 1 || method.getParameterTypes()[0] != String.class) continue;
            return true;
        }
        return false;
    }

    public static boolean isChatComponentStyle(Class<?> clazz) {
        Field[] fields;
        if (!Modifier.isAbstract(clazz.getModifiers())) {
            return false;
        }
        if (!MinecraftMapper.get("IChatComponent").isAssignableFrom(clazz)) {
            return false;
        }
        for (Field field : fields = clazz.getDeclaredFields()) {
            ParameterizedType pt;
            Type[] typeArgs;
            Type genericType;
            if (!Modifier.isProtected(field.getModifiers()) || !List.class.isAssignableFrom(field.getType()) || !((genericType = field.getGenericType()) instanceof ParameterizedType) || (typeArgs = (pt = (ParameterizedType)genericType).getActualTypeArguments()).length != 1 || !(typeArgs[0] instanceof Class) || !((Class)typeArgs[0]).equals(MinecraftMapper.get("IChatComponent"))) continue;
            return true;
        }
        return false;
    }

    public static boolean isChatComponentText(Class<?> clazz) {
        Constructor<?>[] constructors;
        Field[] fields;
        if (!MinecraftMapper.get("ChatComponentStyle").isAssignableFrom(clazz)) {
            return false;
        }
        boolean hasPrivateFinalString = false;
        for (Field field : fields = clazz.getDeclaredFields()) {
            int mods = field.getModifiers();
            if (!Modifier.isPrivate(mods) || !Modifier.isFinal(mods) || field.getType() != String.class) continue;
            hasPrivateFinalString = true;
            break;
        }
        if (!hasPrivateFinalString) {
            return false;
        }
        for (Constructor<?> constructor : constructors = clazz.getDeclaredConstructors()) {
            Class<?>[] params = constructor.getParameterTypes();
            if (params.length != 1 || params[0] != String.class) continue;
            return true;
        }
        return false;
    }

    public static Method getMethodByParamAndReturnTypeAndVisibility(Class<?> inWhoClass, Class<?>[] paramTypes, Class<?> returnType, String visibility) {
        Method[] methods;
        for (Method method : methods = inWhoClass.getDeclaredMethods()) {
            if (!Arrays.equals(method.getParameterTypes(), paramTypes) || !method.getReturnType().equals(returnType)) continue;
            int mods = method.getModifiers();
            boolean visible = false;
            switch (visibility.toLowerCase()) {
                case "public": {
                    visible = Modifier.isPublic(mods);
                    break;
                }
                case "private": {
                    visible = Modifier.isPrivate(mods);
                    break;
                }
                case "protected": {
                    visible = Modifier.isProtected(mods);
                    break;
                }
                case "package": 
                case "default": {
                    visible = !Modifier.isPublic(mods) && !Modifier.isPrivate(mods) && !Modifier.isProtected(mods);
                    break;
                }
                case "any": {
                    visible = true;
                    break;
                }
                default: {
                    throw new IllegalArgumentException("Visibility must be one of: public, private, protected, package, any");
                }
            }
            if (!visible) continue;
            return method;
        }
        return null;
    }

    public static void findEffectRenderer() {
        Class<?> worldClass = MinecraftMapper.get("World");
        Class<?> textureManagerClass = MinecraftMapper.get("TextureManager");
        if (worldClass != null && textureManagerClass != null) {
            for (Class<?> clazz : MinecraftMapper.getClasses()) {
                boolean hasProtectedWorld = false;
                boolean hasPrivateList = false;
                boolean hasPrivateTextureManager = false;
                boolean hasPrivateMap = false;
                for (Field f : clazz.getDeclaredFields()) {
                    int mods = f.getModifiers();
                    Class<?> type = f.getType();
                    if (Modifier.isProtected(mods) && type.equals(worldClass)) {
                        hasProtectedWorld = true;
                    }
                    if (Modifier.isPrivate(mods) && type.equals(List.class)) {
                        hasPrivateList = true;
                    }
                    if (Modifier.isPrivate(mods) && type.equals(textureManagerClass)) {
                        hasPrivateTextureManager = true;
                    }
                    if (!Modifier.isPrivate(mods) || !type.equals(Map.class)) continue;
                    hasPrivateMap = true;
                }
                if (!hasProtectedWorld || !hasPrivateList || !hasPrivateTextureManager || !hasPrivateMap) continue;
                MinecraftMapper.put("EffectRenderer", clazz);
                return;
            }
        }
    }

    public static void findC06PacketPlayerPosLook(List<Class<?>> classes) {
        for (Class<?> clazz : classes) {
            Constructor<?>[] constructors;
            String name = clazz.getName();
            if (!name.contains("$") || clazz.getSuperclass() == Object.class || (constructors = clazz.getDeclaredConstructors()).length != 2) continue;
            boolean hasNoArg = false;
            boolean hasCorrectParams = false;
            for (Constructor<?> constructor : constructors) {
                Class<?>[] params = constructor.getParameterTypes();
                if (params.length == 0) {
                    hasNoArg = true;
                    continue;
                }
                if (params.length != 6 || params[0] != Double.TYPE || params[1] != Double.TYPE || params[2] != Double.TYPE || params[3] != Float.TYPE || params[4] != Float.TYPE || params[5] != Boolean.TYPE) continue;
                hasCorrectParams = true;
            }
            if (!hasNoArg || !hasCorrectParams) continue;
            MinecraftMapper.put("C06PacketPlayerPosLook", clazz);
            MinecraftMapper.findC03PacketPlayerFromC06(classes);
            return;
        }
    }

    public static void findPlayerCapabilitiesMethods(Class<?> netHandlerClass, Class<?> packetClass, Class<?> playerCapsClass) throws Exception {
        byte[] bytes = MinecraftMapper.getClassBytes(netHandlerClass);
        if (!MinecraftMapper.missingClassBytes("findPlayerCapabilitiesMethods", netHandlerClass, bytes)) {
            if (packetClass != null && playerCapsClass != null) {
                ClassReader cr = new ClassReader(bytes);
                ClassNode cn = new ClassNode();
                cr.accept((ClassVisitor)cn, 0);
                String packetInternal = packetClass.getName().replace('.', '/');
                String capsInternal = playerCapsClass.getName().replace('.', '/');
                int boolIndex = 0;
                int floatGetterIndex = 0;
                int floatSetterIndex = 0;
                for (MethodNode mn : cn.methods) {
                    if (!mn.desc.equals("(L" + packetInternal + ";)V")) continue;
                    for (AbstractInsnNode insn : mn.instructions) {
                        Method m;
                        if (insn.getOpcode() != 182) continue;
                        MethodInsnNode min = (MethodInsnNode)insn;
                        String owner = min.owner;
                        String name = min.name;
                        String desc = min.desc;
                        if (owner.equals(packetInternal)) {
                            if (desc.equals("()Z")) {
                                m = packetClass.getDeclaredMethod(name, new Class[0]);
                                switch (boolIndex) {
                                    case 0: {
                                        MinecraftMapper.putMethod("S39PacketPlayerAbilities.isFlying", m);
                                        break;
                                    }
                                    case 1: {
                                        MinecraftMapper.putMethod("S39PacketPlayerAbilities.isCreativeMode", m);
                                        break;
                                    }
                                    case 2: {
                                        MinecraftMapper.putMethod("S39PacketPlayerAbilities.isInvulnerable", m);
                                        break;
                                    }
                                    case 3: {
                                        MinecraftMapper.putMethod("S39PacketPlayerAbilities.allowFlying", m);
                                    }
                                }
                                ++boolIndex;
                                continue;
                            }
                            if (!desc.equals("()F")) continue;
                            m = packetClass.getDeclaredMethod(name, new Class[0]);
                            switch (floatGetterIndex) {
                                case 0: {
                                    MinecraftMapper.putMethod("S39PacketPlayerAbilities.getFlySpeed", m);
                                    break;
                                }
                                case 1: {
                                    MinecraftMapper.putMethod("S39PacketPlayerAbilities.getWalkSpeed", m);
                                }
                            }
                            ++floatGetterIndex;
                            continue;
                        }
                        if (!owner.equals(capsInternal) || !desc.equals("(F)V")) continue;
                        m = playerCapsClass.getDeclaredMethod(name, Float.TYPE);
                        switch (floatSetterIndex) {
                            case 0: {
                                MinecraftMapper.putMethod("PlayerCapabilities.setFlySpeed", m);
                                break;
                            }
                            case 1: {
                                MinecraftMapper.putMethod("PlayerCapabilities.setWalkSpeed", m);
                            }
                        }
                        ++floatSetterIndex;
                    }
                    return;
                }
            } else {
                MinecraftMapper.warnMappingSkip("findPlayerCapabilitiesMethods", "S39PacketPlayerAbilities or PlayerCapabilities is not mapped");
            }
        }
    }

    private static boolean extractAndSaveHandlerClientClass(Type handlerType) {
        WildcardType wildcard;
        Type[] upperBounds;
        if (handlerType instanceof Class) {
            Class handlerClass = (Class)handlerType;
            MinecraftMapper.put("INetHandlerPlayClient", handlerClass);
            return true;
        }
        if (handlerType instanceof ParameterizedType) {
            ParameterizedType paramType = (ParameterizedType)handlerType;
            Type rawType = paramType.getRawType();
            if (rawType instanceof Class) {
                Class handlerClass = (Class)rawType;
                MinecraftMapper.put("INetHandlerPlayClient", handlerClass);
                return true;
            }
        } else if (handlerType instanceof WildcardType && (upperBounds = (wildcard = (WildcardType)handlerType).getUpperBounds()).length > 0 && upperBounds[0] instanceof Class) {
            Class handlerClass = (Class)upperBounds[0];
            MinecraftMapper.put("INetHandlerPlayClient", handlerClass);
            return true;
        }
        return false;
    }

    private static boolean extractAndSaveHandlerClass(Type handlerType) {
        WildcardType wildcard;
        Type[] upperBounds;
        if (handlerType instanceof Class) {
            Class handlerClass = (Class)handlerType;
            MinecraftMapper.put("INetHandlerPlayServer", handlerClass);
            return true;
        }
        if (handlerType instanceof ParameterizedType) {
            ParameterizedType paramType = (ParameterizedType)handlerType;
            Type rawType = paramType.getRawType();
            if (rawType instanceof Class) {
                Class handlerClass = (Class)rawType;
                MinecraftMapper.put("INetHandlerPlayServer", handlerClass);
                return true;
            }
        } else if (handlerType instanceof WildcardType && (upperBounds = (wildcard = (WildcardType)handlerType).getUpperBounds()).length > 0 && upperBounds[0] instanceof Class) {
            Class handlerClass = (Class)upperBounds[0];
            MinecraftMapper.put("INetHandlerPlayServer", handlerClass);
            return true;
        }
        return false;
    }

    private static boolean isEntityClassType(Type type, Class<?> entityClass) {
        Type[] typeArgs;
        ParameterizedType paramType;
        if (type instanceof ParameterizedType && (paramType = (ParameterizedType)type).getRawType() == Class.class && (typeArgs = paramType.getActualTypeArguments()).length == 1 && typeArgs[0] instanceof WildcardType) {
            WildcardType wildcard = (WildcardType)typeArgs[0];
            Type[] upperBounds = wildcard.getUpperBounds();
            return upperBounds.length == 1 && upperBounds[0] == entityClass;
        }
        return false;
    }

    private static String getDescriptor(Field field) {
        Class<?> type = field.getType();
        if (type.isPrimitive()) {
            if (type == Integer.TYPE) {
                return "I";
            }
            if (type == Boolean.TYPE) {
                return "Z";
            }
            if (type == Short.TYPE) {
                return "S";
            }
            if (type == Long.TYPE) {
                return "J";
            }
            if (type == Character.TYPE) {
                return "C";
            }
            if (type == Byte.TYPE) {
                return "B";
            }
            if (type == Float.TYPE) {
                return "F";
            }
            return type == Double.TYPE ? "D" : null;
        }
        return "L" + type.getName().replace('.', '/') + ";";
    }

    private static boolean matchParams(Method method, Class<?> ... expected) {
        Class<?>[] params = method.getParameterTypes();
        if (params.length != expected.length) {
            return false;
        }
        for (int i = 0; i < params.length; ++i) {
            if (params[i].equals(expected[i])) continue;
            return false;
        }
        return true;
    }

    public static void analyzeClassForEntityRegistrations(Class<?> clazz) {
        try {
            String className = clazz.getName().replace('.', '/') + ".class";
            InputStream is = clazz.getClassLoader().getResourceAsStream(className);
            if (is == null) {
                return;
            }
            byte[] bytecode = MinecraftMapper.readAllBytes(is);
            is.close();
            String bytecodeStr = new String(bytecode);
            Pattern pattern = Pattern.compile("addMapping\\(L([^;]+);");
            Matcher matcher = pattern.matcher(bytecodeStr);
            while (matcher.find()) {
                String var7 = matcher.group(1);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static Object getWorldObj() {
        try {
            Field worldObjField = MinecraftMapper.getField("EntityPlayerSP.worldObj");
            if (worldObjField == null) {
                return null;
            }
            Object player = MinecraftMapper.getThePlayer();
            if (player == null) {
                return null;
            }
            worldObjField.setAccessible(true);
            return worldObjField.get(player);
        }
        catch (IllegalAccessException | IllegalArgumentException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void findGetBlockInChunk() {
        Class<?> chunkClass = MinecraftMapper.get("Chunk");
        Class<?> blockClass = MinecraftMapper.get("Block");
        if (chunkClass != null && blockClass != null) {
            for (Method method : chunkClass.getDeclaredMethods()) {
                int mods = method.getModifiers();
                Class<?>[] params = method.getParameterTypes();
                if (!Modifier.isPublic(mods) || params.length != 3 || params[0] != Integer.TYPE || params[1] != Integer.TYPE || params[2] != Integer.TYPE || !method.getReturnType().equals(blockClass)) continue;
                MinecraftMapper.putMethod("Chunk.getBlock", method);
                MinecraftMapper.findGetIdFromBlock();
                break;
            }
        }
    }

    public static void findC03PacketPlayerFromC06(List<Class<?>> classes) {
        String c06Name;
        Class<?> c06 = MinecraftMapper.get("C06PacketPlayerPosLook");
        if (c06 != null && (c06Name = c06.getName()).contains("$")) {
            String outerName = c06Name.split("\\$")[0];
            for (Class<?> clazz : classes) {
                if (!clazz.getName().equals(outerName)) continue;
                MinecraftMapper.put("C03PacketPlayer", clazz);
                MinecraftMapper.findC04PacketPlayerPosition(classes);
                MinecraftMapper.findC05PacketPlayerLook(classes);
                for (Field field : clazz.getDeclaredFields()) {
                    if (field.getType() != Boolean.TYPE) continue;
                    MinecraftMapper.putField("C03PacketPlayer.onGround", field);
                    break;
                }
                return;
            }
        }
    }

    private static byte[] readAllBytes(InputStream inputStream) throws IOException {
        int nRead;
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[16384];
        while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, nRead);
        }
        return buffer.toByteArray();
    }

    public static void findGetIdFromBlock() {
        Class<?> blockClass = MinecraftMapper.get("Block");
        if (blockClass != null) {
            for (Method method : blockClass.getDeclaredMethods()) {
                int mods = method.getModifiers();
                Class<?>[] params = method.getParameterTypes();
                if (!Modifier.isPublic(mods) || !Modifier.isStatic(mods) || method.getReturnType() != Integer.TYPE || params.length != 1 || !params[0].equals(blockClass)) continue;
                MinecraftMapper.putMethod("Block.getIdFromBlock", method);
                break;
            }
        }
    }

    public static void findC04PacketPlayerPosition(List<Class<?>> classes) {
        Class<?> c03 = MinecraftMapper.get("C03PacketPlayer");
        if (c03 == null) {
            System.out.println("C03PacketPlayer bulunamad\u00c3\u201e\u00c2\u00b1.");
        } else {
            for (Class<?> clazz : classes) {
                if (clazz.getSuperclass() != c03) continue;
                int constructorMatchCount = 0;
                for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                    Class<?>[] params = constructor.getParameterTypes();
                    if (params.length == 0) {
                        ++constructorMatchCount;
                        continue;
                    }
                    if (params.length != 4 || params[0] != Double.TYPE || params[1] != Double.TYPE || params[2] != Double.TYPE || params[3] != Boolean.TYPE) continue;
                    ++constructorMatchCount;
                }
                if (constructorMatchCount != 2) continue;
                MinecraftMapper.put("C04PacketPlayerPosition", clazz);
                return;
            }
        }
    }

    private static void updateMotionField(Field field, Object player, double value) throws Exception {
        Object current = field.get(player);
        if (current != null) {
            Constructor<?> ctor = current.getClass().getDeclaredConstructor(Double.TYPE);
            ctor.setAccessible(true);
            field.set(player, ctor.newInstance(value));
        }
    }

    public static double getMotionX() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0;
            }
            Field f = MinecraftMapper.getField("Entity.motionX");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            Object obj = f.get(player);
            if (obj == null) {
                return 0.0;
            }
            if (obj instanceof Double) {
                return (Double)obj;
            }
            Method getValue = MinecraftMapper.getMethod("MotionContainer.getValue");
            if (getValue != null) {
                return (Double)getValue.invoke(obj, new Object[0]);
            }
            for (Field df : obj.getClass().getDeclaredFields()) {
                if (df.getType() != Double.TYPE) continue;
                df.setAccessible(true);
                return df.getDouble(obj);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return 0.0;
    }

    public static double getMotionY() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0;
            }
            Field f = MinecraftMapper.getField("Entity.motionY");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            Object obj = f.get(player);
            if (obj == null) {
                return 0.0;
            }
            if (obj instanceof Double) {
                return (Double)obj;
            }
            Method getValue = MinecraftMapper.getMethod("MotionContainer.getValue");
            if (getValue != null) {
                return (Double)getValue.invoke(obj, new Object[0]);
            }
            for (Field df : obj.getClass().getDeclaredFields()) {
                if (df.getType() != Double.TYPE) continue;
                df.setAccessible(true);
                return df.getDouble(obj);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return 0.0;
    }

    public static double getMotionZ() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0;
            }
            Field f = MinecraftMapper.getField("Entity.motionZ");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            Object obj = f.get(player);
            if (obj == null) {
                return 0.0;
            }
            if (obj instanceof Double) {
                return (Double)obj;
            }
            Method getValue = MinecraftMapper.getMethod("MotionContainer.getValue");
            if (getValue != null) {
                return (Double)getValue.invoke(obj, new Object[0]);
            }
            for (Field df : obj.getClass().getDeclaredFields()) {
                if (df.getType() != Double.TYPE) continue;
                df.setAccessible(true);
                return df.getDouble(obj);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return 0.0;
    }

    public static void setMotionX(double value) {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return;
            }
            Field f = MinecraftMapper.getField("Entity.motionX");
            if (f == null) {
                return;
            }
            f.setAccessible(true);
            Object current = f.get(player);
            if (current instanceof Double) {
                f.set(player, value);
                return;
            }
            MinecraftMapper.updateMotionField(f, player, value);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setMotionY(double value) {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return;
            }
            Field f = MinecraftMapper.getField("Entity.motionY");
            if (f == null) {
                return;
            }
            f.setAccessible(true);
            Object current = f.get(player);
            if (current instanceof Double) {
                f.set(player, value);
                return;
            }
            MinecraftMapper.updateMotionField(f, player, value);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setMotionZ(double value) {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return;
            }
            Field f = MinecraftMapper.getField("Entity.motionZ");
            if (f == null) {
                return;
            }
            f.setAccessible(true);
            Object current = f.get(player);
            if (current instanceof Double) {
                f.set(player, value);
                return;
            }
            MinecraftMapper.updateMotionField(f, player, value);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static double getPosX() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0;
            }
            Field f = MinecraftMapper.getField("Entity.posX");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            return f.getDouble(player);
        }
        catch (Exception var2) {
            return 0.0;
        }
    }

    public static double getPosY() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0;
            }
            Field f = MinecraftMapper.getField("Entity.posY");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            return f.getDouble(player);
        }
        catch (Exception var2) {
            return 0.0;
        }
    }

    public static double getPosZ() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0;
            }
            Field f = MinecraftMapper.getField("Entity.posZ");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            return f.getDouble(player);
        }
        catch (Exception var2) {
            return 0.0;
        }
    }

    public static double getPosX(Object entity) {
        try {
            Field f = MinecraftMapper.getField("Entity.posX");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            return f.getDouble(entity);
        }
        catch (Exception var2) {
            return 0.0;
        }
    }

    public static double getPosY(Object entity) {
        try {
            Field f = MinecraftMapper.getField("Entity.posY");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            return f.getDouble(entity);
        }
        catch (Exception var2) {
            return 0.0;
        }
    }

    public static double getPosZ(Object entity) {
        try {
            Field f = MinecraftMapper.getField("Entity.posZ");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            return f.getDouble(entity);
        }
        catch (Exception var2) {
            return 0.0;
        }
    }

    public static float getRotationYaw() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0f;
            }
            Field f = MinecraftMapper.getField("Entity.rotationYaw");
            if (f == null) {
                return 0.0f;
            }
            f.setAccessible(true);
            return f.getFloat(player);
        }
        catch (Exception var2) {
            return 0.0f;
        }
    }

    public static float getRotationPitch() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0f;
            }
            Field f = MinecraftMapper.getField("Entity.rotationPitch");
            if (f == null) {
                return 0.0f;
            }
            f.setAccessible(true);
            return f.getFloat(player);
        }
        catch (Exception var2) {
            return 0.0f;
        }
    }

    public static void setOnGround(boolean value) {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return;
            }
            Field f = MinecraftMapper.getField("Entity.onGround");
            if (f == null) {
                return;
            }
            f.setAccessible(true);
            Object current = f.get(player);
            if (current instanceof Boolean) {
                f.set(player, value);
            } else if (current != null) {
                for (Field bf : current.getClass().getDeclaredFields()) {
                    if (bf.getType() != Boolean.TYPE) continue;
                    bf.setAccessible(true);
                    bf.setBoolean(current, value);
                    return;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void setFallDistance(float value) {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return;
            }
            Field f = MinecraftMapper.getField("Entity.fallDistance");
            if (f == null) {
                return;
            }
            f.setAccessible(true);
            f.setFloat(player, Math.max(0.0f, value));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static float getFallDistance() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return 0.0f;
            }
            Field f = MinecraftMapper.getField("Entity.fallDistance");
            if (f == null) {
                return 0.0f;
            }
            f.setAccessible(true);
            return f.getFloat(player);
        }
        catch (Exception var2) {
            return 0.0f;
        }
    }

    public static boolean isOnGround() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return false;
            }
            Field f = MinecraftMapper.getField("Entity.onGround");
            if (f == null) {
                return false;
            }
            f.setAccessible(true);
            Object val = f.get(player);
            if (val instanceof Boolean) {
                return (Boolean)val;
            }
            if (val != null) {
                Method getValue = MinecraftMapper.getMethod("BooleanContainer.getValue");
                if (getValue != null) {
                    return (Boolean)getValue.invoke(val, new Object[0]);
                }
                for (Field bf : val.getClass().getDeclaredFields()) {
                    if (bf.getType() != Boolean.TYPE) continue;
                    bf.setAccessible(true);
                    return bf.getBoolean(val);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return false;
    }

    public static Object getCurrentScreen() {
        try {
            Object mc = MinecraftMapper.getMinecraft();
            if (mc == null) {
                return null;
            }
            Field f = MinecraftMapper.getField("Minecraft.currentScreen");
            if (f == null) {
                return null;
            }
            f.setAccessible(true);
            return f.get(mc);
        }
        catch (Exception var2) {
            return null;
        }
    }

    public static double getMotionX(Object player) {
        try {
            Method m;
            if (player == null) {
                return 0.0;
            }
            Field f = MinecraftMapper.getField("Entity.motionX");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            Object val = f.get(player);
            if (val instanceof Double) {
                return (Double)val;
            }
            if (val != null && (m = MinecraftMapper.getMethod("MotionContainer.getValue")) != null) {
                return (Double)m.invoke(val, new Object[0]);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return 0.0;
    }

    public static double getMotionZ(Object player) {
        try {
            Method m;
            if (player == null) {
                return 0.0;
            }
            Field f = MinecraftMapper.getField("Entity.motionZ");
            if (f == null) {
                return 0.0;
            }
            f.setAccessible(true);
            Object val = f.get(player);
            if (val instanceof Double) {
                return (Double)val;
            }
            if (val != null && (m = MinecraftMapper.getMethod("MotionContainer.getValue")) != null) {
                return (Double)m.invoke(val, new Object[0]);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return 0.0;
    }

    private static interface MappingStep {
        public void run() throws Throwable;
    }
}

