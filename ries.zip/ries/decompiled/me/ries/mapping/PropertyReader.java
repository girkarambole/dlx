/*
 * Decompiled with CFR 0.152.
 */
package me.ries.mapping;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Type;

final class PropertyReader {
    private final String name;
    private final Class<?> type;
    private final Type genericType;
    private final Field field;
    private final Method method;

    private PropertyReader(String name, Class<?> type, Type genericType, Field field, Method method) {
        this.name = name;
        this.type = type;
        this.genericType = genericType;
        this.field = field;
        this.method = method;
    }

    static PropertyReader fromField(String name, Field field) {
        PropertyReader.setAccessible(field);
        return new PropertyReader(name, field.getType(), field.getGenericType(), field, null);
    }

    static PropertyReader fromMethod(String name, Method method) {
        PropertyReader.setAccessible(method);
        return new PropertyReader(name, method.getReturnType(), method.getGenericReturnType(), null, method);
    }

    String getName() {
        return this.name;
    }

    Class<?> getType() {
        return this.type;
    }

    Type getGenericType() {
        return this.genericType;
    }

    Object read(Object source) throws Exception {
        return this.field != null ? this.field.get(source) : this.method.invoke(source, new Object[0]);
    }

    private static void setAccessible(AccessibleObject accessibleObject) {
        try {
            accessibleObject.setAccessible(true);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

