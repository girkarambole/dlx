/*
 * Decompiled with CFR 0.152.
 */
package me.ries.mapping;

import java.beans.Introspector;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import me.ries.mapping.MappingIgnore;
import me.ries.mapping.MappingName;
import me.ries.mapping.PropertyReader;
import me.ries.mapping.PropertyWriter;

final class MappingPlan {
    private final Map<String, PropertyReader> readers;
    private final List<PropertyWriter> writers;

    private MappingPlan(Map<String, PropertyReader> readers, List<PropertyWriter> writers) {
        this.readers = Collections.unmodifiableMap(readers);
        this.writers = Collections.unmodifiableList(writers);
    }

    static MappingPlan build(Class<?> sourceType, Class<?> targetType) {
        return new MappingPlan(MappingPlan.readersFor(sourceType), MappingPlan.writersFor(targetType));
    }

    PropertyReader getReader(String name) {
        return this.readers.get(name);
    }

    List<PropertyWriter> getWriters() {
        return this.writers;
    }

    private static Map<String, PropertyReader> readersFor(Class<?> type) {
        LinkedHashMap<String, PropertyReader> readers = new LinkedHashMap<String, PropertyReader>();
        for (Class<?> current : MappingPlan.hierarchy(type)) {
            for (Field field : current.getDeclaredFields()) {
                if (MappingPlan.skipField(field)) continue;
                String name = MappingPlan.mappedName(field, field.getName());
                readers.put(name, PropertyReader.fromField(name, field));
            }
            for (AccessibleObject accessibleObject : current.getDeclaredMethods()) {
                if (MappingPlan.skipReaderMethod((Method)accessibleObject)) continue;
                String propertyName = MappingPlan.getterName((Method)accessibleObject);
                String name = MappingPlan.mappedName((Method)accessibleObject, propertyName);
                readers.put(name, PropertyReader.fromMethod(name, (Method)accessibleObject));
            }
        }
        return readers;
    }

    private static List<PropertyWriter> writersFor(Class<?> type) {
        LinkedHashMap<String, PropertyWriter> writers = new LinkedHashMap<String, PropertyWriter>();
        for (Class<?> current : MappingPlan.hierarchy(type)) {
            String sourceName;
            String propertyName;
            for (Method method : current.getDeclaredMethods()) {
                if (MappingPlan.skipWriterMethod(method)) continue;
                propertyName = MappingPlan.setterName(method);
                sourceName = MappingPlan.mappedName(method, propertyName);
                writers.put(propertyName, PropertyWriter.fromMethod(propertyName, sourceName, method));
            }
            for (AccessibleObject accessibleObject : current.getDeclaredFields()) {
                if (MappingPlan.skipField((Field)accessibleObject) || Modifier.isFinal(((Field)accessibleObject).getModifiers())) continue;
                propertyName = ((Field)accessibleObject).getName();
                sourceName = MappingPlan.mappedName((Field)accessibleObject, propertyName);
                if (writers.containsKey(propertyName)) continue;
                writers.put(propertyName, PropertyWriter.fromField(propertyName, sourceName, (Field)accessibleObject));
            }
        }
        return new ArrayList<PropertyWriter>(writers.values());
    }

    private static List<Class<?>> hierarchy(Class<?> type) {
        ArrayList classes = new ArrayList();
        for (Class<?> current = type; current != null && current != Object.class; current = current.getSuperclass()) {
            classes.add(0, current);
        }
        return classes;
    }

    private static boolean skipField(Field field) {
        int modifiers = field.getModifiers();
        return Modifier.isStatic(modifiers) || field.isSynthetic() || field.getAnnotation(MappingIgnore.class) != null;
    }

    private static boolean skipReaderMethod(Method method) {
        int modifiers = method.getModifiers();
        return Modifier.isStatic(modifiers) || method.isSynthetic() || method.getParameterTypes().length != 0 || method.getReturnType() == Void.TYPE || "getClass".equals(method.getName()) || method.getAnnotation(MappingIgnore.class) != null || MappingPlan.getterName(method) == null;
    }

    private static boolean skipWriterMethod(Method method) {
        int modifiers = method.getModifiers();
        return Modifier.isStatic(modifiers) || method.isSynthetic() || method.getParameterTypes().length != 1 || method.getAnnotation(MappingIgnore.class) != null || MappingPlan.setterName(method) == null;
    }

    private static String getterName(Method method) {
        String name = method.getName();
        if (name.startsWith("get") && name.length() > 3) {
            return Introspector.decapitalize(name.substring(3));
        }
        if (!name.startsWith("is") || name.length() <= 2 || method.getReturnType() != Boolean.TYPE && method.getReturnType() != Boolean.class) {
            MappingName mappingName = method.getAnnotation(MappingName.class);
            return mappingName == null ? null : name;
        }
        return Introspector.decapitalize(name.substring(2));
    }

    private static String setterName(Method method) {
        String name = method.getName();
        if (name.startsWith("set") && name.length() > 3) {
            return Introspector.decapitalize(name.substring(3));
        }
        MappingName mappingName = method.getAnnotation(MappingName.class);
        return mappingName == null ? null : name;
    }

    private static String mappedName(Field field, String fallback) {
        MappingName annotation = field.getAnnotation(MappingName.class);
        return annotation != null && annotation.value().trim().length() != 0 ? annotation.value().trim() : fallback;
    }

    private static String mappedName(Method method, String fallback) {
        MappingName annotation = method.getAnnotation(MappingName.class);
        return annotation != null && annotation.value().trim().length() != 0 ? annotation.value().trim() : fallback;
    }
}

