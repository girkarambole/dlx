/*
 * Decompiled with CFR 0.152.
 */
package me.ries.mapping;

public interface TypeConverter<S, T> {
    public boolean supports(Class<?> var1, Class<?> var2);

    public T convert(S var1, Class<T> var2);
}

