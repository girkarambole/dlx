/*
 * Decompiled with CFR 0.152.
 */
package me.ries.mapping;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import me.ries.loader.ClassByteResolver;
import me.ries.mapping.MappingConfiguration;
import me.ries.mapping.MappingException;
import me.ries.mapping.MappingPlan;
import me.ries.mapping.PropertyReader;
import me.ries.mapping.PropertyWriter;
import me.ries.mapping.ReflectionMappingCache;
import me.ries.mapping.TypeConverter;
import me.ries.mapping.TypeConverterRegistry;
import me.ries.mapping.TypeReference;
import me.ries.util.Logger;

public class AutoMapper {
    private static final Map<String, Class<?>> classMappings = new ConcurrentHashMap();
    private static final Map<String, Field> fieldMappings = new ConcurrentHashMap<String, Field>();
    private static final Map<String, Method> methodMappings = new ConcurrentHashMap<String, Method>();
    private static final ReflectionMappingCache objectMappingCache = new ReflectionMappingCache();
    private static volatile MappingConfiguration configuration = MappingConfiguration.defaults();
    public static List<Class<?>> cachedClasses = new CopyOnWriteArrayList();

    private AutoMapper() {
    }

    public static List<Class<?>> getClasses() {
        return cachedClasses;
    }

    public static void put(String name, Class<?> clazz) {
        Class<?> previous;
        String rejectionReason;
        if (name != null && clazz != null && (rejectionReason = AutoMapper.getClassMappingRejectionReason(name, clazz)) == null && (previous = classMappings.get(name)) != clazz) {
            classMappings.put(name, clazz);
            AutoMapper.saveClass(clazz, name);
            if (previous == null) {
                // empty if block
            }
        }
    }

    public static void putField(String fullName, Field field) {
        if (fullName != null && field != null && !fieldMappings.containsKey(fullName)) {
            AutoMapper.makeAccessible(field);
            fieldMappings.put(fullName, field);
        }
    }

    public static void putMethod(String fullName, Method method) {
        if (fullName != null && method != null) {
            AutoMapper.makeAccessible(method);
            methodMappings.put(fullName, method);
        }
    }

    public static Class<?> get(String name) {
        return classMappings.get(name);
    }

    public static Field getField(String fullName) {
        return fieldMappings.get(fullName);
    }

    public static Method getMethod(String fullName) {
        return methodMappings.get(fullName);
    }

    public static boolean contains(String name) {
        return classMappings.containsKey(name);
    }

    public static boolean containsField(String fullName) {
        return fieldMappings.containsKey(fullName);
    }

    public static boolean containsMethod(String fullName) {
        return methodMappings.containsKey(fullName);
    }

    public static Map<String, Class<?>> getAll() {
        return new LinkedHashMap(classMappings);
    }

    public static Map<String, Field> getAllFields() {
        return new LinkedHashMap<String, Field>(fieldMappings);
    }

    public static Map<String, Method> getAllMethods() {
        return new LinkedHashMap<String, Method>(methodMappings);
    }

    public static MappingConfiguration getConfiguration() {
        return configuration;
    }

    public static void setConfiguration(MappingConfiguration newConfiguration) {
        if (newConfiguration == null) {
            throw new IllegalArgumentException("configuration cannot be null");
        }
        configuration = newConfiguration;
        objectMappingCache.clear();
    }

    public static void resetConfiguration() {
        AutoMapper.setConfiguration(MappingConfiguration.defaults());
    }

    public static void registerConverter(TypeConverter<?, ?> converter) {
        configuration.getTypeConverterRegistry().register(converter);
    }

    public static <T> T map(Object source, Class<T> targetType) {
        return AutoMapper.map(source, targetType, configuration);
    }

    public static <T> T map(Object source, Class<T> targetType, MappingConfiguration config) {
        if (targetType == null) {
            throw new IllegalArgumentException("targetType cannot be null");
        }
        Object mapped = AutoMapper.mapValue(source, targetType, AutoMapper.normalize(config), new MappingContext());
        return (T)mapped;
    }

    public static <T> T map(Object source, TypeReference<T> targetType) {
        return AutoMapper.map(source, targetType, configuration);
    }

    public static <T> T map(Object source, TypeReference<T> targetType, MappingConfiguration config) {
        if (targetType == null) {
            throw new IllegalArgumentException("targetType cannot be null");
        }
        return (T)AutoMapper.mapValue(source, targetType.getType(), AutoMapper.normalize(config), new MappingContext());
    }

    public static Object map(Object source, Type targetType) {
        return AutoMapper.map(source, targetType, configuration);
    }

    public static Object map(Object source, Type targetType, MappingConfiguration config) {
        if (targetType == null) {
            throw new IllegalArgumentException("targetType cannot be null");
        }
        return AutoMapper.mapValue(source, targetType, AutoMapper.normalize(config), new MappingContext());
    }

    public static <T> List<T> mapList(Collection<?> source, Class<T> elementType) {
        if (source == null) {
            return null;
        }
        ArrayList<T> result = new ArrayList<T>(source.size());
        MappingConfiguration config = configuration;
        MappingContext context = new MappingContext();
        for (Object item : source) {
            result.add(elementType.cast(AutoMapper.mapValue(item, elementType, config, context.next())));
        }
        return result;
    }

    public static Object mapArray(Object source, Class<?> componentType) {
        if (componentType == null) {
            throw new IllegalArgumentException("componentType cannot be null");
        }
        return AutoMapper.mapArray(source, componentType, componentType, configuration, new MappingContext());
    }

    public static void clearObjectMappingCache() {
        objectMappingCache.clear();
    }

    public static String getObjectMappingCacheStats() {
        return objectMappingCache.stats();
    }

    private static Object mapValue(Object source, Type targetType, MappingConfiguration config, MappingContext context) {
        Class<?> targetClass;
        if (source == null) {
            return null;
        }
        if (context.depth > config.getMaxDepth()) {
            return AutoMapper.mappingFailure("Maximum mapping depth exceeded: " + config.getMaxDepth(), config, null);
        }
        if (targetType instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType)((Object)targetType);
            Class<?> rawType = AutoMapper.resolveClass(parameterizedType.getRawType());
            if (rawType != null && Collection.class.isAssignableFrom(rawType)) {
                Type elementType = parameterizedType.getActualTypeArguments()[0];
                return AutoMapper.mapCollection(source, rawType, elementType, config, context.next());
            }
            Class clazz = targetType = rawType == null ? Object.class : rawType;
        }
        if (targetType instanceof GenericArrayType) {
            Type componentType = ((GenericArrayType)((Object)targetType)).getGenericComponentType();
            Class<?> componentClass = AutoMapper.resolveClass(componentType);
            return AutoMapper.mapArray(source, componentClass == null ? Object.class : componentClass, componentType, config, context.next());
        }
        if (targetType instanceof TypeVariable || targetType instanceof WildcardType) {
            targetType = Object.class;
        }
        if ((targetClass = AutoMapper.resolveClass((Type)((Object)targetType))) != null && targetClass != Object.class) {
            if (targetClass.isPrimitive()) {
                targetClass = TypeConverterRegistry.wrap(targetClass);
            }
            if (targetClass.isInstance(source)) {
                return source;
            }
            if (targetClass.isArray()) {
                return AutoMapper.mapArray(source, targetClass.getComponentType(), targetClass.getComponentType(), config, context.next());
            }
            if (Collection.class.isAssignableFrom(targetClass)) {
                return AutoMapper.mapCollection(source, targetClass, Object.class, config, context.next());
            }
            if (!AutoMapper.isSimpleType(targetClass) && !AutoMapper.isSimpleType(source.getClass())) {
                if (!config.isNestedMappingEnabled()) {
                    return AutoMapper.mappingFailure("Nested mapping is disabled for " + source.getClass().getName() + " -> " + targetClass.getName(), config, null);
                }
                Object visited = context.getVisited(source);
                return visited != null && targetClass.isInstance(visited) ? visited : AutoMapper.mapObject(source, targetClass, config, context.next());
            }
            return AutoMapper.convertSimpleValue(source, targetClass, config);
        }
        return source;
    }

    private static Object mapObject(Object source, Class<?> targetClass, MappingConfiguration config, MappingContext context) {
        Object target = AutoMapper.instantiate(targetClass, config);
        if (target == null) {
            return null;
        }
        context.putVisited(source, target);
        MappingPlan plan = objectMappingCache.getPlan(source.getClass(), targetClass);
        for (PropertyWriter writer : plan.getWriters()) {
            PropertyReader reader = plan.getReader(writer.getSourceName());
            if (reader == null) {
                AutoMapper.handleMissingProperty(writer, config);
                continue;
            }
            try {
                Object mappedValue;
                Object rawValue = reader.read(source);
                if (rawValue == null && !config.isMapNullValues() || (mappedValue = AutoMapper.mapValue(rawValue, writer.getGenericType(), config, context.next())) == null && writer.getType().isPrimitive()) continue;
                writer.write(target, mappedValue);
            }
            catch (Throwable t) {
                AutoMapper.mappingFailure("Could not map property '" + writer.getPropertyName() + "': " + t.getMessage(), config, t);
            }
        }
        return target;
    }

    private static Object mapCollection(Object source, Class<?> collectionType, Type elementType, MappingConfiguration config, MappingContext context) {
        Collection<Object> target = AutoMapper.instantiateCollection(collectionType, config);
        if (target == null) {
            return null;
        }
        if (source.getClass().isArray()) {
            int length = Array.getLength(source);
            for (int i = 0; i < length; ++i) {
                target.add(AutoMapper.mapValue(Array.get(source, i), elementType, config, context.next()));
            }
            return target;
        }
        if (!(source instanceof Iterable)) {
            return AutoMapper.mappingFailure("Source is not a collection or array: " + source.getClass().getName(), config, null);
        }
        for (Object item : (Iterable)source) {
            target.add(AutoMapper.mapValue(item, elementType, config, context.next()));
        }
        return target;
    }

    private static Object mapArray(Object source, Class<?> componentClass, Type componentType, MappingConfiguration config, MappingContext context) {
        int i;
        if (source == null) {
            return null;
        }
        ArrayList<Object> sourceValues = new ArrayList<Object>();
        if (source.getClass().isArray()) {
            int length = Array.getLength(source);
            for (i = 0; i < length; ++i) {
                sourceValues.add(Array.get(source, i));
            }
        } else {
            if (!(source instanceof Iterable)) {
                return AutoMapper.mappingFailure("Source is not a collection or array: " + source.getClass().getName(), config, null);
            }
            for (Object item : (Iterable)source) {
                sourceValues.add(item);
            }
        }
        Object array = Array.newInstance(componentClass, sourceValues.size());
        for (i = 0; i < sourceValues.size(); ++i) {
            Object mappedValue = AutoMapper.mapValue(sourceValues.get(i), componentType, config, context.next());
            if (mappedValue == null && componentClass.isPrimitive()) continue;
            Array.set(array, i, mappedValue);
        }
        return array;
    }

    private static Object convertSimpleValue(Object source, Class<?> targetClass, MappingConfiguration config) {
        try {
            return config.getTypeConverterRegistry().convert(source, targetClass);
        }
        catch (RuntimeException ex) {
            return AutoMapper.mappingFailure(ex.getMessage(), config, ex);
        }
    }

    private static Object instantiate(Class<?> targetClass, MappingConfiguration config) {
        try {
            Constructor<?> constructor = targetClass.getDeclaredConstructor(new Class[0]);
            AutoMapper.makeAccessible(constructor);
            return constructor.newInstance(new Object[0]);
        }
        catch (Throwable t) {
            return AutoMapper.mappingFailure("Target type has no usable no-arg constructor: " + targetClass.getName(), config, t);
        }
    }

    private static Collection<Object> instantiateCollection(Class<?> collectionType, MappingConfiguration config) {
        if (collectionType != null && collectionType != Collection.class && collectionType != List.class && collectionType != Iterable.class) {
            if (collectionType != Set.class && collectionType != LinkedHashSet.class) {
                if (collectionType != Queue.class && collectionType != LinkedList.class) {
                    if (!collectionType.isInterface() && !Modifier.isAbstract(collectionType.getModifiers())) {
                        try {
                            Constructor<?> constructor = collectionType.getDeclaredConstructor(new Class[0]);
                            AutoMapper.makeAccessible(constructor);
                            return (Collection)constructor.newInstance(new Object[0]);
                        }
                        catch (Throwable t) {
                            return (Collection)AutoMapper.mappingFailure("Collection type has no usable no-arg constructor: " + collectionType.getName(), config, t);
                        }
                    }
                    if (Set.class.isAssignableFrom(collectionType)) {
                        return new LinkedHashSet<Object>();
                    }
                    return Queue.class.isAssignableFrom(collectionType) ? new LinkedList() : new ArrayList();
                }
                return new LinkedList<Object>();
            }
            return new LinkedHashSet<Object>();
        }
        return new ArrayList<Object>();
    }

    private static void handleMissingProperty(PropertyWriter writer, MappingConfiguration config) {
        if (config.isIgnoreMissingProperties()) {
            AutoMapper.logDebug(config, "No source property for target property: " + writer.getPropertyName());
        } else {
            AutoMapper.mappingFailure("No source property for target property: " + writer.getPropertyName(), config, null);
        }
    }

    private static Object mappingFailure(String message, MappingConfiguration config, Throwable cause) {
        if (config.isDebugLoggingEnabled()) {
            Logger.debug("[AutoMapper] " + message);
        }
        if (config.isFailOnMappingError()) {
            if (cause == null) {
                throw new MappingException(message);
            }
            throw new MappingException(message, cause);
        }
        return null;
    }

    private static MappingConfiguration normalize(MappingConfiguration config) {
        return config == null ? configuration : config;
    }

    private static void logDebug(MappingConfiguration config, String message) {
        if (config.isDebugLoggingEnabled()) {
            Logger.debug("[AutoMapper] " + message);
        }
    }

    private static boolean isSimpleType(Class<?> type) {
        Class<?> wrapped = TypeConverterRegistry.wrap(type);
        return wrapped.isPrimitive() || wrapped.isEnum() || wrapped == String.class || Number.class.isAssignableFrom(wrapped) || wrapped == Boolean.class || wrapped == Character.class || Date.class.isAssignableFrom(wrapped) || UUID.class == wrapped;
    }

    private static Class<?> resolveClass(Type type) {
        if (type instanceof Class) {
            return (Class)type;
        }
        if (type instanceof ParameterizedType) {
            return AutoMapper.resolveClass(((ParameterizedType)type).getRawType());
        }
        if (type instanceof WildcardType) {
            Type[] upperBounds = ((WildcardType)type).getUpperBounds();
            return upperBounds.length == 0 ? Object.class : AutoMapper.resolveClass(upperBounds[0]);
        }
        if (type instanceof TypeVariable) {
            Type[] bounds = ((TypeVariable)type).getBounds();
            return bounds.length == 0 ? Object.class : AutoMapper.resolveClass(bounds[0]);
        }
        return null;
    }

    public static void exportToFile(String filePath) {
        try {
            File file = new File(filePath);
            File parent = file.getParentFile();
            if (parent != null) {
                parent.mkdirs();
            }
            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter((OutputStream)new FileOutputStream(file), StandardCharsets.UTF_8));){
                writer.write("{Mapping}\n\n");
                for (Map.Entry<String, Class<?>> entry : AutoMapper.getAll().entrySet()) {
                    String key = entry.getKey();
                    Class<?> clazz = entry.getValue();
                    if (key == null || clazz == null) continue;
                    List fieldsList = AutoMapper.getAllFields().entrySet().stream().filter(fe -> ((String)fe.getKey()).startsWith(key + ".")).collect(Collectors.toList());
                    List methodsList = AutoMapper.getAllMethods().entrySet().stream().filter(me -> ((String)me.getKey()).startsWith(key + ".")).filter(me -> me.getValue() != null).collect(Collectors.toList());
                    writer.write(key + " {\n");
                    writer.write("  class: " + clazz.getName() + "\n\n");
                    if (!fieldsList.isEmpty()) {
                        writer.write("  fields: {\n");
                        for (Map.Entry fieldEntry : fieldsList) {
                            String fieldName = ((String)fieldEntry.getKey()).substring(key.length() + 1);
                            Field field = (Field)fieldEntry.getValue();
                            String typeName = field.getType().getName();
                            String obfName = field.getName();
                            writer.write(String.format("    %-12s -> type: %-20s, obf: %s\n", fieldName, typeName, obfName));
                        }
                        writer.write("  }\n\n");
                    }
                    if (!methodsList.isEmpty()) {
                        writer.write("  methods: {\n");
                        for (Map.Entry methodEntry : methodsList) {
                            String methodName = ((String)methodEntry.getKey()).substring(key.length() + 1);
                            Method method = (Method)methodEntry.getValue();
                            String returnType = method.getReturnType().getName();
                            Class<?>[] params = method.getParameterTypes();
                            StringBuilder paramList = new StringBuilder();
                            for (int i = 0; i < params.length; ++i) {
                                paramList.append(params[i].getSimpleName());
                                if (i >= params.length - 1) continue;
                                paramList.append(", ");
                            }
                            String obfName = method.getName();
                            String displayMethodName = paramList.length() > 40 ? methodName + "(...)" : (paramList.length() > 0 ? methodName + "(" + paramList + ")" : methodName + "()");
                            writer.write(String.format("    %-30s -> returns: %-15s, obf: %s\n", displayMethodName, returnType, obfName));
                        }
                        writer.write("  }\n");
                    }
                    writer.write("}\n\n");
                }
                Logger.info("Mapping successfully exported to: " + filePath);
            }
        }
        catch (IOException e) {
            Logger.error("Failed to export mappings: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void saveClass(Class<?> clazz, String name) {
        if (clazz != null && name != null) {
            try {
                byte[] classBytes;
                File file = new File("C:\\ries\\classes\\" + name + ".class");
                File parent = file.getParentFile();
                if (parent != null) {
                    parent.mkdirs();
                }
                if ((classBytes = AutoMapper.getClassBytes(clazz)) != null) {
                    Files.write(file.toPath(), classBytes, new OpenOption[0]);
                }
            }
            catch (Throwable e) {
                Logger.error("Failed to save class: " + e.getMessage());
            }
        }
    }

    public static byte[] getClassBytes(Class<?> clazz) {
        return ClassByteResolver.readClassBytes(clazz);
    }

    public static void clear() {
        classMappings.clear();
        fieldMappings.clear();
        methodMappings.clear();
        objectMappingCache.clear();
        Logger.info("All mappings cleared");
    }

    public static int getClassCount() {
        return classMappings.size();
    }

    public static int getFieldCount() {
        return fieldMappings.size();
    }

    public static int getMethodCount() {
        return methodMappings.size();
    }

    private static void makeAccessible(AccessibleObject accessibleObject) {
        try {
            accessibleObject.setAccessible(true);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static String getClassMappingRejectionReason(String logicalName, Class<?> clazz) {
        if (clazz.isPrimitive()) {
            return "primitive class cannot represent an obfuscated runtime type";
        }
        if (clazz.isArray()) {
            return "array class cannot represent an obfuscated runtime type";
        }
        String className = clazz.getName();
        if (!AutoMapper.isGameClassName(className) && !AutoMapper.isExplicitExternalMapping(logicalName, clazz)) {
            return AutoMapper.isPlatformOrLibraryClassName(className) ? "platform/library class does not match logical mapping name" : null;
        }
        return null;
    }

    private static boolean isExplicitExternalMapping(String logicalName, Class<?> clazz) {
        if (logicalName != null && clazz != null) {
            return logicalName.equals(clazz.getName()) || logicalName.equals(clazz.getSimpleName());
        }
        return false;
    }

    private static boolean isGameClassName(String className) {
        return className != null && (className.startsWith("craftrise.") || className.startsWith("crsecond.") || className.startsWith("cr.") || className.startsWith("com.craftrise."));
    }

    private static boolean isPlatformOrLibraryClassName(String className) {
        return className != null && (className.startsWith("java.") || className.startsWith("javax.") || className.startsWith("sun.") || className.startsWith("jdk.") || className.startsWith("com.sun.") || className.startsWith("com.google.") || className.startsWith("io.netty.") || className.startsWith("org."));
    }

    private static final class MappingContext {
        private final IdentityHashMap<Object, Object> visited;
        private final int depth;

        private MappingContext() {
            this(new IdentityHashMap<Object, Object>(), 0);
        }

        private MappingContext(IdentityHashMap<Object, Object> visited, int depth) {
            this.visited = visited;
            this.depth = depth;
        }

        private MappingContext next() {
            return new MappingContext(this.visited, this.depth + 1);
        }

        private Object getVisited(Object source) {
            return this.visited.get(source);
        }

        private void putVisited(Object source, Object target) {
            this.visited.put(source, target);
        }
    }
}

