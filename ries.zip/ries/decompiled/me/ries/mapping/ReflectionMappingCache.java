/*
 * Decompiled with CFR 0.152.
 */
package me.ries.mapping;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import me.ries.mapping.MappingPlan;

final class ReflectionMappingCache {
    private final ConcurrentMap<Key, MappingPlan> plans = new ConcurrentHashMap<Key, MappingPlan>();

    ReflectionMappingCache() {
    }

    MappingPlan getPlan(Class<?> sourceType, Class<?> targetType) {
        Key key = new Key(sourceType, targetType);
        MappingPlan existing = (MappingPlan)this.plans.get(key);
        if (existing != null) {
            return existing;
        }
        MappingPlan created = MappingPlan.build(sourceType, targetType);
        MappingPlan previous = this.plans.putIfAbsent(key, created);
        return previous == null ? created : previous;
    }

    void clear() {
        this.plans.clear();
    }

    String stats() {
        return "Object mapping plans: " + this.plans.size();
    }

    private static final class Key {
        private final Class<?> sourceType;
        private final Class<?> targetType;
        private final int hash;

        private Key(Class<?> sourceType, Class<?> targetType) {
            this.sourceType = sourceType;
            this.targetType = targetType;
            this.hash = 31 * sourceType.hashCode() + targetType.hashCode();
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Key)) {
                return false;
            }
            Key other = (Key)obj;
            return this.sourceType == other.sourceType && this.targetType == other.targetType;
        }

        public int hashCode() {
            return this.hash;
        }
    }
}

