/*
 * Decompiled with CFR 0.152.
 */
package me.ries;

import java.io.File;
import java.lang.reflect.Field;
import java.util.List;
import me.ries.Ries;
import me.ries.config.ConfigManager;
import me.ries.event.Event;
import me.ries.event.Render2DEvent;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.util.HardcodedUtils;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class Main {
    public static void StartClient(List<Class<?>> list) {
        try {
            File file;
            File file2 = new File("C:\\ries");
            if (!file2.exists()) {
                file2.mkdirs();
            }
            if (!(file = ConfigManager.getInstance().getDirectory()).exists()) {
                file.mkdirs();
            }
            MinecraftMapper.scanAndMap(list);
            HardcodedUtils.apply();
            Ries.initialize();
        }
        catch (Throwable throwable) {
            Logger.error("Error in StartClient: " + throwable.getMessage());
            throwable.printStackTrace();
        }
    }

    public static void main(String[] stringArray) {
        Logger.info("Main method called (not used by C++ loader)");
    }

    public static void onRender3D() {
        try {
            Object object;
            float f = 1.0f;
            try {
                object = MappingUtils.getField("craftrise.Config.renderPartialTicks");
                if (object != null) {
                    ((Field)object).setAccessible(true);
                    f = ((Field)object).getFloat(null);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            object = new Render3DEvent(f);
            Ries.getInstance().getEventBus().post((Event)object);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    public static void onRender2D() {
        try {
            Object object;
            float f = 1.0f;
            try {
                object = MappingUtils.getField("craftrise.Config.renderPartialTicks");
                if (object != null) {
                    ((Field)object).setAccessible(true);
                    f = ((Field)object).getFloat(null);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            object = new Render2DEvent(f);
            Ries.getInstance().getEventBus().post((Event)object);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

