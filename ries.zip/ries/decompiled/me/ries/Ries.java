/*
 * Decompiled with CFR 0.152.
 */
package me.ries;

import java.lang.reflect.Method;
import me.ries.chat.RiesChatManager;
import me.ries.command.CommandManager;
import me.ries.event.Event;
import me.ries.event.EventBus;
import me.ries.event.EventListener;
import me.ries.event.PacketReceiveEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.ModuleManager;
import me.ries.module.impl.FakeScoreBoardInjector;
import me.ries.notification.NotificationManager;
import me.ries.packethook.PacketHook;
import me.ries.util.BotTracker;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class Ries {
    private static Ries instance;
    private EventBus eventBus = new EventBus();
    private ModuleManager moduleManager = new ModuleManager();
    private boolean initialized = false;
    private static final long AUTOSAVE_INTERVAL_MS = 0L;

    private Ries() {
    }

    public static void initialize() {
        if (instance == null) {
            instance = new Ries();
        }
        instance.init();
    }

    private void init() {
        try {
            this.moduleManager.loadModules();
            this.moduleManager.registerEventListeners(this.eventBus);
            PacketHook.get().init();
            CommandManager.init();
            Logger.info("Injecting FakeScoreBoard proxy...");
            FakeScoreBoardInjector.inject();
            this.registerGlobalChatListener();
            RiesChatManager.start();
            this.initialized = true;
            this.startEventLoop();
            this.playStartupSound();
            try {
                NotificationManager.info("Massacre", "Client initialized!", 3000L);
            }
            catch (Throwable throwable) {}
        }
        catch (Throwable throwable) {
            this.initialized = false;
            Logger.error("Failed to initialize Ries: " + throwable.getMessage());
            throwable.printStackTrace();
        }
    }

    private void registerGlobalChatListener() {
        this.eventBus.subscribe(PacketReceiveEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                Class<?> clazz;
                Object object;
                if (event instanceof PacketReceiveEvent && (object = ((PacketReceiveEvent)event).getPacket()) != null && (clazz = MappingUtils.get("S02PacketChat")) != null && clazz.isInstance(object)) {
                    try {
                        String string;
                        Method method;
                        Object object2;
                        String string2 = null;
                        Method method2 = MappingUtils.getMethod("S02PacketChat.getChatComponent");
                        if (method2 != null && (object2 = method2.invoke(object, new Object[0])) != null && (method = MappingUtils.getMethod("IChatComponent.getUnformattedText")) != null) {
                            string2 = (String)method.invoke(object2, new Object[0]);
                        }
                        if (string2 != null && ((string = string2.replaceAll("\u00a7[0-9a-fk-or]", "").trim()).contains("adl\u0131 oyuncuyu \u00f6ld\u00fcrd\u00fcn") || string.contains("adli oyuncuyu oldurdun") || string.contains("taraf\u0131ndan katledildi") || string.contains(" \u00f6ld\u00fcrd\u00fc") || string.contains(" oldurdu"))) {
                            String string3 = "adl\u0131 oyuncuyu \u00f6ld\u00fcrd\u00fcn";
                            if (!string.contains(string3)) {
                                string3 = "adli oyuncuyu oldurdun";
                            }
                            if (string.contains(string3)) {
                                int n = string.indexOf(string3);
                                String string4 = string.substring(0, n).trim();
                                String[] stringArray = string4.split("\\s+");
                                if (stringArray.length > 0) {
                                    String string5 = stringArray[stringArray.length - 1];
                                    BotTracker.registerKill(string5);
                                }
                            } else {
                                BotTracker.registerKill("unknown");
                            }
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
            }
        });
    }

    private void startEventLoop() {
        Thread thread = new Thread(() -> {
            long l = 0L;
            long l2 = 0L;
            while (this.initialized) {
                try {
                    long l3 = System.currentTimeMillis();
                    RiesChatManager.tick();
                    if (l3 - l >= 200L) {
                        BotTracker.observeAll();
                        l = l3;
                    }
                    if (l3 - l2 >= 500L) {
                        CommandManager.applyAllahPrefix();
                        l2 = l3;
                    }
                    Thread.sleep(50L);
                }
                catch (InterruptedException interruptedException) {
                    Thread.currentThread().interrupt();
                    break;
                }
                catch (Throwable throwable) {
                    Logger.warn("Ries event loop error: " + throwable.getMessage());
                }
            }
        });
        thread.setName("Ries-EventLoop");
        thread.setDaemon(true);
        thread.start();
    }

    public static Ries getInstance() {
        if (instance == null) {
            instance = new Ries();
        }
        return instance;
    }

    public EventBus getEventBus() {
        return this.eventBus;
    }

    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }

    public boolean isInitialized() {
        return this.initialized;
    }

    public void shutdown() {
        Logger.info("Shutting down Ries...");
        this.initialized = false;
        PacketHook.get().shutdown();
        this.moduleManager.disableAllModules();
    }

    private void playStartupSound() {
        new Thread(() -> {
            try {
                for (int i = 0; i < 100 && this.initialized; ++i) {
                    Object object = MinecraftMapper.getThePlayer();
                    if (object != null) {
                        Method method = null;
                        for (Class<?> clazz = object.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
                            for (Method method2 : clazz.getDeclaredMethods()) {
                                Class<?>[] classArray;
                                if (method2.getParameterCount() != 3 || (classArray = method2.getParameterTypes())[0] != String.class || classArray[1] != Float.TYPE || classArray[2] != Float.TYPE) continue;
                                method2.setAccessible(true);
                                method = method2;
                                break;
                            }
                            if (method != null) break;
                        }
                        if (method != null) {
                            method.invoke(object, "random.orb", Float.valueOf(1.0f), Float.valueOf(1.0f));
                            Logger.info("Played startup orb sound.");
                            break;
                        }
                    }
                    Thread.sleep(200L);
                }
            }
            catch (Throwable throwable) {
                Logger.warn("Failed to play startup sound: " + throwable.getMessage());
            }
        }).start();
    }
}

