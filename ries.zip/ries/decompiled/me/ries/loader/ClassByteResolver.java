/*
 * Decompiled with CFR 0.152.
 */
package me.ries.loader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import me.ries.loader.ClassByteStore;

public final class ClassByteResolver {
    private static final File[] KNOWN_CLASS_DIRS = new File[]{new File("C:\\ries\\transformed"), new File("C:\\ries\\classes"), new File("C:\\pulse\\classes")};
    private static final File[] KNOWN_JARS = new File[]{new File("C:\\pulse\\cr.jar"), new File("C:\\pulse\\output.jar"), new File("C:\\ries\\cr.jar"), new File("C:\\ries\\output.jar")};
    private static final Map<String, byte[]> diskCache = new HashMap<String, byte[]>();
    private static final Set<String> diskMisses = new HashSet<String>();
    private static final Map<String, File> knownJarIndex = new HashMap<String, File>();
    private static boolean knownJarIndexBuilt;

    private ClassByteResolver() {
    }

    public static byte[] readClassBytes(Class<?> clazz) {
        if (clazz == null) {
            return null;
        }
        byte[] bytes = ClassByteStore.get(clazz);
        if (ClassByteResolver.isValid(bytes)) {
            return bytes;
        }
        bytes = ClassByteResolver.readFromPatchedClassLoaderMethod(clazz);
        if (ClassByteResolver.isValid(bytes)) {
            return ClassByteResolver.remember(clazz, bytes);
        }
        bytes = ClassByteResolver.readFromPatchedClassLoaderMap(clazz);
        if (ClassByteResolver.isValid(bytes)) {
            return ClassByteResolver.remember(clazz, bytes);
        }
        bytes = ClassByteResolver.readFromClassResource(clazz);
        if (ClassByteResolver.isValid(bytes)) {
            return ClassByteResolver.remember(clazz, bytes);
        }
        bytes = ClassByteResolver.readFromCodeSource(clazz);
        if (ClassByteResolver.isValid(bytes)) {
            return ClassByteResolver.remember(clazz, bytes);
        }
        bytes = ClassByteResolver.readFromKnownDiskLocations(clazz);
        return ClassByteResolver.isValid(bytes) ? ClassByteResolver.remember(clazz, bytes) : null;
    }

    private static byte[] readFromPatchedClassLoaderMethod(Class<?> clazz) {
        try {
            Method method = ClassLoader.class.getDeclaredMethod("getCustomClassByte", Class.class);
            method.setAccessible(true);
            Object value = method.invoke(null, clazz);
            return value instanceof byte[] ? (byte[])value : null;
        }
        catch (Throwable var3) {
            return null;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static byte[] readFromPatchedClassLoaderMap(Class<?> clazz) {
        try {
            Field field = ClassLoader.class.getDeclaredField("customClassBytes");
            field.setAccessible(true);
            Object mapObject = field.get(null);
            if (!(mapObject instanceof Map)) {
                return null;
            }
            Map map = (Map)mapObject;
            Object object = mapObject;
            synchronized (object) {
                Object exact = map.get(clazz);
                if (exact instanceof byte[] && ((byte[])exact).length > 0) {
                    return (byte[])exact;
                }
                String className = clazz.getName();
                for (Map.Entry entry : map.entrySet()) {
                    Object key = entry.getKey();
                    Object value = entry.getValue();
                    if (!(key instanceof Class) || !className.equals(((Class)key).getName()) || !(value instanceof byte[]) || ((byte[])value).length <= 0) continue;
                    return (byte[])value;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static byte[] readFromClassResource(Class<?> clazz) {
        byte[] byArray;
        String resourceName = ClassByteResolver.toResourceName(clazz);
        InputStream in = null;
        try {
            byte[] var42;
            ClassLoader loader = clazz.getClassLoader();
            if (loader != null) {
                in = loader.getResourceAsStream(resourceName);
            }
            if (in == null) {
                in = ClassLoader.getSystemResourceAsStream(resourceName);
            }
            byArray = var42 = in == null ? null : ClassByteResolver.readAllBytes(in);
        }
        catch (Throwable var8) {
            try {
                byte[] var4 = null;
                return var4;
            }
            catch (Throwable throwable) {
                throw throwable;
            }
            finally {
                ClassByteResolver.closeQuietly(in);
            }
        }
        ClassByteResolver.closeQuietly(in);
        return byArray;
    }

    private static byte[] readFromCodeSource(Class<?> clazz) {
        try {
            URL location;
            ProtectionDomain domain = clazz.getProtectionDomain();
            CodeSource source = domain == null ? null : domain.getCodeSource();
            URL uRL = location = source == null ? null : source.getLocation();
            if (location == null) {
                return null;
            }
            URI uri = location.toURI();
            File file = new File(uri);
            return ClassByteResolver.readFromFileLocation(file, ClassByteResolver.toResourceName(clazz));
        }
        catch (Throwable var6) {
            return null;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static byte[] readFromKnownDiskLocations(Class<?> clazz) {
        File jar;
        byte dir;
        Object[] cached;
        String className = clazz.getName();
        String resourceName = ClassByteResolver.toResourceName(clazz);
        Map<String, byte[]> map = diskCache;
        synchronized (map) {
            cached = diskCache.get(className);
            if (cached != null) {
                return ClassByteResolver.copy(cached);
            }
            if (diskMisses.contains(className)) {
                return null;
            }
        }
        byte[] bytes = null;
        cached = KNOWN_CLASS_DIRS;
        int n = cached.length;
        for (int i = 0; i < n && !ClassByteResolver.isValid(bytes = ClassByteResolver.readFromDirectory((File)(dir = cached[i]), resourceName)); ++i) {
        }
        if (!ClassByteResolver.isValid(bytes) && (jar = ClassByteResolver.findKnownJar(resourceName)) != null) {
            bytes = ClassByteResolver.readFromJar(jar, resourceName);
        }
        Map<String, byte[]> map2 = diskCache;
        synchronized (map2) {
            if (ClassByteResolver.isValid(bytes)) {
                diskCache.put(className, ClassByteResolver.copy(bytes));
            } else {
                diskMisses.add(className);
            }
        }
        return ClassByteResolver.isValid(bytes) ? ClassByteResolver.copy(bytes) : null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static File findKnownJar(String resourceName) {
        Map<String, File> map = knownJarIndex;
        synchronized (map) {
            if (!knownJarIndexBuilt) {
                ClassByteResolver.buildKnownJarIndex();
                knownJarIndexBuilt = true;
            }
            return knownJarIndex.get(resourceName);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void buildKnownJarIndex() {
        for (File jarFile : KNOWN_JARS) {
            if (jarFile == null || !jarFile.isFile()) continue;
            JarFile jar = null;
            try {
                jar = new JarFile(jarFile);
                Enumeration<JarEntry> entries = jar.entries();
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (name == null || !name.endsWith(".class") || knownJarIndex.containsKey(name)) continue;
                    knownJarIndex.put(name, jarFile);
                }
            }
            catch (Throwable throwable) {
            }
            finally {
                if (jar != null) {
                    try {
                        jar.close();
                    }
                    catch (IOException iOException) {}
                }
            }
        }
    }

    private static byte[] readFromFileLocation(File file, String resourceName) {
        if (file != null && file.exists()) {
            return file.isDirectory() ? ClassByteResolver.readFromDirectory(file, resourceName) : ClassByteResolver.readFromJar(file, resourceName);
        }
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static byte[] readFromDirectory(File directory, String resourceName) {
        byte[] byArray;
        if (directory == null || !directory.isDirectory()) return null;
        File classFile = new File(directory, resourceName.replace('/', File.separatorChar));
        if (!classFile.isFile()) {
            return null;
        }
        FileInputStream in = null;
        try {
            byte[] var4;
            in = new FileInputStream(classFile);
            byArray = var4 = ClassByteResolver.readAllBytes(in);
        }
        catch (Throwable var9) {
            Object var5;
            try {
                var5 = null;
            }
            catch (Throwable throwable) {
                ClassByteResolver.closeQuietly(in);
                throw throwable;
            }
            ClassByteResolver.closeQuietly(in);
            return var5;
        }
        ClassByteResolver.closeQuietly(in);
        return byArray;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static byte[] readFromJar(File jarFile, String resourceName) {
        block18: {
            byte[] var18;
            InputStream in;
            JarFile jar;
            block17: {
                byte[] var182;
                if (jarFile == null || !jarFile.isFile()) break block18;
                jar = null;
                in = null;
                jar = new JarFile(jarFile);
                JarEntry entry = jar.getJarEntry(resourceName);
                if (entry == null) break block17;
                in = jar.getInputStream(entry);
                byte[] byArray = var182 = ClassByteResolver.readAllBytes(in);
                ClassByteResolver.closeQuietly(in);
                if (jar != null) {
                    try {
                        jar.close();
                    }
                    catch (IOException iOException) {
                        // empty catch block
                    }
                }
                return byArray;
            }
            try {
                var18 = null;
            }
            catch (Throwable var16) {
                try {
                    byte[] var183;
                    byte[] byArray = var183 = null;
                    return byArray;
                }
                catch (Throwable throwable) {
                    throw throwable;
                }
                finally {
                    ClassByteResolver.closeQuietly(in);
                    if (jar != null) {
                        try {
                            jar.close();
                        }
                        catch (IOException iOException) {}
                    }
                }
            }
            ClassByteResolver.closeQuietly(in);
            if (jar != null) {
                try {
                    jar.close();
                }
                catch (IOException entry) {}
            }
            return var18;
        }
        return null;
    }

    private static byte[] remember(Class<?> clazz, byte[] bytes) {
        if (!ClassByteResolver.isValid(bytes)) {
            return null;
        }
        ClassByteStore.remember(clazz, bytes);
        return ClassByteResolver.copy(bytes);
    }

    private static String toResourceName(Class<?> clazz) {
        return clazz.getName().replace('.', '/') + ".class";
    }

    private static boolean isValid(byte[] bytes) {
        return bytes != null && bytes.length > 0;
    }

    private static byte[] readAllBytes(InputStream inputStream) throws IOException {
        int read;
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] data = new byte[16384];
        while ((read = inputStream.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, read);
        }
        return buffer.toByteArray();
    }

    private static void closeQuietly(InputStream in) {
        if (in != null) {
            try {
                in.close();
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
    }

    private static byte[] copy(byte[] bytes) {
        byte[] out = new byte[bytes.length];
        System.arraycopy(bytes, 0, out, 0, bytes.length);
        return out;
    }
}

