/*
 * Decompiled with CFR 0.152.
 */
package me.ries.loader;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

public final class ClassByteStore {
    private static final List<Class<?>> customClasses = new ArrayList();
    private static final Map<Class<?>, byte[]> customClassBytes = new IdentityHashMap();

    private ClassByteStore() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void remember(Class<?> clazz, byte[] bytecode) {
        if (clazz != null) {
            Object object = customClasses;
            synchronized (object) {
                if (!customClasses.contains(clazz)) {
                    customClasses.add(clazz);
                }
            }
            if (bytecode != null && bytecode.length > 0) {
                object = customClassBytes;
                synchronized (object) {
                    customClassBytes.put(clazz, ClassByteStore.copy(bytecode));
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static byte[] get(Class<?> clazz) {
        if (clazz == null) {
            return null;
        }
        Map<Class<?>, byte[]> map = customClassBytes;
        synchronized (map) {
            byte[] bytes = customClassBytes.get(clazz);
            return bytes == null ? null : ClassByteStore.copy(bytes);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static List<Class<?>> snapshot() {
        List<Class<?>> list = customClasses;
        synchronized (list) {
            return new ArrayList(customClasses);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static int size() {
        List<Class<?>> list = customClasses;
        synchronized (list) {
            return customClasses.size();
        }
    }

    private static byte[] copy(byte[] bytes) {
        byte[] out = new byte[bytes.length];
        System.arraycopy(bytes, 0, out, 0, bytes.length);
        return out;
    }
}

