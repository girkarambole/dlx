/*
 * Decompiled with CFR 0.152.
 */
package me.ries.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.ries.event.Event;
import me.ries.event.EventListener;

public class EventBus {
    private Map<Class<?>, List<EventListener>> listeners = new HashMap();

    public void subscribe(Class<?> eventType, EventListener listener) {
        this.listeners.computeIfAbsent(eventType, k -> new ArrayList()).add(listener);
    }

    public void unsubscribe(Class<?> eventType, EventListener listener) {
        List<EventListener> list = this.listeners.get(eventType);
        if (list != null) {
            list.remove(listener);
        }
    }

    public void post(Event event) {
        List<EventListener> list = this.listeners.get(event.getClass());
        if (list != null) {
            for (EventListener listener : list) {
                listener.onEvent(event);
            }
        }
    }
}

