/*
 * Decompiled with CFR 0.152.
 */
package me.ries.event;

import me.ries.event.Event;

public class PacketReceiveEvent
extends Event {
    private final Object packet;

    public PacketReceiveEvent(Object packet) {
        this.packet = packet;
    }

    public Object getPacket() {
        return this.packet;
    }
}

