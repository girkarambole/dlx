/*
 * Decompiled with CFR 0.152.
 */
package me.ries.event;

import me.ries.event.Event;

public class PacketSendEvent
extends Event {
    private final Object packet;

    public PacketSendEvent(Object packet) {
        this.packet = packet;
    }

    public Object getPacket() {
        return this.packet;
    }
}

