/*
 * Decompiled with CFR 0.152.
 */
package me.ries.event;

import me.ries.event.Event;

public interface EventListener {
    public void onEvent(Event var1);
}

