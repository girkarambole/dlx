/*
 * Decompiled with CFR 0.152.
 */
package me.ries.event;

public abstract class Event {
    private boolean cancelled = false;

    public void cancel() {
        this.cancelled = true;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }
}

