/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.channel.Channel
 */
package me.ries.packethook;

import io.netty.channel.Channel;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventBus;
import me.ries.event.PacketReceiveEvent;
import me.ries.event.PacketSendEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.util.Logger;
import me.ries.util.UnsafeHelper;

public class PacketHook {
    private static final PacketHook INSTANCE = new PacketHook();
    private static final long PACKET_LISTENER_OFFSET = 64L;
    private static final long CHANNEL_OFFSET = 68L;
    private static final int MAX_FORCE_RETRIES = 20;
    private volatile boolean initialized;
    private volatile boolean sendHooked;
    private volatile boolean receiveHooked;
    private volatile boolean forceMode;
    private volatile Object hookedNetworkManager;
    private volatile int forceRetryCount;
    private ScheduledExecutorService injectExecutor;
    private ScheduledExecutorService forceExecutor;
    private static volatile long lastPacketTime;
    private static volatile long debugPacketCount;

    public static PacketHook get() {
        return INSTANCE;
    }

    public synchronized void init() {
        if (!this.initialized) {
            this.initialized = true;
            this.injectExecutor = PacketHook.newExecutor("Ries-PacketHook");
            this.injectExecutor.scheduleAtFixedRate(this::injectIfNeeded, 0L, 500L, TimeUnit.MILLISECONDS);
            Logger.info("PacketHook: inject loop started");
        }
    }

    public synchronized void shutdown() {
        this.initialized = false;
        if (this.injectExecutor != null) {
            this.injectExecutor.shutdownNow();
            this.injectExecutor = null;
        }
        if (this.forceExecutor != null) {
            this.forceExecutor.shutdownNow();
            this.forceExecutor = null;
        }
        this.resetHookState();
    }

    public synchronized void forceInject() {
        Logger.info("PacketHook: force reinject requested");
        this.resetHookState();
        this.forceMode = true;
        this.forceRetryCount = 0;
        if (this.forceExecutor != null) {
            this.forceExecutor.shutdownNow();
        }
        this.forceExecutor = PacketHook.newExecutor("Ries-PacketHook-Reinject");
        this.forceExecutor.scheduleAtFixedRate(() -> {
            if (!(!this.forceMode || this.sendHooked && this.receiveHooked)) {
                if (++this.forceRetryCount > 20) {
                    Logger.warn("PacketHook: force reinject timed out");
                    this.stopForceMode();
                } else {
                    this.inject();
                }
            } else {
                this.stopForceMode();
            }
        }, 200L, 200L, TimeUnit.MILLISECONDS);
    }

    private static ScheduledExecutorService newExecutor(String string) {
        return Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, string);
            thread.setDaemon(true);
            return thread;
        });
    }

    private synchronized void stopForceMode() {
        this.forceMode = false;
        if (this.forceExecutor != null) {
            this.forceExecutor.shutdownNow();
            this.forceExecutor = null;
        }
    }

    private void resetHookState() {
        this.sendHooked = false;
        this.receiveHooked = false;
        this.forceMode = false;
        this.hookedNetworkManager = null;
        lastPacketTime = System.currentTimeMillis();
    }

    private void injectIfNeeded() {
        if (this.initialized) {
            if (this.sendHooked && this.receiveHooked) {
                long l = System.currentTimeMillis();
                long l2 = l - lastPacketTime;
                if (l2 > 5000L) {
                    Logger.info("PacketHook: no packet activity detected for " + l2 + "ms, forcing reinject");
                    this.forceInject();
                    return;
                }
                Object object = this.resolveNetworkManagerQuietly();
                if (object != null && this.hookedNetworkManager != null && object != this.hookedNetworkManager) {
                    Logger.info("PacketHook: NetworkManager changed, reinjecting");
                    this.resetHookState();
                }
                if (this.sendHooked && this.receiveHooked) {
                    return;
                }
            }
            this.inject();
        }
    }

    public synchronized void inject() {
        try {
            Object object = this.resolveNetworkManager();
            if (object == null) {
                return;
            }
            this.hookPacketListener(object);
            this.hookChannel(object);
            if (this.sendHooked && this.receiveHooked) {
                this.hookedNetworkManager = object;
            }
        }
        catch (Throwable throwable) {
            Logger.debug("PacketHook: inject failed - " + throwable.getMessage());
        }
    }

    private Object resolveNetworkManagerQuietly() {
        try {
            return this.resolveNetworkManager();
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private Object resolveNetworkManager() throws Exception {
        Object object = MinecraftMapper.getThePlayer();
        if (object == null) {
            return null;
        }
        Field field = MinecraftMapper.getField("EntityPlayerSP.sendQueue");
        if (field == null) {
            field = MinecraftMapper.getFieldByType(object.getClass(), MinecraftMapper.get("NetHandlerPlayClient"));
        }
        if (field == null) {
            return null;
        }
        field.setAccessible(true);
        Object object2 = field.get(object);
        if (object2 == null) {
            return null;
        }
        Field field2 = MinecraftMapper.getField("NetHandlerPlayClient.networkManager");
        if (field2 == null) {
            field2 = MinecraftMapper.getFieldByType(object2.getClass(), MinecraftMapper.get("NetworkManager"));
        }
        if (field2 == null) {
            return null;
        }
        field2.setAccessible(true);
        return field2.get(object2);
    }

    private void hookChannel(Object object) throws Exception {
        Field field = MinecraftMapper.getField("NetworkManager.channel");
        if (field == null) {
            field = MinecraftMapper.getFieldByType(object.getClass(), Channel.class);
        }
        if (field != null) {
            this.checkAndHookField(object, field, "Channel (SEND)", true);
        } else {
            this.checkAndHookOffset(object, 68L, "Channel (SEND)", true);
        }
    }

    private void hookPacketListener(Object object) throws Exception {
        Field field = this.findPacketListenerField(object);
        if (field != null) {
            this.checkAndHookField(object, field, "PacketListener (RECEIVE)", false);
        } else {
            this.checkAndHookOffset(object, 64L, "PacketListener (RECEIVE)", false);
        }
    }

    private Field findPacketListenerField(Object object) {
        for (Class<?> clazz = object.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            Field[] fieldArray;
            for (Field field : fieldArray = clazz.getDeclaredFields()) {
                int n = field.getModifiers();
                if (Modifier.isStatic(n) || field.getType() == Channel.class || Channel.class.isAssignableFrom(field.getType())) continue;
                try {
                    field.setAccessible(true);
                    Object object2 = field.get(object);
                    if (!this.isPacketListener(object2)) continue;
                    return field;
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
        return null;
    }

    private boolean isPacketListener(Object object) {
        if (object == null) {
            return false;
        }
        Class<?> clazz = MinecraftMapper.get("INetHandlerPlayClient");
        Class<?> clazz2 = MinecraftMapper.get("INetHandlerPlayServer");
        if (!(clazz != null && clazz.isInstance(object) || clazz2 != null && clazz2.isInstance(object))) {
            for (Class<?> clazz3 : PacketHook.collectInterfaces(object.getClass())) {
                String string = clazz3.getName();
                if (!string.contains("INetHandler") && !string.endsWith(".PacketListener")) continue;
                return true;
            }
            return object.getClass().getName().contains("NetHandler");
        }
        return true;
    }

    private void checkAndHookField(Object object, Field field, String string, boolean bl) throws Exception {
        Object object2;
        field.setAccessible(true);
        Object object3 = field.get(object);
        if (object3 != null && !this.markIfAlreadyHooked(object3, bl) && (object2 = this.createProxy(object3, bl, string)) != null) {
            try {
                field.set(object, object2);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                UnsafeHelper.putObject(object, UnsafeHelper.getUnsafe().objectFieldOffset(field), object2);
            }
            this.markHooked(bl);
            Logger.info("PacketHook: hooked " + string + " via field " + field.getName());
        }
    }

    private void checkAndHookOffset(Object object, long l, String string, boolean bl) throws Exception {
        Object object2;
        Object object3 = UnsafeHelper.getObject(object, l);
        if (object3 != null && !this.markIfAlreadyHooked(object3, bl) && (object2 = this.createProxy(object3, bl, string)) != null) {
            UnsafeHelper.putObject(object, l, object2);
            this.markHooked(bl);
            Logger.info("PacketHook: hooked " + string + " at offset 0x" + Long.toHexString(l).toUpperCase());
        }
    }

    private boolean markIfAlreadyHooked(Object object, boolean bl) {
        if (!Proxy.isProxyClass(object.getClass())) {
            return false;
        }
        if (!this.forceMode) {
            this.markHooked(bl);
        }
        return true;
    }

    private void markHooked(boolean bl) {
        if (bl) {
            this.sendHooked = true;
        } else {
            this.receiveHooked = true;
        }
    }

    private Object createProxy(Object object, boolean bl, String string) {
        Class[] classArray = PacketHook.collectInterfaces(object.getClass()).toArray(new Class[0]);
        if (classArray.length == 0) {
            Logger.warn("PacketHook: " + string + " has no interfaces: " + object.getClass().getName());
            return null;
        }
        return Proxy.newProxyInstance(object.getClass().getClassLoader(), classArray, (InvocationHandler)new GenericProxy(object, bl));
    }

    private static Set<Class<?>> collectInterfaces(Class<?> clazz) {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        PacketHook.collectInterfaces(clazz, linkedHashSet);
        return linkedHashSet;
    }

    private static void collectInterfaces(Class<?> clazz, Set<Class<?>> set) {
        if (clazz != null) {
            Class<?>[] classArray;
            for (Class<?> clazz2 : classArray = clazz.getInterfaces()) {
                set.add(clazz2);
                PacketHook.collectInterfaces(clazz2, set);
            }
            PacketHook.collectInterfaces(clazz.getSuperclass(), set);
        }
    }

    private static void postSend(Object object) {
        PacketSendEvent packetSendEvent = new PacketSendEvent(object);
        PacketHook.postEvent(packetSendEvent);
        if (packetSendEvent.isCancelled()) {
            throw new PacketCancelledException();
        }
    }

    private static void postReceive(Object object) {
        PacketReceiveEvent packetReceiveEvent = new PacketReceiveEvent(object);
        PacketHook.postEvent(packetReceiveEvent);
        if (packetReceiveEvent.isCancelled()) {
            throw new PacketCancelledException();
        }
    }

    private static void postEvent(Event event) {
        try {
            EventBus eventBus = Ries.getInstance().getEventBus();
            if (eventBus != null) {
                eventBus.post(event);
            }
        }
        catch (Throwable throwable) {
            Logger.debug("PacketHook: event dispatch failed - " + throwable.getMessage());
        }
    }

    private static boolean isUseEntityPacket(Object object) {
        Class<?> clazz = MinecraftMapper.get("C02PacketUseEntity");
        return object != null && clazz != null && clazz.isInstance(object);
    }

    private static boolean isPacket(Object object) {
        if (object == null) {
            return false;
        }
        Class<?> clazz = MinecraftMapper.get("Packet");
        return clazz == null || clazz.isInstance(object);
    }

    private static void dumpUseEntityPacket(Object object) {
        if (PacketHook.isUseEntityPacket(object)) {
            try {
                Field[] fieldArray;
                ArrayList<String> arrayList = new ArrayList<String>();
                for (Field field : fieldArray = object.getClass().getDeclaredFields()) {
                    field.setAccessible(true);
                    arrayList.add(field.getName() + "=" + field.get(object));
                }
                Logger.debug("PacketHook C02: " + arrayList);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private static Object defaultReturnValue(Class<?> clazz) {
        if (clazz.isPrimitive() && clazz != Void.TYPE) {
            if (clazz == Boolean.TYPE) {
                return Boolean.FALSE;
            }
            if (clazz == Character.TYPE) {
                return Character.valueOf('\u0000');
            }
            if (clazz == Byte.TYPE) {
                return 0;
            }
            if (clazz == Short.TYPE) {
                return 0;
            }
            if (clazz == Integer.TYPE) {
                return 0;
            }
            if (clazz == Long.TYPE) {
                return 0L;
            }
            if (clazz == Float.TYPE) {
                return Float.valueOf(0.0f);
            }
            return clazz == Double.TYPE ? Double.valueOf(0.0) : null;
        }
        return null;
    }

    static {
        debugPacketCount = 0L;
    }

    private static class GenericProxy
    implements InvocationHandler {
        private final Object original;
        private final boolean channelHook;

        private GenericProxy(Object object, boolean bl) {
            this.original = object;
            this.channelHook = bl;
        }

        @Override
        public Object invoke(Object object, Method method, Object[] objectArray) throws Throwable {
            try {
                if (objectArray != null && objectArray.length > 0) {
                    Object object2 = objectArray[0];
                    String string = method.getName();
                    if (this.channelHook && string.startsWith("write")) {
                        if (PacketHook.isPacket(object2)) {
                            lastPacketTime = System.currentTimeMillis();
                            ++debugPacketCount;
                            PacketHook.postSend(object2);
                        } else {
                            Logger.info("PacketHook: SEND write method but arg not a Packet. Class: " + object2.getClass().getName());
                        }
                    } else if (!this.channelHook && objectArray.length == 1) {
                        if (PacketHook.isPacket(object2)) {
                            lastPacketTime = System.currentTimeMillis();
                            ++debugPacketCount;
                            PacketHook.postReceive(object2);
                        } else if (++debugPacketCount % 500L == 0L) {
                            Logger.info("PacketHook: RECEIVE 1 arg method but arg not a Packet. Class: " + object2.getClass().getName() + ", Method: " + string);
                        }
                    }
                }
            }
            catch (PacketCancelledException packetCancelledException) {
                return PacketHook.defaultReturnValue(method.getReturnType());
            }
            try {
                return method.invoke(this.original, objectArray);
            }
            catch (InvocationTargetException invocationTargetException) {
                throw invocationTargetException.getCause();
            }
        }
    }

    private static class PacketCancelledException
    extends RuntimeException {
        private static final long serialVersionUID = 1L;

        private PacketCancelledException() {
        }
    }
}

