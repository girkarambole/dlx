/*
 * Decompiled with CFR 0.152.
 */
package me.ries.setting;

import me.ries.module.Module;
import me.ries.setting.OptionBase;

public final class BooleanOption
extends OptionBase<Boolean> {
    public BooleanOption(String name, boolean defaultValue, Module module) {
        super(name, defaultValue, module);
    }

    public void toggle() {
        this.setValue((Boolean)this.getValue() == false);
    }

    @Override
    public void fromConfigValue(Object value) {
        if (value instanceof Boolean) {
            this.setValue((Boolean)value);
        } else if (value instanceof String) {
            this.setValue(Boolean.parseBoolean((String)value));
        }
    }
}
