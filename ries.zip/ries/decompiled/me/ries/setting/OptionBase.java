/*
 * Decompiled with CFR 0.152.
 */
package me.ries.setting;

import me.ries.module.Module;
import me.ries.module.impl.DeveloperModeModule;

public abstract class OptionBase<T> {
    private final String name;
    private final T defaultValue;
    private final Module module;
    private String group = "";
    private String dependency = "";
    protected T value;

    protected OptionBase(String string, T t, Module module) {
        this.name = string;
        this.defaultValue = t;
        this.value = t;
        this.module = module;
    }

    public String getName() {
        return this.name;
    }

    public T getValue() {
        if (!DeveloperModeModule.isDevModeActive()) {
            String string;
            String string2 = this.module != null ? this.module.getName() : "";
            String string3 = string = this.name != null ? this.name : "";
            if (string2.equalsIgnoreCase("KillAura")) {
                if (string.equalsIgnoreCase("KeepSprint")) {
                    return (T)"On";
                }
                if (string.equalsIgnoreCase("AttackMode")) {
                    return (T)"Single";
                }
                if (string.equalsIgnoreCase("TargetLock")) {
                    return (T)"On";
                }
                if (string.equalsIgnoreCase("RangeCircle")) {
                    return (T)Boolean.FALSE;
                }
                if (string.equalsIgnoreCase("TargetMarker")) {
                    return (T)Boolean.FALSE;
                }
                if (string.equalsIgnoreCase("Tracer")) {
                    return (T)Boolean.FALSE;
                }
                if (string.equalsIgnoreCase("Raytrace")) {
                    return (T)Boolean.TRUE;
                }
                if (string.equalsIgnoreCase("FOV")) {
                    return (T)Double.valueOf(360.0);
                }
                if (string.equalsIgnoreCase("RotSpeed")) {
                    return (T)Double.valueOf(1.0);
                }
                if (string.equalsIgnoreCase("AimPoint")) {
                    return this.defaultValue;
                }
            } else if (string2.equalsIgnoreCase("Reach")) {
                if (string.equalsIgnoreCase("WallCheck")) {
                    return (T)Boolean.TRUE;
                }
                if (string.equalsIgnoreCase("Range Jitter")) {
                    return (T)Double.valueOf(0.0);
                }
                if (string.equalsIgnoreCase("DynamicChance")) {
                    return (T)Boolean.FALSE;
                }
                if (string.equalsIgnoreCase("AutoRange")) {
                    return (T)Boolean.FALSE;
                }
            } else if (string2.equalsIgnoreCase("TPAura")) {
                if (string.equalsIgnoreCase("HeadRide")) {
                    return (T)Boolean.TRUE;
                }
                if (string.equalsIgnoreCase("RangeCircle")) {
                    return (T)Boolean.FALSE;
                }
                if (string.equalsIgnoreCase("TargetMarker")) {
                    return (T)Boolean.FALSE;
                }
                if (string.equalsIgnoreCase("Tracer")) {
                    return (T)Boolean.FALSE;
                }
                if (string.equalsIgnoreCase("RotSpeed")) {
                    return (T)Double.valueOf(1.0);
                }
                if (string.equalsIgnoreCase("AimPoint")) {
                    return this.defaultValue;
                }
                if (string.equalsIgnoreCase("TargetLock")) {
                    return (T)"On";
                }
            } else if (string2.equalsIgnoreCase("Fly") && string.equalsIgnoreCase("Packet Hold")) {
                return (T)Boolean.TRUE;
            }
        }
        return this.value;
    }

    public boolean isVisible() {
        String string;
        if (DeveloperModeModule.isDevModeActive()) {
            return true;
        }
        String string2 = this.module != null ? this.module.getName() : "";
        String string3 = string = this.name != null ? this.name : "";
        return !(string2.equalsIgnoreCase("KillAura") ? string.equalsIgnoreCase("KeepSprint") || string.equalsIgnoreCase("AttackMode") || string.equalsIgnoreCase("TargetLock") || string.equalsIgnoreCase("RangeCircle") || string.equalsIgnoreCase("TargetMarker") || string.equalsIgnoreCase("Tracer") || string.equalsIgnoreCase("Raytrace") || string.equalsIgnoreCase("FOV") || string.equalsIgnoreCase("RotSpeed") || string.equalsIgnoreCase("AimPoint") : (string2.equalsIgnoreCase("Reach") ? string.equalsIgnoreCase("WallCheck") || string.equalsIgnoreCase("Range Jitter") || string.equalsIgnoreCase("Reach FOV") || string.equalsIgnoreCase("DynamicChance") || string.equalsIgnoreCase("AutoRange") : (string2.equalsIgnoreCase("Hitbox") ? string.equalsIgnoreCase("CageDistance") || string.equalsIgnoreCase("CageAlpha") || string.equalsIgnoreCase("CageThickness") : (string2.equalsIgnoreCase("TPAura") ? string.equalsIgnoreCase("Spin Radius") || string.equalsIgnoreCase("Spin Speed") || string.equalsIgnoreCase("HeadRide") || string.equalsIgnoreCase("RangeCircle") || string.equalsIgnoreCase("TargetMarker") || string.equalsIgnoreCase("Tracer") || string.equalsIgnoreCase("RotSpeed") || string.equalsIgnoreCase("AimPoint") || string.equalsIgnoreCase("TargetLock") : string2.equalsIgnoreCase("Fly") && (string.equalsIgnoreCase("Packet Hold") || string.equalsIgnoreCase("Hold Duration") || string.equalsIgnoreCase("Teleport Speed"))))));
    }

    public void setValue(T t) {
        this.value = t;
    }

    public T getDefaultValue() {
        return this.defaultValue;
    }

    public Module getModule() {
        return this.module;
    }

    public String getGroup() {
        return this.group;
    }

    public OptionBase<T> setGroup(String string) {
        this.group = string == null ? "" : string;
        return this;
    }

    public String getDependency() {
        return this.dependency;
    }

    public OptionBase<T> setDependency(String string) {
        this.dependency = string == null ? "" : string;
        return this;
    }

    public Object toConfigValue() {
        return this.value;
    }

    public abstract void fromConfigValue(Object var1);
}

