/*
 * Decompiled with CFR 0.152.
 */
package me.ries.setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import me.ries.module.Module;
import me.ries.setting.OptionBase;

public final class StringOption
extends OptionBase<String> {
    private final List<String> modes;

    public StringOption(String name, String defaultValue, Module module, String ... modes) {
        super(name, defaultValue, module);
        ArrayList<String> values = new ArrayList<String>();
        if (modes != null) {
            for (String mode : modes) {
                if (mode == null || values.contains(mode)) continue;
                values.add(mode);
            }
        }
        if (values.isEmpty()) {
            values.add(defaultValue);
        }
        this.modes = Collections.unmodifiableList(values);
        this.setValue(defaultValue);
    }

    public List<String> getModes() {
        return this.modes;
    }

    @Override
    public void setValue(String value) {
        if (value != null && this.modes.contains(value)) {
            super.setValue(value);
        }
    }

    @Override
    public void fromConfigValue(Object value) {
        if (value != null) {
            this.setValue(String.valueOf(value));
        }
    }
}

