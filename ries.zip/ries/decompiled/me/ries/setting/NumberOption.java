/*
 * Decompiled with CFR 0.152.
 */
package me.ries.setting;

import me.ries.module.Module;
import me.ries.setting.OptionBase;

public final class NumberOption
extends OptionBase<Double> {
    private final double min;
    private final double max;
    private final double increment;

    public NumberOption(String name, double defaultValue, double min, double max, double increment, Module module) {
        super(name, defaultValue, module);
        this.min = Math.min(min, max);
        this.max = Math.max(min, max);
        this.increment = increment <= 0.0 ? 1.0 : increment;
        this.setValue(defaultValue);
    }

    public double getMin() {
        return this.min;
    }

    public double getMax() {
        return this.max;
    }

    public double getIncrement() {
        return this.increment;
    }

    @Override
    public void setValue(Double value) {
        if (value != null) {
            double clamped = Math.max(this.min, Math.min(this.max, value));
            double stepped = (double)Math.round(clamped / this.increment) * this.increment;
            super.setValue(Math.max(this.min, Math.min(this.max, stepped)));
        }
    }

    @Override
    public void fromConfigValue(Object value) {
        if (value instanceof Number) {
            this.setValue(((Number)value).doubleValue());
        } else if (value instanceof String) {
            try {
                this.setValue(Double.parseDouble((String)value));
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
    }
}
