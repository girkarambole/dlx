/*
 * Decompiled with CFR 0.152.
 */
package me.ries.setting;

import me.ries.module.Module;
import me.ries.setting.OptionBase;

public final class TextOption
extends OptionBase<String> {
    public TextOption(String name, String defaultValue, Module module) {
        super(name, defaultValue == null ? "" : defaultValue, module);
    }

    public String getText() {
        return (String)this.getValue();
    }

    public void setText(String text) {
        this.setValue(text == null ? "" : text);
    }

    @Override
    public void fromConfigValue(Object value) {
        this.setText(value == null ? "" : String.valueOf(value));
    }
}

