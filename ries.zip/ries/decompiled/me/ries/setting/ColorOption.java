/*
 * Decompiled with CFR 0.152.
 */
package me.ries.setting;

import java.awt.Color;
import java.util.Map;
import me.ries.module.Module;
import me.ries.setting.OptionBase;

public final class ColorOption
extends OptionBase<Color> {
    public ColorOption(String name, Color defaultValue, Module module) {
        super(name, defaultValue == null ? Color.WHITE : defaultValue, module);
    }

    public float[] getHSB() {
        Color color = (Color)this.getValue();
        return Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
    }

    public void setHSB(float hue, float saturation, float brightness, float alpha) {
        int rgb = Color.HSBtoRGB(ColorOption.clamp(hue), ColorOption.clamp(saturation), ColorOption.clamp(brightness));
        Color rgbColor = new Color(rgb);
        this.setValue(new Color(rgbColor.getRed(), rgbColor.getGreen(), rgbColor.getBlue(), Math.round(ColorOption.clamp(alpha) * 255.0f)));
    }

    @Override
    public Object toConfigValue() {
        Color color = (Color)this.getValue();
        return color.getRGB();
    }

    @Override
    public void fromConfigValue(Object value) {
        if (value instanceof Number) {
            this.setValue(new Color(((Number)value).intValue(), true));
        } else if (value instanceof Map) {
            Map map = (Map)value;
            int r = ColorOption.number(map.get("r"), ((Color)this.getValue()).getRed());
            int g = ColorOption.number(map.get("g"), ((Color)this.getValue()).getGreen());
            int b = ColorOption.number(map.get("b"), ((Color)this.getValue()).getBlue());
            int a = ColorOption.number(map.get("a"), ((Color)this.getValue()).getAlpha());
            this.setValue(new Color(ColorOption.clampInt(r), ColorOption.clampInt(g), ColorOption.clampInt(b), ColorOption.clampInt(a)));
        } else if (value != null) {
            try {
                this.setValue(new Color((int)Long.parseLong(String.valueOf(value)), true));
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
    }

    private static int number(Object value, int fallback) {
        return value instanceof Number ? ((Number)value).intValue() : fallback;
    }

    private static float clamp(float value) {
        return Math.max(0.0f, Math.min(1.0f, value));
    }

    private static int clampInt(int value) {
        return Math.max(0, Math.min(255, value));
    }
}
