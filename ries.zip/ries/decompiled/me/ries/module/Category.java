/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    RENDER("Render"),
    MISC("Misc"),
    MOD("Mod");

    private final String displayName;

    private Category(String string2) {
        this.displayName = string2;
    }

    public String getDisplayName() {
        return this.displayName;
    }
}

