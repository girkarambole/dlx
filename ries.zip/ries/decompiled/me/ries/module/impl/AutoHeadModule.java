/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import me.ries.util.MappingUtils;

public class AutoHeadModule
extends Module {
    private final NumberOption autoHeadHp = new NumberOption("AutoHeadHP", 14.0, 1.0, 20.0, 0.5, this);
    private final NumberOption autoHeadDelay = new NumberOption("AutoHead Delay", 2000.0, 0.0, 3000.0, 50.0, this);
    private long cooldownEnd = 0L;
    private long eatTime = 0L;
    private boolean switchBackPending = false;
    private int savedSlot = -1;

    public AutoHeadModule() {
        super("AutoHead", "Automatically eats Golden Heads on low health.", Category.MOD, 0);
        this.addOptions(this.autoHeadHp, this.autoHeadDelay);
    }

    @Override
    public void onEnable() {
        this.cooldownEnd = 0L;
        this.eatTime = 0L;
        this.switchBackPending = false;
        this.savedSlot = -1;
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        Object object = this.getThePlayer();
        if (object == null) {
            return;
        }
        long l = System.currentTimeMillis();
        if (this.switchBackPending) {
            this.switchBackPending = false;
            if (this.savedSlot >= 0) {
                this.setHotbarSlot(object, this.savedSlot);
            }
            this.savedSlot = -1;
            this.cooldownEnd = l + ((Double)this.autoHeadDelay.getValue()).longValue();
            return;
        }
        if (l < this.cooldownEnd) {
            return;
        }
        float f = this.getAutoHeadHealth(object);
        float f2 = ((Double)this.autoHeadHp.getValue()).floatValue();
        if (f <= 0.0f || f > f2) {
            return;
        }
        int n = this.findGoldenHeadSlot(object);
        if (n < 0) {
            return;
        }
        this.savedSlot = this.getHotbarSlot(object);
        this.setHotbarSlot(object, n);
        this.sendC08ItemUse(object);
        this.triggerItemUseAnimation(object);
        this.eatTime = l;
        this.switchBackPending = true;
    }

    private float getAutoHeadHealth(Object object) {
        try {
            float f = MappingUtils.getEntityHealth(object);
            if (f > 0.0f) {
                return f;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            Field field = MappingUtils.getField("EntityLivingBase.health");
            if (field != null) {
                field.setAccessible(true);
                return field.getFloat(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 20.0f;
    }

    private int getHotbarSlot(Object object) {
        try {
            Object object2 = MappingUtils.getInventory(object);
            if (object2 == null) {
                return 0;
            }
            Field field = MappingUtils.getField("InventoryPlayer.currentItem");
            if (field != null) {
                field.setAccessible(true);
                return field.getInt(object2);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0;
    }

    private void setHotbarSlot(Object object, int n) {
        block7: {
            Class<?> clazz;
            if (n < 0 || n > 8) {
                return;
            }
            try {
                Constructor<?>[] constructorArray;
                clazz = MappingUtils.getInventory(object);
                if (clazz != null && (constructorArray = MappingUtils.getField("InventoryPlayer.currentItem")) != null) {
                    constructorArray.setAccessible(true);
                    constructorArray.setInt(clazz, n);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            try {
                clazz = MappingUtils.get("C09PacketHeldItemChange");
                if (clazz == null) break block7;
                for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                    Class<?>[] classArray = constructor.getParameterTypes();
                    if (classArray.length != 1 || classArray[0] != Integer.TYPE) continue;
                    constructor.setAccessible(true);
                    this.sendPacket(constructor.newInstance(n));
                    break;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void sendPacket(Object object) {
        try {
            Object object2 = this.getNetHandler();
            Method method = MappingUtils.getMethod("NetHandlerPlayClient.sendPacket");
            if (object != null && object2 != null && method != null) {
                method.setAccessible(true);
                method.invoke(object2, object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private Object getNetHandler() {
        try {
            Field field = MappingUtils.getField("EntityPlayerSP.sendQueue");
            Object object = this.getThePlayer();
            if (field != null && object != null) {
                field.setAccessible(true);
                return field.get(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private int findGoldenHeadSlot(Object object) {
        try {
            Object object2 = MappingUtils.getInventory(object);
            if (object2 == null) {
                return -1;
            }
            Field field = MappingUtils.getField("InventoryPlayer.mainInventory");
            if (field == null) {
                return -1;
            }
            field.setAccessible(true);
            Object[] objectArray = (Object[])field.get(object2);
            if (objectArray == null) {
                return -1;
            }
            for (int i = 0; i < Math.min(9, objectArray.length); ++i) {
                Object object3 = objectArray[i];
                if (object3 == null || !this.isGoldenHead(object3)) continue;
                return i;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return -1;
    }

    private boolean isGoldenHead(Object object) {
        Object object2;
        Object object3;
        try {
            object3 = MappingUtils.getMethod("ItemStack.getDisplayName");
            if (object3 != null) {
                String string;
                ((Method)object3).setAccessible(true);
                object2 = ((Method)object3).invoke(object, new Object[0]);
                if (object2 instanceof String && ((string = ((String)object2).replaceAll("[\u00a7\u00c2\u00a7][0-9a-fA-Fk-orK-OR]", "").replaceAll("[^\\x20-\\x7E\u00c0-\u024f]", "").trim().toLowerCase()).contains("kafa") || string.contains("golden head") || string.contains("skull") || string.contains("altin") || string.contains("alt\u0131n"))) {
                    return true;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            object3 = MappingUtils.getItemName(object);
            if (object3 != null && (((String)(object2 = ((String)object3).toLowerCase())).contains("golden") || ((String)object2).contains("apple") || ((String)object2).contains("skull"))) {
                return true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private void triggerItemUseAnimation(Object object) {
        try {
            Method method = MappingUtils.getMethod("EntityPlayer.getHeldItem");
            Method method2 = MappingUtils.getMethod("EntityPlayer.setItemInUse");
            if (method != null && method2 != null) {
                method.setAccessible(true);
                method2.setAccessible(true);
                Object object2 = method.invoke(object, new Object[0]);
                if (object2 != null) {
                    method2.invoke(object, object2, 72000);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void sendC08ItemUse(Object object) {
        try {
            Method method;
            Object object2 = this.getPlayerController();
            Object object3 = MappingUtils.getWorldObj();
            Object object4 = MappingUtils.getHeldItem(object);
            if (object2 != null && object3 != null && object4 != null && (method = this.findSendUseItemMethod()) != null) {
                method.invoke(object2, object, object3, object4);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private Object getPlayerController() {
        try {
            Object object = MappingUtils.getMinecraft();
            Field field = MappingUtils.getField("Minecraft.playerController");
            if (field != null) {
                field.setAccessible(true);
                return field.get(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private Method findSendUseItemMethod() {
        try {
            Class<?> clazz = MappingUtils.get("PlayerControllerMP");
            Class<?> clazz2 = MappingUtils.get("ItemStack");
            if (clazz == null || clazz2 == null) {
                return null;
            }
            for (Method method : clazz.getDeclaredMethods()) {
                Class<?>[] classArray;
                if (method.getReturnType() != Boolean.TYPE || method.getParameterCount() != 3 || (classArray = method.getParameterTypes())[2] != clazz2) continue;
                method.setAccessible(true);
                return method;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }
}

