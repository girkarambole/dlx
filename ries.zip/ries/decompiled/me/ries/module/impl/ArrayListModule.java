/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.awt.Color;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.ColorOption;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;

public class ArrayListModule
extends Module {
    private final StringOption theme = new StringOption("Theme", "Classic", this, "Classic", "Liquid Glass");
    private final BooleanOption showPrefix = new BooleanOption("Show Prefix", true, (Module)this);
    private final ColorOption color1 = new ColorOption("Color 1", new Color(255, 75, 145, 255), (Module)this);
    private final ColorOption color2 = new ColorOption("Color 2", new Color(155, 93, 229, 255), (Module)this);

    private final BooleanOption background = new BooleanOption("Background", true, (Module)this);
    private final NumberOption bgAlpha = new NumberOption("Bg Opacity", 140.0, 0.0, 255.0, 5.0, (Module)this);
    private final NumberOption bgGrayness = new NumberOption("Bg Grayness", 15.0, 0.0, 255.0, 5.0, (Module)this);
    private final NumberOption itemGap = new NumberOption("Item Gap", 0.0, 0.0, 6.0, 0.5, (Module)this);
    private final BooleanOption rightBar = new BooleanOption("Right Bar", true, (Module)this);
    private final NumberOption barWidth = new NumberOption("Bar Width", 2.0, 0.5, 6.0, 0.5, (Module)this);
    private final BooleanOption blur = new BooleanOption("Blur", true, (Module)this);

    public ArrayListModule() {
        super("ArrayList", "Displays active client modules list", Category.RENDER, 0);
        this.theme.setGroup("Visuals");
        this.showPrefix.setGroup("Visuals");
        this.color1.setGroup("Visuals");
        this.color2.setGroup("Visuals");
        this.background.setGroup("Visuals");
        this.bgAlpha.setGroup("Visuals");
        this.bgGrayness.setGroup("Visuals");
        this.itemGap.setGroup("Visuals");
        this.rightBar.setGroup("Visuals");
        this.barWidth.setGroup("Visuals");
        this.blur.setGroup("Visuals");
        this.addOptions(this.theme, this.showPrefix, this.color1, this.color2, this.background, this.bgAlpha, this.bgGrayness, this.itemGap, this.rightBar, this.barWidth, this.blur);
    }

    public String getThemeMode() {
        return (String)this.theme.getValue();
    }

    public boolean isShowPrefix() {
        return (Boolean)this.showPrefix.getValue();
    }

    public Color getColor1() {
        return (Color)this.color1.getValue();
    }

    public Color getColor2() {
        return (Color)this.color2.getValue();
    }

    public boolean isBackground() {
        return (Boolean)this.background.getValue();
    }

    public int getBgAlpha() {
        return ((Double)this.bgAlpha.getValue()).intValue();
    }

    public int getBgGrayness() {
        return ((Double)this.bgGrayness.getValue()).intValue();
    }

    public float getItemGap() {
        return ((Double)this.itemGap.getValue()).floatValue();
    }

    public boolean isRightBar() {
        return (Boolean)this.rightBar.getValue();
    }

    public float getBarWidth() {
        return ((Double)this.barWidth.getValue()).floatValue();
    }

    public boolean isBlur() {
        return (Boolean)this.blur.getValue();
    }

    public Color getAccentColor() {
        return this.getColor1();
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
    }
}
