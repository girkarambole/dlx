/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.PacketSendEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class ParticlesModule
extends Module {
    public static boolean enabled = false;
    public static StringOption type;
    public static NumberOption multiplier;
    private static Class<?> particleEnumClass;
    private static Method spawnParticleMethod;
    private static Object[] enumConstants;

    public ParticlesModule() {
        super("Particles", "Modifies and multiplies hit particles", Category.RENDER, 0);
        type = new StringOption("Type", "CRIT", this, "EXPLOSION_NORMAL", "EXPLOSION_LARGE", "EXPLOSION_HUGE", "FIREWORKS_SPARK", "WATER_BUBBLE", "WATER_SPLASH", "WATER_WAKE", "SUSPENDED", "SUSPENDED_DEPTH", "CRIT", "CRIT_MAGIC", "SMOKE_NORMAL", "SMOKE_LARGE", "SPELL", "SPELL_INSTANT", "SPELL_MOB", "SPELL_MOB_AMBIENT", "SPELL_WITCH", "DRIP_WATER", "DRIP_LAVA", "VILLAGER_ANGRY", "VILLAGER_HAPPY", "TOWN_AURA", "NOTE", "PORTAL", "ENCHANTMENT_TABLE", "FLAME", "LAVA", "FOOTSTEP", "CLOUD", "REDSTONE", "SNOWBALL", "SNOW_SHOVEL", "SLIME", "HEART", "BARRIER", "ITEM_CRACK", "BLOCK_CRACK", "BLOCK_DUST", "WATER_DROP", "ITEM_TAKE", "MOB_APPEARANCE");
        multiplier = new NumberOption("Multiplier", 15.0, 1.0, 100.0, 1.0, this);
        this.addOptions(type, multiplier);
        Ries.getInstance().getEventBus().subscribe(PacketSendEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (enabled && event instanceof PacketSendEvent) {
                    ParticlesModule.this.onPacketSend((PacketSendEvent)event);
                }
            }
        });
    }

    @Override
    public void onEnable() {
        enabled = true;
        ParticlesModule.initReflection();
    }

    @Override
    public void onDisable() {
        enabled = false;
    }

    @Override
    public void onUpdate() {
    }

    public static boolean isModuleEnabled() {
        return enabled;
    }

    private void onPacketSend(PacketSendEvent event) {
        Object packet = event.getPacket();
        Class<?> c02Class = MinecraftMapper.get("C02PacketUseEntity");
        if (packet != null && c02Class != null && c02Class.isInstance(packet)) {
            try {
                Field actionField = null;
                for (Field f : c02Class.getDeclaredFields()) {
                    if (!f.getType().isEnum()) continue;
                    actionField = f;
                    break;
                }
                if (actionField != null) {
                    actionField.setAccessible(true);
                    Object actionVal = actionField.get(packet);
                    if (actionVal != null && "ATTACK".equals(((Enum)actionVal).name())) {
                        Object entity = null;
                        Method getEntityMethod = MappingUtils.getMethod("C02PacketUseEntity.getEntity");
                        if (getEntityMethod != null) {
                            entity = getEntityMethod.invoke(packet, MappingUtils.getWorldObj());
                        }
                        if (entity != null) {
                            ParticlesModule.onAttack(entity);
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public static void onAttack(Object entity) {
        if (!enabled) {
            return;
        }
        int count = ((Double)multiplier.getValue()).intValue();
        ParticlesModule.spawnParticles(entity, count);
    }

    private static void initReflection() {
        block7: {
            if (particleEnumClass != null) {
                return;
            }
            try {
                Class<?> worldClass;
                for (Class<?> c : MinecraftMapper.getClasses()) {
                    ?[] constants;
                    if (!c.isEnum() || (constants = c.getEnumConstants()) == null || constants.length <= 30) continue;
                    boolean hasCrit = false;
                    boolean hasFlame = false;
                    for (Object obj : constants) {
                        String name = ((Enum)obj).name();
                        if ("CRIT".equals(name)) {
                            hasCrit = true;
                        }
                        if (!"FLAME".equals(name)) continue;
                        hasFlame = true;
                    }
                    if (!hasCrit || !hasFlame) continue;
                    particleEnumClass = c;
                    enumConstants = constants;
                    break;
                }
                if ((worldClass = MappingUtils.get("World")) == null || particleEnumClass == null) break block7;
                for (Method m : worldClass.getDeclaredMethods()) {
                    Class<?>[] params = m.getParameterTypes();
                    if (params.length != 8 || params[0] != particleEnumClass || params[1] != Double.TYPE || params[2] != Double.TYPE || params[3] != Double.TYPE || params[4] != Double.TYPE || params[5] != Double.TYPE || params[6] != Double.TYPE || params[7] != int[].class) continue;
                    m.setAccessible(true);
                    spawnParticleMethod = m;
                    break;
                }
            }
            catch (Throwable t) {
                Logger.warn("ParticlesModule initReflection failed: " + t.getMessage());
            }
        }
    }

    private static Object getEnumConstant(String name) {
        if (enumConstants == null) {
            return null;
        }
        for (Object obj : enumConstants) {
            if (!((Enum)obj).name().equalsIgnoreCase(name)) continue;
            return obj;
        }
        return null;
    }

    public static void spawnParticles(Object entity, int count) {
        ParticlesModule.initReflection();
        if (spawnParticleMethod == null || particleEnumClass == null) {
            return;
        }
        try {
            Object world = MappingUtils.getWorldObj();
            if (world == null || entity == null) {
                return;
            }
            double[] pos = MappingUtils.getInterpolatedPos(entity, 1.0f);
            double x = pos[0];
            double y = pos[1] + 1.0;
            double z = pos[2];
            String pType = (String)type.getValue();
            Object enumVal = ParticlesModule.getEnumConstant(pType);
            if (enumVal == null) {
                enumVal = enumConstants[0];
            }
            int[] extraArgs = new int[]{};
            for (int i = 0; i < count; ++i) {
                double rx = (Math.random() - 0.5) * 0.4;
                double ry = (Math.random() - 0.5) * 0.6;
                double rz = (Math.random() - 0.5) * 0.4;
                double sx = (Math.random() - 0.5) * 0.15;
                double sy = Math.random() * 0.15;
                double sz = (Math.random() - 0.5) * 0.15;
                spawnParticleMethod.invoke(world, enumVal, x + rx, y + ry, z + rz, sx, sy, sz, extraArgs);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    static {
        particleEnumClass = null;
        spawnParticleMethod = null;
        enumConstants = null;
    }
}

