/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.GLU
 */
package me.ries.module.impl;

import java.lang.reflect.Method;
import java.nio.Buffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render3DEvent;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.KillAuraModule;
import me.ries.module.impl.TPAuraModule;
import me.ries.setting.BooleanOption;
import me.ries.ui.ClickGui;
import me.ries.util.FontUtil;
import me.ries.util.GLErrorChecker;
import me.ries.util.GaussianBlur;
import me.ries.util.GlStateManager;
import me.ries.util.MappingUtils;
import me.ries.util.RoundedUtil;
import me.ries.util.ScissorUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public class TargetHudModule
extends Module {
    public final BooleanOption followTarget = new BooleanOption("FollowTarget", false, (Module)this);
    public static float posX = 420.0f;
    public static float posY = 40.0f;
    public static float width = 110.0f;
    public static float height = 38.0f;
    private static final float MIN_W = 80.0f;
    private static final float MAX_W = 200.0f;
    private static final float MIN_H = 32.0f;
    private static final float MAX_H = 80.0f;
    private final FloatBuffer proj_modelView = BufferUtils.createFloatBuffer((int)16);
    private final FloatBuffer proj_projection = BufferUtils.createFloatBuffer((int)16);
    private final IntBuffer proj_viewport = BufferUtils.createIntBuffer((int)16);
    private boolean proj_matricesCached = false;
    private static boolean isDragging = false;
    private static boolean isResizing = false;
    private static int resizeEdge = 0;
    private static float dragOffsetX = 0.0f;
    private static float dragOffsetY = 0.0f;
    private static final int MAX_HIT_BUBBLES = 8;
    private float healthAnim = 0.0f;
    private float displayedHealth = 0.0f;
    private float showAnim = 0.0f;
    private float bounceAnim = 1.0f;
    private float avatarPopAnim = 1.0f;
    private float lastTrackedHealth = -1.0f;
    private Object lastTarget = null;
    private Object animTarget = null;
    private long lastTargetTime = 0L;
    private final List<HitBubble> hitBubbles = new ArrayList<HitBubble>();
    private static Method methodGetLocationSkin;
    private static Method methodGetTextureManager;
    private static Method methodBindTexture;
    private static boolean reflectionCached;

    public static void resetDragState() {
        isDragging = false;
        isResizing = false;
        resizeEdge = 0;
    }

    public TargetHudModule() {
        super("TargetHUD", "Shows current combat target", Category.RENDER, 0);
        this.addOptions(this.followTarget);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    TargetHudModule.this.onRender3D();
                }
            }
        });
    }

    @Override
    public void onEnable() {
        this.showAnim = 0.0f;
        this.healthAnim = 0.0f;
        this.displayedHealth = 0.0f;
        this.bounceAnim = 1.0f;
        this.avatarPopAnim = 1.0f;
        this.lastTrackedHealth = -1.0f;
        this.animTarget = null;
        this.hitBubbles.clear();
        this.cacheReflection();
    }

    @Override
    public void onDisable() {
        this.lastTarget = null;
        this.animTarget = null;
        this.hitBubbles.clear();
    }

    @Override
    public void onUpdate() {
    }

    public void onRender3D() {
        if (this.isEnabled()) {
            ((Buffer)this.proj_modelView).clear();
            ((Buffer)this.proj_projection).clear();
            ((Buffer)this.proj_viewport).clear();
            GL11.glGetFloat((int)2982, (FloatBuffer)this.proj_modelView);
            GL11.glGetFloat((int)2983, (FloatBuffer)this.proj_projection);
            GL11.glGetInteger((int)2978, (IntBuffer)this.proj_viewport);
            this.proj_matricesCached = true;
        }
    }

    public void render() {
        if (this.isEnabled() && !ClickGui.isUiEditMode()) {
            this.renderInternal();
        }
    }

    public void renderForEditMode() {
        if (this.isEnabled()) {
            this.renderInternal();
        }
    }

    private void cacheReflection() {
        TargetHudModule.cacheReflectionStatic();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void renderInternal() {
        float targetShow;
        boolean guiOpen;
        this.cacheReflection();
        Object target = this.resolveTarget();
        boolean hasTarget = target != null;
        boolean inEditMode = guiOpen = ClickGui.isUiEditMode();
        if (hasTarget) {
            this.lastTargetTime = System.currentTimeMillis();
        }
        boolean stillAlive = false;
        if (!hasTarget && this.lastTarget != null) {
            try {
                if (MappingUtils.getEntityHealth(this.lastTarget) > 0.0f) {
                    stillAlive = true;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        if (hasTarget) {
            this.lastTarget = target;
        }
        boolean shouldShow = hasTarget || stillAlive && System.currentTimeMillis() - this.lastTargetTime < 100L || guiOpen;
        float f = targetShow = shouldShow ? 1.0f : 0.0f;
        this.showAnim = Math.abs(this.showAnim - targetShow) > 0.001f ? this.lerp(this.showAnim, targetShow, shouldShow ? 0.15f : 0.22f) : targetShow;
        if (this.showAnim < 0.01f) {
            this.lastTarget = null;
        } else {
            GLErrorChecker.clear();
            GL11.glPushAttrib((int)1048575);
            GL11.glPushMatrix();
            GLErrorChecker.check("TargetHudModule.renderInternal init");
            try {
                String name;
                float eased = 1.0f - (float)Math.pow(1.0f - this.showAnim, 3.0);
                int sw = ScissorUtil.getScaledWidth();
                int sh = ScissorUtil.getScaledHeight();
                posX = Math.max(5.0f, Math.min((float)sw - width - 5.0f, posX));
                posY = Math.max(5.0f, Math.min((float)sh - height - 5.0f, posY));
                if (((Boolean)this.followTarget.getValue()).booleanValue() && !inEditMode) {
                    float[] screen;
                    Object followEntity;
                    Object object = hasTarget ? target : (followEntity = stillAlive ? this.lastTarget : null);
                    if (followEntity != null && (screen = this.projectEntityCenter(followEntity)) != null) {
                        float tx = screen[0];
                        float ty = screen[1];
                        float offset = 20.0f;
                        posX = tx + width + offset * 2.0f < (float)sw ? tx + offset : tx - width - offset;
                        posY = ty - height / 2.0f;
                        posX = Math.max(5.0f, Math.min((float)sw - width - 5.0f, posX));
                        posY = Math.max(5.0f, Math.min((float)sh - height - 5.0f, posY));
                    }
                }
                if (!Mouse.isGrabbed()) {
                    this.handleInteraction(sw, sh);
                }
                String string = hasTarget ? MappingUtils.getName(target) : (name = stillAlive && this.lastTarget != null ? MappingUtils.getName(this.lastTarget) : "Preview");
                float health = hasTarget ? MappingUtils.getEntityHealth(target) : (stillAlive && this.lastTarget != null ? MappingUtils.getEntityHealth(this.lastTarget) : 11.0f);
                float targetHealthAnim = Math.min(1.0f, health / 20.0f);
                if (Math.abs(this.healthAnim - targetHealthAnim) > 0.001f) {
                    this.healthAnim = this.lerp(this.healthAnim, targetHealthAnim, 0.1f);
                }
                this.displayedHealth = Math.abs(this.displayedHealth - health) > 0.05f ? this.lerp(this.displayedHealth, health, 0.14f) : health;
                this.updateCombatAnimations(hasTarget, target, health);
                float alpha = eased * (guiOpen && !hasTarget ? 0.75f : 1.0f);
                Object renderTarget = target != null ? target : this.lastTarget;
                float slideY = (1.0f - eased) * -10.0f;
                this.setupHudDrawState();
                this.renderPanel(posX, posY + slideY, width, height, name, this.displayedHealth, alpha, eased, renderTarget, guiOpen, this.bounceAnim, this.avatarPopAnim);
            }
            finally {
                GL11.glPopMatrix();
                GL11.glPopAttrib();
                GLErrorChecker.check("TargetHudModule.renderInternal end");
            }
        }
    }

    private Object resolveTarget() {
        Object target;
        KillAuraModule killAura = Ries.getInstance().getModuleManager().getModule(KillAuraModule.class);
        if (killAura != null && killAura.isEnabled() && (target = killAura.getClosestTarget()) != null) {
            return target;
        }
        TPAuraModule tpAura = Ries.getInstance().getModuleManager().getModule(TPAuraModule.class);
        return tpAura != null && tpAura.isEnabled() ? tpAura.getHudTarget() : null;
    }

    private void handleInteraction(int sw, int sh) {
        if (!ClickGui.isUiEditMode()) {
            isDragging = false;
            isResizing = false;
            resizeEdge = 0;
        } else {
            boolean inside;
            int mx = ScissorUtil.mapMouseX(Mouse.getX());
            int my = ScissorUtil.mapMouseY(Mouse.getY());
            float x = posX;
            float y = posY;
            float w = width;
            float h = height;
            float edge = 6.0f;
            boolean onRight = (float)mx >= x + w - edge && (float)mx <= x + w + 2.0f && (float)my >= y && (float)my <= y + h;
            boolean onBottom = (float)my >= y + h - edge && (float)my <= y + h + 2.0f && (float)mx >= x && (float)mx <= x + w;
            boolean onCorner = onRight && onBottom;
            boolean bl = inside = (float)mx >= x && (float)mx <= x + w && (float)my >= y && (float)my <= y + h;
            if (Mouse.isButtonDown((int)0)) {
                if (!isDragging && !isResizing) {
                    if (ClickGui.isDraggingAnyElement()) {
                        return;
                    }
                    if (onCorner) {
                        isResizing = true;
                        resizeEdge = 3;
                        ClickGui.setDraggingAnyElement(true);
                    } else if (onRight) {
                        isResizing = true;
                        resizeEdge = 1;
                        ClickGui.setDraggingAnyElement(true);
                    } else if (onBottom) {
                        isResizing = true;
                        resizeEdge = 2;
                        ClickGui.setDraggingAnyElement(true);
                    } else if (inside) {
                        isDragging = true;
                        dragOffsetX = (float)mx - x;
                        dragOffsetY = (float)my - y;
                        ClickGui.setDraggingAnyElement(true);
                    }
                }
                if (isDragging) {
                    posX = Math.max(5.0f, Math.min((float)sw - width - 5.0f, (float)mx - dragOffsetX));
                    posY = Math.max(5.0f, Math.min((float)sh - height - 5.0f, (float)my - dragOffsetY));
                }
                if (isResizing) {
                    if (resizeEdge == 1 || resizeEdge == 3) {
                        width = Math.max(80.0f, Math.min(200.0f, (float)mx - x));
                    }
                    if (resizeEdge == 2 || resizeEdge == 3) {
                        height = Math.max(32.0f, Math.min(80.0f, (float)my - y));
                    }
                }
            } else {
                if (isDragging || isResizing) {
                    ClickGui.setDraggingAnyElement(false);
                }
                isDragging = false;
                isResizing = false;
                resizeEdge = 0;
            }
        }
    }

    private void updateCombatAnimations(boolean hasTarget, Object target, float health) {
        if (hasTarget && target != null && target != this.animTarget) {
            this.animTarget = target;
            this.bounceAnim = 0.86f;
            this.lastTrackedHealth = health;
        }
        this.bounceAnim = this.lerp(this.bounceAnim, 1.0f, 0.14f);
        this.avatarPopAnim = this.lerp(this.avatarPopAnim, 1.0f, 0.2f);
        if (hasTarget && target != null && this.lastTrackedHealth > 0.0f && health < this.lastTrackedHealth - 0.4f) {
            this.avatarPopAnim = 1.16f;
            this.spawnHitBubbles();
        }
        if (hasTarget) {
            this.lastTrackedHealth = health;
        } else if (!hasTarget && this.showAnim < 0.05f) {
            this.lastTrackedHealth = -1.0f;
            this.animTarget = null;
        }
        this.updateHitBubbles();
    }

    private void spawnHitBubbles() {
        int count = 2 + (int)(Math.random() * 3.0);
        for (int i = 0; i < count && this.hitBubbles.size() < 8; ++i) {
            float angle = (float)(Math.random() * Math.PI * 2.0);
            float speed = 14.0f + (float)Math.random() * 12.0f;
            float life = 0.28f + (float)Math.random() * 0.28f;
            float size = 1.2f + (float)Math.random() * 1.6f;
            this.hitBubbles.add(new HitBubble((float)Math.cos(angle), (float)Math.sin(angle), speed, life, size));
        }
    }

    private void updateHitBubbles() {
        Iterator<HitBubble> it = this.hitBubbles.iterator();
        while (it.hasNext()) {
            HitBubble bubble = it.next();
            bubble.age += 0.016f;
            if (!(bubble.age >= bubble.life)) continue;
            it.remove();
        }
    }

    private void renderHitBubbles(float cx, float cy, float avatarSize, float alpha) {
        if (!this.hitBubbles.isEmpty()) {
            float half = avatarSize * 0.5f;
            for (HitBubble bubble : this.hitBubbles) {
                float t = bubble.age / bubble.life;
                float fade = (1.0f - t) * alpha;
                float dist = t * bubble.speed;
                float bx = cx + bubble.dirX * (half * 0.75f + dist);
                float by = cy + bubble.dirY * (half * 0.75f + dist);
                float s = bubble.size * (1.0f - t * 0.35f);
                this.drawRect(bx - s * 0.5f, by - s * 0.5f, s, s, this.hex(255, 255, 255, (int)(180.0f * fade)));
            }
        }
    }

    private void renderPanel(float x, float y, float w, float h, String name, float health, float alpha, float eased, Object target, boolean guiOpen, float bounceScale, float avatarPopScale) {
        float r = Math.min(10.0f, h * 0.25f);
        if (!isDragging && !isResizing) {
            GaussianBlur.renderBlurRounded(x, y, w, h, r, 8.0f * alpha);
        }
        this.setupHudDrawState();
        float scale = (0.95f + 0.05f * eased) * bounceScale;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x + w / 2.0f, y + h / 2.0f, 0.0f);
        GlStateManager.scale(scale, scale, 1.0f);
        GlStateManager.translate(-(x + w / 2.0f), -(y + h / 2.0f), 0.0f);
        RoundedUtil.roundedRect((double)x, (double)y, (double)w, (double)h, (double)r, this.hex(15, 15, 18, (int)(120.0f * alpha)));
        int borderColor = !isDragging && !isResizing ? this.hex(255, 255, 255, (int)(20.0f * alpha)) : this.hex(100, 150, 255, (int)(80.0f * alpha));
        RoundedUtil.drawRoundOutline(x, y, w, h, r, 1.0f, borderColor);
        float pad = h * 0.15f;
        float avatarSize = h - pad * 2.0f;
        float avatarX = x + pad;
        float avatarY = y + pad;
        RoundedUtil.roundedRect((double)avatarX, (double)avatarY, (double)avatarSize, (double)avatarSize, 4.0, this.hex(30, 30, 35, (int)(255.0f * alpha)));
        float headX = avatarX + 1.0f;
        float headY = avatarY + 1.0f;
        float headSize = Math.max(4.0f, avatarSize - 2.0f);
        float headCx = headX + headSize * 0.5f;
        float headCy = headY + headSize * 0.5f;
        if (target != null) {
            this.renderHeadWithPop(headX, headY, headSize, headSize, target, alpha, 3.0f, avatarPopScale);
        } else {
            this.drawHeadPlaceholder(headX, headY, headSize, headSize, "P", alpha, 3.0f);
        }
        this.renderHitBubbles(headCx, headCy, headSize, alpha);
        this.setupHudDrawState();
        float infoX = avatarX + avatarSize + pad;
        float infoW = w - avatarSize - pad * 3.0f;
        float nameScale = Math.min(0.6f, (h - 20.0f) / 30.0f);
        GlStateManager.pushMatrix();
        GlStateManager.translate(infoX, y + pad, 0.0f);
        GlStateManager.scale(nameScale, nameScale, 1.0f);
        FontUtil.drawString(name, 0.5f, 0.5f, this.hex(0, 0, 0, (int)(150.0f * alpha)), false);
        FontUtil.drawString(name, 0.0f, 0.0f, this.hex(255, 255, 255, (int)(255.0f * alpha)), false);
        GlStateManager.popMatrix();
        float hpScale = nameScale * 0.85f;
        float hpY = y + pad + (float)FontUtil.getHeight() * nameScale + 2.0f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(infoX, hpY, 0.0f);
        GlStateManager.scale(hpScale, hpScale, 1.0f);
        FontUtil.drawString("HP", 0.0f, 0.0f, this.hex(239, 68, 68, (int)(255.0f * alpha)), false);
        float hpLabelW = FontUtil.getStringWidth("HP");
        GlStateManager.popMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.translate(infoX + hpLabelW * hpScale + 3.0f, hpY, 0.0f);
        GlStateManager.scale(hpScale, hpScale, 1.0f);
        FontUtil.drawString(String.format("%.0f", Float.valueOf(health)), 0.0f, 0.0f, this.hex(161, 161, 170, (int)(255.0f * alpha)), false);
        GlStateManager.popMatrix();
        float barH = Math.max(3.0f, h * 0.1f);
        float barY = y + h - pad - barH;
        this.drawRect(infoX, barY, infoW, barH, this.hex(30, 30, 35, (int)(220.0f * alpha)));
        float fillW = infoW * this.healthAnim;
        if (fillW > 1.0f) {
            this.drawGradient(infoX, barY, fillW, barH, this.hex(220, 220, 225, (int)(255.0f * alpha)), this.hex(120, 120, 130, (int)(255.0f * alpha)));
        }
        if (guiOpen) {
            float hs = 6.0f;
            float hx = x + w - hs - 2.0f;
            float hy = y + h - hs - 2.0f;
            int hc = isResizing ? this.hex(100, 150, 255, (int)(150.0f * alpha)) : this.hex(80, 80, 90, (int)(100.0f * alpha));
            this.drawRect(hx, hy, hs, hs, hc);
        }
        GlStateManager.popMatrix();
    }

    private void renderHeadWithPop(float x, float y, float w, float h, Object target, float alpha, float cornerRadius, float popScale) {
        if (popScale <= 1.005f) {
            this.renderHead(x, y, w, h, target, alpha, cornerRadius);
        } else {
            float cx = x + w / 2.0f;
            float cy = y + h / 2.0f;
            GlStateManager.pushMatrix();
            GlStateManager.translate(cx, cy, 0.0f);
            GlStateManager.scale(popScale, popScale, 1.0f);
            GlStateManager.translate(-cx, -cy, 0.0f);
            this.renderHead(x, y, w, h, target, alpha, cornerRadius);
            GlStateManager.popMatrix();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void renderHead(float x, float y, float w, float h, Object target, float alpha, float cornerRadius) {
        block11: {
            GLErrorChecker.clear();
            GL11.glPushAttrib((int)1048575);
            GlStateManager.pushMatrix();
            try {
                GL11.glEnable((int)3553);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glDisable((int)2929);
                GL11.glDisable((int)2896);
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
                float radius = Math.min(cornerRadius, Math.min(w, h) / 2.0f);
                Object skin = TargetHudModule.resolveSkin(target);
                Object textureManager = TargetHudModule.getTextureManager();
                if (skin != null && textureManager != null && methodBindTexture != null) {
                    TargetHudModule.bindTexture(textureManager, skin);
                    int texWidth = 64;
                    int texHeight = 64;
                    try {
                        texWidth = GL11.glGetTexLevelParameteri((int)3553, (int)0, (int)4096);
                        texHeight = GL11.glGetTexLevelParameteri((int)3553, (int)0, (int)4097);
                        if (texWidth <= 0 || texHeight <= 0) {
                            texWidth = 64;
                            texHeight = 64;
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    GL11.glTexParameteri((int)3553, (int)10241, (int)9728);
                    GL11.glTexParameteri((int)3553, (int)10240, (int)9728);
                    float scale = (float)texWidth / 64.0f;
                    float headU = 8.0f * scale;
                    float headV = 8.0f * scale;
                    float headSize = 8.0f * scale;
                    float overlayU = 40.0f * scale;
                    float aaWidth = 0.8f;
                    float step = 0.5f;
                    for (float dy = 0.0f; dy < h; dy += step) {
                        for (float dx = 0.0f; dx < w; dx += step) {
                            float pixelAlpha = this.cornerPixelAlpha(dx, dy, w, h, radius, aaWidth);
                            if (pixelAlpha <= 0.005f) continue;
                            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)(alpha * pixelAlpha));
                            float px = x + dx;
                            float py = y + dy;
                            float u = headU + dx / w * headSize;
                            float v = headV + dy / h * headSize;
                            float u2 = overlayU + dx / w * headSize;
                            float uSpan = headSize * step / w;
                            float vSpan = headSize * step / h;
                            this.drawTextureSlice(px, py, step, step, u, v, uSpan, vSpan, texWidth, texHeight);
                            this.drawTextureSlice(px, py, step, step, u2, v, uSpan, vSpan, texWidth, texHeight);
                        }
                    }
                    break block11;
                }
                this.drawHeadPlaceholder(x, y, w, h, radius, alpha);
            }
            catch (Throwable var35) {
                this.drawHeadPlaceholder(x, y, w, h, Math.min(cornerRadius, Math.min(w, h) / 2.0f), alpha);
            }
            finally {
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GlStateManager.popMatrix();
                GL11.glPopAttrib();
                GLErrorChecker.check("TargetHudModule.renderHead end");
            }
        }
    }

    private float cornerPixelAlpha(float dx, float dy, float w, float h, float radius, float aaWidth) {
        float dist;
        if (dx >= radius && dx <= w - radius) {
            return 1.0f;
        }
        if (dy >= radius && dy <= h - radius) {
            return 1.0f;
        }
        if (dx < radius && dy < radius) {
            dist = (float)Math.sqrt((dx - radius) * (dx - radius) + (dy - radius) * (dy - radius));
        } else if (dx > w - radius && dy < radius) {
            float ddx = dx - (w - radius);
            dist = (float)Math.sqrt(ddx * ddx + (dy - radius) * (dy - radius));
        } else if (dx < radius && dy > h - radius) {
            float ddy = dy - (h - radius);
            dist = (float)Math.sqrt((dx - radius) * (dx - radius) + ddy * ddy);
        } else {
            float ddx = dx - (w - radius);
            float ddy = dy - (h - radius);
            dist = (float)Math.sqrt(ddx * ddx + ddy * ddy);
        }
        return Math.max(0.0f, Math.min(1.0f, (radius - dist) / aaWidth + 0.5f));
    }

    private void drawTextureSlice(float x, float y, float w, float h, float u, float v, float uW, float vH, float texW, float texH) {
        float u1 = u / texW;
        float v1 = v / texH;
        float u2 = (u + uW) / texW;
        float v2 = (v + vH) / texH;
        GL11.glBegin((int)7);
        GL11.glTexCoord2f((float)u1, (float)v1);
        GL11.glVertex2f((float)x, (float)y);
        GL11.glTexCoord2f((float)u1, (float)v2);
        GL11.glVertex2f((float)x, (float)(y + h));
        GL11.glTexCoord2f((float)u2, (float)v2);
        GL11.glVertex2f((float)(x + w), (float)(y + h));
        GL11.glTexCoord2f((float)u2, (float)v1);
        GL11.glVertex2f((float)(x + w), (float)y);
        GL11.glEnd();
    }

    private void setupHudDrawState() {
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)2896);
        GL11.glDisable((int)3008);
        GL11.glDisable((int)2960);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glShadeModel((int)7424);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
        GL11.glDepthMask((boolean)false);
    }

    private void drawHeadPlaceholder(float x, float y, float w, float h, float radius, float alpha) {
        RoundedUtil.roundedRect((double)x, (double)y, (double)w, (double)h, (double)radius, this.hex(70, 70, 75, (int)(200.0f * alpha)));
    }

    private void drawHeadPlaceholder(float x, float y, float w, float h, String name, float alpha, float cornerRadius) {
        this.drawHeadPlaceholder(x, y, w, h, cornerRadius, alpha);
        if (name != null && !name.isEmpty()) {
            String letter = name.substring(0, 1).toUpperCase();
            float scale = Math.min(0.55f, h / 22.0f);
            GlStateManager.pushMatrix();
            GlStateManager.translate(x + w / 2.0f - (float)FontUtil.getStringWidth(letter) * scale * 0.5f, y + h / 2.0f - (float)FontUtil.getHeight() * scale * 0.5f, 0.0f);
            GlStateManager.scale(scale, scale, 1.0f);
            FontUtil.drawString(letter, 0.0f, 0.0f, this.hex(180, 180, 190, (int)(220.0f * alpha)), false);
            GlStateManager.popMatrix();
        }
    }

    public static void cacheReflectionStatic() {
        if (!reflectionCached) {
            reflectionCached = true;
            try {
                methodGetLocationSkin = MappingUtils.getMethod("AbstractClientPlayer.getLocationSkin");
                if (methodGetLocationSkin != null) {
                    methodGetLocationSkin.setAccessible(true);
                }
                if ((methodGetTextureManager = MappingUtils.getMethod("Minecraft.getTextureManager")) != null) {
                    methodGetTextureManager.setAccessible(true);
                }
                if ((methodBindTexture = MappingUtils.getMethod("TextureManager.bindTexture")) != null) {
                    methodBindTexture.setAccessible(true);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    public static Object resolveSkin(Object entity) {
        if (entity == null) {
            return null;
        }
        TargetHudModule.cacheReflectionStatic();
        try {
            Object skin;
            if (methodGetLocationSkin != null && (skin = methodGetLocationSkin.invoke(entity, new Object[0])) != null) {
                return skin;
            }
        }
        catch (Throwable skin) {
            // empty catch block
        }
        try {
            Class<?> resLoc = MappingUtils.get("ResourceLocation");
            if (resLoc == null) {
                return null;
            }
            for (Method m : entity.getClass().getMethods()) {
                if (m.getParameterCount() != 0 || !resLoc.isAssignableFrom(m.getReturnType())) continue;
                m.setAccessible(true);
                Object skin = m.invoke(entity, new Object[0]);
                if (skin == null) continue;
                return skin;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    public static Object getTextureManager() {
        TargetHudModule.cacheReflectionStatic();
        try {
            Object mc = MappingUtils.getMinecraft();
            return mc != null && methodGetTextureManager != null ? methodGetTextureManager.invoke(mc, new Object[0]) : null;
        }
        catch (Throwable var1) {
            return null;
        }
    }

    public static void bindTexture(Object textureManager, Object skin) throws Exception {
        TargetHudModule.cacheReflectionStatic();
        if (methodBindTexture == null && textureManager != null && skin != null) {
            for (Method m : textureManager.getClass().getMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (p.length <= 0 || !p[0].isAssignableFrom(skin.getClass())) continue;
                methodBindTexture = m;
                methodBindTexture.setAccessible(true);
                break;
            }
        }
        if (methodBindTexture == null) {
            throw new Exception("methodBindTexture could not be found via reflection.");
        }
        Class<?>[] params = methodBindTexture.getParameterTypes();
        if (params.length >= 3) {
            methodBindTexture.invoke(textureManager, skin, 0, 0);
        } else if (params.length == 2) {
            methodBindTexture.invoke(textureManager, skin, 0);
        } else {
            methodBindTexture.invoke(textureManager, skin);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void drawRect(float x, float y, float w, float h, int color) {
        GL11.glPushAttrib((int)1048575);
        try {
            GL11.glDisable((int)3553);
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            this.setColorArgb(color);
            GL11.glBegin((int)7);
            GL11.glVertex2f((float)x, (float)y);
            GL11.glVertex2f((float)x, (float)(y + h));
            GL11.glVertex2f((float)(x + w), (float)(y + h));
            GL11.glVertex2f((float)(x + w), (float)y);
            GL11.glEnd();
        }
        finally {
            GL11.glPopAttrib();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void drawGradient(float x, float y, float w, float h, int color1, int color2) {
        GL11.glPushAttrib((int)1048575);
        try {
            GL11.glDisable((int)3553);
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glShadeModel((int)7425);
            GL11.glBegin((int)7);
            this.setColorArgb(color1);
            GL11.glVertex2f((float)x, (float)y);
            GL11.glVertex2f((float)x, (float)(y + h));
            this.setColorArgb(color2);
            GL11.glVertex2f((float)(x + w), (float)(y + h));
            GL11.glVertex2f((float)(x + w), (float)y);
            GL11.glEnd();
        }
        finally {
            GL11.glPopAttrib();
        }
    }

    private void setColorArgb(int color) {
        GL11.glColor4f((float)((float)(color >> 16 & 0xFF) / 255.0f), (float)((float)(color >> 8 & 0xFF) / 255.0f), (float)((float)(color & 0xFF) / 255.0f), (float)((float)(color >> 24 & 0xFF) / 255.0f));
    }

    private float[] projectEntityCenter(Object entity) {
        if (!this.proj_matricesCached) {
            return null;
        }
        try {
            double[] pos = MappingUtils.getInterpolatedPos(entity, 1.0f);
            double camX = MappingUtils.getRenderPosX();
            double camY = MappingUtils.getRenderPosY();
            double camZ = MappingUtils.getRenderPosZ();
            float relX = (float)(pos[0] - camX);
            float relY = (float)(pos[1] - camY + 0.85);
            float relZ = (float)(pos[2] - camZ);
            FloatBuffer win = BufferUtils.createFloatBuffer((int)3);
            ((Buffer)this.proj_modelView).rewind();
            ((Buffer)this.proj_projection).rewind();
            ((Buffer)this.proj_viewport).rewind();
            if (!GLU.gluProject((float)relX, (float)relY, (float)relZ, (FloatBuffer)this.proj_modelView, (FloatBuffer)this.proj_projection, (IntBuffer)this.proj_viewport, (FloatBuffer)win)) {
                return null;
            }
            float sz = win.get(2);
            if (!(sz < 0.0f) && !(sz > 1.0f)) {
                int scale = ScissorUtil.getScaleFactor();
                float sx = win.get(0) / (float)scale;
                float sy = ((float)Display.getHeight() - win.get(1)) / (float)scale;
                return new float[]{sx, sy};
            }
            return null;
        }
        catch (Throwable var17) {
            return null;
        }
    }

    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private int hex(int r, int g, int b, int a) {
        return (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
    }

    static {
        reflectionCached = false;
    }

    private static final class HitBubble {
        final float dirX;
        final float dirY;
        final float speed;
        final float life;
        final float size;
        float age;

        HitBubble(float dirX, float dirY, float speed, float life, float size) {
            this.dirX = dirX;
            this.dirY = dirY;
            this.speed = speed;
            this.life = life;
            this.size = size;
            this.age = 0.0f;
        }
    }
}

