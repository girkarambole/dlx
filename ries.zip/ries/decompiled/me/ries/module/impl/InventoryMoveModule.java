/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package me.ries.module.impl;

import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import org.lwjgl.input.Keyboard;

public class InventoryMoveModule
extends Module {
    public InventoryMoveModule() {
        super("InventoryMove", "Move while inventory is open", Category.MOVEMENT, 0);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
        Object player;
        Object screen = MinecraftMapper.getCurrentScreen();
        if (screen != null && (player = MinecraftMapper.getPlayer()) != null) {
            float yaw = MinecraftMapper.getRotationYaw();
            double speed = 0.2;
            boolean w = Keyboard.isKeyDown((int)17);
            boolean s = Keyboard.isKeyDown((int)31);
            boolean a = Keyboard.isKeyDown((int)30);
            boolean d = Keyboard.isKeyDown((int)32);
            if (w || s || a || d) {
                double mag;
                double r;
                double motionX = MinecraftMapper.getMotionX();
                double motionZ = MinecraftMapper.getMotionZ();
                double rad = Math.toRadians(yaw);
                if (w) {
                    motionX += -Math.sin(rad) * speed;
                    motionZ += Math.cos(rad) * speed;
                }
                if (s) {
                    motionX += Math.sin(rad) * speed;
                    motionZ += -Math.cos(rad) * speed;
                }
                if (a) {
                    r = rad - 1.5707963267948966;
                    motionX += -Math.sin(r) * speed;
                    motionZ += Math.cos(r) * speed;
                }
                if (d) {
                    r = rad + 1.5707963267948966;
                    motionX += -Math.sin(r) * speed;
                    motionZ += Math.cos(r) * speed;
                }
                if ((mag = Math.sqrt(motionX * motionX + motionZ * motionZ)) > speed * 1.5) {
                    motionX = motionX / mag * speed * 1.5;
                    motionZ = motionZ / mag * speed * 1.5;
                }
                MinecraftMapper.setMotionX(motionX);
                MinecraftMapper.setMotionZ(motionZ);
            }
        }
    }
}

