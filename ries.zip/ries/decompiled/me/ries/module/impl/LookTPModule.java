/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package me.ries.module.impl;

import java.lang.reflect.Method;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.notification.NotificationManager;
import me.ries.setting.NumberOption;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Keyboard;

public class LookTPModule
extends Module {
    private int keyHeldTicks = 0;

    public LookTPModule() {
        super("LookTP", "Teleport in looking direction by configured blocks", Category.MISC, 0);
        this.addOptions(new NumberOption("Blocks", 1.0, 0.1, 5.0, 0.1, this), new NumberOption("Speed", 5.0, 1.0, 10.0, 1.0, this));
    }

    private double blocksOption() {
        return (Double)((NumberOption)this.getOption("Blocks")).getValue();
    }

    private int speedThreshold() {
        int speed = ((Double)((NumberOption)this.getOption("Speed")).getValue()).intValue();
        return Math.max(1, 7 - speed);
    }

    @Override
    public void onEnable() {
        this.keyHeldTicks = 0;
    }

    @Override
    public void onDisable() {
        this.keyHeldTicks = 0;
    }

    @Override
    public void onUpdate() {
        if (MinecraftMapper.getPlayer() == null) {
            return;
        }
        if (MinecraftMapper.getCurrentScreen() != null) {
            return;
        }
        int key = this.getKeyBind();
        if (key <= 0) {
            return;
        }
        boolean keyDown = Keyboard.isKeyDown((int)key);
        if (keyDown) {
            if (this.keyHeldTicks == 0 || this.keyHeldTicks >= this.speedThreshold()) {
                this.doLookTP();
                if (this.keyHeldTicks > 0) {
                    this.keyHeldTicks = 0;
                }
            }
            ++this.keyHeldTicks;
        } else {
            this.keyHeldTicks = 0;
        }
    }

    private void doLookTP() {
        try {
            Object player = MinecraftMapper.getPlayer();
            if (player == null) {
                return;
            }
            double x = MinecraftMapper.getPosX();
            double y = MinecraftMapper.getPosY();
            double z = MinecraftMapper.getPosZ();
            double blocks = this.blocksOption();
            float yaw = MinecraftMapper.getRotationYaw();
            float pitch = MinecraftMapper.getRotationPitch();
            double yawRad = Math.toRadians(yaw);
            double pitchRad = Math.toRadians(pitch);
            double dirX = -Math.sin(yawRad) * Math.cos(pitchRad);
            double dirY = -Math.sin(pitchRad);
            double dirZ = Math.cos(yawRad) * Math.cos(pitchRad);
            double newX = x + dirX * blocks;
            double newY = y + dirY * blocks;
            double newZ = z + dirZ * blocks;
            Method setPos = MappingUtils.getMethod("Entity.setPositionAndUpdate");
            if (setPos != null) {
                setPos.setAccessible(true);
                setPos.invoke(player, newX, newY, newZ);
            }
            MinecraftMapper.setMotionX(0.0);
            MinecraftMapper.setMotionY(0.0);
            MinecraftMapper.setMotionZ(0.0);
            MinecraftMapper.setFallDistance(0.0f);
            NotificationManager.info("LookTP", String.format("X: %.1f Y: %.1f Z: %.1f", newX, newY, newZ), 1500L);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Override
    public String getOptionPrefix() {
        double b = this.blocksOption();
        return b == Math.floor(b) ? String.valueOf((int)b) + "b" : String.format("%.1f", b) + "b";
    }
}

