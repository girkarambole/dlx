/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.ries.mapping.MinecraftMapper
 *  me.ries.module.Category
 *  me.ries.module.Module
 *  me.ries.setting.BooleanOption
 *  me.ries.setting.NumberOption
 *  me.ries.setting.OptionBase
 *  me.ries.util.BotTracker
 *  me.ries.util.Logger
 *  me.ries.util.MappingUtils
 *  org.lwjgl.input.Mouse
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.setting.OptionBase;
import me.ries.util.BotTracker;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;

public class AimBotModule
extends Module {
    private final NumberOption range = new NumberOption("Range", 7.0, 1.0, 10.0, 0.5, (Module)this);
    private final NumberOption speed = new NumberOption("Speed", 0.15, 0.05, 1.0, 0.05, (Module)this);
    private final BooleanOption onlyOnClick = new BooleanOption("OnClick", false, (Module)this);
    private final BooleanOption targetLock = new BooleanOption("TargetLock", false, (Module)this);
    private float lastYaw = 0.0f;
    private float lastPitch = 0.0f;
    private boolean initialized = false;
    private Object lockedTarget = null;

    public AimBotModule() {
        super("AimBot", "Aims at the nearest player", Category.COMBAT, 0);
        this.range.setGroup("Combat");
        this.speed.setGroup("Combat");
        this.onlyOnClick.setGroup("Combat");
        this.targetLock.setGroup("Combat");
        this.addOptions(new OptionBase[]{this.range, this.speed, this.onlyOnClick, this.targetLock});
    }

    public String getOptionPrefix() {
        double d = (Double)this.range.getValue();
        return d == Math.floor(d) ? String.valueOf((int)d) : String.format("%.1f", d);
    }

    public Object getLockedTarget() {
        return this.lockedTarget;
    }

    public void onEnable() {
        this.initialized = false;
        this.lockedTarget = null;
        Logger.info((String)"AimBot enabled");
    }

    public void onDisable() {
        this.initialized = false;
        this.lockedTarget = null;
        Logger.info((String)"AimBot disabled");
    }

    public void onUpdate() {
        Object object;
        if (this.isEnabled() && (object = this.getThePlayer()) != null && this.getTheWorld() != null) {
            Object object2;
            Object object3;
            try {
                object3 = MinecraftMapper.getPlayerEntitiesInWorld().iterator();
                while (object3.hasNext()) {
                    object2 = object3.next();
                    BotTracker.observe(object2);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (((Boolean)this.onlyOnClick.getValue()).booleanValue()) {
                try {
                    if (!Mouse.isButtonDown((int)0)) {
                        return;
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            if (this.getCurrentScreen() == null && (object3 = this.resolveTarget(object)) != null && (object2 = (Object)this.getRotationsTo(object, object3)) != null) {
                Object e = object2[0];
                float f = this.clamp((float)object2[1], -90.0f, 90.0f);
                if (!this.initialized) {
                    this.lastYaw = this.getPlayerYaw(object);
                    this.lastPitch = this.getPlayerPitch(object);
                    this.initialized = true;
                }
                float f2 = ((Double)this.speed.getValue()).floatValue();
                this.lastYaw = this.smoothAngle(this.lastYaw, (float)e, f2);
                this.lastPitch = this.smoothAngle(this.lastPitch, f, f2);
                this.setBodyRotation(object, this.lastYaw, this.lastPitch);
            }
        }
    }

    private Object resolveTarget(Object object) {
        double d = (Double)this.range.getValue();
        if (((Boolean)this.targetLock.getValue()).booleanValue()) {
            if (this.lockedTarget != null && this.isValidTarget(this.lockedTarget, object) && this.distanceTo(object, this.lockedTarget) <= d) {
                return this.lockedTarget;
            }
            if (this.lockedTarget != null) {
                this.initialized = false;
            }
            this.lockedTarget = null;
        }
        Object object2 = this.findNearest(object, d);
        if (((Boolean)this.targetLock.getValue()).booleanValue() && object2 != null) {
            this.lockedTarget = object2;
        }
        return object2;
    }

    private Object findNearest(Object object, double d) {
        Object var4_3 = null;
        double d2 = Double.MAX_VALUE;
        double d3 = d * d;
        try {
            Field field = MappingUtils.getField((String)"Entity.posX");
            Field field2 = MappingUtils.getField((String)"Entity.posY");
            Field field3 = MappingUtils.getField((String)"Entity.posZ");
            if (field == null || field2 == null || field3 == null) {
                return null;
            }
            field.setAccessible(true);
            field2.setAccessible(true);
            field3.setAccessible(true);
            double d4 = field.getDouble(object);
            double d5 = field2.getDouble(object);
            double d6 = field3.getDouble(object);
            for (Object e : MinecraftMapper.getPlayerEntitiesInWorld()) {
                double d7;
                double d8;
                double d9;
                double d10;
                if (!this.isValidTarget(e, object) || !((d10 = (d9 = field.getDouble(e) - d4) * d9 + (d8 = field2.getDouble(e) - d5) * d8 + (d7 = field3.getDouble(e) - d6) * d7) <= d3) || !(d10 < d2)) continue;
                d2 = d10;
                var4_3 = e;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return var4_3;
    }

    private boolean isValidTarget(Object object, Object object2) {
        if (object != null && object != object2) {
            Object object3;
            Object object4;
            if (!this.isValidCombatTarget(object)) {
                return false;
            }
            try {
                object4 = MappingUtils.getMethod((String)"Entity.getFlag");
                if (object4 != null) {
                    ((Method)object4).setAccessible(true);
                    object3 = ((Method)object4).invoke(object, 5);
                    if (object3 instanceof Boolean && ((Boolean)object3).booleanValue()) {
                        return false;
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            BotTracker.observe((Object)object);
            if (BotTracker.isBot((Object)object)) {
                return false;
            }
            if (BotTracker.isBotByHp((Object)object)) {
                return false;
            }
            try {
                object4 = MappingUtils.getField((String)"Entity.isDead");
                if (object4 == null) {
                    object4 = MappingUtils.getField((String)"Entity.dead");
                }
                if (object4 != null) {
                    ((Field)object4).setAccessible(true);
                    object3 = ((Field)object4).get(object);
                    if (object3 instanceof Boolean && ((Boolean)object3).booleanValue()) {
                        return false;
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            try {
                object4 = MappingUtils.getField((String)"Entity.dataWatcher");
                object3 = MappingUtils.getMethod((String)"DataWatcher.getFloat");
                if (object4 != null && object3 != null) {
                    float f;
                    Object object5;
                    ((Field)object4).setAccessible(true);
                    ((Method)object3).setAccessible(true);
                    Object object6 = ((Field)object4).get(object);
                    if (object6 != null && (object5 = ((Method)object3).invoke(object6, 25)) instanceof Number && (f = ((Number)object5).floatValue() / 571.875f) <= 0.0f) {
                        return false;
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            object4 = MinecraftMapper.getName((Object)object);
            if (object4 == null) {
                return false;
            }
            object3 = ((String)object4).replaceAll("\u00a7[0-9a-fk-or]", "").trim();
            return !((String)object3).isEmpty();
        }
        return false;
    }

    private float[] getRotationsTo(Object object, Object object2) {
        if (object != null && object2 != null) {
            double d = this.pos(object, "Entity.posX");
            double d2 = this.pos(object, "Entity.posY") + this.eyeH(object);
            double d3 = this.pos(object, "Entity.posZ");
            double d4 = this.pos(object2, "Entity.posX");
            double d5 = this.pos(object2, "Entity.posY") + this.eyeH(object2);
            double d6 = this.pos(object2, "Entity.posZ");
            double d7 = d4 - d;
            double d8 = d5 - d2;
            double d9 = d6 - d3;
            double d10 = Math.sqrt(d7 * d7 + d9 * d9);
            float f = (float)Math.toDegrees(Math.atan2(d9, d7)) - 90.0f;
            float f2 = (float)(-Math.toDegrees(Math.atan2(d8, d10)));
            return new float[]{f, f2};
        }
        return null;
    }

    private float smoothAngle(float f, float f2, float f3) {
        float f4;
        for (f4 = f2 - f; f4 > 180.0f; f4 -= 360.0f) {
        }
        while (f4 < -180.0f) {
            f4 += 360.0f;
        }
        return f + f4 * f3;
    }

    private float clamp(float f, float f2, float f3) {
        return Math.max(f2, Math.min(f3, f));
    }

    private float getPlayerYaw(Object object) {
        try {
            Field field = MappingUtils.getField((String)"Entity.rotationYaw");
            if (field != null) {
                field.setAccessible(true);
                return field.getFloat(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0.0f;
    }

    private float getPlayerPitch(Object object) {
        try {
            Field field = MappingUtils.getField((String)"Entity.rotationPitch");
            if (field != null) {
                field.setAccessible(true);
                return field.getFloat(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0.0f;
    }

    private void setBodyRotation(Object object, float f, float f2) {
        try {
            Field field = MappingUtils.getField((String)"Entity.rotationYaw");
            Field field2 = MappingUtils.getField((String)"Entity.rotationPitch");
            if (field != null) {
                field.setAccessible(true);
                field.setFloat(object, f);
            }
            if (field2 != null) {
                field2.setAccessible(true);
                field2.setFloat(object, f2);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private double distanceTo(Object object, Object object2) {
        if (object != null && object2 != null) {
            try {
                Method method = MappingUtils.getMethod((String)"Entity.getDistanceToEntity");
                if (method != null) {
                    method.setAccessible(true);
                    return ((Number)method.invoke(object, object2)).doubleValue();
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            double d = this.pos(object, "Entity.posX") - this.pos(object2, "Entity.posX");
            double d2 = this.pos(object, "Entity.posY") - this.pos(object2, "Entity.posY");
            double d3 = this.pos(object, "Entity.posZ") - this.pos(object2, "Entity.posZ");
            return Math.sqrt(d * d + d2 * d2 + d3 * d3);
        }
        return Double.MAX_VALUE;
    }

    private double pos(Object object, String string) {
        try {
            Field field = MappingUtils.getField((String)string);
            if (field != null) {
                field.setAccessible(true);
                return field.getDouble(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0.0;
    }

    private double eyeH(Object object) {
        try {
            Method method = MappingUtils.getMethod((String)"Entity.getEyeHeight");
            if (method != null) {
                method.setAccessible(true);
                return ((Number)method.invoke(object, new Object[0])).doubleValue();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 1.62;
    }

    private Object getCurrentScreen() {
        try {
            Object object = this.getMinecraft();
            Field field = MappingUtils.getField((String)"Minecraft.currentScreen");
            if (object != null && field != null) {
                field.setAccessible(true);
                return field.get(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }
}
