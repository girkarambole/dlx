/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package me.ries.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render3DEvent;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.opengl.GL11;

public class OreESPModule
extends Module {
    public static final Set<OreBlock> blocks = ConcurrentHashMap.newKeySet();
    private final BooleanOption realOresOnly = new BooleanOption("Anti-Obfuscator", false, (Module)this);
    private final BooleanOption showDiamond = new BooleanOption("Diamond", true, (Module)this);
    private final BooleanOption showGold = new BooleanOption("Gold", true, (Module)this);
    private final BooleanOption showEmerald = new BooleanOption("Emerald", true, (Module)this);
    private final BooleanOption showAmethyst = new BooleanOption("Amethyst", true, (Module)this);
    private final BooleanOption showLapis = new BooleanOption("Lapis", true, (Module)this);
    private final BooleanOption showRedstone = new BooleanOption("Redstone", true, (Module)this);
    private final BooleanOption showIron = new BooleanOption("Iron", true, (Module)this);
    private final BooleanOption showCoal = new BooleanOption("Coal", false, (Module)this);
    private final BooleanOption showQuartz = new BooleanOption("Quartz", false, (Module)this);
    private final NumberOption chunkCount = new NumberOption("Chunks", 9.0, 1.0, 60.0, 1.0, this);
    private final NumberOption lineWidth = new NumberOption("LineWidth", 2.0, 1.0, 5.0, 0.5, this);
    private Thread autoScanThread = null;
    private volatile boolean autoScanRunning = false;

    public OreESPModule() {
        super("OreESP", "Highlights mining ores through walls with 3D boxes and colors", Category.PLAYER, 0);
        this.addOptions(this.realOresOnly, this.showDiamond, this.showGold, this.showEmerald, this.showAmethyst, this.showLapis, this.showRedstone, this.showIron, this.showCoal, this.showQuartz, this.chunkCount, this.lineWidth);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    OreESPModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
    }

    @Override
    public void onEnable() {
        Logger.info("OreESP: ENABLED");
        blocks.clear();
        this.startAutoScan();
    }

    @Override
    public void onDisable() {
        Logger.info("OreESP: DISABLED");
        this.stopAutoScan();
        blocks.clear();
    }

    @Override
    public void onUpdate() {
        Object object;
        if (this.isEnabled() && !blocks.isEmpty() && (object = MappingUtils.getThePlayer()) != null) {
            double[] dArray = MappingUtils.getInterpolatedPos(object, 1.0f);
            double d = dArray[0];
            double d2 = dArray[1];
            double d3 = dArray[2];
            ArrayList<OreBlock> arrayList = new ArrayList<OreBlock>();
            for (OreBlock oreBlock : blocks) {
                int n;
                int n2;
                int n3;
                int n4;
                double d4 = oreBlock.x - d;
                double d5 = oreBlock.y - d2;
                double d6 = oreBlock.z - d3;
                if (!(d4 * d4 + d5 * d5 + d6 * d6 <= 2048.0) || (n4 = this.getBlockIdAt(n3 = (int)Math.floor(oreBlock.x), n2 = (int)Math.floor(oreBlock.y), n = (int)Math.floor(oreBlock.z))) == oreBlock.id) continue;
                arrayList.add(oreBlock);
            }
            if (!arrayList.isEmpty()) {
                blocks.removeAll(arrayList);
            }
        }
    }

    private void startAutoScan() {
        this.stopAutoScan();
        this.autoScanRunning = true;
        this.autoScanThread = new Thread(() -> {
            while (this.autoScanRunning && this.isEnabled()) {
                try {
                    Object object = MappingUtils.getThePlayer();
                    if (object != null) {
                        double[] dArray = MappingUtils.getInterpolatedPos(object, 1.0f);
                        int n = (int)Math.floor(dArray[0]) >> 4;
                        int n2 = (int)Math.floor(dArray[2]) >> 4;
                        this.performAutoScan(n, n2, (int)Math.floor(dArray[1]));
                    }
                    Thread.sleep(200L);
                }
                catch (InterruptedException interruptedException) {
                    break;
                }
                catch (Throwable throwable) {
                }
            }
        }, "OreESP-AutoScanner");
        this.autoScanThread.setDaemon(true);
        this.autoScanThread.start();
    }

    private void stopAutoScan() {
        this.autoScanRunning = false;
        if (this.autoScanThread != null) {
            this.autoScanThread.interrupt();
            this.autoScanThread = null;
        }
    }

    private void performAutoScan(int n, int n2, int n3) {
        int n4;
        int n5;
        int n6 = ((Double)this.chunkCount.getValue()).intValue();
        ArrayList<ChunkOffset> arrayList = new ArrayList<ChunkOffset>();
        int n7 = (int)Math.ceil(Math.sqrt(n6));
        for (n5 = -n7; n5 <= n7; ++n5) {
            for (n4 = -n7; n4 <= n7; ++n4) {
                arrayList.add(new ChunkOffset(n5, n4));
            }
        }
        arrayList.sort((chunkOffset, chunkOffset2) -> Double.compare(chunkOffset.dist, chunkOffset2.dist));
        n5 = Math.min(n6, arrayList.size());
        try {
            for (n4 = 0; n4 < n5; ++n4) {
                ChunkOffset chunkOffset3 = (ChunkOffset)arrayList.get(n4);
                if (!this.autoScanRunning || !this.isEnabled() || MappingUtils.getThePlayer() == null) {
                    return;
                }
                int n8 = n + chunkOffset3.dx;
                int n9 = n2 + chunkOffset3.dz;
                int n10 = n8 * 16;
                int n11 = n9 * 16;
                for (int i = 0; i < 16; ++i) {
                    int n12 = n10 + i;
                    for (int j = 0; j < 16; ++j) {
                        int n13 = n11 + j;
                        for (int k = 255; k >= 0; --k) {
                            float[] fArray;
                            int n14 = this.getBlockIdAt(n12, k, n13);
                            if (n14 == 0 || (fArray = this.getOreColor(n14)) == null || ((Boolean)this.realOresOnly.getValue()).booleanValue() && !this.isExposed(n12, k, n13)) continue;
                            this.addBlock(n12, k, n13, n14, fArray);
                        }
                    }
                }
                Thread.sleep(2L);
            }
        }
        catch (InterruptedException interruptedException) {
            // empty catch block
        }
    }

    private void addBlock(int n, int n2, int n3, int n4, float[] fArray) {
        OreBlock oreBlock = new OreBlock((double)n + 0.5, n2, (double)n3 + 0.5, n4, fArray);
        blocks.add(oreBlock);
    }

    private boolean isExposed(int n, int n2, int n3) {
        int[][] nArrayArray;
        for (int[] nArray : nArrayArray = new int[][]{{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}}) {
            int n4 = this.getBlockIdAt(n + nArray[0], n2 + nArray[1], n3 + nArray[2]);
            if (n4 != 0 && n4 != 8 && n4 != 9 && n4 != 10 && n4 != 11) continue;
            return true;
        }
        return false;
    }

    private float[] getOreColor(int n) {
        if (n == 56 && !((Boolean)this.showDiamond.getValue()).booleanValue()) {
            return null;
        }
        if (n == 129 && !((Boolean)this.showEmerald.getValue()).booleanValue()) {
            return null;
        }
        if (n == 14 && !((Boolean)this.showGold.getValue()).booleanValue()) {
            return null;
        }
        if (n == 557 && !((Boolean)this.showAmethyst.getValue()).booleanValue()) {
            return null;
        }
        if (n == 21 && !((Boolean)this.showLapis.getValue()).booleanValue()) {
            return null;
        }
        if (!(n != 73 && n != 74 || ((Boolean)this.showRedstone.getValue()).booleanValue())) {
            return null;
        }
        if (n == 15 && !((Boolean)this.showIron.getValue()).booleanValue()) {
            return null;
        }
        if (n == 16 && !((Boolean)this.showCoal.getValue()).booleanValue()) {
            return null;
        }
        if (n == 153 && !((Boolean)this.showQuartz.getValue()).booleanValue()) {
            return null;
        }
        switch (n) {
            case 14: {
                return new float[]{1.0f, 0.85f, 0.0f};
            }
            case 15: {
                return new float[]{0.7f, 0.7f, 0.7f};
            }
            case 16: {
                return new float[]{0.25f, 0.25f, 0.25f};
            }
            case 21: {
                return new float[]{0.1f, 0.4f, 1.0f};
            }
            case 56: {
                return new float[]{0.0f, 0.9f, 1.0f};
            }
            case 73: 
            case 74: {
                return new float[]{1.0f, 0.15f, 0.15f};
            }
            case 129: {
                return new float[]{0.0f, 1.0f, 0.2f};
            }
            case 153: {
                return new float[]{0.95f, 0.95f, 0.95f};
            }
            case 557: {
                return new float[]{0.6f, 0.2f, 0.8f};
            }
        }
        return null;
    }

    private int getBlockIdAt(int n, int n2, int n3) {
        Object object;
        Object object2;
        Object object3;
        Method method;
        Object object4;
        Object object5;
        try {
            object5 = MappingUtils.getWorldObj();
            if (object5 != null) {
                object4 = MappingUtils.getMethod("World.getChunkFromChunkCoords");
                method = MappingUtils.getMethod("Chunk.getBlock");
                object3 = MappingUtils.getMethod("Block.getIdFromBlock");
                if (object4 != null && method != null && object3 != null) {
                    ((Method)object4).setAccessible(true);
                    method.setAccessible(true);
                    ((Method)object3).setAccessible(true);
                    object2 = ((Method)object4).invoke(object5, n >> 4, n3 >> 4);
                    if (object2 != null && (object = method.invoke(object2, n & 0xF, n2, n3 & 0xF)) != null) {
                        return (Integer)((Method)object3).invoke(null, object);
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            object5 = MappingUtils.getWorldObj();
            if (object5 != null && (object4 = this.createBlockPos(n, n2, n3)) != null && (method = MappingUtils.getMethod("World.getBlockState")) != null) {
                method.setAccessible(true);
                object3 = method.invoke(object5, object4);
                if (object3 != null) {
                    object2 = MappingUtils.getMethod("IBlockState.getBlock");
                    object = MappingUtils.getMethod("Block.getIdFromBlock");
                    if (object2 != null && object != null) {
                        ((Method)object2).setAccessible(true);
                        ((Method)object).setAccessible(true);
                        Object object6 = ((Method)object2).invoke(object3, new Object[0]);
                        if (object6 != null) {
                            return (Integer)((Method)object).invoke(null, object6);
                        }
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0;
    }

    private Object createBlockPos(int n, int n2, int n3) {
        try {
            Class<?> clazz = MappingUtils.get("BlockPos");
            if (clazz == null) {
                return null;
            }
            Constructor<?> constructor = clazz.getConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE);
            constructor.setAccessible(true);
            return constructor.newInstance(n, n2, n3);
        }
        catch (Throwable throwable) {
            try {
                Class<?> clazz = MappingUtils.get("BlockPos");
                Constructor<?> constructor = clazz.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);
                constructor.setAccessible(true);
                return constructor.newInstance(n, n2, n3);
            }
            catch (Throwable throwable2) {
                return null;
            }
        }
    }

    private void onRender3D(float f) {
        if (this.isEnabled() && !blocks.isEmpty()) {
            try {
                Object object = MappingUtils.getThePlayer();
                if (object == null) {
                    return;
                }
                double d = MappingUtils.getRenderPosX();
                double d2 = MappingUtils.getRenderPosY();
                double d3 = MappingUtils.getRenderPosZ();
                GL11.glPushMatrix();
                GL11.glPushAttrib((int)1048575);
                GL11.glDisable((int)3553);
                GL11.glDisable((int)2896);
                GL11.glDisable((int)2929);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glEnable((int)2848);
                GL11.glHint((int)3154, (int)4354);
                float f2 = ((Double)this.lineWidth.getValue()).floatValue();
                GL11.glLineWidth((float)f2);
                for (OreBlock oreBlock : blocks) {
                    double d4 = oreBlock.x - d;
                    double d5 = oreBlock.y - d2;
                    double d6 = oreBlock.z - d3;
                    float[] fArray = oreBlock.color;
                    if (fArray == null) continue;
                    GL11.glColor4f((float)fArray[0], (float)fArray[1], (float)fArray[2], (float)0.9f);
                    this.draw3DOreBox(d4, d5, d6);
                }
                GL11.glPopAttrib();
                GL11.glPopMatrix();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void draw3DOreBox(double d, double d2, double d3) {
        double d4 = d - 0.5;
        double d5 = d + 0.5;
        double d6 = d2 + 1.0;
        double d7 = d3 - 0.5;
        double d8 = d3 + 0.5;
        GL11.glBegin((int)1);
        GL11.glVertex3d((double)d4, (double)d2, (double)d7);
        GL11.glVertex3d((double)d5, (double)d2, (double)d7);
        GL11.glVertex3d((double)d5, (double)d2, (double)d7);
        GL11.glVertex3d((double)d5, (double)d2, (double)d8);
        GL11.glVertex3d((double)d5, (double)d2, (double)d8);
        GL11.glVertex3d((double)d4, (double)d2, (double)d8);
        GL11.glVertex3d((double)d4, (double)d2, (double)d8);
        GL11.glVertex3d((double)d4, (double)d2, (double)d7);
        GL11.glVertex3d((double)d4, (double)d6, (double)d7);
        GL11.glVertex3d((double)d5, (double)d6, (double)d7);
        GL11.glVertex3d((double)d5, (double)d6, (double)d7);
        GL11.glVertex3d((double)d5, (double)d6, (double)d8);
        GL11.glVertex3d((double)d5, (double)d6, (double)d8);
        GL11.glVertex3d((double)d4, (double)d6, (double)d8);
        GL11.glVertex3d((double)d4, (double)d6, (double)d8);
        GL11.glVertex3d((double)d4, (double)d6, (double)d7);
        GL11.glVertex3d((double)d4, (double)d2, (double)d7);
        GL11.glVertex3d((double)d4, (double)d6, (double)d7);
        GL11.glVertex3d((double)d5, (double)d2, (double)d7);
        GL11.glVertex3d((double)d5, (double)d6, (double)d7);
        GL11.glVertex3d((double)d5, (double)d2, (double)d8);
        GL11.glVertex3d((double)d5, (double)d6, (double)d8);
        GL11.glVertex3d((double)d4, (double)d2, (double)d8);
        GL11.glVertex3d((double)d4, (double)d6, (double)d8);
        GL11.glEnd();
    }

    public static class OreBlock {
        public final double x;
        public final double y;
        public final double z;
        public final int id;
        public final float[] color;

        public OreBlock(double d, double d2, double d3, int n, float[] fArray) {
            this.x = d;
            this.y = d2;
            this.z = d3;
            this.id = n;
            this.color = fArray;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (!(object instanceof OreBlock)) {
                return false;
            }
            OreBlock oreBlock = (OreBlock)object;
            return Double.compare(oreBlock.x, this.x) == 0 && Double.compare(oreBlock.y, this.y) == 0 && Double.compare(oreBlock.z, this.z) == 0;
        }

        public int hashCode() {
            long l = Double.doubleToLongBits(this.x);
            l ^= Double.doubleToLongBits(this.y) * 31L;
            return (int)((l ^= Double.doubleToLongBits(this.z) * 31L) ^ l >>> 32);
        }
    }

    private static class ChunkOffset {
        final int dx;
        final int dz;
        final double dist;

        ChunkOffset(int n, int n2) {
            this.dx = n;
            this.dz = n2;
            this.dist = n * n + n2 * n2;
        }
    }
}

