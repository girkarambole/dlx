/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.GLU
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.nio.Buffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Map;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render2DEvent;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.FriendManagerModule;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.BotTracker;
import me.ries.util.FontUtil;
import me.ries.util.GLErrorChecker;
import me.ries.util.MappingUtils;
import me.ries.util.ScissorUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public class EspModule
extends Module {
    private final StringOption mode = new StringOption("Mode", "2D", this, "2D", "3D");
    private final NumberOption range = new NumberOption("Range", 128.0, 16.0, 512.0, 16.0, this);
    private final BooleanOption box = new BooleanOption("Box", true, (Module)this);
    private final BooleanOption scanLine = new BooleanOption("ScanLine", true, (Module)this);
    private final BooleanOption tracers = new BooleanOption("Tracers", false, (Module)this);
    private final BooleanOption healthBar = new BooleanOption("HealthBar", true, (Module)this);
    private final BooleanOption showNames = new BooleanOption("Names", true, (Module)this);
    private final BooleanOption showItems = new BooleanOption("Items", true, (Module)this);
    private final NumberOption opacity = new NumberOption("Opacity", 0.85, 0.1, 1.0, 0.05, this);
    private final NumberOption lineWidth = new NumberOption("LineWidth", 1.0, 0.5, 3.0, 0.5, this);
    private static final float VIS_WHITE = 0.96f;
    private static final float VIS_LIGHT = 0.78f;
    private static final float VIS_MID = 0.52f;
    private static final float VIS_DARK = 0.1f;
    private static final float FRIEND_R = 0.2f;
    private static final float FRIEND_G = 0.9f;
    private static final float FRIEND_B = 0.35f;
    private static final float ECLIPSE_R = 0.58f;
    private static final float ECLIPSE_G = 0.25f;
    private static final float ECLIPSE_B = 0.84f;
    private static final int COLOR_NORMAL = 0;
    private static final int COLOR_FRIEND = 1;
    private static final int COLOR_ECLIPSE = 2;
    private static final float PLAYER_HALF_W = 0.42f;
    private static final float PLAYER_HALF_D = 0.42f;
    private static final float PLAYER_HEIGHT = 1.8f;
    private static final float SCAN_CYCLE_MS = 2600.0f;
    private final FloatBuffer modelView = BufferUtils.createFloatBuffer((int)16);
    private final FloatBuffer projection = BufferUtils.createFloatBuffer((int)16);
    private final IntBuffer viewport = BufferUtils.createIntBuffer((int)16);
    private boolean matricesCached = false;

    public EspModule() {
        super("ESP", "Renders entities through walls", Category.RENDER, 0);
        this.mode.setGroup("General");
        this.range.setGroup("General");
        this.box.setGroup("Elements");
        this.scanLine.setGroup("Elements");
        this.tracers.setGroup("Elements");
        this.healthBar.setGroup("Elements");
        this.showNames.setGroup("Elements");
        this.showItems.setGroup("Elements");
        this.opacity.setGroup("Style");
        this.lineWidth.setGroup("Style");
        this.addOptions(this.mode, this.range, this.box, this.scanLine, this.tracers, this.healthBar, this.showNames, this.showItems, this.opacity, this.lineWidth);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    EspModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
        Ries.getInstance().getEventBus().subscribe(Render2DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render2DEvent) {
                    EspModule.this.onRender2D(((Render2DEvent)event).getPartialTicks());
                }
            }
        });
    }

    private static boolean isValidEspTarget(Object entity) {
        Object v;
        Field f2;
        String name2;
        if (entity == null) {
            return false;
        }
        try {
            Object p = MappingUtils.getThePlayer();
            if (entity.equals(p)) {
                return false;
            }
        }
        catch (Throwable p) {
            // empty catch block
        }
        try {
            String clean;
            name2 = MappingUtils.getName(entity);
            if (name2 != null && ((clean = name2.replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim()).startsWith("[CR]") || clean.matches(".*[\\[\\]].*"))) {
                return false;
            }
        }
        catch (Throwable name2) {
            // empty catch block
        }
        try {
            f2 = MappingUtils.getField("Entity.isInvisible");
            if (f2 == null) {
                f2 = MappingUtils.getField("Entity.invisible");
            }
            if (f2 != null) {
                f2.setAccessible(true);
                v = f2.get(entity);
                if (v instanceof Boolean && ((Boolean)v).booleanValue()) {
                    return false;
                }
            }
        }
        catch (Throwable f2) {
            // empty catch block
        }
        if (BotTracker.isBot(entity)) {
            return false;
        }
        BotTracker.observe(entity);
        if (BotTracker.isBotByHp(entity)) {
            return false;
        }
        try {
            f2 = MappingUtils.getField("Entity.isDead");
            if (f2 == null) {
                f2 = MappingUtils.getField("Entity.dead");
            }
            if (f2 != null) {
                f2.setAccessible(true);
                v = f2.get(entity);
                if (v instanceof Boolean && ((Boolean)v).booleanValue()) {
                    return false;
                }
            }
        }
        catch (Throwable f3) {
            // empty catch block
        }
        if (MappingUtils.getEntityHealth(entity) <= 0.0f) {
            return false;
        }
        try {
            name2 = MappingUtils.getName(entity);
            if (name2 == null || name2.replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim().isEmpty()) {
                return false;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return true;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
        this.matricesCached = false;
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public String getOptionPrefix() {
        return (String)this.mode.getValue();
    }

    public void onRender3D(float partialTicks) {
        if (this.isEnabled()) {
            Object[] entities;
            ((Buffer)this.modelView).clear();
            ((Buffer)this.projection).clear();
            ((Buffer)this.viewport).clear();
            GL11.glGetFloat((int)2982, (FloatBuffer)this.modelView);
            GL11.glGetFloat((int)2983, (FloatBuffer)this.projection);
            GL11.glGetInteger((int)2978, (IntBuffer)this.viewport);
            this.matricesCached = true;
            if ("3D".equals(this.mode.getValue()) && (entities = MappingUtils.getPlayerEntitiesInWorld()) != null && entities.length != 0) {
                double camX = MappingUtils.getRenderPosX();
                double camY = MappingUtils.getRenderPosY();
                double camZ = MappingUtils.getRenderPosZ();
                double rangeVal = (Double)this.range.getValue();
                double rangeSq = rangeVal * rangeVal;
                GLErrorChecker.clear();
                this.pushVisualState();
                GL11.glPushMatrix();
                GLErrorChecker.check("EspModule.onRender3D init");
                for (Object entity : entities) {
                    if (!EspModule.isValidEspTarget(entity)) continue;
                    try {
                        double[] pos = MappingUtils.getInterpolatedPos(entity, partialTicks);
                        double dx = pos[0] - camX;
                        double dy = pos[1] - camY;
                        double dz = pos[2] - camZ;
                        double distSq = dx * dx + dy * dy + dz * dz;
                        if (distSq > rangeSq) continue;
                        float alpha = this.distAlpha(Math.sqrt(distSq), rangeVal);
                        float health = MappingUtils.getEntityHealth(entity);
                        int colorType = this.getColorType(entity);
                        if (((Boolean)this.tracers.getValue()).booleanValue()) {
                            this.drawTracer3D(dx, dy, dz, entity, alpha, colorType);
                        }
                        GL11.glPushMatrix();
                        GL11.glTranslated((double)dx, (double)dy, (double)dz);
                        GL11.glRotatef((float)(-MappingUtils.getYaw(entity)), (float)0.0f, (float)1.0f, (float)0.0f);
                        if (((Boolean)this.box.getValue()).booleanValue()) {
                            this.drawMinimalBox(alpha, colorType);
                        }
                        if (((Boolean)this.scanLine.getValue()).booleanValue()) {
                            this.drawScanLine(entity, alpha);
                        }
                        if (((Boolean)this.healthBar.getValue()).booleanValue()) {
                            this.drawMonoHealthBar(health, alpha);
                        }
                        GL11.glPopMatrix();
                        if (((Boolean)this.showNames.getValue()).booleanValue()) {
                            this.drawNameTag3D(entity, dx, dy, dz, alpha);
                        }
                        GLErrorChecker.check("EspModule.onRender3D entity");
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
                GL11.glPopMatrix();
                GL11.glPopAttrib();
                GLErrorChecker.check("EspModule.onRender3D end");
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void onRender2D(float partialTicks) {
        Object[] entities;
        if (this.isEnabled() && "2D".equals(this.mode.getValue()) && this.matricesCached && (entities = MappingUtils.getPlayerEntitiesInWorld()) != null && entities.length != 0) {
            double camX = MappingUtils.getRenderPosX();
            double camY = MappingUtils.getRenderPosY();
            double camZ = MappingUtils.getRenderPosZ();
            double rangeVal = (Double)this.range.getValue();
            double rangeSq = rangeVal * rangeVal;
            float lw = ((Double)this.lineWidth.getValue()).floatValue();
            float sw = ScissorUtil.getScaledWidth();
            float sh = ScissorUtil.getScaledHeight();
            GLErrorChecker.clear();
            GL11.glPushAttrib((int)1048575);
            GL11.glPushMatrix();
            GL11.glDisable((int)3553);
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glDisable((int)2929);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            GLErrorChecker.check("EspModule.onRender2D init");
            try {
                for (Object entity : entities) {
                    if (!EspModule.isValidEspTarget(entity)) continue;
                    try {
                        float[] b;
                        double[] pos = MappingUtils.getInterpolatedPos(entity, partialTicks);
                        double dx = pos[0] - camX;
                        double dy = pos[1] - camY;
                        double dz = pos[2] - camZ;
                        if (dx * dx + dy * dy + dz * dz > rangeSq || (b = this.projectEntityBounds(pos[0], pos[1], pos[2])) == null) continue;
                        float left = b[0];
                        float top = b[1];
                        float right = b[2];
                        float bottom = b[3];
                        if (right < 0.0f || left > sw || bottom < 0.0f || top > sh) continue;
                        float alpha = this.distAlpha(Math.sqrt(dx * dx + dy * dy + dz * dz), rangeVal);
                        float dist = (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
                        float health = MappingUtils.getEntityHealth(entity);
                        int colorType = this.getColorType(entity);
                        if (((Boolean)this.tracers.getValue()).booleanValue()) {
                            this.drawTracer2D(left, top, right, bottom, sw, sh, alpha, lw, colorType);
                        }
                        if (((Boolean)this.box.getValue()).booleanValue()) {
                            this.drawBox2D(left, top, right, bottom, alpha, lw, colorType);
                        }
                        if (((Boolean)this.healthBar.getValue()).booleanValue()) {
                            this.drawHealthBar2D(health, right, top, bottom, alpha, lw, dist, rangeVal);
                        }
                        if (((Boolean)this.showNames.getValue()).booleanValue()) {
                            this.drawNameTag2D(entity, left, top, right, alpha);
                        }
                        if (((Boolean)this.showItems.getValue()).booleanValue()) {
                            this.drawItemInfo2D(entity, left, top, right, bottom, alpha);
                        }
                        GLErrorChecker.check("EspModule.onRender2D entity");
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
            }
            finally {
                GL11.glPopMatrix();
                GL11.glPopAttrib();
                GLErrorChecker.check("EspModule.onRender2D end");
            }
        }
    }

    private float[] projectEntityBounds(double ex, double ey, double ez) {
        float[] fArray;
        float minX = Float.MAX_VALUE;
        float minY = Float.MAX_VALUE;
        float maxX = -3.4028235E38f;
        float maxY = -3.4028235E38f;
        int valid = 0;
        for (int i = 0; i < 8; ++i) {
            double oz;
            double oy;
            double ox = (i & 1) == 0 ? (double)-0.42f : (double)0.42f;
            float[] s = this.projectToScreen(ex + ox, ey + (oy = (i & 2) == 0 ? 0.0 : (double)1.8f), ez + (oz = (i & 4) == 0 ? (double)-0.42f : (double)0.42f));
            if (s == null || s[2] >= 1.0f) continue;
            ++valid;
            if (s[0] < minX) {
                minX = s[0];
            }
            if (s[1] < minY) {
                minY = s[1];
            }
            if (s[0] > maxX) {
                maxX = s[0];
            }
            if (!(s[1] > maxY)) continue;
            maxY = s[1];
        }
        if (valid >= 2) {
            float[] fArray2 = new float[4];
            fArray2[0] = minX;
            fArray2[1] = minY;
            fArray2[2] = maxX;
            fArray = fArray2;
            fArray2[3] = maxY;
        } else {
            fArray = null;
        }
        return fArray;
    }

    private float[] projectToScreen(double wx, double wy, double wz) {
        FloatBuffer mv = BufferUtils.createFloatBuffer((int)16);
        ((Buffer)this.modelView).rewind();
        mv.put(this.modelView);
        ((Buffer)mv).rewind();
        double camX = MappingUtils.getRenderPosX();
        double camY = MappingUtils.getRenderPosY();
        double camZ = MappingUtils.getRenderPosZ();
        float m00 = mv.get(0);
        float m01 = mv.get(1);
        float m02 = mv.get(2);
        float m03 = mv.get(3);
        float m10 = mv.get(4);
        float m11 = mv.get(5);
        float m12 = mv.get(6);
        float m13 = mv.get(7);
        float m20 = mv.get(8);
        float m21 = mv.get(9);
        float m22 = mv.get(10);
        float m23 = mv.get(11);
        float m30 = mv.get(12);
        float m31 = mv.get(13);
        float m32 = mv.get(14);
        float m33 = mv.get(15);
        float tx = (float)(-camX * (double)m00 - camY * (double)m10 - camZ * (double)m20 + (double)m30);
        float ty = (float)(-camX * (double)m01 - camY * (double)m11 - camZ * (double)m21 + (double)m31);
        float tz = (float)(-camX * (double)m02 - camY * (double)m12 - camZ * (double)m22 + (double)m32);
        float tw = (float)(-camX * (double)m03 - camY * (double)m13 - camZ * (double)m23 + (double)m33);
        mv.put(12, tx);
        mv.put(13, ty);
        mv.put(14, tz);
        mv.put(15, tw);
        ((Buffer)mv).rewind();
        FloatBuffer win = BufferUtils.createFloatBuffer((int)3);
        ((Buffer)this.projection).rewind();
        ((Buffer)this.viewport).rewind();
        if (!GLU.gluProject((float)((float)wx), (float)((float)wy), (float)((float)wz), (FloatBuffer)mv, (FloatBuffer)this.projection, (IntBuffer)this.viewport, (FloatBuffer)win)) {
            return null;
        }
        int scale = ScissorUtil.getScaleFactor();
        float screenX = win.get(0) / (float)scale;
        float screenY = ((float)Display.getHeight() - win.get(1)) / (float)scale;
        float screenZ = win.get(2);
        return new float[]{screenX, screenY, screenZ};
    }

    private void drawBox2D(float left, float top, float right, float bottom, float alpha, float lw, int colorType) {
        float w = right - left;
        float h = bottom - top;
        float arm = Math.max(4.0f, Math.min(w, h) * 0.2f);
        GL11.glLineWidth((float)(lw * 1.1f + 1.5f));
        GL11.glBegin((int)1);
        GL11.glColor4f((float)0.0f, (float)0.0f, (float)0.0f, (float)(alpha * 0.8f));
        this.drawCorner2D(left, top, arm, 1.0f, 1.0f);
        this.drawCorner2D(right, top, arm, -1.0f, 1.0f);
        this.drawCorner2D(left, bottom, arm, 1.0f, -1.0f);
        this.drawCorner2D(right, bottom, arm, -1.0f, -1.0f);
        GL11.glEnd();
        GL11.glLineWidth((float)(lw * 1.1f));
        GL11.glBegin((int)1);
        if (colorType == 1) {
            this.glFriend(0.9f, alpha);
        } else if (colorType == 2) {
            this.glEclipse(0.9f, alpha);
        } else {
            this.glMono(0.96f, alpha);
        }
        this.drawCorner2D(left, top, arm, 1.0f, 1.0f);
        this.drawCorner2D(right, top, arm, -1.0f, 1.0f);
        this.drawCorner2D(left, bottom, arm, 1.0f, -1.0f);
        this.drawCorner2D(right, bottom, arm, -1.0f, -1.0f);
        GL11.glEnd();
    }

    private void drawCorner2D(float cx, float cy, float arm, float sx, float sy) {
        GL11.glVertex2f((float)cx, (float)cy);
        GL11.glVertex2f((float)(cx + sx * arm), (float)cy);
        GL11.glVertex2f((float)cx, (float)cy);
        GL11.glVertex2f((float)cx, (float)(cy + sy * arm));
    }

    private void drawHealthBar2D(float health, float right, float top, float bottom, float alpha, float lw, float dist, double rangeVal) {
        float hp = Math.max(0.0f, Math.min(1.0f, health / 20.0f));
        float distT = (float)Math.max(0.0, Math.min(1.0, (double)dist / rangeVal));
        float barW = 3.0f - distT * 1.8f;
        float barX = right + 2.0f + distT;
        float barH = bottom - top;
        if (!(barH < 2.0f)) {
            GL11.glBegin((int)7);
            this.glMono(0.1f, alpha * 0.55f);
            GL11.glVertex2f((float)barX, (float)top);
            GL11.glVertex2f((float)barX, (float)bottom);
            GL11.glVertex2f((float)(barX + barW), (float)bottom);
            GL11.glVertex2f((float)(barX + barW), (float)top);
            if (hp > 0.01f) {
                float fillTop = bottom - barH * hp;
                this.glMono(0.96f, alpha * 0.82f);
                GL11.glVertex2f((float)barX, (float)fillTop);
                GL11.glVertex2f((float)barX, (float)bottom);
                GL11.glVertex2f((float)(barX + barW), (float)bottom);
                GL11.glVertex2f((float)(barX + barW), (float)fillTop);
            }
            GL11.glEnd();
            GL11.glLineWidth((float)(lw * 0.6f + 1.0f));
            GL11.glBegin((int)2);
            GL11.glColor4f((float)0.0f, (float)0.0f, (float)0.0f, (float)(alpha * 0.8f));
            GL11.glVertex2f((float)barX, (float)top);
            GL11.glVertex2f((float)barX, (float)bottom);
            GL11.glVertex2f((float)(barX + barW), (float)bottom);
            GL11.glVertex2f((float)(barX + barW), (float)top);
            GL11.glEnd();
            GL11.glLineWidth((float)(lw * 0.6f));
            GL11.glBegin((int)2);
            this.glMono(0.52f, alpha * 0.4f);
            GL11.glVertex2f((float)barX, (float)top);
            GL11.glVertex2f((float)barX, (float)bottom);
            GL11.glVertex2f((float)(barX + barW), (float)bottom);
            GL11.glVertex2f((float)(barX + barW), (float)top);
            GL11.glEnd();
        }
    }

    private void drawNameTag2D(Object entity, float left, float top, float right, float alpha) {
        String name = MappingUtils.getName(entity);
        if (!(name == null || name.isEmpty() || name.equals("?") || (name = name.replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim()).isEmpty())) {
            float scale = 0.55f;
            float textW = (float)FontUtil.getStringWidth(name) * scale;
            float x = (left + right) * 0.5f - textW * 0.5f;
            float y = top - (float)FontUtil.getFontHeight() * scale - 2.0f;
            float textAlpha = ((Double)this.opacity.getValue()).floatValue();
            int color = (int)(textAlpha * 240.0f) << 24 | 0xF2F2F4;
            GL11.glEnable((int)3553);
            GL11.glPushMatrix();
            GL11.glTranslatef((float)x, (float)y, (float)0.0f);
            GL11.glScalef((float)scale, (float)scale, (float)1.0f);
            FontUtil.drawString(name, 0.0f, 0.0f, color, true);
            GL11.glPopMatrix();
            GL11.glDisable((int)3553);
        }
    }

    private void drawNameTag3D(Object entity, double dx, double dy, double dz, float alpha) {
        String name = MappingUtils.getName(entity);
        if (!(name == null || name.isEmpty() || name.equals("?") || (name = name.replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim()).isEmpty())) {
            GL11.glPushMatrix();
            GL11.glTranslated((double)dx, (double)(dy + 2.0), (double)dz);
            float yaw = MinecraftMapper.getRotationYaw();
            float pitch = MinecraftMapper.getRotationPitch();
            GL11.glRotatef((float)(-yaw), (float)0.0f, (float)1.0f, (float)0.0f);
            GL11.glRotatef((float)pitch, (float)1.0f, (float)0.0f, (float)0.0f);
            float scale = 0.025f;
            GL11.glScalef((float)(-scale), (float)(-scale), (float)scale);
            float textW = FontUtil.getStringWidth(name);
            float x = -textW * 0.5f;
            float y = 0.0f;
            float textAlpha = ((Double)this.opacity.getValue()).floatValue() * alpha;
            int color = (int)(textAlpha * 255.0f) << 24 | 0xFFFFFF;
            GL11.glEnable((int)3553);
            FontUtil.drawString(name, x, y, color, true);
            GL11.glDisable((int)3553);
            GL11.glPopMatrix();
        }
    }

    private void drawItemInfo2D(Object entity, float left, float top, float right, float bottom, float alpha) {
        if (!(alpha < 0.15f)) {
            String label;
            Object held;
            float scale = 0.46f;
            float lineH = (float)FontUtil.getFontHeight() * scale + 1.5f;
            float textAlpha = ((Double)this.opacity.getValue()).floatValue();
            int color = (int)(textAlpha * 240.0f) << 24 | 0xEEEEF0;
            int armorCol = (int)(textAlpha * 210.0f) << 24 | 0xCCCCCF;
            GL11.glEnable((int)3553);
            Object[] armor = MappingUtils.getArmorContents(entity);
            if (armor != null && !this.allNull(armor)) {
                int[] order = new int[]{3, 2, 1, 0};
                float armorX = right + 4.0f;
                float boxH = bottom - top;
                int nonNull = 0;
                for (int idx : order) {
                    if (idx >= armor.length || armor[idx] == null) continue;
                    ++nonNull;
                }
                float slotStep = nonNull > 1 ? boxH / (float)(nonNull - 1) : 0.0f;
                float slotY = top;
                for (int idx : order) {
                    if (idx >= armor.length || armor[idx] == null) continue;
                    String enchs = this.buildEnchSummary(armor[idx]);
                    if (enchs != null && !enchs.isEmpty()) {
                        float fh = (float)FontUtil.getFontHeight() * scale;
                        GL11.glPushMatrix();
                        GL11.glTranslatef((float)armorX, (float)(slotY - fh * 0.5f), (float)0.0f);
                        GL11.glScalef((float)scale, (float)scale, (float)1.0f);
                        FontUtil.drawString(enchs, 0.0f, 0.0f, armorCol, true);
                        GL11.glPopMatrix();
                        slotY += slotStep;
                        continue;
                    }
                    slotY += slotStep;
                }
            }
            if ((held = MappingUtils.getHeldItem(entity)) != null && (label = this.buildItemLabel(held)) != null && !label.isEmpty()) {
                float boxWidth = right - left;
                float centerX = (left + right) * 0.5f;
                float curY = bottom + 2.0f;
                this.drawCenteredText(label, centerX, curY, scale, boxWidth, color);
            }
            GL11.glDisable((int)3553);
        }
    }

    private String buildEnchSummary(Object itemStack) {
        if (itemStack == null) {
            return null;
        }
        Map<Integer, Integer> enchs = MappingUtils.getEnchantments(itemStack);
        if (enchs.isEmpty()) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Integer, Integer> e : enchs.entrySet()) {
            String label = MappingUtils.enchantShortLabel(e.getKey(), e.getValue());
            if (label == null) continue;
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(label);
        }
        return sb.length() > 0 ? sb.toString() : null;
    }

    private String buildItemLabel(Object itemStack) {
        if (itemStack == null) {
            return null;
        }
        String name = MappingUtils.getItemShortName(itemStack);
        if (name != null && !name.isEmpty()) {
            Map<Integer, Integer> enchs = MappingUtils.getEnchantments(itemStack);
            if (enchs.isEmpty()) {
                return name;
            }
            StringBuilder sb = new StringBuilder(name);
            for (Map.Entry<Integer, Integer> e : enchs.entrySet()) {
                String label = MappingUtils.enchantShortLabel(e.getKey(), e.getValue());
                if (label == null) continue;
                sb.append(' ').append(label);
            }
            return sb.toString();
        }
        return null;
    }

    private void drawCenteredText(String text, float cx, float y, float scale, float maxWidth, int color) {
        float tw = (float)FontUtil.getStringWidth(text) * scale;
        if (tw > maxWidth && maxWidth > 0.0f) {
            scale = Math.max(0.28f, scale * (maxWidth / tw));
            tw = (float)FontUtil.getStringWidth(text) * scale;
        }
        float x = cx - tw * 0.5f;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)x, (float)y, (float)0.0f);
        GL11.glScalef((float)scale, (float)scale, (float)1.0f);
        FontUtil.drawString(text, 0.0f, 0.0f, color, true);
        GL11.glPopMatrix();
    }

    private boolean allNull(Object[] arr) {
        for (Object o : arr) {
            if (o == null) continue;
            return false;
        }
        return true;
    }

    private void drawTracer2D(float left, float top, float right, float bottom, float sw, float sh, float alpha, float lw, int colorType) {
        float cx = (left + right) * 0.5f;
        float sx = sw * 0.5f;
        GL11.glLineWidth((float)(lw * 2.0f));
        GL11.glBegin((int)1);
        this.glMono(0.1f, alpha * 0.25f);
        GL11.glVertex2f((float)sx, (float)sh);
        GL11.glVertex2f((float)cx, (float)bottom);
        GL11.glEnd();
        GL11.glLineWidth((float)lw);
        GL11.glBegin((int)1);
        if (colorType == 1) {
            this.glFriend(0.85f, alpha);
        } else if (colorType == 2) {
            this.glEclipse(0.85f, alpha);
        } else {
            this.glMono(0.96f, alpha);
        }
        GL11.glVertex2f((float)sx, (float)sh);
        GL11.glVertex2f((float)cx, (float)bottom);
        GL11.glEnd();
    }

    private void drawMinimalBox(float alpha, int colorType) {
        float w = 0.42f;
        float d = 0.42f;
        float h = 1.8f;
        float arm = 0.24f;
        GL11.glLineWidth((float)(((Double)this.lineWidth.getValue()).floatValue() * 1.1f));
        if (colorType == 1) {
            this.drawBoxCornerColor(0.2f, 0.9f, 0.35f, -w, 0.0f, -d, arm, arm, arm, alpha);
            this.drawBoxCornerColor(0.2f, 0.9f, 0.35f, w, 0.0f, -d, -arm, arm, arm, alpha);
            this.drawBoxCornerColor(0.2f, 0.9f, 0.35f, -w, 0.0f, d, arm, arm, -arm, alpha);
            this.drawBoxCornerColor(0.2f, 0.9f, 0.35f, w, 0.0f, d, -arm, arm, -arm, alpha);
            this.drawBoxCornerColor(0.2f, 0.63f, 0.24499999f, -w, h, -d, arm, -arm, arm, alpha * 0.85f);
            this.drawBoxCornerColor(0.2f, 0.63f, 0.24499999f, w, h, -d, -arm, -arm, arm, alpha * 0.85f);
            this.drawBoxCornerColor(0.2f, 0.63f, 0.24499999f, -w, h, d, arm, -arm, -arm, alpha * 0.85f);
            this.drawBoxCornerColor(0.2f, 0.63f, 0.24499999f, w, h, d, -arm, -arm, -arm, alpha * 0.85f);
        } else if (colorType == 2) {
            this.drawBoxCornerColor(0.58f, 0.25f, 0.84f, -w, 0.0f, -d, arm, arm, arm, alpha);
            this.drawBoxCornerColor(0.58f, 0.25f, 0.84f, w, 0.0f, -d, -arm, arm, arm, alpha);
            this.drawBoxCornerColor(0.58f, 0.25f, 0.84f, -w, 0.0f, d, arm, arm, -arm, alpha);
            this.drawBoxCornerColor(0.58f, 0.25f, 0.84f, w, 0.0f, d, -arm, arm, -arm, alpha);
            this.drawBoxCornerColor(0.58f, 0.175f, 0.588f, -w, h, -d, arm, -arm, arm, alpha * 0.85f);
            this.drawBoxCornerColor(0.58f, 0.175f, 0.588f, w, h, -d, -arm, -arm, arm, alpha * 0.85f);
            this.drawBoxCornerColor(0.58f, 0.175f, 0.588f, -w, h, d, arm, -arm, -arm, alpha * 0.85f);
            this.drawBoxCornerColor(0.58f, 0.175f, 0.588f, w, h, d, -arm, -arm, -arm, alpha * 0.85f);
        } else {
            this.drawBoxCorner(-w, 0.0f, -d, arm, arm, arm, 0.96f, alpha);
            this.drawBoxCorner(w, 0.0f, -d, -arm, arm, arm, 0.96f, alpha);
            this.drawBoxCorner(-w, 0.0f, d, arm, arm, -arm, 0.96f, alpha);
            this.drawBoxCorner(w, 0.0f, d, -arm, arm, -arm, 0.96f, alpha);
            this.drawBoxCorner(-w, h, -d, arm, -arm, arm, 0.78f, alpha * 0.85f);
            this.drawBoxCorner(w, h, -d, -arm, -arm, arm, 0.78f, alpha * 0.85f);
            this.drawBoxCorner(-w, h, d, arm, -arm, -arm, 0.78f, alpha * 0.85f);
            this.drawBoxCorner(w, h, d, -arm, -arm, -arm, 0.78f, alpha * 0.85f);
        }
        GL11.glLineWidth((float)(((Double)this.lineWidth.getValue()).floatValue() * 0.7f));
        GL11.glBegin((int)1);
        if (colorType == 1) {
            GL11.glColor4f((float)0.2f, (float)0.45f, (float)0.175f, (float)(alpha * 0.35f));
        } else if (colorType == 2) {
            GL11.glColor4f((float)0.58f, (float)0.125f, (float)0.42f, (float)(alpha * 0.35f));
        } else {
            this.glMono(0.52f, alpha * 0.35f);
        }
        GL11.glVertex3f((float)(-w), (float)0.0f, (float)(-d));
        GL11.glVertex3f((float)(-w), (float)h, (float)(-d));
        GL11.glVertex3f((float)w, (float)0.0f, (float)(-d));
        GL11.glVertex3f((float)w, (float)h, (float)(-d));
        GL11.glVertex3f((float)(-w), (float)0.0f, (float)d);
        GL11.glVertex3f((float)(-w), (float)h, (float)d);
        GL11.glVertex3f((float)w, (float)0.0f, (float)d);
        GL11.glVertex3f((float)w, (float)h, (float)d);
        GL11.glEnd();
    }

    private void drawBoxCorner(float x, float y, float z, float ax, float ay, float az, float shade, float alpha) {
        GL11.glBegin((int)1);
        this.glMono(shade, alpha);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glVertex3f((float)(x + ax), (float)y, (float)z);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glVertex3f((float)x, (float)(y + ay), (float)z);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glVertex3f((float)x, (float)y, (float)(z + az));
        GL11.glEnd();
    }

    private void drawScanLine(Object entity, float alpha) {
        float entityH = MappingUtils.getEyeHeight(entity) + 0.18f;
        if (entityH < 1.0f) {
            entityH = 1.8f;
        }
        float phaseOffset = (float)(System.identityHashCode(entity) & 0x7FF) / 2048.0f;
        float phase = (float)(System.currentTimeMillis() % 2600L) / 2600.0f;
        float pp = (phase = (phase + phaseOffset) % 1.0f) < 0.5f ? phase * 2.0f : 2.0f - phase * 2.0f;
        float eased = pp * pp * (3.0f - 2.0f * pp);
        float y = 0.08f + (entityH - 0.2f) * eased;
        float half = 0.38f;
        float arm = 0.14f;
        GL11.glLineWidth((float)(((Double)this.lineWidth.getValue()).floatValue() * 1.2f));
        this.drawGroundBrackets(half, half, y, arm, 0.96f, alpha * 0.88f);
        GL11.glLineWidth((float)((Double)this.lineWidth.getValue()).floatValue());
        GL11.glBegin((int)2);
        this.glMono(0.78f, alpha * 0.5f);
        for (int i = 0; i < 12; ++i) {
            double ang = Math.PI * 2 * (double)i / 12.0;
            GL11.glVertex3d((double)(Math.cos(ang) * (double)half * 0.58), (double)y, (double)(Math.sin(ang) * (double)half * 0.58));
        }
        GL11.glEnd();
    }

    private void drawGroundBrackets(float hw, float hd, float y, float arm, float shade, float alpha) {
        GL11.glBegin((int)1);
        this.glMono(shade, alpha);
        GL11.glVertex3d((double)(-hw), (double)y, (double)(-hd));
        GL11.glVertex3d((double)(-hw + arm), (double)y, (double)(-hd));
        GL11.glVertex3d((double)(-hw), (double)y, (double)(-hd));
        GL11.glVertex3d((double)(-hw), (double)y, (double)(-hd + arm));
        GL11.glVertex3d((double)hw, (double)y, (double)(-hd));
        GL11.glVertex3d((double)(hw - arm), (double)y, (double)(-hd));
        GL11.glVertex3d((double)hw, (double)y, (double)(-hd));
        GL11.glVertex3d((double)hw, (double)y, (double)(-hd + arm));
        GL11.glVertex3d((double)(-hw), (double)y, (double)hd);
        GL11.glVertex3d((double)(-hw + arm), (double)y, (double)hd);
        GL11.glVertex3d((double)(-hw), (double)y, (double)hd);
        GL11.glVertex3d((double)(-hw), (double)y, (double)(hd - arm));
        GL11.glVertex3d((double)hw, (double)y, (double)hd);
        GL11.glVertex3d((double)(hw - arm), (double)y, (double)hd);
        GL11.glVertex3d((double)hw, (double)y, (double)hd);
        GL11.glVertex3d((double)hw, (double)y, (double)(hd - arm));
        GL11.glEnd();
    }

    private void drawMonoHealthBar(float health, float alpha) {
        float hp = Math.max(0.0f, Math.min(1.0f, health / 20.0f));
        float barX = 0.56f;
        float barW = 0.05f;
        float barD = 0.04f;
        float fillH = 1.8f * hp;
        GL11.glBegin((int)7);
        this.glMono(0.1f, alpha * 0.55f);
        this.quad(barX, 0.0f, 0.0f, barX + barW, 1.8f, barD);
        if (fillH > 0.02f) {
            this.glMono(0.96f, alpha * 0.82f);
            this.quad(barX, 0.0f, 0.0f, barX + barW, fillH, barD);
        }
        GL11.glEnd();
        GL11.glLineWidth((float)(((Double)this.lineWidth.getValue()).floatValue() * 0.6f));
        GL11.glBegin((int)2);
        this.glMono(0.52f, alpha * 0.45f);
        this.outline(barX, 0.0f, 0.0f, barX + barW, 1.8f, barD);
        GL11.glEnd();
    }

    private void quad(float x1, float y1, float z1, float x2, float y2, float z2) {
        GL11.glVertex3f((float)x1, (float)y1, (float)z1);
        GL11.glVertex3f((float)x1, (float)y2, (float)z1);
        GL11.glVertex3f((float)x2, (float)y2, (float)z2);
        GL11.glVertex3f((float)x2, (float)y1, (float)z2);
    }

    private void outline(float x1, float y1, float z1, float x2, float y2, float z2) {
        GL11.glVertex3f((float)x1, (float)y1, (float)z1);
        GL11.glVertex3f((float)x1, (float)y2, (float)z1);
        GL11.glVertex3f((float)x2, (float)y2, (float)z2);
        GL11.glVertex3f((float)x2, (float)y1, (float)z2);
    }

    private void drawTracer3D(double x, double y, double z, Object entity, float alpha, int colorType) {
        double ty = y + (double)MappingUtils.getEyeHeight(entity) * 0.5;
        GL11.glLineWidth((float)(((Double)this.lineWidth.getValue()).floatValue() * 2.0f));
        GL11.glBegin((int)1);
        this.glMono(0.1f, alpha * 0.25f);
        GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)x, (double)ty, (double)z);
        GL11.glEnd();
        GL11.glLineWidth((float)((Double)this.lineWidth.getValue()).floatValue());
        GL11.glBegin((int)1);
        if (colorType == 1) {
            this.glFriend(0.85f, alpha);
        } else if (colorType == 2) {
            this.glEclipse(0.85f, alpha);
        } else {
            this.glMono(0.96f, alpha);
        }
        GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)x, (double)ty, (double)z);
        GL11.glEnd();
    }

    private float distAlpha(double dist, double rangeVal) {
        float distFactor = (float)Math.max(0.0, Math.min(1.0, 1.0 - dist / rangeVal * 0.45));
        return distFactor * ((Double)this.opacity.getValue()).floatValue();
    }

    private void glMono(float shade, float alpha) {
        GL11.glColor4f((float)shade, (float)shade, (float)(shade + 0.02f), (float)alpha);
    }

    private void glFriend(float brightness, float alpha) {
        GL11.glColor4f((float)(0.2f * brightness), (float)(0.9f * brightness), (float)(0.35f * brightness), (float)alpha);
    }

    private void glEclipse(float brightness, float alpha) {
        GL11.glColor4f((float)(0.58f * brightness), (float)(0.25f * brightness), (float)(0.84f * brightness), (float)alpha);
    }

    private int getColorType(Object entity) {
        if (FriendManagerModule.isFriend(entity)) {
            return 1;
        }
        return FriendManagerModule.isEclipseUser(entity) ? 2 : 0;
    }

    private void drawBoxCornerColor(float r, float g, float b, float x, float y, float z, float ax, float ay, float az, float alpha) {
        GL11.glBegin((int)1);
        GL11.glColor4f((float)r, (float)g, (float)b, (float)alpha);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glVertex3f((float)(x + ax), (float)y, (float)z);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glVertex3f((float)x, (float)(y + ay), (float)z);
        GL11.glVertex3f((float)x, (float)y, (float)z);
        GL11.glVertex3f((float)x, (float)y, (float)(z + az));
        GL11.glEnd();
    }

    private void pushVisualState() {
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)((Double)this.lineWidth.getValue()).floatValue());
    }
}

