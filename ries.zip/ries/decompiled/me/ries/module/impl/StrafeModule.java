/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package me.ries.module.impl;

import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import org.lwjgl.input.Keyboard;

public class StrafeModule
extends Module {
    public StrafeModule() {
        super("Strafe", "Corrects movement direction to match yaw", Category.MOVEMENT, 0);
        this.addOptions(new NumberOption("Speed Boost", 1.0, 0.5, 2.0, 0.05, this));
    }

    @Override
    public String getOptionPrefix() {
        double s = (Double)((NumberOption)this.getOption("Speed Boost")).getValue();
        return String.format("%.2f", s);
    }

    private double speedBoost() {
        return (Double)((NumberOption)this.getOption("Speed Boost")).getValue();
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
        Object player = MinecraftMapper.getPlayer();
        if (player != null && MinecraftMapper.getCurrentScreen() == null) {
            double motionZ;
            double motionX;
            double speed;
            boolean w = Keyboard.isKeyDown((int)17);
            boolean a = Keyboard.isKeyDown((int)30);
            boolean s = Keyboard.isKeyDown((int)31);
            boolean d = Keyboard.isKeyDown((int)32);
            if ((w || a || s || d) && !((speed = Math.sqrt((motionX = MinecraftMapper.getMotionX()) * motionX + (motionZ = MinecraftMapper.getMotionZ()) * motionZ)) < 0.001)) {
                speed *= this.speedBoost();
                float yaw = MinecraftMapper.getRotationYaw();
                float forwardInput = 0.0f;
                if (w) {
                    forwardInput += 1.0f;
                }
                if (s) {
                    forwardInput -= 1.0f;
                }
                float strafeInput = 0.0f;
                if (a) {
                    strafeInput += 1.0f;
                }
                if (d) {
                    strafeInput -= 1.0f;
                }
                if (forwardInput != 0.0f) {
                    yaw = strafeInput > 0.0f ? (yaw += (float)(forwardInput > 0.0f ? -45 : -135)) : (strafeInput < 0.0f ? (yaw += (float)(forwardInput > 0.0f ? 45 : 135)) : (yaw += (float)(forwardInput > 0.0f ? 0 : 180)));
                } else if (strafeInput > 0.0f) {
                    yaw -= 90.0f;
                } else if (strafeInput < 0.0f) {
                    yaw += 90.0f;
                }
                double rad = Math.toRadians(yaw);
                MinecraftMapper.setMotionX(-Math.sin(rad) * speed);
                MinecraftMapper.setMotionZ(Math.cos(rad) * speed);
            }
        }
    }
}

