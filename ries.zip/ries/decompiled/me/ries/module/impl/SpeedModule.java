/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Keyboard;

public class SpeedModule
extends Module {
    private final NumberOption multiplier = new NumberOption("Multiplier", 1.3, 1.0, 3.0, 0.05, this);
    private final BooleanOption hop = new BooleanOption("Hop", true, (Module)this);

    public SpeedModule() {
        super("Speed", "Increases your movement speed", Category.MOVEMENT, 0);
        this.multiplier.setGroup("Speed");
        this.hop.setGroup("Speed");
        this.addOptions(this.multiplier, this.hop);
    }

    @Override
    public String getOptionPrefix() {
        return String.format("%.2fx", (Double)this.multiplier.getValue());
    }

    @Override
    public void onEnable() {
        Logger.info("Speed: enabled");
    }

    @Override
    public void onDisable() {
        Logger.info("Speed: disabled");
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        try {
            boolean moving;
            Object player = this.getThePlayer();
            if (player == null) {
                return;
            }
            if (MinecraftMapper.getCurrentScreen() != null) {
                return;
            }
            double mult = (Double)this.multiplier.getValue();
            double baseSpeed = 0.22;
            double speed = baseSpeed * mult;
            double yaw = Math.toRadians(MinecraftMapper.getRotationYaw());
            boolean w = Keyboard.isKeyDown((int)17);
            boolean s = Keyboard.isKeyDown((int)31);
            boolean a = Keyboard.isKeyDown((int)30);
            boolean d = Keyboard.isKeyDown((int)32);
            boolean bl = moving = w || s || a || d;
            if (moving) {
                if (((Boolean)this.hop.getValue()).booleanValue() && this.isOnGround(player)) {
                    this.setMotionY(0.42);
                    speed *= 1.2;
                }
                double angle = yaw;
                if (w) {
                    if (a) {
                        angle -= 0.7853981633974483;
                    } else if (d) {
                        angle += 0.7853981633974483;
                    }
                } else if (s) {
                    angle += Math.PI;
                    if (a) {
                        angle += 0.7853981633974483;
                    } else if (d) {
                        angle -= 0.7853981633974483;
                    }
                } else if (a) {
                    angle -= 1.5707963267948966;
                } else if (d) {
                    angle += 1.5707963267948966;
                }
                MinecraftMapper.setMotionX(-Math.sin(angle) * speed);
                MinecraftMapper.setMotionZ(Math.cos(angle) * speed);
            }
        }
        catch (Throwable t) {
            Logger.warn("Speed error: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private boolean isOnGround(Object player) {
        try {
            Field f = MappingUtils.getField("Entity.onGround");
            if (f != null) {
                f.setAccessible(true);
                return f.getBoolean(player);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return true;
    }

    private void setMotionY(double motionY) {
        try {
            Field f;
            Object player = this.getThePlayer();
            if (player != null && (f = MappingUtils.getField("Entity.motionY")) != null) {
                f.setAccessible(true);
                f.setDouble(player, motionY);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

