/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package me.ries.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.SecureRandom;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.PacketSendEvent;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.BotTracker;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class KillAuraModule
extends Module {
    private static final Pattern POSITION_PATTERN = Pattern.compile("x=([-\\d,.]+), y=([-\\d,.]+), z=([-\\d,.]+)");
    private final NumberOption range = new NumberOption("Range", 3.5, 1.0, 6.0, 0.1, this);
    private final NumberOption minCps = new NumberOption("MinCPS", 7.0, 6.0, 14.0, 0.1, this);
    private final NumberOption maxCps = new NumberOption("MaxCPS", 13.0, 7.0, 15.0, 0.1, this);
    private final NumberOption failRate = new NumberOption("FailRate", 0.2, 0.0, 1.0, 0.01, this);
    private final StringOption keepSprint = new StringOption("KeepSprint", "Off", this, "On", "Off");
    private final StringOption attackMode = new StringOption("AttackMode", "Single", this, "Single", "Multi");
    private final StringOption targetLock = new StringOption("TargetLock", "Off", this, "On", "Off");
    private final BooleanOption rotationEnabled = new BooleanOption("Rotation", true, (Module)this);
    private final StringOption rotationMode = new StringOption("RotMode", "Silent", this, "Silent", "Body");
    private final NumberOption rotationSpeed = new NumberOption("RotSpeed", 0.65, 0.1, 1.0, 0.05, this);
    private final NumberOption bodyJitter = new NumberOption("BodyJitter", 1.5, 0.0, 5.0, 0.1, this);
    private float jitterPhase = 0.0f;
    private float jitterYawAccum = 0.0f;
    private float jitterPitchAccum = 0.0f;
    private final NumberOption aimPoint = new NumberOption("AimPoint", 0.5, 0.0, 1.0, 0.05, this);
    private final BooleanOption rangeCircle = new BooleanOption("RangeCircle", true, (Module)this);
    private final BooleanOption targetMarker = new BooleanOption("TargetMarker", true, (Module)this);
    private final BooleanOption tracer = new BooleanOption("Tracer", true, (Module)this);
    private final NumberOption fov = new NumberOption("FOV", 180.0, 30.0, 360.0, 5.0, this);
    private final BooleanOption raytrace = new BooleanOption("Raytrace", true, (Module)this);
    private static final float VIS_WHITE = 0.96f;
    private static final float VIS_LIGHT = 0.78f;
    private static final float VIS_MID = 0.52f;
    private static final float VIS_DARK = 0.1f;
    private float lastYaw = 0.0f;
    private float lastPitch = 0.0f;
    private boolean rotationInitialized = false;
    private final Random rand = new SecureRandom();
    private final Random patternRandom = new SecureRandom();
    private final Random humanRandom = new Random();
    private final Map<String, Double> behaviorProfile = new HashMap<String, Double>();
    private final Map<Object, Long> targetAttackHistory = new WeakHashMap<Object, Long>();
    private final Map<Object, double[]> lastEntityPos = Collections.synchronizedMap(new WeakHashMap());
    private final List<Long> lastAttackTimes = new ArrayList<Long>();
    private final Deque<Long> rhythmMemory = new ArrayDeque<Long>(20);
    private final Map<Long, Float> historicalJitter = new HashMap<Long, Float>();
    private Object closestTarget;
    private Object primaryTarget;
    private Object lastClosestTarget;
    private double[] lastTargetPos;
    private long lastAttackTime;
    private long lastSwingTime;
    private long lastTargetSwitchTime;
    private long lastBehaviorUpdateTick = System.currentTimeMillis();
    private long lastVelocityPatternChange = System.currentTimeMillis();
    private long lastVelocityCheck = System.currentTimeMillis();
    private long lastMicroAdjustment = System.currentTimeMillis();
    private long lastPatternReset = System.currentTimeMillis();
    private long lastReflexDelayCheck = System.currentTimeMillis();
    private long lastAACBurstTime;
    private long lastMovementChangeTime;
    private long lastSmoothPacketTime;
    private long humanLastCallTime = System.currentTimeMillis();
    private final long sessionStartTime = System.currentTimeMillis();
    private boolean reflexDelayActive;
    private long reflexDelayStart;
    private long reflexDelayDuration;
    private double reactionReadiness = 0.8 + Math.random() * 0.15;
    private double concentrationDrift = Math.random();
    private double randomWalkMood = 0.5;
    private double mentalEnergy = 82.0 + Math.random() * 16.0;
    private double mentalFocusLevel = 0.65 + Math.random() * 0.25;
    private double bodyFatigueLevel = 0.08 + Math.random() * 0.18;
    private double flowStateIntensity = 0.45 + Math.random() * 0.45;
    private double stressLevel;
    private double singleModeMinCPS = 6.0;
    private double singleModeMaxCPS = 8.0;
    private double humanSmoothedDelay = 150.0;
    private double humanFatigue = 1.0;
    private float playerMovementFactor = 1.0f;
    private int sessionPhase;
    private int attackPatternCounter;
    private int missCounter;
    private int consecutiveHits;
    private int consecutiveMisses;
    private int totalAttackCount;
    private int aacBurstCounter;
    private int multiTargetIndex;
    private int humanBurstRemaining;
    private String lastSelectedAACPattern;
    private Method cachedGetHealthMethod = null;
    private boolean getHealthCached = false;
    private float prevHealthFallback = 20.0f;
    private EventListener packetSendListener;
    private float silentYaw;
    private float silentPitch;
    private boolean isRotatingSilently = false;
    private static Field c03Yaw = null;
    private static Field c03Pitch = null;
    private static Field c03Rotating = null;
    private static Field rotatingField = null;

    public KillAuraModule() {
        super("KillAura", "Attacks nearby valid players", Category.COMBAT, 0);
        this.range.setGroup("Combat");
        this.minCps.setGroup("Timing");
        this.maxCps.setGroup("Timing");
        this.failRate.setGroup("Timing");
        this.keepSprint.setGroup("Behavior");
        this.attackMode.setGroup("Behavior");
        this.targetLock.setGroup("Behavior");
        this.rotationEnabled.setGroup("Rotation");
        this.rotationMode.setGroup("Rotation");
        this.rotationSpeed.setGroup("Rotation");
        this.bodyJitter.setGroup("Rotation");
        this.aimPoint.setGroup("Rotation");
        this.rangeCircle.setGroup("Visuals");
        this.targetMarker.setGroup("Visuals");
        this.tracer.setGroup("Visuals");
        this.fov.setGroup("Combat");
        this.raytrace.setGroup("Combat");
        this.addOptions(this.range, this.minCps, this.maxCps, this.failRate, this.keepSprint, this.attackMode, this.targetLock, this.rotationEnabled, this.rotationMode, this.rotationSpeed, this.bodyJitter, this.aimPoint, this.rangeCircle, this.targetMarker, this.tracer, this.fov, this.raytrace);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    KillAuraModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
        this.patternRandom.setSeed(System.nanoTime() ^ Runtime.getRuntime().freeMemory());
        this.initializeNewBehaviorPattern();
    }

    @Override
    public String getOptionPrefix() {
        double d = (Double)this.range.getValue();
        return d == Math.floor(d) ? String.valueOf((int)d) : String.format("%.1f", d);
    }

    @Override
    public void onEnable() {
        this.lastAttackTime = 0L;
        this.lastSwingTime = 0L;
        this.rotationInitialized = false;
        this.isRotatingSilently = false;
        this.initializeNewBehaviorPattern();
        Logger.kaInfo("=== KillAura ENABLED === range=" + this.range.getValue() + " minCPS=" + this.minCps.getValue() + " maxCPS=" + this.maxCps.getValue() + " mode=" + (String)this.attackMode.getValue() + " targetLock=" + (String)this.targetLock.getValue());
        this.packetSendListener = new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof PacketSendEvent) {
                    KillAuraModule.this.handlePacketSend((PacketSendEvent)event);
                }
            }
        };
        try {
            Ries.getInstance().getEventBus().subscribe(PacketSendEvent.class, this.packetSendListener);
        }
        catch (Throwable throwable) {
            Logger.kaWarn("Failed to subscribe PacketSendEvent: " + throwable.getMessage());
        }
    }

    @Override
    public void onDisable() {
        Logger.kaInfo("=== KillAura DISABLED === totalAttacks=" + this.totalAttackCount + " consecutiveHits=" + this.consecutiveHits + " sessionPhase=" + this.sessionPhase);
        this.resetAllPatterns();
        this.isRotatingSilently = false;
        if (this.packetSendListener != null) {
            try {
                Ries.getInstance().getEventBus().unsubscribe(PacketSendEvent.class, this.packetSendListener);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            this.packetSendListener = null;
        }
    }

    public Object getClosestTarget() {
        return this.closestTarget;
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            this.resetAllPatterns();
        } else {
            try {
                boolean bl;
                this.driftHumanState();
                this.applyReflexBypassPatterns();
                this.updateAdvancedAntiPatternSystem();
                this.executeDynamicTimingManipulation();
                if (!this.processEnhancedReflexDelay()) {
                    return;
                }
                double d = (Double)this.minCps.getValue();
                double d2 = (Double)this.maxCps.getValue();
                double d3 = (Double)this.range.getValue();
                if (this.getCurrentScreen() != null || this.getThePlayer() == null || this.getTheWorld() == null) {
                    if (this.closestTarget != null) {
                        Logger.kaDebug("onUpdate: screen/player/world null -> clearing targets");
                    }
                    this.closestTarget = null;
                    this.primaryTarget = null;
                    this.isRotatingSilently = false;
                    return;
                }
                this.updateCombatModeBehavior();
                boolean bl2 = "On".equals(this.targetLock.getValue()) || "Body".equals(this.rotationMode.getValue());
                boolean bl3 = false;
                if (bl2 && this.primaryTarget != null) {
                    bl = false;
                    try {
                        for (Object object : MinecraftMapper.getPlayerEntitiesInWorld()) {
                            if (object != this.primaryTarget) continue;
                            bl = true;
                            break;
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    if (bl && this.isValidTarget(this.primaryTarget) && this.getHealth(this.primaryTarget) > 0.0f) {
                        double d4 = this.distanceTo(this.primaryTarget);
                        if (d4 <= d3 * 1.5 || "Body".equals(this.rotationMode.getValue())) {
                            this.closestTarget = this.primaryTarget;
                            bl3 = true;
                            Logger.kaDebug("TargetLock: holding lock on " + this.getName(this.primaryTarget) + " dist=" + String.format("%.2f", d4));
                        } else {
                            Logger.kaInfo("TargetLock: releasing lock, target out of range -> " + this.getName(this.primaryTarget) + " dist=" + String.format("%.2f", d4));
                            this.primaryTarget = null;
                        }
                    } else {
                        Logger.kaInfo("TargetLock: releasing lock, target dead/invalid/left world -> " + this.getName(this.primaryTarget));
                        this.primaryTarget = null;
                    }
                }
                if (!bl3) {
                    this.selectClosestTarget(d3);
                }
                if (this.closestTarget != null && !bl3) {
                    bl = false;
                    try {
                        for (Object object : MinecraftMapper.getPlayerEntitiesInWorld()) {
                            if (object != this.closestTarget) continue;
                            bl = true;
                            break;
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    if (!bl) {
                        Logger.kaInfo("onUpdate: target left world -> " + this.getName(this.closestTarget));
                        this.closestTarget = null;
                        this.primaryTarget = null;
                        this.lastClosestTarget = null;
                        return;
                    }
                }
                if (!bl2 && "Single".equals(this.getAttackMode()) && this.closestTarget != null) {
                    if (this.primaryTarget != null && this.isValidTarget(this.primaryTarget) && !(this.distanceTo(this.primaryTarget) > d3 * 1.15)) {
                        double d5 = this.distanceTo(this.primaryTarget);
                        if (d5 <= d3 && this.rand.nextDouble() > 0.7 + this.mentalFocusLevel * 0.2 - this.bodyFatigueLevel * 0.3) {
                            this.closestTarget = this.primaryTarget;
                        }
                    } else {
                        this.primaryTarget = this.closestTarget;
                    }
                }
                if (bl2 && this.primaryTarget == null && this.closestTarget != null) {
                    this.primaryTarget = this.closestTarget;
                    Logger.kaInfo("TargetLock: new lock acquired -> " + this.getName(this.primaryTarget));
                }
                if (this.closestTarget == null) {
                    this.primaryTarget = null;
                    this.isRotatingSilently = false;
                    return;
                }
                this.lastTargetPos = this.getEntityPos(this.closestTarget);
                this.applyRotation(this.closestTarget);
                long l = System.currentTimeMillis();
                double d6 = "Single".equals(this.getAttackMode()) ? this.singleModeMinCPS : d;
                double d7 = "Single".equals(this.getAttackMode()) ? this.singleModeMaxCPS : d2;
                long l2 = this.calculateAAC364OptimizedDelay(d6, d7, this.closestTarget);
                if (l - this.lastAttackTime < l2) {
                    this.storeEntityPos(this.closestTarget);
                    return;
                }
                float f = this.getHealth(this.closestTarget);
                if (f <= 0.0f) {
                    Logger.kaInfo("onUpdate: target dead -> " + this.getName(this.closestTarget) + " health=" + f);
                    this.handleTargetDeath(this.closestTarget);
                    return;
                }
                double d8 = 0.75 + this.flowStateIntensity * 0.15 - this.bodyFatigueLevel * 0.2;
                if (!this.isEntityVisible(this.closestTarget) && this.rand.nextDouble() < d8) {
                    Logger.kaDebug("onUpdate: target invisible, skipping -> " + this.getName(this.closestTarget));
                    return;
                }
                this.handleTargetSwitch(l);
                boolean bl4 = this.shouldFailAAC364Attack();
                this.lastClosestTarget = this.closestTarget;
                if (l - this.lastAttackTime >= l2) {
                    this.targetAttackHistory.put(this.closestTarget, l);
                    this.sendAAC364HumanizedSwing();
                    if (!bl4) {
                        int n;
                        if ("Multi".equals(this.getAttackMode())) {
                            Logger.kaAttack("MULTI-ATTACK swing -> target=" + this.getName(this.closestTarget) + " health=" + this.getHealth(this.closestTarget) + " dist=" + String.format("%.2f", this.distanceTo(this.closestTarget)));
                            this.attackNextMultiTarget(d3, l);
                        } else if (this.isTargetInRange(this.closestTarget, d3)) {
                            Logger.kaAttack("SINGLE-ATTACK -> target=" + this.getName(this.closestTarget) + " health=" + this.getHealth(this.closestTarget) + " dist=" + String.format("%.2f", this.distanceTo(this.closestTarget)) + " consecutiveHits=" + (this.consecutiveHits + 1) + " totalAttacks=" + (this.totalAttackCount + 1));
                            n = this.applyRotation(this.closestTarget) ? 1 : 0;
                            if (n == 0) {
                                this.storeEntityPos(this.closestTarget);
                                return;
                            }
                            this.attackEntity(this.closestTarget);
                            this.lastAttackTime = l;
                            this.rememberAttack(l);
                        } else {
                            Logger.kaDebug("ATTACK SKIPPED: target out of range -> " + this.getName(this.closestTarget) + " dist=" + String.format("%.2f", this.distanceTo(this.closestTarget)) + " range=" + d3);
                        }
                        n = (int)(1.0 + Math.floor(this.flowStateIntensity * 1.5 * this.rand.nextDouble()));
                        this.attackPatternCounter += n;
                        ++this.consecutiveHits;
                        this.consecutiveMisses = 0;
                        ++this.totalAttackCount;
                        double d9 = 0.02 + Math.min(0.3, (double)this.consecutiveHits / 18.0);
                        d9 *= 1.0 + this.bodyFatigueLevel * 0.5;
                        if (this.rand.nextDouble() < d9) {
                            Logger.kaDebug("Pattern reset triggered: consecutiveHits=" + this.consecutiveHits);
                            this.attackPatternCounter = this.rand.nextInt(3);
                            this.consecutiveHits = this.rand.nextInt(2);
                        }
                    } else {
                        Logger.kaDebug("MISS -> target=" + this.getName(this.closestTarget) + " consecutiveMisses=" + (this.consecutiveMisses + 1));
                        this.handleMiss();
                        if (this.consecutiveMisses >= 2 && this.rand.nextDouble() < 0.55) {
                            Logger.kaDebug("MicroAdjust after " + this.consecutiveMisses + " consecutive misses");
                            this.executeAAC364MicroAdjustment();
                        }
                        double d10 = 0.35 + (1.0 - this.flowStateIntensity) * 0.25 + this.bodyFatigueLevel * 0.2;
                        if (this.rand.nextDouble() < d10) {
                            this.executeAAC364MicroAdjustment();
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                Logger.warn("KillAura update error: " + throwable.getMessage());
                Logger.kaWarn("onUpdate EXCEPTION: " + throwable.getClass().getSimpleName() + " -> " + throwable.getMessage());
            }
        }
    }

    private void selectClosestTarget(double d) {
        this.closestTarget = null;
        double d2 = d + 1.0;
        int n = 0;
        List<Object> list = MinecraftMapper.getPlayerEntitiesInWorld();
        for (Object object : list) {
            double d3;
            BotTracker.observe(object);
            if (!this.isValidTarget(object)) continue;
            double d4 = this.distanceTo(object);
            if (d4 > d) continue;
            ++n;
            boolean bl = false;
            if (this.closestTarget == null) {
                bl = this.rand.nextDouble() < 0.92 + this.mentalFocusLevel * 0.08;
            } else {
                double d5 = d2 - d4;
                double d6 = 0.08 + this.concentrationDrift * 0.12;
                double d7 = (this.mentalFocusLevel - 0.5) * 0.1;
                double d8 = d6 + d7;
                if (d5 > d8) {
                    bl = true;
                } else if (d5 > -d8) {
                    double d9 = 0.5 + this.concentrationDrift * 0.3 - this.bodyFatigueLevel * 0.15;
                    bl = this.rand.nextDouble() < d9;
                    boolean bl2 = bl;
                }
                if (!bl && this.rand.nextDouble() < 0.02 * this.mentalFocusLevel) {
                    bl = this.rand.nextDouble() < 0.35;
                    boolean bl3 = bl;
                }
            }
            if (!bl) continue;
            d2 = d4;
            this.closestTarget = object;
        }
    }

    private void handleTargetSwitch(long l) {
        if (this.closestTarget != this.lastClosestTarget && this.lastClosestTarget != null) {
            long l2 = (long)(110.0 * (1.0 + (1.0 - this.mentalFocusLevel) * 0.4));
            long l3 = (long)(50.0 + this.concentrationDrift * 60.0 - this.flowStateIntensity * 40.0);
            long l4 = l2 + (long)this.rand.nextInt((int)Math.max(10L, l3));
            if (l - this.lastTargetSwitchTime < l4) {
                Logger.kaDebug("handleTargetSwitch: switch suppressed (delay=" + l4 + "ms) keeping=" + this.getName(this.lastClosestTarget) + " -> wanted=" + this.getName(this.closestTarget));
                this.closestTarget = this.lastClosestTarget;
            } else {
                Logger.kaInfo("handleTargetSwitch: switched " + this.getName(this.lastClosestTarget) + " -> " + this.getName(this.closestTarget) + " after " + (l - this.lastTargetSwitchTime) + "ms");
                this.consecutiveMisses = 0;
                this.consecutiveHits = Math.max(0, this.consecutiveHits - 1);
                this.lastTargetSwitchTime = l;
            }
        }
    }

    private void attackNextMultiTarget(double d, long l) {
        ArrayList<Object> arrayList = new ArrayList<Object>();
        for (Object object : MinecraftMapper.getPlayerEntitiesInWorld()) {
            if (!this.isValidTarget(object) || !this.isTargetInRange(object, d)) continue;
            arrayList.add(object);
        }
        Collections.sort(arrayList, new Comparator<Object>(){

            @Override
            public int compare(Object object, Object object2) {
                return Double.compare(KillAuraModule.this.distanceTo(object), KillAuraModule.this.distanceTo(object2));
            }
        });
        if (!arrayList.isEmpty()) {
            this.multiTargetIndex %= arrayList.size();
            Object iterator = arrayList.get(this.multiTargetIndex);
            ++this.multiTargetIndex;
            this.closestTarget = iterator;
            Logger.kaAttack("MULTI-ATTACK -> target=" + this.getName(iterator) + " health=" + this.getHealth(iterator) + " dist=" + String.format("%.2f", this.distanceTo(iterator)) + " targetIndex=" + (this.multiTargetIndex - 1) + " totalTargets=" + arrayList.size());
            this.attackEntity(iterator);
            this.lastAttackTime = l;
            this.rememberAttack(l);
        } else {
            Logger.kaDebug("attackNextMultiTarget: no valid targets in range=" + d);
        }
    }

    private boolean shouldFailAAC364Attack() {
        double d;
        double d2 = (Double)this.failRate.getValue();
        double d3 = this.clamp(this.calculateRecentAccuracy(), 0.0, 1.0);
        double d4 = this.clamp(1.0 + (0.58 - d3) * 0.85, 0.3, 2.0);
        double d5 = this.clamp(1.0 + Math.max(0.0, (100.0 - this.mentalEnergy) / 80.0) * 0.35, 0.5, 2.0);
        double d6 = this.clamp(1.0 + this.bodyFatigueLevel * 1.2, 0.5, 2.5);
        double d7 = this.clamp(1.0 - this.mentalFocusLevel * 0.4, 0.4, 1.5);
        double d8 = this.clamp(1.0 - this.flowStateIntensity * 0.5, 0.3, 1.2);
        double d9 = this.clamp(0.85 + (double)this.sessionPhase * 0.15, 0.7, 1.3);
        double d10 = this.clamp(this.calculateCombatIntensity(), 0.0, 1.0);
        double d11 = 1.0;
        if (d10 > 0.8) {
            d11 = 1.35 + this.rand.nextDouble() * 0.2;
        } else if (d10 > 0.5) {
            d11 = 1.1 + this.rand.nextDouble() * 0.12;
        }
        double d12 = this.clamp(this.rand.nextGaussian() * 0.12, -0.25, 0.35);
        double d13 = this.clamp(0.01 + (1.0 - this.mentalFocusLevel) * 0.04, 0.0, 0.15);
        double d14 = 1.0;
        if (this.rand.nextDouble() < d13 && this.consecutiveMisses < 3) {
            d14 = 1.6 + this.rand.nextDouble() * 1.2;
        }
        double d15 = d4 * d5 * d6 * d7 * d8 * d9 * d11 * d14;
        d15 = this.clamp(d15 + d12, 0.3, 3.5);
        if (this.isPlayerMoving(this.closestTarget)) {
            d = this.clamp(this.getEntityVelocity(this.getThePlayer()), 0.0, 2.0);
            d15 *= 1.0 + d * 0.25;
        }
        d = d2 * d15;
        double d16 = this.consecutiveMisses >= 3 ? 0.35 : 0.65;
        d = this.clamp(d, 0.02, d16);
        if (this.rand.nextDouble() < 0.005 && d10 > 0.6) {
            d = Math.min(0.95, d + 0.25);
        }
        if (this.consecutiveMisses >= 2) {
            d *= this.clamp(1.0 - (double)this.consecutiveMisses * 0.22, 0.25, 1.0);
        }
        if (this.consecutiveMisses >= 4) {
            d *= 0.15;
        }
        return this.rand.nextDouble() < d;
    }

    private void updateCombatModeBehavior() {
        if ("Single".equals(this.getAttackMode())) {
            this.handleSingleTargetMode();
        }
    }

    private void handleSingleTargetMode() {
        if (this.primaryTarget != null) {
            boolean bl = false;
            try {
                for (Object object : MinecraftMapper.getPlayerEntitiesInWorld()) {
                    if (object != this.primaryTarget) continue;
                    bl = true;
                    break;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (!bl) {
                this.primaryTarget = null;
                this.closestTarget = null;
                return;
            }
        }
        this.closestTarget = this.primaryTarget != null && this.isValidTarget(this.primaryTarget) && this.distanceTo(this.primaryTarget) <= (Double)this.range.getValue() ? this.primaryTarget : (this.primaryTarget = this.findOptimalSingleTarget());
        this.adjustTimingForSingleMode();
    }

    private Object findOptimalSingleTarget() {
        double d = (Double)this.range.getValue();
        Object object = null;
        double d2 = d + 1.0;
        for (Object object2 : MinecraftMapper.getPlayerEntitiesInWorld()) {
            double d3;
            if (!this.isValidTarget(object2) || (d3 = this.distanceTo(object2)) > d || !(d3 < d2)) continue;
            d2 = d3;
            object = object2;
        }
        return object;
    }

    private void adjustTimingForSingleMode() {
        double d = (Double)this.minCps.getValue();
        double d2 = (Double)this.maxCps.getValue();
        this.singleModeMinCPS = Math.max(d * 0.88, d - 0.6);
        this.singleModeMaxCPS = Math.min(d2 * 1.12, d2 + 0.6);
    }

    private void driftHumanState() {
        long l = System.currentTimeMillis();
        long l2 = l - this.lastBehaviorUpdateTick;
        if (l2 >= 500L) {
            this.lastBehaviorUpdateTick = l;
            this.bodyFatigueLevel = this.clamp(this.bodyFatigueLevel + (this.rand.nextDouble() - 0.45) * 0.008, 0.0, 1.0);
            double d = this.stressLevel / 100.0;
            double d2 = this.bodyFatigueLevel * 0.3;
            this.mentalFocusLevel += (this.rand.nextDouble() - 0.5) * 0.012 - d2 - d * 0.008;
            this.mentalFocusLevel = this.clamp(this.mentalFocusLevel, 0.4, 1.0);
            this.reactionReadiness = this.clamp(0.7 + this.mentalFocusLevel * 0.25 + this.rand.nextGaussian() * 0.05, 0.6, 1.0);
            double d3 = this.calculateCombatIntensity();
            this.flowStateIntensity += (d3 - this.flowStateIntensity) * 0.04;
            this.flowStateIntensity = this.clamp(this.flowStateIntensity - this.bodyFatigueLevel * 0.02, 0.3, 1.0);
            this.concentrationDrift = this.clamp(this.concentrationDrift + (this.rand.nextDouble() - 0.5) * 0.15, 0.0, 1.0);
            this.randomWalkMood = this.clamp(this.randomWalkMood + (this.rand.nextDouble() - 0.5) * 0.08, 0.0, 1.0);
        }
    }

    private void updateAdvancedAntiPatternSystem() {
        long l = System.currentTimeMillis();
        long l2 = l - this.sessionStartTime;
        this.sessionPhase = this.calculateDynamicSessionPhase(l2);
        double d = 0.35 + 0.65 * (1.0 - Math.exp((double)(-this.sessionPhase) / 3.0));
        double d2 = 0.6 + 0.4 * (1.0 - d);
        if (this.timeSince(this.lastMicroAdjustment) > 12000L + (long)this.patternRandom.nextInt(10000) - (long)(2000.0 * (d - 0.5))) {
            if (this.patternRandom.nextDouble() < 0.85 * d) {
                this.executeAAC364CompliantAdjustment();
            } else if (this.patternRandom.nextDouble() < 0.5) {
                this.singleModeMinCPS = this.clamp(this.singleModeMinCPS * (1.0 + this.jitter(0.02)), 3.5, 20.0);
            }
            this.lastMicroAdjustment = l;
        }
        if (this.timeSince(this.lastPatternReset) > 25000L + (long)this.patternRandom.nextInt(20000)) {
            if (this.patternRandom.nextDouble() < 0.6 * (1.0 - d2)) {
                this.executeAdvancedPatternReset();
            } else {
                this.attackPatternCounter = Math.max(0, this.attackPatternCounter - this.patternRandom.nextInt(2));
            }
            this.lastPatternReset = l;
        }
        int n = this.calculateAdaptiveResetThreshold();
        boolean bl = this.consecutiveHits > 18 + this.patternRandom.nextInt(8) && this.patternRandom.nextDouble() < 0.35;
        boolean bl2 = bl;
        if (this.totalAttackCount > n || bl) {
            this.executeStealthPatternReset();
            this.totalAttackCount = this.patternRandom.nextInt(Math.max(1, n / 4));
            this.aacBurstCounter = 0;
        }
        if (this.consecutiveHits > 12 + this.patternRandom.nextInt(6)) {
            if (this.patternRandom.nextDouble() < 0.8) {
                ++this.aacBurstCounter;
            }
            if (this.aacBurstCounter > 2 + this.patternRandom.nextInt(2)) {
                if (this.patternRandom.nextDouble() < 0.7) {
                    this.executePreventiveMicroAdjustment();
                } else {
                    this.lastAttackTime += 10L + (long)this.patternRandom.nextInt(20);
                }
                this.aacBurstCounter = 0;
            }
        } else if (this.aacBurstCounter > 0 && this.patternRandom.nextDouble() < 0.4) {
            --this.aacBurstCounter;
        }
        if (l - this.lastVelocityPatternChange > 15000L + (long)this.patternRandom.nextInt(15000)) {
            this.randomizeVelocityPatterns();
            this.lastVelocityPatternChange = l;
        }
        if (l % 45000L < 80L && this.patternRandom.nextDouble() < 0.18 + 0.2 * (1.0 - d)) {
            this.injectTimingAnomaly();
        }
        this.updateDynamicBehaviorProfile();
        this.simulateHumanVariance();
        this.manageSessionLongevity(l);
    }

    private int calculateDynamicSessionPhase(long l) {
        double d = (double)l / (90000.0 + (double)this.patternRandom.nextInt(45000));
        double d2 = this.calculateCombatIntensity();
        double d3 = this.calculateRecentAccuracy();
        double d4 = 0.0;
        if (d2 > 0.7) {
            d4 += 0.9;
        }
        if (d3 < 0.6) {
            d4 += 0.5;
        }
        int n = (int)Math.floor(d + d4);
        return Math.max(0, Math.min(6, n));
    }

    private void executeAAC364CompliantAdjustment() {
        int n;
        double d = 0.9 + this.patternRandom.nextDouble() * 0.18;
        double d2 = 0.92 + (double)this.sessionPhase * 0.04;
        this.singleModeMinCPS = Math.max(3.8, this.lerp(this.singleModeMinCPS, this.singleModeMinCPS * (d *= d2 * (1.0 + this.jitter(0.012))), 0.45));
        this.singleModeMaxCPS = Math.min(16.5, this.lerp(this.singleModeMaxCPS, this.singleModeMaxCPS * d, 0.35));
        if (this.patternRandom.nextDouble() < 0.45) {
            n = this.patternRandom.nextInt(3);
            this.attackPatternCounter = Math.max(0, this.attackPatternCounter + n - this.patternRandom.nextInt(2));
        }
        if (this.patternRandom.nextDouble() < 0.3) {
            n = 6 + this.patternRandom.nextInt(16);
            if (this.patternRandom.nextDouble() < 0.3) {
                n = -n;
            }
            this.lastAttackTime += this.patternRandom.nextDouble() < 0.65 ? (long)n : (long)(-n / 2);
        }
    }

    private void executeAdvancedPatternReset() {
        double d = 0.75 + this.patternRandom.nextDouble() * 0.5;
        double d2 = 0.85 + (double)this.sessionPhase * 0.06;
        this.singleModeMinCPS = Math.max(4.0, this.lerp(this.singleModeMinCPS, this.singleModeMinCPS * (d *= d2 * (1.0 + this.jitter(0.03))), 0.45));
        this.singleModeMaxCPS = Math.min(15.8, this.lerp(this.singleModeMaxCPS, this.singleModeMaxCPS * d, 0.35));
        this.attackPatternCounter = Math.max(0, this.attackPatternCounter - this.patternRandom.nextInt(4));
        this.consecutiveHits = Math.max(0, this.consecutiveHits - this.patternRandom.nextInt(4));
        this.consecutiveMisses = Math.max(0, this.consecutiveMisses - this.patternRandom.nextInt(3));
        if (this.patternRandom.nextDouble() < 0.5) {
            this.rhythmMemory.clear();
        }
        if (this.patternRandom.nextDouble() < 0.35) {
            this.lastAttackTimes.clear();
        }
        long l = System.currentTimeMillis() - 30000L;
        ArrayList<Long> arrayList = new ArrayList<Long>();
        for (Long l2 : this.historicalJitter.keySet()) {
            if (!(this.patternRandom.nextDouble() < 0.65) && l2 >= l) continue;
            arrayList.add(l2);
        }
        this.historicalJitter.keySet().removeAll(arrayList);
    }

    private int calculateAdaptiveResetThreshold() {
        int n = 260 + this.patternRandom.nextInt(220);
        double d = 1.0 - (double)this.sessionPhase * 0.07;
        double d2 = this.calculateRecentAccuracy() > 0.7 ? 1.15 : 0.92;
        double d3 = 0.9 + this.patternRandom.nextDouble() * 0.3;
        int n2 = (int)((double)n * d * d2 * d3);
        return Math.max(120, n2);
    }

    private void executeStealthPatternReset() {
        for (Map.Entry<String, Double> entry : new ArrayList<Map.Entry<String, Double>>(this.behaviorProfile.entrySet())) {
            this.behaviorProfile.put(entry.getKey(), entry.getValue() * (0.85 + this.patternRandom.nextDouble() * 0.25));
        }
        this.attackPatternCounter = this.patternRandom.nextInt(3);
        this.consecutiveHits = this.patternRandom.nextInt(4);
        this.consecutiveMisses = this.patternRandom.nextInt(2);
        this.missCounter = 0;
        if (this.patternRandom.nextDouble() < 0.5 && !this.rhythmMemory.isEmpty()) {
            int n = Math.max(1, this.rhythmMemory.size() / (2 + this.patternRandom.nextInt(3)));
            for (int i = 0; i < n && !this.rhythmMemory.isEmpty(); ++i) {
                this.rhythmMemory.removeFirst();
            }
        }
        if (this.patternRandom.nextDouble() < 0.25) {
            this.lastAttackTimes.clear();
        }
        ArrayList arrayList = new ArrayList();
        for (Map.Entry<Object, Long> entry : this.targetAttackHistory.entrySet()) {
            if (!(this.patternRandom.nextDouble() < 0.7) && System.currentTimeMillis() - entry.getValue() <= 15000L) continue;
            arrayList.add(entry.getKey());
        }
        Iterator<Map.Entry<Object, Long>> iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            Map.Entry<Object, Long> entry;
            entry = iterator.next();
            this.targetAttackHistory.remove(entry);
        }
        this.initializeAAC364CompliantPattern();
    }

    private void executePreventiveMicroAdjustment() {
        double d = 0.94 + this.patternRandom.nextDouble() * 0.12;
        this.singleModeMinCPS = this.clamp(this.singleModeMinCPS * d * (1.0 + this.jitter(0.01)), 3.5, 18.0);
        this.singleModeMaxCPS = this.clamp(this.singleModeMaxCPS * d * (1.0 + this.jitter(0.01)), 6.0, 20.0);
        if (this.patternRandom.nextDouble() < 0.35) {
            this.attackPatternCounter = Math.max(0, this.attackPatternCounter + (this.patternRandom.nextInt(3) - 1));
        }
        if (this.patternRandom.nextDouble() < 0.28) {
            this.lastAttackTime += 4L + (long)this.patternRandom.nextInt(14);
        }
    }

    private void randomizeVelocityPatterns() {
        double d = 0.7 + this.patternRandom.nextDouble() * 0.6;
        this.playerMovementFactor = (float)this.lerp(this.playerMovementFactor, (float)d, 0.35);
        if (this.patternRandom.nextDouble() < 0.35) {
            this.lastMovementChangeTime = System.currentTimeMillis();
        }
    }

    private void injectTimingAnomaly() {
        int n = this.patternRandom.nextInt(3);
        if (n == 0) {
            this.lastAttackTime += 6L + (long)this.patternRandom.nextInt(16);
        } else if (n == 1) {
            this.lastAttackTime -= 4L + (long)this.patternRandom.nextInt(12);
        } else {
            this.attackPatternCounter = Math.max(0, this.attackPatternCounter + (this.patternRandom.nextInt(3) - 1));
        }
    }

    private void updateDynamicBehaviorProfile() {
        double d;
        double d2 = this.calculateRecentAccuracy();
        double d3 = this.calculateCombatIntensity();
        if (d2 < 0.5 && this.patternRandom.nextDouble() < 0.38) {
            d = this.behaviorProfile.containsKey("cps_variance") ? this.behaviorProfile.get("cps_variance") : 0.2;
            this.behaviorProfile.put("cps_variance", this.clamp(this.lerp(d, Math.min(0.35, d * 1.25), 0.4 + this.jitter(0.03)), 0.02, 0.6));
        }
        if (d3 > 0.75 && this.patternRandom.nextDouble() < 0.48) {
            d = this.behaviorProfile.containsKey("fail_rate_base") ? this.behaviorProfile.get("fail_rate_base") : 0.1;
            this.behaviorProfile.put("fail_rate_base", this.clamp(this.lerp(d, Math.min(0.28, d * 1.18), 0.35 + this.jitter(0.03)), 0.01, 0.4));
        }
        if (this.sessionPhase > 3) {
            double d4 = this.behaviorProfile.containsKey("rotation_speed") ? this.behaviorProfile.get("rotation_speed") : 0.65;
            this.behaviorProfile.put("rotation_speed", this.clamp(this.lerp(d4, d4 * 0.92, 0.25 + this.jitter(0.02)), 0.25, 1.3));
        }
    }

    private void simulateHumanVariance() {
        if (this.patternRandom.nextDouble() < 0.06) {
            this.singleModeMinCPS *= 0.88 + this.jitter(0.02);
            this.singleModeMaxCPS *= 0.88 + this.jitter(0.02);
        }
        if (this.patternRandom.nextDouble() < 0.05) {
            this.singleModeMinCPS *= 1.12 + this.jitter(0.02);
            this.singleModeMaxCPS *= 1.12 + this.jitter(0.02);
        }
    }

    private void manageSessionLongevity(long l) {
        if (this.sessionPhase > 4) {
            if (this.patternRandom.nextDouble() < 0.095) {
                this.executeStealthPatternReset();
            }
            if (l % 60000L < 100L) {
                double d = this.behaviorProfile.containsKey("cps_variance") ? this.behaviorProfile.get("cps_variance") : 0.2;
                double d2 = 1.04 + (double)this.sessionPhase * 0.03 + this.jitter(0.02);
                this.behaviorProfile.put("cps_variance", this.clamp(d * d2, 0.01, 0.6));
            }
            if (this.patternRandom.nextDouble() < 0.03) {
                this.singleModeMinCPS = Math.max(3.5, this.singleModeMinCPS * (0.96 + this.jitter(0.01)));
                this.singleModeMaxCPS = Math.max(5.0, this.singleModeMaxCPS * (0.98 + this.jitter(0.01)));
            }
        }
    }

    private void initializeAAC364CompliantPattern() {
        String[] stringArray = new String[]{"BALANCED", "STEADY", "ADAPTIVE", "PRECISE"};
        double d = 0.4 + 0.6 * (1.0 - Math.exp((double)(-this.sessionPhase) / 4.0));
        double[] dArray = new double[stringArray.length];
        for (int i = 0; i < dArray.length; ++i) {
            dArray[i] = 1.0;
            if (!stringArray[i].equals(this.lastSelectedAACPattern)) continue;
            int n = i;
            dArray[n] = dArray[n] * (1.2 + this.patternRandom.nextDouble() * 0.6 * d);
        }
        double d2 = 0.0;
        for (double d3 : dArray) {
            d2 += d3;
        }
        double d4 = this.patternRandom.nextDouble() * d2;
        String string = stringArray[0];
        for (int i = 0; i < dArray.length; ++i) {
            if (!((d4 -= dArray[i]) <= 0.0)) continue;
            string = stringArray[i];
            break;
        }
        double d5 = 0.15;
        double d6 = 0.55;
        if ("BALANCED".equals(string)) {
            d5 = 0.16 + this.patternRandom.nextDouble() * 0.06;
            d6 = 0.58 + this.patternRandom.nextDouble() * 0.12;
        } else if ("STEADY".equals(string)) {
            d5 = 0.1 + this.patternRandom.nextDouble() * 0.05;
            d6 = 0.48 + this.patternRandom.nextDouble() * 0.1;
        } else if ("ADAPTIVE".equals(string)) {
            d5 = 0.2 + this.patternRandom.nextDouble() * 0.1;
            d6 = 0.65 + this.patternRandom.nextDouble() * 0.18;
        } else if ("PRECISE".equals(string)) {
            d5 = 0.09 + this.patternRandom.nextDouble() * 0.04;
            d6 = 0.44 + this.patternRandom.nextDouble() * 0.08;
        }
        double d7 = 1.0 - 0.12 * (1.0 - Math.exp((double)(-this.sessionPhase) / 6.0));
        this.behaviorProfile.put("cps_variance", this.clamp(d5 * d7 + this.jitter(0.02), 0.0, 1.0));
        this.behaviorProfile.put("rotation_speed", this.clamp(d6 * (1.0 + 0.06 * (1.0 - d)) + this.jitter(0.02), 0.0, 1.0));
        this.lastSelectedAACPattern = string;
    }

    private void applyReflexBypassPatterns() {
        long l;
        long l2;
        long l3 = System.currentTimeMillis();
        if (l3 % (l2 = 25000L + (long)this.patternRandom.nextInt(15000)) < 140L) {
            int n = (int)Math.round(this.patternRandom.nextGaussian() * 6.0);
            this.lastAttackTime += (long)n;
            double d = 0.1 + 0.18 * this.calculateCombatIntensity();
            if (this.patternRandom.nextDouble() < d) {
                this.attackPatternCounter = (this.attackPatternCounter + 1 + this.patternRandom.nextInt(2)) % 4;
            }
            this.humanFatigue = Math.max(0.4, this.humanFatigue - this.patternRandom.nextDouble() * 0.02);
        }
        if (l3 - this.lastVelocityCheck > (l = 8000L + (long)this.patternRandom.nextInt(12000))) {
            if (this.patternRandom.nextDouble() < 0.85) {
                this.modifyVelocityPatterns();
                this.lastVelocityCheck = l3;
            } else {
                this.lastVelocityCheck = l3 - (long)this.patternRandom.nextInt(4000);
            }
        }
    }

    private long calculateAAC364OptimizedDelay(double d, double d2, Object object) {
        double d3;
        long l = System.currentTimeMillis();
        double d4 = (double)(l - this.humanLastCallTime) / 1000.0;
        this.humanLastCallTime = l;
        double d5 = Math.max(1.0, d);
        double d6 = Math.max(d5 + 0.1, d2);
        double d7 = (d5 + d6) / 2.0 * (0.92 + this.humanRandom.nextDouble() * 0.16);
        double d8 = (d6 - d5) * (0.1 + this.humanRandom.nextDouble() * 0.06);
        double d9 = d7 + this.humanRandom.nextGaussian() * d8;
        if (this.humanRandom.nextDouble() < 0.06) {
            d9 *= 0.75 + this.humanRandom.nextDouble() * 1.35;
        }
        d9 = this.clamp(d9, d5, d6);
        double d10 = 1.0 + Math.sin((double)l * 7.2E-4) * 0.065 + Math.cos((double)l * 0.00185) * 0.045 + Math.sin((double)l * 2.7E-4) * 0.02;
        d9 *= d10;
        this.humanFatigue = this.clamp(this.humanFatigue + (this.humanRandom.nextDouble() - 0.5) * 0.012, 0.88, 1.12);
        d9 *= this.humanFatigue * (1.0 + (double)this.sessionPhase * 0.032);
        if (object != null) {
            d3 = this.distanceTo(object);
            if (d3 > 6.0) {
                d9 *= 0.89;
            } else if (d3 < 1.8) {
                d9 *= 1.11;
            }
        }
        if (this.humanBurstRemaining > 0) {
            d9 *= 1.06;
            --this.humanBurstRemaining;
        } else if (this.humanRandom.nextDouble() < 0.045) {
            this.humanBurstRemaining = 1 + this.humanRandom.nextInt(3);
        }
        if (d4 > 2.0 && this.humanRandom.nextDouble() < 0.5) {
            d9 *= 0.78 + this.humanRandom.nextDouble() * 0.18;
        }
        if (this.humanRandom.nextDouble() < 0.018) {
            d9 /= 1.25 + this.humanRandom.nextDouble() * 1.6;
        }
        d3 = 1000.0 / Math.max(1.0, d9);
        d3 += this.clamp(this.humanRandom.nextGaussian() * 7.0, -28.0, 28.0);
        d3 += (this.humanRandom.nextDouble() - 0.5) * 9.0;
        if (this.humanRandom.nextDouble() < 0.007) {
            d3 += 60.0 + this.humanRandom.nextDouble() * 220.0;
        }
        double d11 = this.clamp(1.0 - Math.exp(-Math.max(0.01, d4) * 1.6), 0.08, 0.45);
        this.humanSmoothedDelay = this.humanSmoothedDelay * (1.0 - d11) + d3 * d11;
        return (long)this.clamp(this.humanSmoothedDelay, 35.0, 800.0);
    }

    private void executeAAC364MicroAdjustment() {
        double d = 0.92 + this.patternRandom.nextDouble() * 0.14;
        this.singleModeMinCPS = Math.max(4.2, this.singleModeMinCPS * d);
        this.singleModeMaxCPS = Math.min(15.5, this.singleModeMaxCPS * d);
        if (this.patternRandom.nextDouble() < 0.35) {
            this.attackPatternCounter = Math.max(0, this.attackPatternCounter + (this.patternRandom.nextInt(3) - 1));
        }
        if (this.patternRandom.nextDouble() < 0.25) {
            this.lastAttackTime -= 8L + (long)this.patternRandom.nextInt(20);
        }
    }

    private void sendAAC364HumanizedSwing() {
        long l;
        long l2 = System.currentTimeMillis();
        if (l2 - this.lastSwingTime >= (l = 30L + (long)this.patternRandom.nextInt(25))) {
            this.sendSwing();
            this.lastSwingTime = l2;
        }
    }

    private boolean processEnhancedReflexDelay() {
        long l = System.currentTimeMillis();
        if (l - this.lastReflexDelayCheck > 3000L + (long)this.patternRandom.nextInt(5000)) {
            if (this.patternRandom.nextDouble() < 0.32) {
                this.reflexDelayActive = true;
                this.reflexDelayStart = l;
                this.reflexDelayDuration = 120L + (long)this.patternRandom.nextInt(300);
            }
            this.lastReflexDelayCheck = l;
        }
        if (this.reflexDelayActive && l - this.reflexDelayStart < this.reflexDelayDuration) {
            if (this.patternRandom.nextDouble() < 0.35) {
                this.executeAAC364MicroAdjustment();
            }
            return false;
        }
        this.reflexDelayActive = false;
        return true;
    }

    private void modifyVelocityPatterns() {
        if (this.patternRandom.nextDouble() < 0.4) {
            this.playerMovementFactor = 0.8f + this.patternRandom.nextFloat() * 0.4f;
        }
        if (this.patternRandom.nextDouble() < 0.25) {
            this.lastMovementChangeTime = System.currentTimeMillis();
        }
    }

    private void executeDynamicTimingManipulation() {
        long l = System.currentTimeMillis();
        if (this.patternRandom.nextDouble() < 0.15) {
            this.lastSmoothPacketTime = l - (15L + (long)this.patternRandom.nextInt(30));
        }
        if (l % 20000L < 50L && this.patternRandom.nextDouble() < 0.3) {
            this.lastAttackTime += 20L + (long)this.patternRandom.nextInt(25);
        }
        if (this.sessionPhase > 2 && this.patternRandom.nextDouble() < 0.1) {
            this.lastAttackTime -= (long)this.patternRandom.nextInt(35);
        }
    }

    private void handleTargetDeath(Object object) {
        BotTracker.registerKill(this.getName(object));
        Logger.kaInfo("handleTargetDeath: target=" + this.getName(object) + " consecutiveHits=" + this.consecutiveHits + " totalAttacks=" + this.totalAttackCount);
        this.lastTargetPos = this.getEntityPos(object);
        this.targetAttackHistory.remove(object);
        if (this.primaryTarget == object) {
            this.primaryTarget = null;
        }
        if (this.closestTarget == object) {
            this.closestTarget = null;
        }
        this.attackPatternCounter = Math.max(0, this.attackPatternCounter - this.patternRandom.nextInt(3));
        this.consecutiveHits = 0;
    }

    private void handleMiss() {
        this.lastAttackTime = System.currentTimeMillis();
        ++this.consecutiveMisses;
        this.consecutiveHits = 0;
        ++this.missCounter;
        ++this.totalAttackCount;
        Logger.kaDebug("handleMiss: consecutiveMisses=" + this.consecutiveMisses + " missCounter=" + this.missCounter + " totalAttacks=" + this.totalAttackCount);
        if (this.missCounter > 1 + this.patternRandom.nextInt(2) && this.patternRandom.nextDouble() < 0.65) {
            Logger.kaDebug("handleMiss: pattern counter reset after " + this.missCounter + " misses");
            this.attackPatternCounter = this.patternRandom.nextInt(3);
        }
    }

    private boolean isTargetInRange(Object object, double d) {
        return object != null && this.distanceTo(object) <= d * 1.05;
    }

    private boolean isEntityVisible(Object object) {
        return !this.isInvisible(object);
    }

    private void initializeNewBehaviorPattern() {
        this.behaviorProfile.clear();
        String[] stringArray = new String[]{"STEADY", "AGGRESSIVE", "DEFENSIVE", "ERRATIC", "PRECISE", "ADAPTIVE", "BALANCED"};
        String string = stringArray[this.patternRandom.nextInt(stringArray.length)];
        if ("STEADY".equals(string)) {
            this.behaviorProfile.put("cps_variance", 0.14 + this.patternRandom.nextDouble() * 0.07);
            this.behaviorProfile.put("fail_rate_base", 0.07 + this.patternRandom.nextDouble() * 0.05);
            this.behaviorProfile.put("rotation_speed", 0.6 + this.patternRandom.nextDouble() * 0.12);
        } else if ("AGGRESSIVE".equals(string)) {
            this.behaviorProfile.put("cps_variance", 0.24 + this.patternRandom.nextDouble() * 0.1);
            this.behaviorProfile.put("fail_rate_base", 0.11 + this.patternRandom.nextDouble() * 0.06);
            this.behaviorProfile.put("rotation_speed", 0.8 + this.patternRandom.nextDouble() * 0.18);
        } else if ("DEFENSIVE".equals(string)) {
            this.behaviorProfile.put("cps_variance", 0.1 + this.patternRandom.nextDouble() * 0.06);
            this.behaviorProfile.put("fail_rate_base", 0.05 + this.patternRandom.nextDouble() * 0.04);
            this.behaviorProfile.put("rotation_speed", 0.5 + this.patternRandom.nextDouble() * 0.12);
        } else if ("ERRATIC".equals(string)) {
            this.behaviorProfile.put("cps_variance", 0.38 + this.patternRandom.nextDouble() * 0.18);
            this.behaviorProfile.put("fail_rate_base", 0.16 + this.patternRandom.nextDouble() * 0.1);
            this.behaviorProfile.put("rotation_speed", 1.05 + this.patternRandom.nextDouble() * 0.35);
        } else if ("PRECISE".equals(string)) {
            this.behaviorProfile.put("cps_variance", 0.08 + this.patternRandom.nextDouble() * 0.05);
            this.behaviorProfile.put("fail_rate_base", 0.03 + this.patternRandom.nextDouble() * 0.03);
            this.behaviorProfile.put("rotation_speed", 0.4 + this.patternRandom.nextDouble() * 0.12);
        } else if ("ADAPTIVE".equals(string)) {
            this.behaviorProfile.put("cps_variance", 0.17 + this.patternRandom.nextDouble() * 0.12);
            this.behaviorProfile.put("fail_rate_base", 0.08 + this.patternRandom.nextDouble() * 0.06);
            this.behaviorProfile.put("rotation_speed", 0.7 + this.patternRandom.nextDouble() * 0.22);
        } else {
            this.behaviorProfile.put("cps_variance", 0.2 + this.patternRandom.nextDouble() * 0.1);
            this.behaviorProfile.put("fail_rate_base", 0.09 + this.patternRandom.nextDouble() * 0.05);
            this.behaviorProfile.put("rotation_speed", 0.65 + this.patternRandom.nextDouble() * 0.18);
        }
        double d = 0.7 + Math.log((double)this.sessionPhase + 1.0) * 0.12;
        for (Map.Entry<String, Double> entry : new ArrayList<Map.Entry<String, Double>>(this.behaviorProfile.entrySet())) {
            this.behaviorProfile.put(entry.getKey(), entry.getValue() * d);
        }
        Logger.kaInfo("initializeNewBehaviorPattern: pattern=" + string + " phaseFactor=" + String.format("%.3f", d) + " sessionPhase=" + this.sessionPhase + " cps_variance=" + String.format("%.3f", this.behaviorProfile.containsKey("cps_variance") ? this.behaviorProfile.get("cps_variance") : 0.0) + " fail_rate_base=" + String.format("%.3f", this.behaviorProfile.containsKey("fail_rate_base") ? this.behaviorProfile.get("fail_rate_base") : 0.0) + " rotation_speed=" + String.format("%.3f", this.behaviorProfile.containsKey("rotation_speed") ? this.behaviorProfile.get("rotation_speed") : 0.0));
    }

    private double calculateCombatIntensity() {
        if (this.closestTarget == null) {
            return 0.0;
        }
        long l = System.currentTimeMillis();
        double d = 0.0;
        d += Math.min(1.0, this.calculateAttackFrequency() / 13.0) * (0.3 + (double)(l % 45L) * 0.004);
        d += Math.min(1.0, (double)this.getNearbyEntities().size() / 7.0) * (0.2 + (double)(l % 35L) * 0.003);
        d += (1.0 - Math.min(1.0, this.distanceTo(this.closestTarget) / 10.0)) * (0.35 + (double)(l % 55L) * 0.003);
        return Math.min(1.0, (d += this.calculateDamageExchangeRate() * (0.25 + (double)(l % 40L) * 0.004)) * (0.85 + (double)(System.nanoTime() % 250L) / 1000.0));
    }

    private double calculateAttackFrequency() {
        return Math.min(13.0, (double)this.lastAttackTimes.size() / 9.0) * (0.75 + (double)(System.nanoTime() % 500L) / 1000.0);
    }

    private double calculateDamageExchangeRate() {
        return (double)(System.nanoTime() % 700L) / 1000.0 * 0.55;
    }

    private double calculateRecentAccuracy() {
        return 0.6 + (double)(System.nanoTime() % 550L) / 1000.0 * 0.35;
    }

    private void resetAllPatterns() {
        Logger.kaInfo("resetAllPatterns: clearing all state totalAttacks=" + this.totalAttackCount + " consecutiveHits=" + this.consecutiveHits + " sessionPhase=" + this.sessionPhase);
        this.closestTarget = null;
        this.primaryTarget = null;
        this.lastTargetPos = null;
        this.lastClosestTarget = null;
        this.behaviorProfile.clear();
        this.attackPatternCounter = this.patternRandom.nextInt(3);
        this.consecutiveHits = this.patternRandom.nextInt(3);
        this.consecutiveMisses = 0;
        this.missCounter = 0;
        this.rhythmMemory.clear();
        this.lastAttackTimes.clear();
        this.historicalJitter.clear();
        this.targetAttackHistory.clear();
        this.aacBurstCounter = 0;
        this.lastAACBurstTime = System.currentTimeMillis();
        this.initializeNewBehaviorPattern();
    }

    private boolean isValidTarget(Object object) {
        if (object != null && object != this.getThePlayer()) {
            Object object2;
            if (!this.isValidCombatTarget(object)) {
                return false;
            }
            Object object3 = this.getThePlayer();
            if (object3 == null) {
                return false;
            }
            if (((Boolean)this.raytrace.getValue()).booleanValue() && this.isInvisible(object)) {
                return false;
            }
            float[] fArray = this.getRotationsTo(object);
            if (fArray != null) {
                float f = fArray[0];
                float f2 = MinecraftMapper.getRotationYaw();
                double d = (Double)this.fov.getValue();
                if (d < 360.0 && (double)KillAuraModule.angleDiff(f2, f) > d / 2.0) {
                    return false;
                }
            }
            if (this.isBot(object)) {
                return false;
            }
            if (BotTracker.isBotByHp(object)) {
                return false;
            }
            if (BotTracker.isDeadRecently(object)) {
                return false;
            }
            try {
                object2 = MappingUtils.getField("Entity.isDead");
                if (object2 == null) {
                    object2 = MappingUtils.getField("Entity.dead");
                }
                if (object2 != null) {
                    ((Field)object2).setAccessible(true);
                    Object object4 = ((Field)object2).get(object);
                    if (object4 instanceof Boolean && ((Boolean)object4).booleanValue()) {
                        return false;
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (MappingUtils.getEntityHealth(object) <= 0.0f) {
                return false;
            }
            object2 = this.getName(object);
            if (object2 == null) {
                return false;
            }
            String string = this.stripColor((String)object2).trim();
            return string.length() != 0;
        }
        return false;
    }

    private boolean canEntityBeSeen(Object object, Object object2) {
        return !this.isInvisible(object2);
    }

    private boolean isBot(Object object) {
        return BotTracker.isBot(object);
    }

    private String getAttackMode() {
        return (String)this.attackMode.getValue();
    }

    private List<Object> getNearbyEntities() {
        Object object = this.getThePlayer();
        double d = (Double)this.range.getValue() + 10.0;
        ArrayList<Object> arrayList = new ArrayList<Object>();
        if (object == null) {
            return arrayList;
        }
        double d2 = this.getPosX(object);
        double d3 = this.getPosY(object);
        double d4 = this.getPosZ(object);
        for (Object object2 : MinecraftMapper.getPlayerEntitiesInWorld()) {
            double d5;
            double d6;
            double d7;
            if (object2 == null || object2 == object || !((d7 = this.getPosX(object2) - d2) * d7 + (d6 = this.getPosY(object2) - d3) * d6 + (d5 = this.getPosZ(object2) - d4) * d5 <= d * d)) continue;
            arrayList.add(object2);
        }
        return arrayList;
    }

    private void attackEntity(Object object) {
        try {
            String string = this.getName(object);
            float f = this.getHealth(object);
            double d = this.distanceTo(object);
            Logger.kaAttack("attackEntity -> name=" + string + " health=" + f + " dist=" + String.format("%.2f", d) + " totalAttacks=" + this.totalAttackCount + " consecutiveHits=" + this.consecutiveHits + " sessionPhase=" + this.sessionPhase + " focus=" + String.format("%.3f", this.mentalFocusLevel) + " fatigue=" + String.format("%.3f", this.bodyFatigueLevel) + " flow=" + String.format("%.3f", this.flowStateIntensity));
            boolean bl = MinecraftMapper.attackEntity(object);
            if (!bl) {
                Logger.kaWarn("attackEntity: raw attack returned false -> target=" + string);
                Logger.warn("KillAura raw attack failed");
            } else {
                Logger.kaDebug("attackEntity: SUCCESS -> " + string);
            }
            try {
                if (Mouse.isButtonDown((int)1)) {
                    Object object2 = this.getThePlayer();
                    Method method = MappingUtils.getMethod("EntityPlayer.getHeldItem");
                    Method method2 = MappingUtils.getMethod("EntityPlayer.setItemInUse");
                    if (method != null && method2 != null && object2 != null) {
                        method.setAccessible(true);
                        method2.setAccessible(true);
                        Object object3 = method.invoke(object2, new Object[0]);
                        if (object3 != null) {
                            method2.invoke(object2, object3, 72000);
                        }
                    }
                }
            }
            catch (Throwable throwable) {}
        }
        catch (Throwable throwable) {
            Logger.kaWarn("attackEntity EXCEPTION: " + throwable.getClass().getSimpleName() + " -> " + throwable.getMessage());
            Logger.warn("KillAura attack failed: " + throwable.getMessage());
        }
    }

    private Object createC02(Object object) {
        try {
            if (object == null) {
                return null;
            }
            Class<?> clazz = MappingUtils.get("C02PacketUseEntity");
            Class<?> clazz2 = MappingUtils.get("C02PacketUseEntityAction");
            if (clazz != null && clazz2 != null) {
                for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                    Class<?>[] classArray = constructor.getParameterTypes();
                    if (classArray.length != 2 || classArray[1] != clazz2) continue;
                    constructor.setAccessible(true);
                    Object object2 = this.getAttackEnum(clazz2);
                    return constructor.newInstance(object, object2);
                }
                Object obj = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                Field field = this.findPrivateIntField(clazz);
                Field field2 = this.getFieldByType(clazz, clazz2);
                if (field != null && field2 != null) {
                    field.setAccessible(true);
                    field2.setAccessible(true);
                    field.setInt(obj, this.getId(object));
                    field2.set(obj, this.getAttackEnum(clazz2));
                    return obj;
                }
                return null;
            }
            return null;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private Object getAttackEnum(Class<?> clazz) throws Exception {
        Field field = clazz.getField("ATTACK");
        field.setAccessible(true);
        return field.get(null);
    }

    private float[] getRotationsTo(Object object) {
        Object object2 = this.getThePlayer();
        if (object2 != null && object != null) {
            double d = this.getPosX(object2);
            double d2 = this.getPosY(object2) + this.getEyeHeight(object2);
            double d3 = this.getPosZ(object2);
            double d4 = this.getPosX(object);
            double d5 = this.getEyeHeight(object);
            double d6 = this.getPosZ(object);
            double d7 = (Double)this.aimPoint.getValue();
            double d8 = this.getPosY(object) + d5 * d7 * 2.0 * 0.9;
            double d9 = d4 - d;
            double d10 = d8 - d2;
            double d11 = d6 - d3;
            double d12 = Math.sqrt(d9 * d9 + d11 * d11);
            float f = (float)Math.toDegrees(Math.atan2(d11, d9)) - 90.0f;
            float f2 = (float)(-Math.toDegrees(Math.atan2(d10, d12)));
            return new float[]{f, f2};
        }
        return null;
    }

    private float smoothAngle(float f, float f2, float f3) {
        float f4;
        for (f4 = f2 - f; f4 > 180.0f; f4 -= 360.0f) {
        }
        while (f4 < -180.0f) {
            f4 += 360.0f;
        }
        float f5 = f4 * f3;
        return f + (f5 += (float)(this.rand.nextGaussian() * 0.4));
    }

    private boolean applyRotation(Object object) {
        if (!((Boolean)this.rotationEnabled.getValue()).booleanValue()) {
            return true;
        }
        float[] fArray = this.getRotationsTo(object);
        if (fArray == null) {
            return true;
        }
        float f = fArray[0];
        float f2 = fArray[1];
        if (f2 > 90.0f) {
            f2 = 90.0f;
        }
        if (f2 < -90.0f) {
            f2 = -90.0f;
        }
        if (!this.rotationInitialized) {
            Object object2 = this.getThePlayer();
            if (object2 != null) {
                this.lastYaw = this.getPlayerRotationYaw(object2);
                this.lastPitch = this.getPlayerRotationPitch(object2);
            }
            this.rotationInitialized = true;
        }
        float f3 = ((Double)this.rotationSpeed.getValue()).floatValue();
        float f4 = this.smoothAngle(this.lastYaw, f, f3);
        float f5 = this.smoothAngle(this.lastPitch, f2, f3);
        float f6 = this.getGCDFix();
        float f7 = f4 - this.lastYaw;
        float f8 = f5 - this.lastPitch;
        f4 = this.lastYaw + KillAuraModule.snapToGCD(f7, f6);
        f5 = this.lastPitch + KillAuraModule.snapToGCD(f8, f6);
        this.lastYaw = f4;
        this.lastPitch = f5;
        boolean bl = "Silent".equals(this.rotationMode.getValue());
        boolean isBodyMode = "Body".equals(this.rotationMode.getValue());
        if (isBodyMode) {
            float jitterStrength = ((Double)this.bodyJitter.getValue()).floatValue();
            if (jitterStrength > 0.0f) {
                this.jitterPhase += (float)(this.rand.nextDouble() * 0.7 + 0.3);
                float noise1 = (float)(Math.sin(this.jitterPhase * 1.7) * Math.cos(this.jitterPhase * 0.9));
                float noise2 = (float)(Math.sin(this.jitterPhase * 2.3 + 1.1) * Math.cos(this.jitterPhase * 1.3));
                float targetJY = noise1 * jitterStrength * 0.5f;
                float targetJP = noise2 * jitterStrength * 0.25f;
                float jSmooth = 0.35f + (float)this.rand.nextDouble() * 0.3f;
                this.jitterYawAccum = this.jitterYawAccum + (targetJY - this.jitterYawAccum) * jSmooth;
                this.jitterPitchAccum = this.jitterPitchAccum + (targetJP - this.jitterPitchAccum) * jSmooth;
                f4 += this.jitterYawAccum;
                f5 += this.jitterPitchAccum;
                if (f5 > 90.0f) f5 = 90.0f;
                if (f5 < -90.0f) f5 = -90.0f;
            }
        }
        if (bl) {
            this.isRotatingSilently = true;
            this.silentYaw = f4;
            this.silentPitch = f5;
            this.sendSilentRotation(f4, f5);
            try {
                Object object3 = this.getThePlayer();
                if (object3 != null) {
                    Field field = MappingUtils.getField("EntityLivingBase.rotationYawHead");
                    Field field2 = MappingUtils.getField("EntityLivingBase.renderYawOffset");
                    if (field != null) {
                        field.setAccessible(true);
                        field.setFloat(object3, f4);
                    }
                    if (field2 != null) {
                        field2.setAccessible(true);
                        field2.setFloat(object3, f4);
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            float f9 = KillAuraModule.angleDiff(f4, f);
            float f10 = KillAuraModule.angleDiff(f5, f2);
            return f9 < 45.0f && f10 < 30.0f;
        }
        this.setPlayerRotation(f4, f5);
        float f11 = KillAuraModule.angleDiff(f4, f);
        float f12 = KillAuraModule.angleDiff(f5, f2);
        return f11 < 25.0f && f12 < 20.0f;
    }

    private static float snapToGCD(float f, float f2) {
        return (float)Math.round(f / f2) * f2;
    }

    private float getGCDFix() {
        float f = 0.5f;
        float f2 = f * 0.6f + 0.2f;
        return f2 * f2 * f2 * 1.2f;
    }

    private static float angleDiff(float f, float f2) {
        float f3 = Math.abs(f - f2) % 360.0f;
        return f3 > 180.0f ? 360.0f - f3 : f3;
    }

    private double getEyeHeight(Object object) {
        try {
            Method method = MappingUtils.getMethod("Entity.getEyeHeight");
            if (method != null) {
                method.setAccessible(true);
                return ((Number)method.invoke(object, new Object[0])).doubleValue();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 1.62;
    }

    private float getPlayerRotationYaw(Object object) {
        try {
            Field field = MappingUtils.getField("Entity.rotationYaw");
            if (field != null) {
                field.setAccessible(true);
                return field.getFloat(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0.0f;
    }

    private float getPlayerRotationPitch(Object object) {
        try {
            Field field = MappingUtils.getField("Entity.rotationPitch");
            if (field != null) {
                field.setAccessible(true);
                return field.getFloat(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0.0f;
    }

    private void setPlayerRotation(float f, float f2) {
        try {
            Object object = this.getThePlayer();
            if (object == null) {
                return;
            }
            Field field = MappingUtils.getField("Entity.rotationYaw");
            Field field2 = MappingUtils.getField("Entity.rotationPitch");
            if (field != null) {
                field.setAccessible(true);
                field.setFloat(object, f);
            }
            if (field2 != null) {
                field2.setAccessible(true);
                field2.setFloat(object, f2);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void sendSilentRotation(float f, float f2) {
        try {
            Class<?> clazz = MappingUtils.get("C05PacketPlayerLook");
            if (clazz != null) {
                Object object = this.getThePlayer();
                boolean bl = this.isOnGround(object);
                Object obj = clazz.getConstructor(Float.TYPE, Float.TYPE, Boolean.TYPE).newInstance(Float.valueOf(f), Float.valueOf(f2), bl);
                this.sendPacket(obj);
                return;
            }
            Class<?> clazz2 = MappingUtils.get("C03PacketPlayer");
            if (clazz2 != null) {
                Object obj = clazz2.getConstructor(new Class[0]).newInstance(new Object[0]);
                Field field = MappingUtils.getField("C03PacketPlayer.yaw");
                Field field2 = MappingUtils.getField("C03PacketPlayer.pitch");
                Field field3 = MappingUtils.getField("C03PacketPlayer.onGround");
                if (field != null && field2 != null) {
                    field.setAccessible(true);
                    field2.setAccessible(true);
                    field.setFloat(obj, f);
                    field2.setFloat(obj, f2);
                    if (field3 != null) {
                        field3.setAccessible(true);
                        Object object = this.getThePlayer();
                        field3.setBoolean(obj, this.isOnGround(object));
                    }
                    this.sendPacket(obj);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private boolean isOnGround(Object object) {
        try {
            Field field = MappingUtils.getField("Entity.onGround");
            if (field != null) {
                field.setAccessible(true);
                return field.getBoolean(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return true;
    }

    private void sendSwing() {
        try {
            Method method = MappingUtils.getMethod("EntityPlayerSP.swingItem");
            Object object = this.getThePlayer();
            if (method != null && object != null) {
                method.setAccessible(true);
                method.invoke(object, new Object[0]);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void sendPacket(Object object) {
        try {
            Object object2 = this.getNetHandler();
            Method method = MappingUtils.getMethod("NetHandlerPlayClient.sendPacket");
            if (object != null && object2 != null && method != null) {
                method.setAccessible(true);
                method.invoke(object2, object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private Object getCurrentScreen() {
        try {
            Object object = this.getMinecraft();
            Field field = MappingUtils.getField("Minecraft.currentScreen");
            if (object != null && field != null) {
                field.setAccessible(true);
                return field.get(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private Object getNetHandler() {
        try {
            Field field = MappingUtils.getField("EntityPlayerSP.sendQueue");
            Object object = this.getThePlayer();
            if (field != null && object != null) {
                field.setAccessible(true);
                return field.get(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private int getId(Object object) {
        if (object == null) {
            return -1;
        }
        try {
            Method method = object.getClass().getMethod("hashCode", new Class[0]);
            return (Integer)method.invoke(object, new Object[0]);
        }
        catch (Throwable throwable) {
            return object.hashCode();
        }
    }

    private double distanceTo(Object object) {
        Object object2;
        if (object == null) {
            return Double.MAX_VALUE;
        }
        try {
            object2 = MappingUtils.getMethod("Entity.getDistanceToEntity");
            Object object3 = this.getThePlayer();
            if (object2 != null && object3 != null) {
                ((Method)object2).setAccessible(true);
                return ((Number)((Method)object2).invoke(object3, object)).doubleValue();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        object2 = this.getThePlayer();
        if (object2 == null) {
            return Double.MAX_VALUE;
        }
        double d = this.getPosX(object2) - this.getPosX(object);
        double d2 = this.getPosY(object2) - this.getPosY(object);
        double d3 = this.getPosZ(object2) - this.getPosZ(object);
        return Math.sqrt(d * d + d2 * d2 + d3 * d3);
    }

    private double getPosX(Object object) {
        return this.getDoubleField(object, "Entity.posX", 0, 1.0);
    }

    private double getPosY(Object object) {
        return this.getDoubleField(object, "Entity.posY", 1, 1.0);
    }

    private double getPosZ(Object object) {
        return this.getDoubleField(object, "Entity.posZ", 2, 1.0);
    }

    private double getDoubleField(Object object, String string, int n, double object2) {
        Object object3;
        if (object == null) {
            return object2;
        }
        try {
            object3 = MappingUtils.getField(string);
            if (object3 != null) {
                ((Field)object3).setAccessible(true);
                return ((Field)object3).getDouble(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        object3 = this.parseEntityPosition(object);
        double[] posArr = (double[])object3;
        return posArr == null ? object2 : posArr[n];
    }

    private double[] parseEntityPosition(Object object) {
        try {
            Matcher matcher = POSITION_PATTERN.matcher(String.valueOf(object));
            if (matcher.find()) {
                return new double[]{Double.parseDouble(matcher.group(1).replace(",", ".")), Double.parseDouble(matcher.group(2).replace(",", ".")), Double.parseDouble(matcher.group(3).replace(",", "."))};
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private double[] getEntityPos(Object object) {
        double[] dArray;
        if (object == null) {
            dArray = null;
        } else {
            double[] dArray2 = new double[3];
            dArray2[0] = this.getPosX(object);
            dArray2[1] = this.getPosY(object);
            dArray = dArray2;
            dArray2[2] = this.getPosZ(object);
        }
        return dArray;
    }

    private float getHealth(Object object) {
        Object object2;
        block15: {
            if (object == null) {
                return this.prevHealthFallback;
            }
            try {
                object2 = MappingUtils.getField("Entity.dataWatcher");
                Method methodArray = (Method)MappingUtils.getMethod("DataWatcher.getFloat");
                if (object2 != null && methodArray != null) {
                    Object object3;
                    ((Field)object2).setAccessible(true);
                    methodArray.setAccessible(true);
                    Object object4 = ((Field)object2).get(object);
                    if (object4 != null && (object3 = methodArray.invoke(object4, 25)) instanceof Number) {
                        float f2 = ((Number)object3).floatValue() / 571.875f;
                        if (f2 > 0.0f) {
                            this.prevHealthFallback = f2;
                            return f2;
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (!this.getHealthCached) {
                this.getHealthCached = true;
                try {
                    object2 = MappingUtils.get("AbstractClientPlayer");
                    if (object2 == null) break block15;
                    for (Method method : ((Class)object2).getDeclaredMethods()) {
                        if (method.getParameterCount() != 0 || method.getReturnType() != Float.TYPE || (method.getModifiers() & 8) != 0) continue;
                        method.setAccessible(true);
                        this.cachedGetHealthMethod = method;
                        break;
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
        if (this.cachedGetHealthMethod != null) {
            try {
                object2 = this.cachedGetHealthMethod.invoke(object, new Object[0]);
                if (object2 instanceof Number) {
                    float f = ((Number)object2).floatValue();
                    if (f > 0.0f) {
                        this.prevHealthFallback = f;
                    }
                    return f;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return this.prevHealthFallback;
    }

    private String getName(Object object) {
        return MinecraftMapper.getName(object);
    }

    private boolean isInvisible(Object object) {
        try {
            Method method = MappingUtils.getMethod("Entity.getFlag");
            if (method != null && object != null) {
                method.setAccessible(true);
                Object object2 = method.invoke(object, 5);
                if (object2 instanceof Boolean) {
                    return (Boolean)object2;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return false;
    }

    private boolean isPlayerMoving(Object object) {
        return this.getEntityVelocity(object) > 1.0E-4;
    }

    private double getEntityVelocity(Object object) {
        double d = this.getMotion(object, "Entity.motionX");
        double d2 = this.getMotion(object, "Entity.motionY");
        double d3 = this.getMotion(object, "Entity.motionZ");
        return Math.sqrt(d * d + d2 * d2 + d3 * d3) * (double)this.playerMovementFactor;
    }

    private double getMotion(Object object, String string) {
        try {
            Field field = MappingUtils.getField(string);
            Method method = MappingUtils.getMethod("MotionContainer.getDoubleValue");
            if (field != null && method != null && object != null) {
                field.setAccessible(true);
                Object object2 = field.get(object);
                if (object2 != null) {
                    method.setAccessible(true);
                    return ((Number)method.invoke(object2, new Object[0])).doubleValue();
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0.0;
    }

    private void storeEntityPos(Object object) {
        double[] dArray = this.getEntityPos(object);
        if (dArray != null) {
            this.lastEntityPos.put(object, dArray);
        }
    }

    private void rememberAttack(long l) {
        this.lastAttackTimes.add(l);
        while (this.lastAttackTimes.size() > 40) {
            this.lastAttackTimes.remove(0);
        }
        this.rhythmMemory.addLast(l);
        while (this.rhythmMemory.size() > 20) {
            this.rhythmMemory.removeFirst();
        }
    }

    private Field findPrivateIntField(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            int n = field.getModifiers();
            if (field.getType() != Integer.TYPE || Modifier.isStatic(n)) continue;
            return field;
        }
        return null;
    }

    private Field getFieldByType(Class<?> clazz, Class<?> clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private long timeSince(long l) {
        return System.currentTimeMillis() - l;
    }

    private double jitter(double d) {
        return this.patternRandom.nextGaussian() * d;
    }

    private double lerp(double d, double d2, double d3) {
        return d + d3 * (d2 - d);
    }

    private double clamp(double d, double d2, double d3) {
        return Math.max(d2, Math.min(d3, d));
    }

    private float clamp(float f, float f2, float f3) {
        return Math.max(f2, Math.min(f3, f));
    }

    private String stripColor(String string) {
        return string == null ? "" : string.replaceAll("(?i)\\u00A7.", "");
    }

    public void onRender3D(float f) {
        if (this.isEnabled()) {
            Object object;
            if (((Boolean)this.rangeCircle.getValue()).booleanValue()) {
                this.renderRangeCircle(f);
            }
            if ((object = this.closestTarget) != null) {
                if (((Boolean)this.targetMarker.getValue()).booleanValue()) {
                    this.renderTargetMarker(object, f);
                }
                if (((Boolean)this.tracer.getValue()).booleanValue()) {
                    this.renderTracer(object, f);
                }
            }
        }
    }

    private void glMono(float f, float f2) {
        GL11.glColor4f((float)f, (float)f, (float)(f + 0.02f), (float)f2);
    }

    private void pushVisualState() {
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
    }

    private void drawGroundRing(double d, float f, float f2, float f3, int n) {
        GL11.glBegin((int)2);
        this.glMono(f2, f3);
        for (int i = 0; i <= 360; i += n) {
            double d2 = Math.toRadians(i);
            GL11.glVertex3d((double)(Math.cos(d2) * d), (double)f, (double)(Math.sin(d2) * d));
        }
        GL11.glEnd();
    }

    private void drawCornerBrackets(float f, float f2, float f3, float f4, float f5, float f6) {
        this.drawRoundedCornerBrackets(f, f2, f3, f4, f4 * 0.28f, f5, f6);
    }

    private void drawRoundedCornerBrackets(float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        float f8 = Math.min(f5, f4 * 0.45f);
        GL11.glBegin((int)3);
        this.glMono(f6, f7);
        this.drawBracketL(-f, -f2, f3, f4, f8, 1.0f, 1.0f);
        GL11.glEnd();
        GL11.glBegin((int)3);
        this.glMono(f6, f7);
        this.drawBracketL(f, -f2, f3, f4, f8, -1.0f, 1.0f);
        GL11.glEnd();
        GL11.glBegin((int)3);
        this.glMono(f6, f7);
        this.drawBracketL(-f, f2, f3, f4, f8, 1.0f, -1.0f);
        GL11.glEnd();
        GL11.glBegin((int)3);
        this.glMono(f6, f7);
        this.drawBracketL(f, f2, f3, f4, f8, -1.0f, -1.0f);
        GL11.glEnd();
    }

    private void drawBracketL(float f, float f2, float f3, float f4, float f5, float f6, float f7) {
        GL11.glVertex3d((double)(f + f6 * f4), (double)f3, (double)f2);
        GL11.glVertex3d((double)(f + f6 * f5), (double)f3, (double)f2);
        float f8 = f + f6 * f5;
        float f9 = f2 + f7 * f5;
        double d = f7 > 0.0f ? 4.71238898038469 : 1.5707963267948966;
        double d2 = f6 > 0.0f ? Math.PI : 0.0;
        double d3 = d2 - d;
        if (d3 > Math.PI) {
            d3 -= Math.PI * 2;
        } else if (d3 < -Math.PI) {
            d3 += Math.PI * 2;
        }
        for (int i = 0; i <= 5; ++i) {
            double d4 = (double)i / 5.0;
            double d5 = d + d3 * d4;
            GL11.glVertex3d((double)((double)f8 + Math.cos(d5) * (double)f5), (double)f3, (double)((double)f9 + Math.sin(d5) * (double)f5));
        }
        GL11.glVertex3d((double)f, (double)f3, (double)(f2 + f7 * f4));
    }

    private void drawHorizontalRing(float f, float f2, float f3, float f4, float f5, float f6, int n) {
        GL11.glBegin((int)2);
        this.glMono(f5, f6);
        for (int i = 0; i < n; ++i) {
            double d = Math.PI * 2 * (double)i / (double)n;
            GL11.glVertex3d((double)((double)f + Math.cos(d) * (double)f4), (double)f3, (double)((double)f2 + Math.sin(d) * (double)f4));
        }
        GL11.glEnd();
    }

    private void renderTargetMarker(Object object, float f) {
        double[] dArray = MappingUtils.getInterpolatedPos(object, f);
        double d = MappingUtils.getRenderPosX();
        double d2 = MappingUtils.getRenderPosY();
        double d3 = MappingUtils.getRenderPosZ();
        float f2 = MappingUtils.getEyeHeight(object) + 0.18f;
        if (f2 < 1.0f) {
            f2 = 1.8f;
        }
        float f3 = 2400.0f;
        float f4 = (float)(System.currentTimeMillis() % (long)f3) / f3;
        float f5 = f4 < 0.5f ? f4 * 2.0f : 2.0f - f4 * 2.0f;
        float f6 = f5 * f5 * (3.0f - 2.0f * f5);
        float f7 = 0.08f;
        float f8 = f2 - 0.12f;
        float f9 = f7 + (f8 - f7) * f6;
        this.pushVisualState();
        GL11.glPushMatrix();
        GL11.glTranslated((double)(dArray[0] - d), (double)(dArray[1] - d2), (double)(dArray[2] - d3));
        float f10 = 0.42f;
        float f11 = 0.16f;
        GL11.glLineWidth((float)1.4f);
        this.drawCornerBrackets(f10, f10, f9, f11, 0.96f, 0.92f);
        GL11.glLineWidth((float)1.0f);
        this.drawHorizontalRing(0.0f, 0.0f, f9, f10 * 0.58f, 0.78f, 0.55f, 24);
        GL11.glLineWidth((float)0.8f);
        this.drawHorizontalRing(0.0f, 0.0f, f9, f10 * 0.14f, 0.52f, 0.45f, 16);
        GL11.glPopMatrix();
        GL11.glPopAttrib();
    }

    private void renderTracer(Object object, float f) {
        Object object2 = this.getThePlayer();
        if (object2 != null) {
            double[] dArray = MappingUtils.getInterpolatedPos(object2, f);
            double[] dArray2 = MappingUtils.getInterpolatedPos(object, f);
            double d = MappingUtils.getRenderPosX();
            double d2 = MappingUtils.getRenderPosY();
            double d3 = MappingUtils.getRenderPosZ();
            float f2 = 1.62f;
            float f3 = 1.62f;
            double d4 = dArray[0];
            double d5 = dArray[1] + (double)f2;
            double d6 = dArray[2];
            double d7 = dArray2[0];
            double d8 = dArray2[1] + (double)f3 / 2.0;
            double d9 = dArray2[2];
            this.pushVisualState();
            GL11.glPushMatrix();
            GL11.glTranslated((double)(-d), (double)(-d2), (double)(-d3));
            GL11.glLineWidth((float)2.2f);
            GL11.glBegin((int)1);
            this.glMono(0.1f, 0.28f);
            GL11.glVertex3d((double)d4, (double)d5, (double)d6);
            GL11.glVertex3d((double)d7, (double)d8, (double)d9);
            GL11.glEnd();
            GL11.glLineWidth((float)1.0f);
            GL11.glBegin((int)1);
            this.glMono(0.96f, 0.72f);
            GL11.glVertex3d((double)d4, (double)d5, (double)d6);
            GL11.glVertex3d((double)d7, (double)d8, (double)d9);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glPopAttrib();
        }
    }

    private void renderRangeCircle(float f) {
        Object object = this.getThePlayer();
        if (object != null) {
            double d;
            double d2;
            double d3;
            int n;
            double[] dArray = MappingUtils.getInterpolatedPos(object, f);
            double d4 = MappingUtils.getRenderPosX();
            double d5 = MappingUtils.getRenderPosY();
            double d6 = MappingUtils.getRenderPosZ();
            double d7 = (Double)this.range.getValue();
            double d8 = (double)(System.currentTimeMillis() % 4000L) / 4000.0 * Math.PI * 2.0;
            double d9 = (double)(-(System.currentTimeMillis() % 6000L)) / 6000.0 * Math.PI * 2.0;
            this.pushVisualState();
            GL11.glPushMatrix();
            GL11.glTranslated((double)(dArray[0] - d4), (double)(dArray[1] - d5), (double)(dArray[2] - d6));
            GL11.glBegin((int)5);
            for (n = 0; n <= 360; n += 4) {
                d3 = Math.toRadians(n);
                d2 = Math.cos(d3) * d7;
                d = Math.sin(d3) * d7;
                this.glMono(0.78f, 0.1f);
                GL11.glVertex3d((double)d2, (double)0.02, (double)d);
                this.glMono(0.78f, 0.0f);
                GL11.glVertex3d((double)d2, (double)0.38, (double)d);
            }
            GL11.glEnd();
            GL11.glLineWidth((float)1.0f);
            this.drawGroundRing(d7, 0.03f, 0.96f, 0.88f, 4);
            GL11.glLineWidth((float)0.6f);
            this.drawGroundRing(d7 * 0.94, 0.025f, 0.52f, 0.35f, 6);
            GL11.glLineWidth((float)1.0f);
            GL11.glBegin((int)1);
            for (n = 0; n < 4; ++n) {
                d3 = d8 + 0.7853981633974483 + (double)n * 1.5707963267948966;
                d2 = Math.cos(d3);
                d = Math.sin(d3);
                double d10 = d7 * 0.98;
                double d11 = d7 + 0.32;
                this.glMono(0.96f, 0.75f);
                GL11.glVertex3d((double)(d2 * d10), (double)0.03, (double)(d * d10));
                GL11.glVertex3d((double)(d2 * d11), (double)0.03, (double)(d * d11));
            }
            GL11.glEnd();
            GL11.glLineWidth((float)1.2f);
            int n2 = 8;
            int n3 = 6;
            d = Math.toRadians(18.0);
            for (int i = 0; i < n2; ++i) {
                double d12 = d9 + (double)i * (Math.PI * 2 / (double)n2);
                GL11.glBegin((int)3);
                this.glMono(0.96f, 0.5f);
                for (int j = 0; j <= n3; ++j) {
                    double d13 = d12 + d * (double)j / (double)n3;
                    double d14 = d7 + 0.06;
                    GL11.glVertex3d((double)(Math.cos(d13) * d14), (double)0.03, (double)(Math.sin(d13) * d14));
                }
                GL11.glEnd();
            }
            GL11.glPopMatrix();
            GL11.glPopAttrib();
        }
    }

    private void initC03Fields() {
        if (c03Yaw != null) {
            return;
        }
        try {
            c03Yaw = MappingUtils.getField("C03PacketPlayer.yaw");
            c03Pitch = MappingUtils.getField("C03PacketPlayer.pitch");
            Class<?> clazz = MappingUtils.get("C03PacketPlayer");
            if (clazz != null) {
                c03Rotating = KillAuraModule.getRotatingField(clazz);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static Field getRotatingField(Class<?> clazz) {
        block4: {
            if (rotatingField != null) {
                return rotatingField;
            }
            try {
                Class<?> clazz2 = MappingUtils.get("C05PacketPlayerLook");
                if (clazz2 == null) break block4;
                Constructor<?> constructor = clazz2.getConstructor(Float.TYPE, Float.TYPE, Boolean.TYPE);
                constructor.setAccessible(true);
                Object obj = constructor.newInstance(Float.valueOf(0.0f), Float.valueOf(0.0f), false);
                Field field = MappingUtils.getField("C03PacketPlayer.onGround");
                for (Field field2 : clazz.getDeclaredFields()) {
                    if (field2.getType() != Boolean.TYPE || Modifier.isStatic(field2.getModifiers()) || field != null && field2.getName().equals(field.getName())) continue;
                    field2.setAccessible(true);
                    boolean bl = field2.getBoolean(obj);
                    if (!bl) continue;
                    rotatingField = field2;
                    break;
                }
            }
            catch (Throwable throwable) {
                Logger.kaWarn("Failed to find rotating field dynamically: " + throwable.getMessage());
            }
        }
        return rotatingField;
    }

    private void handlePacketSend(PacketSendEvent packetSendEvent) {
        if (!this.isEnabled() || !this.isRotatingSilently) {
            return;
        }
        try {
            Object object = packetSendEvent.getPacket();
            if (object == null) {
                return;
            }
            Class<?> clazz = MappingUtils.get("C03PacketPlayer");
            if (clazz == null || !clazz.isInstance(object)) {
                return;
            }
            this.initC03Fields();
            if (c03Yaw != null) {
                c03Yaw.setAccessible(true);
                c03Yaw.setFloat(object, this.silentYaw);
            }
            if (c03Pitch != null) {
                c03Pitch.setAccessible(true);
                c03Pitch.setFloat(object, this.silentPitch);
            }
            if (c03Rotating != null) {
                c03Rotating.setAccessible(true);
                c03Rotating.setBoolean(object, true);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

