/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.GL11
 */
package me.ries.module.impl;

import java.awt.Color;
import java.lang.reflect.Field;
import java.nio.Buffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render3DEvent;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.AimBotModule;
import me.ries.module.impl.KillAuraModule;
import me.ries.module.impl.TPAuraModule;
import me.ries.setting.ColorOption;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.MappingUtils;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class TargetIndicatorModule
extends Module {
    private final StringOption mode = new StringOption("Mode", "Cylinder", this, "Cylinder", "Diamond");
    private final NumberOption heightOffset = new NumberOption("Height", 2.6, 0.5, 5.0, 0.1, this);
    private final NumberOption size = new NumberOption("Radius/Size", 0.65, 0.2, 1.5, 0.05, this);
    private final NumberOption cylinderHeight = new NumberOption("CylinderHeight", 0.35, 0.1, 1.0, 0.05, this);
    private final NumberOption bobSpeed = new NumberOption("BobSpeed", 2.5, 0.5, 5.0, 0.1, this);
    private final ColorOption customColor = new ColorOption("Color", new Color(0, 240, 255, 180), (Module)this);
    private final FloatBuffer modelView = BufferUtils.createFloatBuffer((int)16);
    private final FloatBuffer projection = BufferUtils.createFloatBuffer((int)16);
    private final IntBuffer viewport = BufferUtils.createIntBuffer((int)16);
    private boolean matricesCached = false;
    private Object lastTarget = null;
    private long lastTargetTime = 0L;

    public TargetIndicatorModule() {
        super("TargetIndicator", "Visual 3D target indicator (Cylinder or Diamond)", Category.RENDER, 0);
        this.mode.setGroup("Visual");
        this.heightOffset.setGroup("Visual");
        this.size.setGroup("Visual");
        this.cylinderHeight.setGroup("Visual");
        this.bobSpeed.setGroup("Visual");
        this.customColor.setGroup("Visual");
        this.addOptions(this.mode, this.heightOffset, this.size, this.cylinderHeight, this.bobSpeed, this.customColor);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    TargetIndicatorModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
    }

    @Override
    public void onEnable() {
        this.lastTarget = null;
        this.matricesCached = false;
    }

    @Override
    public void onDisable() {
        this.lastTarget = null;
    }

    @Override
    public void onUpdate() {
    }

    private void onRender3D(float f) {
        if (this.isEnabled()) {
            double[] dArray;
            Object object;
            boolean bl;
            ((Buffer)this.modelView).clear();
            ((Buffer)this.projection).clear();
            ((Buffer)this.viewport).clear();
            GL11.glGetFloat((int)2982, (FloatBuffer)this.modelView);
            GL11.glGetFloat((int)2983, (FloatBuffer)this.projection);
            GL11.glGetInteger((int)2978, (IntBuffer)this.viewport);
            this.matricesCached = true;
            Object object2 = this.resolveTarget();
            if (object2 != null) {
                this.lastTarget = object2;
                this.lastTargetTime = System.currentTimeMillis();
            }
            boolean bl2 = bl = this.lastTarget != null && System.currentTimeMillis() - this.lastTargetTime < 200L;
            Object object3 = object2 != null ? object2 : (object = bl ? this.lastTarget : null);
            if (object != null && (dArray = MappingUtils.getInterpolatedPos(object, f)) != null) {
                double d = MappingUtils.getRenderPosX();
                double d2 = MappingUtils.getRenderPosY();
                double d3 = MappingUtils.getRenderPosZ();
                double d4 = dArray[0] - d;
                double d5 = dArray[1] - d2;
                double d6 = dArray[2] - d3;
                GL11.glPushAttrib((int)1048575);
                GL11.glPushMatrix();
                GL11.glDisable((int)3553);
                GL11.glDisable((int)2896);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glDisable((int)2929);
                GL11.glDepthMask((boolean)false);
                GL11.glDisable((int)2884);
                GL11.glShadeModel((int)7425);
                GL11.glTranslated((double)d4, (double)d5, (double)d6);
                if ("Cylinder".equals(this.mode.getValue())) {
                    this.drawCylinderIndicator(object);
                } else {
                    long l = System.currentTimeMillis();
                    float f2 = (float)(l % 3000L) / 3000.0f * 360.0f;
                    float f3 = (float)Math.sin((double)l / 600.0) * 0.07f;
                    GL11.glTranslated((double)0.0, (double)(((Double)this.heightOffset.getValue()).floatValue() + f3), (double)0.0);
                    GL11.glRotatef((float)f2, (float)0.0f, (float)1.0f, (float)0.0f);
                    this.drawDiamond(((Double)this.size.getValue()).floatValue());
                }
                GL11.glDepthMask((boolean)true);
                GL11.glEnable((int)2929);
                GL11.glEnable((int)3553);
                GL11.glPopMatrix();
                GL11.glPopAttrib();
            }
        }
    }

    private double getEntityHeight(Object object) {
        try {
            Field field = MappingUtils.getField("Entity.height");
            if (field != null) {
                field.setAccessible(true);
                return field.getFloat(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 1.8;
    }

    private void drawCylinderIndicator(Object object) {
        double d;
        double d2;
        double d3;
        int n;
        double d4 = this.getEntityHeight(object);
        double d5 = (Double)this.size.getValue();
        double d6 = (Double)this.cylinderHeight.getValue();
        double d7 = (Double)this.bobSpeed.getValue();
        long l = System.currentTimeMillis();
        double d8 = (double)l * 0.001 * d7;
        double d9 = (Math.sin(d8) + 1.0) / 2.0;
        double d10 = d9 * (d4 - d6);
        int n2 = 40;
        Color color = (Color)this.customColor.getValue();
        float f = (float)color.getRed() / 255.0f;
        float f2 = (float)color.getGreen() / 255.0f;
        float f3 = (float)color.getBlue() / 255.0f;
        float f4 = (float)color.getAlpha() / 255.0f;
        double d11 = d10 + d6 / 2.0;
        double d12 = d10 + d6;
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)1.5f);
        GL11.glBegin((int)8);
        for (n = 0; n <= n2; ++n) {
            d3 = (double)n * (Math.PI * 2) / (double)n2;
            d2 = Math.cos(d3) * d5;
            d = Math.sin(d3) * d5;
            GL11.glColor4f((float)f, (float)f2, (float)f3, (float)(f4 * 0.45f));
            GL11.glVertex3d((double)d2, (double)d11, (double)d);
            GL11.glColor4f((float)f, (float)f2, (float)f3, (float)0.0f);
            GL11.glVertex3d((double)d2, (double)d12, (double)d);
        }
        GL11.glEnd();
        GL11.glBegin((int)8);
        for (n = 0; n <= n2; ++n) {
            d3 = (double)n * (Math.PI * 2) / (double)n2;
            d2 = Math.cos(d3) * d5;
            d = Math.sin(d3) * d5;
            GL11.glColor4f((float)f, (float)f2, (float)f3, (float)0.0f);
            GL11.glVertex3d((double)d2, (double)d10, (double)d);
            GL11.glColor4f((float)f, (float)f2, (float)f3, (float)(f4 * 0.45f));
            GL11.glVertex3d((double)d2, (double)d11, (double)d);
        }
        GL11.glEnd();
        GL11.glBegin((int)3);
        for (n = 0; n <= n2; ++n) {
            d3 = (double)n * (Math.PI * 2) / (double)n2;
            d2 = Math.cos(d3) * d5;
            d = Math.sin(d3) * d5;
            GL11.glColor4f((float)f, (float)f2, (float)f3, (float)(f4 * 0.9f));
            GL11.glVertex3d((double)d2, (double)d11, (double)d);
        }
        GL11.glEnd();
    }

    private void drawDiamond(float f) {
        double d;
        int n;
        float f2 = f * 0.5f;
        float f3 = f;
        float f4 = f * 0.4f;
        float f5 = f * 1.2f;
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)1.0f);
        GL11.glColor4f((float)0.96f, (float)0.96f, (float)0.98f, (float)0.85f);
        GL11.glBegin((int)2);
        for (n = 0; n < 8; ++n) {
            d = Math.toRadians(n * 45);
            GL11.glVertex3d((double)(Math.cos(d) * (double)f3), (double)0.0, (double)(Math.sin(d) * (double)f3));
        }
        GL11.glEnd();
        GL11.glBegin((int)2);
        for (n = 0; n < 8; ++n) {
            d = Math.toRadians(n * 45);
            GL11.glVertex3d((double)(Math.cos(d) * (double)f2), (double)f4, (double)(Math.sin(d) * (double)f2));
        }
        GL11.glEnd();
        GL11.glBegin((int)1);
        for (n = 0; n < 8; ++n) {
            d = Math.toRadians(n * 45);
            GL11.glVertex3d((double)(Math.cos(d) * (double)f2), (double)f4, (double)(Math.sin(d) * (double)f2));
            GL11.glVertex3d((double)(Math.cos(d) * (double)f3), (double)0.0, (double)(Math.sin(d) * (double)f3));
        }
        GL11.glEnd();
        GL11.glBegin((int)1);
        for (n = 0; n < 8; ++n) {
            d = Math.toRadians(n * 45);
            GL11.glVertex3d((double)(Math.cos(d) * (double)f3), (double)0.0, (double)(Math.sin(d) * (double)f3));
            GL11.glVertex3d((double)0.0, (double)(-f5), (double)0.0);
        }
        GL11.glEnd();
    }

    private Object resolveTarget() {
        Object object;
        Object object2;
        Object object3;
        KillAuraModule killAuraModule = Ries.getInstance().getModuleManager().getModule(KillAuraModule.class);
        if (killAuraModule != null && killAuraModule.isEnabled() && (object3 = killAuraModule.getClosestTarget()) != null) {
            return object3;
        }
        TPAuraModule tPAuraModule = Ries.getInstance().getModuleManager().getModule(TPAuraModule.class);
        if (tPAuraModule != null && tPAuraModule.isEnabled() && (object2 = tPAuraModule.getHudTarget()) != null) {
            return object2;
        }
        AimBotModule aimBotModule = Ries.getInstance().getModuleManager().getModule(AimBotModule.class);
        if (aimBotModule != null && aimBotModule.isEnabled() && (object = aimBotModule.getLockedTarget()) != null) {
            return object;
        }
        return null;
    }
}

