/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.awt.Color;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.ColorOption;

public class WatermarkModule
extends Module {
    private final ColorOption color1 = new ColorOption("Color 1", new Color(255, 75, 145, 255), (Module)this);
    private final ColorOption color2 = new ColorOption("Color 2", new Color(155, 93, 229, 255), (Module)this);

    public WatermarkModule() {
        super("Watermark", "Displays client watermark and information", Category.RENDER, 0);
        this.color1.setGroup("Visuals");
        this.color2.setGroup("Visuals");
        this.addOptions(this.color1, this.color2);
    }

    public Color getColor1() {
        return (Color)this.color1.getValue();
    }

    public Color getColor2() {
        return (Color)this.color2.getValue();
    }

    public Color getAccentColor() {
        return this.getColor1();
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
    }
}

