/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Random;
import me.ries.Ries;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.FlyModule;
import me.ries.module.impl.FriendManagerModule;
import me.ries.module.impl.KillAuraModule;
import me.ries.module.impl.VClipDownModule;
import me.ries.setting.NumberOption;
import me.ries.setting.OptionBase;
import me.ries.setting.TextOption;
import me.ries.util.ChatUtils;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class BotModule
extends Module {
    private final TextOption targetName = new TextOption("Target", "", (Module)this);
    private final NumberOption followRange = new NumberOption("FollowRange", 3.0, 1.0, 10.0, 0.5, this);
    private final NumberOption combatRange = new NumberOption("CombatRange", 6.0, 2.0, 10.0, 0.5, this);
    private final NumberOption protectRange = new NumberOption("ProtectRange", 30.0, 5.0, 50.0, 1.0, this);
    private boolean autoEnabledKa = false;
    private boolean autoEnabledFly = false;
    private final Random rand = new Random();
    private int strafeDir = 1;
    private long lastStrafeChange = 0L;
    private static final long STRAFE_INTERVAL = 600L;
    private boolean isAiming = false;
    private static final float AIM_THRESHOLD = 18.0f;
    private double lastPosX = 0.0;
    private double lastPosZ = 0.0;
    private long lastStuckCheck = 0L;
    private int stuckCounter = 0;
    private static final long STUCK_CHECK_MS = 400L;
    private boolean wasDead = false;
    private long respawnTime = 0L;
    private boolean respawnFlyOpened = false;
    private static final long RESPAWN_FLY_DURATION = 8000L;
    private int blockHitTicks = 0;
    private Object currentEnemyTarget = null;
    private boolean isEatingGap = false;
    private int eatingTicks = 0;
    private int originalSlot = 0;

    public BotModule() {
        super("Bot", "Follows target. Auto Fly+KillAura. Smart obstacle VClip, blockhit, auto gap & respawn.", Category.MOD, 0);
        this.targetName.setGroup("Behavior");
        this.followRange.setGroup("Behavior");
        this.combatRange.setGroup("Behavior");
        this.protectRange.setGroup("Behavior");
        this.addOptions(this.targetName, this.followRange, this.combatRange, this.protectRange);
    }

    @Override
    public void onEnable() {
        this.autoEnabledKa = false;
        this.autoEnabledFly = false;
        this.strafeDir = 1;
        this.lastStrafeChange = System.currentTimeMillis();
        this.lastStuckCheck = System.currentTimeMillis();
        this.stuckCounter = 0;
        this.wasDead = false;
        this.respawnFlyOpened = false;
        this.isAiming = false;
        this.blockHitTicks = 0;
        this.currentEnemyTarget = null;
        this.isEatingGap = false;
        this.eatingTicks = 0;
        try {
            FlyModule flyModule = this.getFly();
            if (flyModule != null && !flyModule.isEnabled()) {
                flyModule.enable();
                this.autoEnabledFly = true;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        ChatUtils.addChatMessage("\u00a77[Bot] \u00a7aAktif. Hedef: \u00a7f" + this.getTargetStr());
    }

    @Override
    public void onDisable() {
        this.disableIfWeEnabled();
        ChatUtils.addChatMessage("\u00a77[Bot] \u00a7cKapat\u0131ld\u0131.");
    }

    @Override
    public void onUpdate() {
        try {
            Object object = this.getThePlayer();
            if (object == null) {
                return;
            }
            if (this.getCurrentScreen() != null) {
                return;
            }
            FlyModule flyModule = this.getFly();
            if (flyModule != null && !flyModule.isEnabled()) {
                flyModule.enable();
                this.autoEnabledFly = true;
            }
            this.handleRespawn(object);
            String string = this.getTargetStr();
            Object object2 = string.isEmpty() ? null : this.findPlayerByName(string);
            Object object3 = this.getClosestEnemy(object, object2);
            boolean bl = object3 != null;
            KillAuraModule killAuraModule = this.getKillAura();
            this.handleAutoGap(object);
            if (!this.isEatingGap) {
                this.stickToGround(object, object2, object3);
            }
            boolean bl2 = false;
            if (this.isEatingGap) {
                if (killAuraModule != null && killAuraModule.isEnabled()) {
                    killAuraModule.disable();
                }
                return;
            }
            if (bl) {
                boolean bl3;
                boolean bl4 = this.aimAtEnemy(object, object3);
                boolean bl5 = bl3 = bl4 || killAuraModule != null && killAuraModule.isEnabled();
                if (bl3) {
                    this.isAiming = false;
                    if (killAuraModule != null && !killAuraModule.isEnabled()) {
                        killAuraModule.enable();
                        this.autoEnabledKa = true;
                        ChatUtils.addChatMessage("\u00a77[Bot] \u00a7eKillAura a\u00e7\u0131ld\u0131 (kitlendi).");
                    }
                } else {
                    this.isAiming = true;
                }
                if (this.isAiming) {
                    this.moveTowards(object, object3);
                } else if (flyModule != null && flyModule.isEnabled()) {
                    this.combatMove(object, object3);
                } else {
                    this.moveTowards(object, object3);
                }
                bl2 = true;
            } else {
                double d;
                double d2;
                this.isAiming = false;
                if (this.autoEnabledKa && killAuraModule != null && killAuraModule.isEnabled()) {
                    killAuraModule.disable();
                    this.autoEnabledKa = false;
                    ChatUtils.addChatMessage("\u00a77[Bot] \u00a7cKillAura kapat\u0131ld\u0131.");
                }
                if (object2 != null && (d2 = this.distanceBetween(object, object2)) > (d = ((Double)this.followRange.getValue()).doubleValue())) {
                    this.moveTowards(object, object2);
                    bl2 = true;
                }
            }
            if (killAuraModule != null && killAuraModule.isEnabled() && killAuraModule.getClosestTarget() != null) {
                this.doProperBlockHit(object);
            }
            if (bl2) {
                this.checkAndJumpObstacle(object);
            }
        }
        catch (Throwable throwable) {
            Logger.warn("[Bot] hata: " + throwable.getMessage());
        }
    }

    private void handleAutoGap(Object object) {
        try {
            Field field;
            int n;
            Field field2 = MappingUtils.getField("InventoryPlayer.currentItem");
            Field field3 = MappingUtils.getField("EntityPlayer.inventory");
            if (field2 == null || field3 == null) {
                return;
            }
            field2.setAccessible(true);
            field3.setAccessible(true);
            Object object2 = field3.get(object);
            if (object2 == null) {
                return;
            }
            float f = MappingUtils.getEntityHealth(object);
            int n2 = this.getHurtTime(object);
            String string = this.getTargetStr();
            Object object3 = string.isEmpty() ? null : this.findPlayerByName(string);
            Object object4 = this.getClosestEnemy(object, object3);
            boolean bl = false;
            boolean bl2 = false;
            if (object4 != null) {
                double d = this.distanceBetween(object, object4);
                if (d <= 7.0) {
                    bl = true;
                }
                if (d <= 3.5) {
                    bl2 = true;
                }
            }
            if (this.isEatingGap) {
                if (n2 > 0 || bl2) {
                    this.isEatingGap = false;
                    this.eatingTicks = 0;
                    this.sendReleaseUseItem();
                    field2.setInt(object2, this.originalSlot);
                    ChatUtils.addChatMessage("\u00a77[Bot] \u00a7cHasar al\u0131nd\u0131 veya d\u00fc\u015fman \u00e7ok yak\u0131nda! Gap yeme iptal edildi, sava\u015fa d\u00f6n\u00fcl\u00fcyor.");
                    return;
                }
                ++this.eatingTicks;
                if (this.eatingTicks > 35) {
                    this.isEatingGap = false;
                    this.eatingTicks = 0;
                    field2.setInt(object2, this.originalSlot);
                    ChatUtils.addChatMessage("\u00a77[Bot] \u00a7aAlt\u0131n elma yendi.");
                } else {
                    Field field4 = MappingUtils.getField("InventoryPlayer.mainInventory");
                    if (field4 != null) {
                        Method method;
                        field4.setAccessible(true);
                        Object[] objectArray = (Object[])field4.get(object2);
                        int n3 = field2.getInt(object2);
                        Object object5 = objectArray[n3];
                        if (object5 != null && (method = MappingUtils.getMethod("EntityPlayer.setItemInUse")) != null) {
                            method.setAccessible(true);
                            method.invoke(object, object5, 72000);
                        }
                    }
                }
            } else if (f > 0.0f && f <= 12.0f && n2 == 0 && !bl && (n = this.findGapSlot(object)) != -1 && (field = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                field.setAccessible(true);
                Object[] objectArray = (Object[])field.get(object2);
                Object object6 = objectArray[n];
                if (object6 != null) {
                    Class<?> clazz;
                    Constructor<?> constructor;
                    int n4 = field2.getInt(object2);
                    field2.setInt(object2, n);
                    Class<?> clazz2 = MappingUtils.get("C08PacketPlayerBlockPlacement");
                    if (clazz2 != null && (constructor = clazz2.getConstructor(clazz = MappingUtils.get("ItemStack"))) != null) {
                        constructor.setAccessible(true);
                        Object obj = constructor.newInstance(object6);
                        this.sendPacket(obj);
                    }
                    this.isEatingGap = true;
                    this.eatingTicks = 0;
                    this.originalSlot = n4;
                    ChatUtils.addChatMessage("\u00a77[Bot] \u00a7eG\u00fcvenli b\u00f6lge, can d\u00fc\u015f\u00fck (" + String.format("%.1f", Float.valueOf(f)) + "). Alt\u0131n elma yeniyor...");
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    /*
     * WARNING - void declaration
     */
    private void sendReleaseUseItem() {
        try {
            Class<?> clazz = MappingUtils.get("C07PacketPlayerDigging");
            Class<?> clazz2 = MappingUtils.get("C07PacketPlayerDigging.Action");
            Class<?> clazz3 = MappingUtils.get("BlockPos");
            Class<?> clazz4 = MappingUtils.get("EnumFacing");
            if (clazz != null && clazz2 != null && clazz3 != null && clazz4 != null) {
                void var6_10;
                Object obj;
                Object var5_6 = null;
                for (Object obj2 : clazz2.getEnumConstants()) {
                    if (!"RELEASE_USE_ITEM".equals(obj2.toString())) continue;
                    var5_6 = obj2;
                    break;
                }
                Object var6_8 = null;
                Object object = clazz4.getEnumConstants();
                int n = ((?[])object).length;
                for (int i = 0; i < n; ++i) {
                    obj = object[i];
                    if (!"DOWN".equals(obj.toString())) continue;
                    Object obj3 = obj;
                    break;
                }
                if ((object = clazz3.getConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE)) != null && var5_6 != null && var6_10 != null) {
                    ((Constructor)object).setAccessible(true);
                    Object t = ((Constructor)object).newInstance(0, 0, 0);
                    Constructor<?> constructor = clazz.getConstructor(clazz2, clazz3, clazz4);
                    if (constructor != null) {
                        constructor.setAccessible(true);
                        obj = constructor.newInstance(var5_6, t, var6_10);
                        this.sendPacket(obj);
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private int findGapSlot(Object object) {
        try {
            Field field = MappingUtils.getField("EntityPlayer.inventory");
            if (field != null) {
                Field field2;
                field.setAccessible(true);
                Object object2 = field.get(object);
                if (object2 != null && (field2 = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                    field2.setAccessible(true);
                    Object[] objectArray = (Object[])field2.get(object2);
                    if (objectArray != null) {
                        for (int i = 0; i < 9; ++i) {
                            String string;
                            String string2;
                            Object object3 = objectArray[i];
                            if (object3 == null || (string2 = MappingUtils.getItemName(object3)) == null || !(string = string2.toLowerCase()).contains("applegold") && !string.contains("goldenapple") && !string.contains("aelma")) continue;
                            return i;
                        }
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return -1;
    }

    private void stickToGround(Object object, Object object2, Object object3) {
        try {
            double d;
            double d2;
            double d3;
            double d4;
            double d5;
            double d6;
            double d7;
            Field field = MappingUtils.getField("Entity.posX");
            Field field2 = MappingUtils.getField("Entity.posY");
            Field field3 = MappingUtils.getField("Entity.posZ");
            if (field == null || field2 == null || field3 == null) {
                return;
            }
            field.setAccessible(true);
            field2.setAccessible(true);
            field3.setAccessible(true);
            double d8 = MinecraftMapper.getPosX();
            double d9 = MinecraftMapper.getPosY();
            double d10 = MinecraftMapper.getPosZ();
            int n = (int)Math.floor(d8);
            int n2 = (int)Math.floor(d9);
            int n3 = (int)Math.floor(d10);
            int n4 = this.getBlockIdAt(n, n2 - 1, n3);
            if (n4 != 0) {
                return;
            }
            int n5 = this.getBlockIdAt(n, n2 - 4, n3);
            if (n5 != 0) {
                return;
            }
            if (object3 != null && (d7 = Math.sqrt((d6 = d8 - (d5 = field.getDouble(object3))) * d6 + (d4 = d10 - (d3 = field3.getDouble(object3))) * d4)) <= 4.0 && (d2 = d9 - (d = field2.getDouble(object3))) > 0.3) {
                this.doVClipDown(d2);
                ChatUtils.addChatMessage("\u00a77[Bot] \u00a7eVClip Down (D\u00fc\u015fman Y hizas\u0131: " + String.format("%.2f", d2) + "b).");
                return;
            }
            if (object2 != null && (d7 = Math.sqrt((d6 = d8 - (d5 = field.getDouble(object2))) * d6 + (d4 = d10 - (d3 = field3.getDouble(object2))) * d4)) <= 4.0 && (d2 = d9 - (d = field2.getDouble(object2))) > 0.8) {
                this.doVClipDown(d2);
                ChatUtils.addChatMessage("\u00a77[Bot] \u00a7eVClip Down (Arkada\u015f Y hizas\u0131: " + String.format("%.2f", d2) + "b).");
                return;
            }
            int n6 = this.getGroundY(n, n2 - 1, n3);
            double d11 = d9 - (double)n6;
            if (n6 > 0 && d11 > 0.5) {
                this.doVClipDown(d11);
                ChatUtils.addChatMessage("\u00a77[Bot] \u00a7eVClip Down (Zemin hizas\u0131: " + String.format("%.2f", d11) + "b).");
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void doVClipDown(double d) {
        try {
            VClipDownModule vClipDownModule = Ries.getInstance().getModuleManager().getModule(VClipDownModule.class);
            if (vClipDownModule != null) {
                Method method;
                OptionBase<?> optionBase = vClipDownModule.getOption("Blocks");
                if (optionBase != null) {
                    optionBase.setValue(d);
                }
                if ((method = vClipDownModule.getClass().getDeclaredMethod("doVClip", new Class[0])) != null) {
                    method.setAccessible(true);
                    method.invoke((Object)vClipDownModule, new Object[0]);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private int getBlockIdAt(int n, int n2, int n3) {
        try {
            Object object = MappingUtils.getWorldObj();
            if (object == null) {
                return 0;
            }
            Method method = MappingUtils.getMethod("World.getChunkFromChunkCoords");
            if (method == null) {
                return 0;
            }
            Object object2 = method.invoke(object, n >> 4, n3 >> 4);
            if (object2 == null) {
                return 0;
            }
            Method method2 = MappingUtils.getMethod("Chunk.getBlock");
            if (method2 == null) {
                return 0;
            }
            Object object3 = method2.invoke(object2, n & 0xF, n2, n3 & 0xF);
            if (object3 == null) {
                return 0;
            }
            Method method3 = MappingUtils.getMethod("Block.getIdFromBlock");
            if (method3 != null) {
                return (Integer)method3.invoke(null, object3);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0;
    }

    private int getGroundY(int n, int n2, int n3) {
        for (int i = n2; i > 0; --i) {
            int n4 = this.getBlockIdAt(n, i, n3);
            if (n4 == 0) continue;
            return i + 1;
        }
        return 0;
    }

    private void handleRespawn(Object object) {
        try {
            Module module;
            boolean bl;
            float f = MappingUtils.getEntityHealth(object);
            boolean bl2 = bl = f <= 0.0f;
            if (bl && !this.wasDead) {
                this.wasDead = true;
                this.respawnFlyOpened = false;
                ChatUtils.addChatMessage("\u00a77[Bot] \u00a7c\u00d6ld\u00fcn! Respawn bekleniyor...");
                if (this.autoEnabledKa) {
                    module = this.getKillAura();
                    if (module != null) {
                        module.disable();
                    }
                    this.autoEnabledKa = false;
                }
                if (this.autoEnabledFly) {
                    module = this.getFly();
                    if (module != null) {
                        module.disable();
                    }
                    this.autoEnabledFly = false;
                }
            } else if (!bl && this.wasDead) {
                this.wasDead = false;
                this.respawnTime = System.currentTimeMillis();
                ChatUtils.addChatMessage("\u00a77[Bot] \u00a7aRespawn! Hedef aran\u0131yor...");
                module = this.getFly();
                if (module != null && !module.isEnabled()) {
                    module.enable();
                    this.autoEnabledFly = true;
                    this.respawnFlyOpened = true;
                    ChatUtils.addChatMessage("\u00a77[Bot] \u00a7eFly a\u00e7\u0131ld\u0131 (respawn).");
                }
            }
            if (this.respawnFlyOpened && !this.wasDead && System.currentTimeMillis() - this.respawnTime > 8000L) {
                Object object2;
                module = this.getFly();
                String string = this.getTargetStr();
                Object object3 = object2 = string.isEmpty() ? null : this.findPlayerByName(string);
                if (object2 != null && this.distanceBetween(object, object2) <= (Double)this.followRange.getValue() * 2.0 && this.autoEnabledFly && module != null && module.isEnabled()) {
                    module.disable();
                    this.autoEnabledFly = false;
                    this.respawnFlyOpened = false;
                    ChatUtils.addChatMessage("\u00a77[Bot] \u00a7cFly kapat\u0131ld\u0131 (hedefe ula\u015f\u0131ld\u0131).");
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void checkAndJumpObstacle(Object object) {
        try {
            long l = System.currentTimeMillis();
            if (l - this.lastStuckCheck < 400L) {
                return;
            }
            this.lastStuckCheck = l;
            double d = MinecraftMapper.getPosX();
            double d2 = MinecraftMapper.getPosY();
            double d3 = MinecraftMapper.getPosZ();
            double d4 = Math.sqrt((d - this.lastPosX) * (d - this.lastPosX) + (d3 - this.lastPosZ) * (d3 - this.lastPosZ));
            if (d4 < 0.18) {
                ++this.stuckCounter;
                double d5 = 1.25;
                if (this.stuckCounter == 2) {
                    d5 = 2.25;
                } else if (this.stuckCounter == 3) {
                    d5 = 3.25;
                } else if (this.stuckCounter >= 4) {
                    d5 = 4.25;
                    this.stuckCounter = 0;
                }
                double d6 = d2 + d5;
                Method method = MappingUtils.getMethod("Entity.setPositionAndUpdate");
                if (method != null) {
                    method.setAccessible(true);
                    method.invoke(object, d, d6, d3);
                    MinecraftMapper.setMotionY(0.0);
                    MinecraftMapper.setFallDistance(0.0f);
                    Logger.info("[Bot] Stuck! Vclipped up by " + d5 + " to Y: " + d6);
                }
            } else {
                this.stuckCounter = 0;
            }
            this.lastPosX = d;
            this.lastPosZ = d3;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void moveTowards(Object object, Object object2) {
        block12: {
            try {
                float f;
                Field field = MappingUtils.getField("Entity.posX");
                Field field2 = MappingUtils.getField("Entity.posZ");
                Field field3 = MappingUtils.getField("Entity.rotationYaw");
                if (field == null || field2 == null || field3 == null) {
                    return;
                }
                field.setAccessible(true);
                field2.setAccessible(true);
                field3.setAccessible(true);
                double d = field.getDouble(object2) - field.getDouble(object);
                double d2 = field2.getDouble(object2) - field2.getDouble(object);
                float f2 = (float)(Math.toDegrees(Math.atan2(d2, d)) - 90.0);
                float f3 = field3.getFloat(object);
                for (f = f2 - f3; f > 180.0f; f -= 360.0f) {
                }
                while (f < -180.0f) {
                    f += 360.0f;
                }
                float f4 = f3 + f * 0.6f;
                field3.setFloat(object, f4);
                FlyModule flyModule = this.getFly();
                if (flyModule != null && flyModule.isEnabled()) {
                    double d3 = this.getFlySpeed(flyModule);
                    double d4 = Math.toRadians(f4);
                    double d5 = 0.65;
                    MinecraftMapper.setMotionX(MinecraftMapper.getMotionX() * d5 + -Math.sin(d4) * d3 * (1.0 - d5));
                    MinecraftMapper.setMotionZ(MinecraftMapper.getMotionZ() * d5 + Math.cos(d4) * d3 * (1.0 - d5));
                    Field field4 = MappingUtils.getField("Entity.posY");
                    if (field4 != null) {
                        field4.setAccessible(true);
                        double d6 = field4.getDouble(object2) - field4.getDouble(object);
                        if (Math.abs(d6) > 1.5) {
                            MinecraftMapper.setMotionY(d6 * 0.15);
                        }
                    }
                    break block12;
                }
                try {
                    Field field5 = MappingUtils.getField("EntityPlayerSP.moveForward");
                    if (field5 == null) {
                        field5 = MappingUtils.getField("EntityPlayer.moveForward");
                    }
                    if (field5 != null) {
                        field5.setAccessible(true);
                        field5.setFloat(object, 0.98f);
                    }
                }
                catch (Throwable throwable) {}
            }
            catch (Throwable throwable) {
                Logger.warn("[Bot] moveTowards hata: " + throwable.getMessage());
            }
        }
    }

    private void combatMove(Object object, Object object2) {
        try {
            Field field = MappingUtils.getField("Entity.posX");
            Field field2 = MappingUtils.getField("Entity.posZ");
            Field field3 = MappingUtils.getField("Entity.rotationYaw");
            if (field == null || field2 == null || field3 == null) {
                return;
            }
            field.setAccessible(true);
            field2.setAccessible(true);
            field3.setAccessible(true);
            float f = field3.getFloat(object);
            if (object2 != null) {
                float f2;
                double d = field.getDouble(object2) - field.getDouble(object);
                double d2 = field2.getDouble(object2) - field2.getDouble(object);
                float f3 = (float)(Math.toDegrees(Math.atan2(d2, d)) - 90.0);
                for (f2 = f3 - f; f2 > 180.0f; f2 -= 360.0f) {
                }
                while (f2 < -180.0f) {
                    f2 += 360.0f;
                }
                field3.setFloat(object, f += f2 * 0.55f);
            }
            FlyModule flyModule = this.getFly();
            double d = this.getFlySpeed(flyModule);
            double d3 = Math.toRadians(f);
            double d4 = -Math.sin(d3) * d * 0.9;
            double d5 = Math.cos(d3) * d * 0.9;
            long l = System.currentTimeMillis();
            if (l - this.lastStrafeChange >= 600L) {
                if (this.rand.nextDouble() < 0.6) {
                    this.strafeDir = -this.strafeDir;
                }
                this.lastStrafeChange = l;
            }
            double d6 = d3 + (double)this.strafeDir * 1.5707963267948966;
            double d7 = -Math.sin(d6) * d * 0.6;
            double d8 = Math.cos(d6) * d * 0.6;
            double d9 = 0.6;
            MinecraftMapper.setMotionX(MinecraftMapper.getMotionX() * d9 + (d4 + d7) * (1.0 - d9));
            MinecraftMapper.setMotionZ(MinecraftMapper.getMotionZ() * d9 + (d5 + d8) * (1.0 - d9));
            double d10 = MinecraftMapper.getMotionY();
            if (d10 < -0.02) {
                MinecraftMapper.setMotionY(d10 * 0.7);
            }
        }
        catch (Throwable throwable) {
            Logger.warn("[Bot] combatMove hata: " + throwable.getMessage());
        }
    }

    /*
     * WARNING - void declaration
     */
    private void doProperBlockHit(Object object) {
        try {
            Method method = MappingUtils.getMethod("EntityPlayer.getHeldItem");
            if (method == null || object == null) {
                return;
            }
            method.setAccessible(true);
            Object object2 = method.invoke(object, new Object[0]);
            if (object2 == null) {
                return;
            }
            Class<?> clazz = MappingUtils.get("ItemSword");
            Object object3 = MappingUtils.getMethod("ItemStack.getItem").invoke(object2, new Object[0]);
            if (clazz == null || !clazz.isInstance(object3)) {
                return;
            }
            ++this.blockHitTicks;
            if (this.blockHitTicks % 2 == 0) {
                Class<?> clazz2 = MappingUtils.get("C07PacketPlayerDigging");
                Class<?> clazz3 = MappingUtils.get("C07PacketPlayerDigging.Action");
                Class<?> clazz4 = MappingUtils.get("BlockPos");
                Class<?> clazz5 = MappingUtils.get("EnumFacing");
                if (clazz2 != null && clazz3 != null && clazz4 != null && clazz5 != null) {
                    void var11_20;
                    Object obj;
                    Object var10_15 = null;
                    for (Object obj2 : clazz3.getEnumConstants()) {
                        if (!"RELEASE_USE_ITEM".equals(obj2.toString())) continue;
                        var10_15 = obj2;
                        break;
                    }
                    Object var11_18 = null;
                    Object object4 = clazz5.getEnumConstants();
                    int n = ((?[])object4).length;
                    for (int i = 0; i < n; ++i) {
                        obj = object4[i];
                        if (!"DOWN".equals(obj.toString())) continue;
                        Object obj3 = obj;
                        break;
                    }
                    if ((object4 = clazz4.getConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE)) != null && var10_15 != null && var11_20 != null) {
                        ((Constructor)object4).setAccessible(true);
                        Object t = ((Constructor)object4).newInstance(0, 0, 0);
                        Constructor<?> constructor = clazz2.getConstructor(clazz3, clazz4, clazz5);
                        if (constructor != null) {
                            constructor.setAccessible(true);
                            obj = constructor.newInstance(var10_15, t, var11_20);
                            this.sendPacket(obj);
                        }
                    }
                }
            } else {
                Class<?> clazz6;
                Constructor<?> constructor;
                Class<?> clazz7;
                Method method2 = MappingUtils.getMethod("EntityPlayer.setItemInUse");
                if (method2 != null) {
                    method2.setAccessible(true);
                    method2.invoke(object, object2, 72000);
                }
                if ((clazz7 = MappingUtils.get("C08PacketPlayerBlockPlacement")) != null && (constructor = clazz7.getConstructor(clazz6 = MappingUtils.get("ItemStack"))) != null) {
                    constructor.setAccessible(true);
                    Object obj = constructor.newInstance(object2);
                    this.sendPacket(obj);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void sendPacket(Object object) {
        try {
            Object object2 = this.getNetHandler();
            Method method = MappingUtils.getMethod("NetHandlerPlayClient.sendPacket");
            if (object != null && object2 != null && method != null) {
                method.setAccessible(true);
                method.invoke(object2, object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private Object getNetHandler() {
        try {
            Field field = MappingUtils.getField("EntityPlayerSP.sendQueue");
            Object object = this.getThePlayer();
            if (field != null && object != null) {
                field.setAccessible(true);
                return field.get(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private Object getClosestEnemy(Object object, Object object2) {
        try {
            double d;
            if (object2 == null) {
                this.currentEnemyTarget = null;
                return null;
            }
            double d2 = this.distanceBetween(object, object2);
            if (d2 > (d = ((Double)this.protectRange.getValue()).doubleValue())) {
                this.currentEnemyTarget = null;
                return null;
            }
            double d3 = (Double)this.combatRange.getValue();
            if (this.currentEnemyTarget != null) {
                double d4;
                boolean bl = false;
                try {
                    for (Object object3 : MinecraftMapper.getPlayerEntitiesInWorld()) {
                        if (object3 != this.currentEnemyTarget) continue;
                        bl = true;
                        break;
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                if (bl && !FriendManagerModule.isFriend(this.currentEnemyTarget) && this.isValidCombatTarget(this.currentEnemyTarget) && MappingUtils.getEntityHealth(this.currentEnemyTarget) > 0.0f && (d4 = this.distanceBetween(object2, this.currentEnemyTarget)) <= d) {
                    return this.currentEnemyTarget;
                }
            }
            this.currentEnemyTarget = null;
            Object object4 = null;
            double d5 = d3 + 1.0;
            for (Object object5 : MinecraftMapper.getPlayerEntitiesInWorld()) {
                double d6;
                if (object5 == object || FriendManagerModule.isFriend(object5) || object5 == object2 || !this.isValidCombatTarget(object5) || !((d6 = this.distanceBetween(object2, object5)) <= d3) || !(d6 < d5)) continue;
                d5 = d6;
                object4 = object5;
            }
            this.currentEnemyTarget = object4;
            return object4;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private boolean aimAtEnemy(Object object, Object object2) {
        try {
            float f;
            float f2;
            Field field = MappingUtils.getField("Entity.posX");
            Field field2 = MappingUtils.getField("Entity.posY");
            Field field3 = MappingUtils.getField("Entity.posZ");
            Field field4 = MappingUtils.getField("Entity.rotationYaw");
            Field field5 = MappingUtils.getField("Entity.rotationPitch");
            if (field == null || field2 == null || field3 == null || field4 == null) {
                return false;
            }
            field.setAccessible(true);
            field2.setAccessible(true);
            field3.setAccessible(true);
            field4.setAccessible(true);
            if (field5 != null) {
                field5.setAccessible(true);
            }
            double d = field.getDouble(object);
            double d2 = field2.getDouble(object) + 1.62;
            double d3 = field3.getDouble(object);
            double d4 = field.getDouble(object2);
            double d5 = field2.getDouble(object2) + 0.9;
            double d6 = field3.getDouble(object2);
            double d7 = d4 - d;
            double d8 = d5 - d2;
            double d9 = d6 - d3;
            double d10 = Math.sqrt(d7 * d7 + d9 * d9);
            float f3 = (float)(Math.toDegrees(Math.atan2(d9, d7)) - 90.0);
            float f4 = (float)(-Math.toDegrees(Math.atan2(d8, d10)));
            float f5 = field4.getFloat(object);
            float f6 = field5 != null ? field5.getFloat(object) : 0.0f;
            for (f2 = f3 - f5; f2 > 180.0f; f2 -= 360.0f) {
            }
            while (f2 < -180.0f) {
                f2 += 360.0f;
            }
            float f7 = f4 - f6;
            float f8 = 0.55f;
            float f9 = f5 + f2 * f8;
            float f10 = f6 + f7 * f8;
            f10 = Math.max(-90.0f, Math.min(90.0f, f10));
            field4.setFloat(object, f9);
            if (field5 != null) {
                field5.setFloat(object, f10);
            }
            return (f = Math.abs(f2) * (1.0f - f8)) < 18.0f;
        }
        catch (Throwable throwable) {
            Logger.warn("[Bot] aimAtEnemy hata: " + throwable.getMessage());
            return false;
        }
    }

    private int getHurtTime(Object object) {
        try {
            Field field = MappingUtils.getField("EntityLivingBase.hurtTime");
            if (field != null) {
                field.setAccessible(true);
                return field.getInt(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0;
    }

    private void disableIfWeEnabled() {
        Module module;
        try {
            module = this.getKillAura();
            if (this.autoEnabledKa && module != null && module.isEnabled()) {
                module.disable();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            module = this.getFly();
            if (this.autoEnabledFly && module != null && module.isEnabled()) {
                module.disable();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        this.autoEnabledKa = false;
        this.autoEnabledFly = false;
    }

    private KillAuraModule getKillAura() {
        try {
            return Ries.getInstance().getModuleManager().getModule(KillAuraModule.class);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private FlyModule getFly() {
        try {
            return Ries.getInstance().getModuleManager().getModule(FlyModule.class);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private double getFlySpeed(FlyModule flyModule) {
        try {
            OptionBase<?> optionBase;
            OptionBase<?> optionBase2 = optionBase = flyModule != null ? flyModule.getOption("Speed") : null;
            if (optionBase != null && optionBase.getValue() instanceof Double) {
                return (Double)optionBase.getValue();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0.24;
    }

    private String getTargetStr() {
        Object t = this.targetName.getValue();
        return t == null ? "" : t.toString().trim();
    }

    private Object findPlayerByName(String string) {
        String string2 = string.toLowerCase();
        try {
            for (Object object : MinecraftMapper.getPlayerEntitiesInWorld()) {
                String string3 = MinecraftMapper.getName(object);
                if (string3 == null || !string3.replaceAll("\u00a7.", "").trim().toLowerCase().equals(string2)) continue;
                return object;
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private double distanceBetween(Object object, Object object2) {
        try {
            Field field = MappingUtils.getField("Entity.posX");
            Field field2 = MappingUtils.getField("Entity.posY");
            Field field3 = MappingUtils.getField("Entity.posZ");
            if (field == null || field2 == null || field3 == null) {
                return 999.0;
            }
            field.setAccessible(true);
            field2.setAccessible(true);
            field3.setAccessible(true);
            double d = field.getDouble(object) - field.getDouble(object2);
            double d2 = field2.getDouble(object) - field2.getDouble(object2);
            double d3 = field3.getDouble(object) - field3.getDouble(object2);
            return Math.sqrt(d * d + d2 * d2 + d3 * d3);
        }
        catch (Throwable throwable) {
            return 999.0;
        }
    }

    private Object getCurrentScreen() {
        try {
            Object object = this.getMinecraft();
            if (object == null) {
                return null;
            }
            Field field = MappingUtils.getField("Minecraft.currentScreen");
            if (field == null) {
                return null;
            }
            field.setAccessible(true);
            return field.get(object);
        }
        catch (Throwable throwable) {
            return null;
        }
    }
}

