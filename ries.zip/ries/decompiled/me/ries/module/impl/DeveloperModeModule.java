/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import me.ries.Ries;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.util.Logger;

public class DeveloperModeModule
extends Module {
    public DeveloperModeModule() {
        super("DeveloperMode", "Hides or shows advanced option controls", Category.MOD, 0);
    }

    @Override
    public void onEnable() {
        Logger.info("DeveloperMode enabled - all options visible");
    }

    @Override
    public void onDisable() {
        Logger.info("DeveloperMode disabled - advanced options hidden and enforced");
    }

    @Override
    public void onUpdate() {
    }

    public static boolean isDevModeActive() {
        try {
            DeveloperModeModule developerModeModule = Ries.getInstance().getModuleManager().getModule(DeveloperModeModule.class);
            return developerModeModule != null && developerModeModule.isEnabled();
        }
        catch (Throwable throwable) {
            return false;
        }
    }
}

