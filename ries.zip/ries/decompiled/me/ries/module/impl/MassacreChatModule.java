/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.TextOption;

public class MassacreChatModule
extends Module {
    public static TextOption passwordOption;
    public static BooleanOption autoFriendOption;
    public static BooleanOption hideSelfOption;

    public MassacreChatModule() {
        super("Massacre Chat", "Massacre global IRC chat integration.", Category.MOD, 0);
        passwordOption = new TextOption("Password", "", (Module)this);
        autoFriendOption = new BooleanOption("AutoFriend", true, (Module)this);
        hideSelfOption = new BooleanOption("HideSelf", false, (Module)this);
        this.addOptions(passwordOption, autoFriendOption, hideSelfOption);
    }

    public boolean getAutoFriendValue() {
        return autoFriendOption != null && (Boolean)autoFriendOption.getValue() != false;
    }

    public boolean getHideSelfValue() {
        return hideSelfOption != null && (Boolean)hideSelfOption.getValue() != false;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
    }
}

