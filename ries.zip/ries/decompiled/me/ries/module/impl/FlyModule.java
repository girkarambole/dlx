/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package me.ries.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Random;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Keyboard;

public class FlyModule
extends Module {
    private long packetHoldStartTime = 0L;
    private double[] heldPosition = null;
    private boolean isHoldingPackets = false;
    private double lastMotionX = 0.0;
    private double lastMotionY = 0.0;
    private double lastMotionZ = 0.0;
    private float simulatedFallDistance = 0.0f;
    private double lastSpeed = 0.0;
    private int tickCounter = 0;
    private long flyStartTime = 0L;
    private int flyTicks = 0;
    private double lastSentY = 0.0;
    private boolean flyInitialized = false;
    private double lastX1;
    private double lastY1;
    private double lastZ1;
    private boolean wasFlying = false;
    private final Random rand = new Random();
    private Field xFieldCache = null;
    private Field yFieldCache = null;
    private Field zFieldCache = null;

    public FlyModule() {
        super("Fly", "Fly bypass module", Category.MOVEMENT, 0);
        this.addOptions(new StringOption("Mode", "Glide", this, "Glide", "MotionPlusGlide", "Motion", "C03Cancel"), new NumberOption("Speed", 0.24, 0.1, 8.0, 0.01, this), new NumberOption("Vertical Speed", 0.22, 0.05, 5.0, 0.01, this), new BooleanOption("Disable Y", false, (Module)this), new BooleanOption("Packet Hold", true, (Module)this).setDependency("Mode:MotionPlusGlide"), new NumberOption("Hold Duration", 8.0, 1.0, 20.0, 0.5, this).setDependency("Mode:MotionPlusGlide"), new NumberOption("Teleport Speed", 0.3, 0.1, 2.0, 0.1, this).setDependency("Mode:MotionPlusGlide"));
    }

    @Override
    public String getOptionPrefix() {
        double d = this.flySpeed();
        return String.format("%.2f", d);
    }

    private String flyMode() {
        return (String)((StringOption)this.getOption("Mode")).getValue();
    }

    private double flySpeed() {
        return (Double)((NumberOption)this.getOption("Speed")).getValue();
    }

    private double flyVerticalSpeed() {
        return (Double)((NumberOption)this.getOption("Vertical Speed")).getValue();
    }

    private boolean enablePacketHold() {
        return (Boolean)((BooleanOption)this.getOption("Packet Hold")).getValue();
    }

    private boolean disableY() {
        return (Boolean)((BooleanOption)this.getOption("Disable Y")).getValue();
    }

    private double holdDuration() {
        return (Double)((NumberOption)this.getOption("Hold Duration")).getValue();
    }

    private double teleportSpeed() {
        return (Double)((NumberOption)this.getOption("Teleport Speed")).getValue();
    }

    static float degreesToRadians(float f) {
        return f * ((float)Math.PI / 180);
    }

    @Override
    public void onEnable() {
        this.flyInitialized = false;
        this.tickCounter = 0;
        this.flyTicks = 0;
        this.isHoldingPackets = false;
        this.heldPosition = null;
        this.lastSpeed = 0.0;
        this.simulatedFallDistance = 0.0f;
        this.wasFlying = false;
    }

    @Override
    public void onDisable() {
        this.flyInitialized = false;
        this.isHoldingPackets = false;
        this.heldPosition = null;
        this.wasFlying = false;
    }

    @Override
    public void onUpdate() {
        if (MinecraftMapper.getPlayer() != null) {
            switch (this.flyMode()) {
                case "Glide": {
                    this.flyGlide();
                    break;
                }
                case "MotionPlusGlide": {
                    this.flyMotionPlusGlide();
                    break;
                }
                case "Motion": {
                    this.flyMotion();
                    break;
                }
                case "C03Cancel": {
                    this.flyC03Cancel();
                }
            }
        }
    }

    private void flyGlide() {
        double d;
        if (!this.flyInitialized) {
            this.flyStartTime = System.currentTimeMillis();
            this.lastSentY = MinecraftMapper.getPosY();
            this.flyInitialized = true;
        }
        ++this.flyTicks;
        double d2 = 20.0;
        long l = 1L;
        double d3 = Math.max(0.5, d2 / 20.0);
        double d4 = 1.0 + (double)l / 100.0 * 0.1;
        double d5 = this.flySpeed() * 0.55 * d3 * d4;
        double d6 = this.flyVerticalSpeed() * 0.55 * d3 * d4;
        float f = MinecraftMapper.getRotationYaw();
        float f2 = (this.rand.nextFloat() - 0.5f) * 0.3f;
        float f3 = FlyModule.degreesToRadians(f + f2);
        double d7 = 0.0;
        double d8 = 0.0;
        double d9 = 0.0;
        if (MinecraftMapper.getCurrentScreen() == null) {
            double d10;
            if (Keyboard.isKeyDown((int)17)) {
                d10 = 1.0 + (this.rand.nextDouble() - 0.5) * 0.03;
                d7 += -Math.sin(f3) * d5 * d10;
                d9 += Math.cos(f3) * d5 * d10;
            }
            if (Keyboard.isKeyDown((int)31)) {
                d10 = 1.0 + (this.rand.nextDouble() - 0.5) * 0.03;
                d7 += Math.sin(f3) * d5 * d10;
                d9 += -Math.cos(f3) * d5 * d10;
            }
            if (Keyboard.isKeyDown((int)30)) {
                d10 = 1.0 + (this.rand.nextDouble() - 0.5) * 0.03;
                d = (double)f3 - 1.5707963267948966;
                d7 += -Math.sin(d) * d5 * d10;
                d9 += Math.cos(d) * d5 * d10;
            }
            if (Keyboard.isKeyDown((int)32)) {
                d10 = 1.0 + (this.rand.nextDouble() - 0.5) * 0.03;
                d = (double)f3 + 1.5707963267948966;
                d7 += -Math.sin(d) * d5 * d10;
                d9 += Math.cos(d) * d5 * d10;
            }
            if (Keyboard.isKeyDown((int)57)) {
                d10 = 1.0 + (this.rand.nextDouble() - 0.5) * 0.03;
                if (!this.disableY()) {
                    d8 += d6 * d10;
                }
            }
            if (Keyboard.isKeyDown((int)42)) {
                d10 = 1.0 + (this.rand.nextDouble() - 0.5) * 0.03;
                if (!this.disableY()) {
                    d8 -= d6 * d10;
                }
            }
        }
        if (!(this.disableY() || MinecraftMapper.getCurrentScreen() == null && (Keyboard.isKeyDown((int)57) || Keyboard.isKeyDown((int)42)))) {
            d8 -= 0.04;
        }
        d = 0.8;
        MinecraftMapper.setMotionX(MinecraftMapper.getMotionX() * d + d7 * (1.0 - d));
        if (!this.disableY()) {
            MinecraftMapper.setMotionY(MinecraftMapper.getMotionY() * d + d8 * (1.0 - d));
        }
        MinecraftMapper.setMotionZ(MinecraftMapper.getMotionZ() * d + d9 * (1.0 - d));
        this.lastSentY = MinecraftMapper.getPosY();
    }

    private void flyMotionPlusGlide() {
        double d;
        double d2;
        long l = System.currentTimeMillis();
        ++this.tickCounter;
        double d3 = 20.0;
        long l2 = 1L;
        double d4 = Math.max(0.3, Math.min(1.2, d3 / 20.0));
        double d5 = Math.min(1.5, 1.0 + (double)l2 / 100.0 * 0.05);
        double d6 = this.flySpeed() * d4 * d5;
        this.lastSpeed = d2 = this.lastSpeed + (d6 - this.lastSpeed) * 0.1;
        if (this.enablePacketHold() && !this.isHoldingPackets) {
            this.packetHoldStartTime = l;
            this.heldPosition = new double[]{MinecraftMapper.getPosX(), MinecraftMapper.getPosY(), MinecraftMapper.getPosZ()};
            this.isHoldingPackets = true;
            System.out.println("[Fly] Packet holding started at: " + this.heldPosition[0] + ", " + this.heldPosition[1] + ", " + this.heldPosition[2]);
        }
        float f = FlyModule.degreesToRadians(MinecraftMapper.getRotationYaw());
        float f2 = FlyModule.degreesToRadians(MinecraftMapper.getRotationPitch());
        double d7 = 0.0;
        double d8 = 0.0;
        double d9 = 0.0;
        boolean bl = false;
        boolean bl2 = false;
        if (MinecraftMapper.getCurrentScreen() == null) {
            if (Keyboard.isKeyDown((int)17)) {
                d7 += -Math.sin(f) * d2 * 0.8;
                d9 += Math.cos(f) * d2 * 0.8;
                d8 += -Math.sin(f2) * d2 * 0.15;
                bl = true;
            }
            if (Keyboard.isKeyDown((int)31)) {
                d7 += Math.sin(f) * d2 * 0.7;
                d9 += -Math.cos(f) * d2 * 0.7;
                d8 += Math.sin(f2) * d2 * 0.15;
                bl = true;
            }
            if (Keyboard.isKeyDown((int)30)) {
                d = (double)f - 1.5707963267948966;
                d7 += -Math.sin(d) * d2 * 0.7;
                d9 += Math.cos(d) * d2 * 0.7;
                bl = true;
            }
            if (Keyboard.isKeyDown((int)32)) {
                d = (double)f + 1.5707963267948966;
                d7 += -Math.sin(d) * d2 * 0.7;
                d9 += Math.cos(d) * d2 * 0.7;
                bl = true;
            }
            if (Keyboard.isKeyDown((int)57)) {
                d8 += d2 * 0.18;
                bl = true;
                bl2 = true;
            }
            if (Keyboard.isKeyDown((int)42)) {
                d8 -= d2 * 0.18;
                bl = true;
                bl2 = true;
            }
        }
        if (!bl) {
            d7 = this.lastMotionX * 0.7;
            if (!this.disableY()) {
                d8 = this.lastMotionY * 0.7;
            }
            d9 = this.lastMotionZ * 0.7;
            if (Math.abs(d7) < 0.01) {
                d7 = 0.0;
            }
            if (Math.abs(d8) < 0.01) {
                d8 = 0.0;
            }
            if (Math.abs(d9) < 0.01) {
                d9 = 0.0;
            }
        }
        d = bl2 ? 0.5 : 0.4;
        double d10 = this.lastMotionX + (d7 - this.lastMotionX) * d;
        double d11 = this.disableY() ? this.lastMotionY : this.lastMotionY + (d8 - this.lastMotionY) * d;
        double d12 = this.lastMotionZ + (d9 - this.lastMotionZ) * d;
        double d13 = this.flySpeed();
        d10 = Math.max(-d13, Math.min(d13, d10));
        d11 = Math.max(-d13, Math.min(d13, d11));
        d12 = Math.max(-d13, Math.min(d13, d12));
        MinecraftMapper.setMotionX(d10);
        if (!this.disableY()) {
            MinecraftMapper.setMotionY(d11);
        }
        MinecraftMapper.setMotionZ(d12);
        this.lastMotionX = d10;
        this.lastMotionY = d11;
        this.lastMotionZ = d12;
        this.manageFallDistance();
        if (this.tickCounter % 5 == 0) {
            // empty if block
        }
        long l3 = (long)(this.holdDuration() * 1000.0);
        if (this.enablePacketHold() && this.isHoldingPackets && l - this.packetHoldStartTime >= l3) {
            this.performSoftTeleport();
        }
        if (this.rand.nextInt(500) < 1) {
            try {
                Thread.sleep(this.rand.nextInt(3) + 1);
            }
            catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void manageFallDistance() {
        if (this.simulatedFallDistance > 0.0f) {
            this.simulatedFallDistance -= 0.05f;
            if (this.simulatedFallDistance < 0.0f) {
                this.simulatedFallDistance = 0.0f;
            }
        }
        if (this.tickCounter % 15 == 0) {
            try {
                MinecraftMapper.setFallDistance(this.simulatedFallDistance);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
    }

    private void performSoftTeleport() {
        double d = MinecraftMapper.getPosX();
        double d2 = MinecraftMapper.getPosY();
        double d3 = MinecraftMapper.getPosZ();
        double d4 = d - this.heldPosition[0];
        double d5 = d2 - this.heldPosition[1];
        double d6 = d3 - this.heldPosition[2];
        double d7 = Math.sqrt(d4 * d4 + d5 * d5 + d6 * d6);
        System.out.println("[Fly] Soft teleport - Distance: " + String.format("%.2f", d7) + " | From: " + String.format("%.1f,%.1f,%.1f", this.heldPosition[0], this.heldPosition[1], this.heldPosition[2]) + " | To: " + String.format("%.1f,%.1f,%.1f", d, d2, d3));
        if (d7 > 0.5) {
            double d8 = Math.min(this.teleportSpeed() / d7, 0.3);
            double[] dArray = this.heldPosition;
            dArray[0] = dArray[0] + d4 * d8;
            dArray = this.heldPosition;
            dArray[1] = dArray[1] + d5 * d8;
            dArray = this.heldPosition;
            dArray[2] = dArray[2] + d6 * d8;
            this.simulatedFallDistance += 0.01f;
            System.out.println("[Fly] Moving held position by " + String.format("%.2f%%", d8 * 100.0));
        } else {
            this.isHoldingPackets = false;
            this.heldPosition = null;
            System.out.println("[Fly] Packet holding released - target reached");
        }
    }

    private void flyMotion() {
        if (!this.flyInitialized) {
            this.flyStartTime = System.currentTimeMillis();
            this.lastSentY = MinecraftMapper.getPosY();
            this.flyInitialized = true;
        }
        ++this.flyTicks;
        double d = 20.0;
        long l = 1L;
        double d2 = Math.max(0.5, d / 20.0);
        double d3 = 1.0 + (double)l / 100.0 * 0.1;
        double d4 = this.flySpeed() * d2 * d3;
        float f = FlyModule.degreesToRadians(MinecraftMapper.getRotationYaw());
        double d5 = 0.0;
        double d6 = 0.0;
        double d7 = 0.0;
        if (MinecraftMapper.getCurrentScreen() == null) {
            double d8;
            if (Keyboard.isKeyDown((int)17)) {
                d5 += -Math.sin(f) * d4;
                d7 += Math.cos(f) * d4;
            }
            if (Keyboard.isKeyDown((int)31)) {
                d5 += Math.sin(f) * d4;
                d7 += -Math.cos(f) * d4;
            }
            if (Keyboard.isKeyDown((int)30)) {
                d8 = (double)f - 1.5707963267948966;
                d5 += -Math.sin(d8) * d4;
                d7 += Math.cos(d8) * d4;
            }
            if (Keyboard.isKeyDown((int)32)) {
                d8 = (double)f + 1.5707963267948966;
                d5 += -Math.sin(d8) * d4;
                d7 += Math.cos(d8) * d4;
            }
            if (Keyboard.isKeyDown((int)57)) {
                d6 += d4;
            }
            if (Keyboard.isKeyDown((int)42)) {
                d6 -= d4;
            }
        }
        if (this.flyTicks % 5 == 0) {
            MinecraftMapper.setFallDistance(0.0f);
        }
        MinecraftMapper.setMotionX(d5);
        if (!this.disableY()) {
            MinecraftMapper.setMotionY(d6);
        }
        MinecraftMapper.setMotionZ(d7);
        this.lastSentY = MinecraftMapper.getPosY();
    }

    private void flyC03Cancel() {
        Object object = MinecraftMapper.getPlayer();
        if (object != null) {
            double d;
            this.lastX1 = MinecraftMapper.getPosX(object);
            this.lastY1 = MinecraftMapper.getPosY(object);
            this.lastZ1 = MinecraftMapper.getPosZ(object);
            this.wasFlying = true;
            double d2 = 20.0;
            long l = 1L;
            double d3 = Math.max(0.8, d2 / 20.0);
            double d4 = 1.0 + (double)l * 0.002;
            double d5 = this.flySpeed() * d3 * d4;
            float f = FlyModule.degreesToRadians(MinecraftMapper.getRotationYaw());
            double d6 = 0.0;
            double d7 = 0.0;
            double d8 = 0.0;
            if (Keyboard.isKeyDown((int)17)) {
                d6 += -Math.sin(f) * d5;
                d8 += Math.cos(f) * d5;
            }
            if (Keyboard.isKeyDown((int)31)) {
                d6 += Math.sin(f) * d5;
                d8 += -Math.cos(f) * d5;
            }
            if (Keyboard.isKeyDown((int)30)) {
                d = (double)f - 1.5707963267948966;
                d6 += -Math.sin(d) * d5;
                d8 += Math.cos(d) * d5;
            }
            if (Keyboard.isKeyDown((int)32)) {
                d = (double)f + 1.5707963267948966;
                d6 += -Math.sin(d) * d5;
                d8 += Math.cos(d) * d5;
            }
            if (Keyboard.isKeyDown((int)57)) {
                d7 += d5;
            }
            if (Keyboard.isKeyDown((int)42)) {
                d7 -= d5;
            }
            MinecraftMapper.setMotionX(d6);
            if (!this.disableY()) {
                MinecraftMapper.setMotionY(d7);
            }
            MinecraftMapper.setMotionZ(d8);
            MinecraftMapper.setFallDistance(0.0f);
        }
    }

    public void onPacketSend(Object object) {
        if (this.isEnabled() && this.flyMode().equals("MotionPlusGlide") && this.enablePacketHold() && this.isHoldingPackets && this.heldPosition != null) {
            try {
                Class<?> clazz = MappingUtils.get("C03PacketPlayer");
                if (clazz == null) {
                    return;
                }
                Method method = object.getClass().getMethod("getPacket", new Class[0]);
                Object object2 = method.invoke(object, new Object[0]);
                if (!clazz.isInstance(object2)) {
                    return;
                }
                if (this.xFieldCache == null || this.yFieldCache == null || this.zFieldCache == null) {
                    this.xFieldCache = MappingUtils.getField("C03PacketPlayer.x");
                    this.yFieldCache = MappingUtils.getField("C03PacketPlayer.y");
                    this.zFieldCache = MappingUtils.getField("C03PacketPlayer.z");
                    if (this.xFieldCache != null) {
                        this.xFieldCache.setAccessible(true);
                    }
                    if (this.yFieldCache != null) {
                        this.yFieldCache.setAccessible(true);
                    }
                    if (this.zFieldCache != null) {
                        this.zFieldCache.setAccessible(true);
                    }
                }
                if (this.xFieldCache != null && this.yFieldCache != null && this.zFieldCache != null) {
                    double d = this.xFieldCache.getDouble(object2);
                    double d2 = this.yFieldCache.getDouble(object2);
                    double d3 = this.zFieldCache.getDouble(object2);
                    this.xFieldCache.setDouble(object2, this.heldPosition[0]);
                    this.yFieldCache.setDouble(object2, this.heldPosition[1]);
                    this.zFieldCache.setDouble(object2, this.heldPosition[2]);
                    if (this.tickCounter % 20 == 0) {
                        System.out.println("[Fly] Packet modified - Real: " + String.format("%.1f,%.1f,%.1f", d, d2, d3) + " | Sent: " + String.format("%.1f,%.1f,%.1f", this.heldPosition[0], this.heldPosition[1], this.heldPosition[2]));
                    }
                }
            }
            catch (Exception exception) {
                System.out.println("[Fly] Packet manipulation error: " + exception.getMessage());
            }
        }
    }

    private void setPlayerOnGroundSafe(boolean bl) {
        block8: {
            try {
                Object object = MinecraftMapper.getPlayer();
                if (object == null) {
                    return;
                }
                Field field = MappingUtils.getField("Entity.onGround");
                if (field == null) {
                    return;
                }
                field.setAccessible(true);
                Object object2 = field.get(object);
                if (object2 instanceof Boolean) {
                    field.set(object, bl);
                    break block8;
                }
                if (object2 == null) break block8;
                try {
                    Constructor<?> constructor = object2.getClass().getDeclaredConstructor(Boolean.TYPE);
                    constructor.setAccessible(true);
                    field.set(object, constructor.newInstance(bl));
                }
                catch (Throwable throwable) {
                    for (Field field2 : object2.getClass().getDeclaredFields()) {
                        if (field2.getType() != Boolean.TYPE || Modifier.isFinal(field2.getModifiers())) continue;
                        field2.setAccessible(true);
                        field2.setBoolean(object2, bl);
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }
}

