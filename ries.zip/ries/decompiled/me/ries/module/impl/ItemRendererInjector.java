/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.objectweb.asm.ClassVisitor
 *  org.objectweb.asm.ClassWriter
 *  org.objectweb.asm.Type
 *  org.objectweb.asm.tree.AbstractInsnNode
 *  org.objectweb.asm.tree.ClassNode
 *  org.objectweb.asm.tree.FieldInsnNode
 *  org.objectweb.asm.tree.InsnList
 *  org.objectweb.asm.tree.InsnNode
 *  org.objectweb.asm.tree.JumpInsnNode
 *  org.objectweb.asm.tree.LabelNode
 *  org.objectweb.asm.tree.MethodInsnNode
 *  org.objectweb.asm.tree.MethodNode
 *  org.objectweb.asm.tree.VarInsnNode
 */
package me.ries.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import me.ries.mapping.MinecraftMapper;
import me.ries.util.MappingUtils;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class ItemRendererInjector {
    private static boolean injected = false;
    private static long lastVerifyLog = 0L;

    public static void inject() {
        if (injected) {
            return;
        }
        try {
            System.out.println("[ItemAnim] === STARTING INJECTION ===");
            Object mc = MinecraftMapper.getMinecraft();
            Class<?> itemRendererClass = MappingUtils.get("ItemRenderer");
            Class<?> mcClass = MappingUtils.get("Minecraft");
            if (mc == null) {
                System.out.println("[ItemAnim] FAIL: mc is null");
                return;
            }
            if (itemRendererClass == null) {
                System.out.println("[ItemAnim] FAIL: ItemRenderer class null");
                return;
            }
            if (mcClass == null) {
                System.out.println("[ItemAnim] FAIL: Minecraft class null");
                return;
            }
            System.out.println("[ItemAnim] ItemRenderer class = " + itemRendererClass.getName());
            Object originalIR = ItemRendererInjector.getItemRendererInstance();
            if (originalIR == null) {
                System.out.println("[ItemAnim] FAIL: original IR instance null");
                return;
            }
            System.out.println("[ItemAnim] Original IR = " + originalIR.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(originalIR)));
            Method mRIFP = MappingUtils.getMethod("ItemRenderer.renderItemInFirstPerson");
            Method mRI = MappingUtils.getMethod("ItemRenderer.renderItem");
            if (mRIFP != null) {
                System.out.println("[ItemAnim] renderItemInFirstPerson: " + mRIFP.getName() + " desc=" + Type.getMethodDescriptor((Method)mRIFP));
            } else {
                System.out.println("[ItemAnim] WARN: renderItemInFirstPerson NOT mapped!");
            }
            if (mRI != null) {
                System.out.println("[ItemAnim] renderItem: " + mRI.getName() + " desc=" + Type.getMethodDescriptor((Method)mRI));
            } else {
                System.out.println("[ItemAnim] WARN: renderItem NOT mapped!");
            }
            if (mRIFP == null && mRI == null) {
                System.out.println("[ItemAnim] FAIL: no methods to hook");
                return;
            }
            Constructor<?> irCtor = ItemRendererInjector.findConstructor(itemRendererClass, mcClass);
            if (irCtor == null) {
                System.out.println("[ItemAnim] FAIL: constructor not found. Listing all ctors:");
                for (Constructor<?> c : itemRendererClass.getDeclaredConstructors()) {
                    StringBuilder sb = new StringBuilder("  ctor(");
                    for (Class<?> p : c.getParameterTypes()) {
                        sb.append(p.getName()).append(", ");
                    }
                    sb.append(")");
                    System.out.println("[ItemAnim] " + sb);
                }
                return;
            }
            byte[] bytes = ItemRendererInjector.generateFakeItemRenderer(itemRendererClass, mcClass, irCtor, mRIFP, mRI);
            System.out.println("[ItemAnim] Generated " + bytes.length + " bytes of bytecode");
            Class<?> fakeClass = ItemRendererInjector.defineClass("me.ries.FakeItemRenderer", bytes, itemRendererClass.getClassLoader());
            if (fakeClass == null) {
                System.out.println("[ItemAnim] FAIL: defineClass returned null");
                return;
            }
            System.out.println("[ItemAnim] FakeItemRenderer defined: " + fakeClass.getName() + " loader=" + fakeClass.getClassLoader());
            Constructor<?> fakeCtor = ItemRendererInjector.findConstructor(fakeClass, mcClass);
            if (fakeCtor == null) {
                System.out.println("[ItemAnim] FAIL: fake ctor not found");
                return;
            }
            fakeCtor.setAccessible(true);
            Object fakeInstance = fakeCtor.newInstance(mc);
            System.out.println("[ItemAnim] Fake instance created: " + fakeInstance.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(fakeInstance)));
            System.out.println("[ItemAnim] fakeInstance instanceof ItemRenderer = " + itemRendererClass.isInstance(fakeInstance));
            ItemRendererInjector.copyFields(originalIR, fakeInstance, itemRendererClass);
            int totalReplaced = 0;
            totalReplaced += ItemRendererInjector.replaceFieldInObjectHierarchy(mc, itemRendererClass, fakeInstance, "Minecraft");
            Class<?> entityRendererClass = MappingUtils.get("EntityRenderer");
            if (entityRendererClass != null) {
                for (Class<?> curMc = mc.getClass(); curMc != null && curMc != Object.class; curMc = curMc.getSuperclass()) {
                    for (Field f : curMc.getDeclaredFields()) {
                        if (!entityRendererClass.isAssignableFrom(f.getType())) continue;
                        try {
                            f.setAccessible(true);
                            Object er = f.get(mc);
                            if (er == null) continue;
                            System.out.println("[ItemAnim] Found EntityRenderer: " + er.getClass().getName() + " in field " + f.getName());
                            totalReplaced += ItemRendererInjector.replaceFieldInObjectHierarchy(er, itemRendererClass, fakeInstance, "EntityRenderer");
                        }
                        catch (Throwable t) {
                            System.out.println("[ItemAnim] Error accessing ER field: " + t.getMessage());
                        }
                    }
                }
            } else {
                System.out.println("[ItemAnim] WARN: EntityRenderer class not mapped");
            }
            System.out.println("[ItemAnim] Total fields replaced: " + totalReplaced);
            if (totalReplaced == 0) {
                System.out.println("[ItemAnim] WARNING: No fields were replaced! Searching ALL fields in mc...");
                ItemRendererInjector.dumpAllFields(mc, itemRendererClass);
            }
            injected = true;
            System.out.println("[ItemAnim] === INJECTION SUCCESSFUL ===");
        }
        catch (Throwable t) {
            System.out.println("[ItemAnim] === INJECTION FAILED === " + t.getClass().getName() + ": " + t.getMessage());
            t.printStackTrace();
        }
    }

    public static void verifyInjection() {
        long now = System.currentTimeMillis();
        if (now - lastVerifyLog < 5000L) {
            return;
        }
        lastVerifyLog = now;
        try {
            Object mc = MinecraftMapper.getMinecraft();
            Class<?> itemRendererClass = MappingUtils.get("ItemRenderer");
            if (mc == null || itemRendererClass == null) {
                return;
            }
            for (Class<?> cur = mc.getClass(); cur != null && cur != Object.class; cur = cur.getSuperclass()) {
                for (Field f : cur.getDeclaredFields()) {
                    if (!itemRendererClass.isAssignableFrom(f.getType())) continue;
                    f.setAccessible(true);
                    Object val = f.get(mc);
                    if (val == null) continue;
                    boolean isFake = val.getClass().getName().contains("FakeItemRenderer");
                    System.out.println("[ItemAnim] VERIFY: mc." + f.getName() + " = " + val.getClass().getName() + " isFake=" + isFake + " @" + Integer.toHexString(System.identityHashCode(val)));
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static int replaceFieldInObjectHierarchy(Object owner, Class<?> fieldType, Object newValue, String context) {
        int count = 0;
        for (Class<?> cur = owner.getClass(); cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            for (Field f : cur.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !fieldType.isAssignableFrom(f.getType())) continue;
                try {
                    f.setAccessible(true);
                    Object oldVal = f.get(owner);
                    f.set(owner, newValue);
                    System.out.println("[ItemAnim] Replaced " + context + "." + f.getName() + " (was " + (oldVal != null ? oldVal.getClass().getSimpleName() : "null") + ", now " + newValue.getClass().getSimpleName() + ") in " + cur.getSimpleName());
                    ++count;
                }
                catch (Throwable t) {
                    System.out.println("[ItemAnim] Failed to replace " + context + "." + f.getName() + ": " + t.getMessage());
                }
            }
        }
        return count;
    }

    private static void dumpAllFields(Object mc, Class<?> targetType) {
        for (Class<?> cur = mc.getClass(); cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            for (Field f : cur.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                try {
                    f.setAccessible(true);
                    Object val = f.get(mc);
                    if (val == null || !targetType.isInstance(val)) continue;
                    System.out.println("[ItemAnim] FOUND UNREPLACED: " + cur.getSimpleName() + "." + f.getName() + " type=" + f.getType().getName() + " val=" + val.getClass().getName());
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
    }

    public static Object getItemRendererInstance() {
        try {
            Object mc = MinecraftMapper.getMinecraft();
            Class<?> itemRendererClass = MappingUtils.get("ItemRenderer");
            if (mc == null || itemRendererClass == null) {
                return null;
            }
            for (Class<?> cur = mc.getClass(); cur != null && cur != Object.class; cur = cur.getSuperclass()) {
                for (Field f : cur.getDeclaredFields()) {
                    if (!itemRendererClass.isAssignableFrom(f.getType())) continue;
                    f.setAccessible(true);
                    Object val = f.get(mc);
                    if (val == null) continue;
                    return val;
                }
            }
            Class<?> entityRendererClass = MappingUtils.get("EntityRenderer");
            if (entityRendererClass != null) {
                for (Class<?> cur = mc.getClass(); cur != null && cur != Object.class; cur = cur.getSuperclass()) {
                    for (Field f : cur.getDeclaredFields()) {
                        if (!entityRendererClass.isAssignableFrom(f.getType())) continue;
                        f.setAccessible(true);
                        Object er = f.get(mc);
                        if (er == null) continue;
                        for (Class<?> erCur = er.getClass(); erCur != null && erCur != Object.class; erCur = erCur.getSuperclass()) {
                            for (Field erf : erCur.getDeclaredFields()) {
                                if (!itemRendererClass.isAssignableFrom(erf.getType())) continue;
                                erf.setAccessible(true);
                                Object val = erf.get(er);
                                if (val == null) continue;
                                return val;
                            }
                        }
                    }
                }
            }
        }
        catch (Throwable t) {
            System.out.println("[ItemAnim] Error searching IR: " + t.getMessage());
        }
        return null;
    }

    private static Constructor<?> findConstructor(Class<?> clazz, Class<?> mcClass) {
        Class<?>[] params;
        for (Constructor<?> c : clazz.getDeclaredConstructors()) {
            params = c.getParameterTypes();
            if (params.length != 1 || !params[0].isAssignableFrom(mcClass)) continue;
            c.setAccessible(true);
            return c;
        }
        for (Constructor<?> c : clazz.getDeclaredConstructors()) {
            params = c.getParameterTypes();
            if (params.length != 1 || !mcClass.isAssignableFrom(params[0])) continue;
            c.setAccessible(true);
            return c;
        }
        return null;
    }

    private static byte[] generateFakeItemRenderer(Class<?> superclass, Class<?> minecraftClass, Constructor<?> superCtor, Method mRenderInFirstPerson, Method mRenderItem) {
        String superName = Type.getInternalName(superclass);
        ClassNode cn = new ClassNode();
        cn.version = 52;
        cn.access = 1;
        cn.name = "me/ries/FakeItemRenderer";
        cn.superName = superName;
        cn.interfaces = new ArrayList();
        Class<?>[] ctorParams = superCtor.getParameterTypes();
        StringBuilder ctorDescBuilder = new StringBuilder("(");
        for (Class<?> clazz : ctorParams) {
            ctorDescBuilder.append(Type.getDescriptor(clazz));
        }
        ctorDescBuilder.append(")V");
        String ctorDesc = ctorDescBuilder.toString();
        MethodNode ctor = new MethodNode(1, "<init>", ctorDesc, null, null);
        ctor.instructions.add((AbstractInsnNode)new VarInsnNode(25, 0));
        int slot = 1;
        for (Class<?> p : ctorParams) {
            ctor.instructions.add((AbstractInsnNode)new VarInsnNode(ItemRendererInjector.loadOpcode(p), slot));
            slot += ItemRendererInjector.slotSize(p);
        }
        ctor.instructions.add((AbstractInsnNode)new MethodInsnNode(183, superName, "<init>", ctorDesc, false));
        ctor.instructions.add((AbstractInsnNode)new InsnNode(177));
        cn.methods.add(ctor);
        if (mRenderInFirstPerson != null) {
            String string = mRenderInFirstPerson.getName();
            String desc = Type.getMethodDescriptor((Method)mRenderInFirstPerson);
            MethodNode mn = new MethodNode(1, string, desc, null, null);
            InsnList il = mn.instructions;
            il.add((AbstractInsnNode)new FieldInsnNode(178, "me/ries/module/impl/ItemAnimationsModule", "enabled", "Z"));
            LabelNode lblSkip = new LabelNode();
            il.add((AbstractInsnNode)new JumpInsnNode(153, lblSkip));
            il.add((AbstractInsnNode)new VarInsnNode(25, 0));
            il.add((AbstractInsnNode)new VarInsnNode(23, 1));
            il.add((AbstractInsnNode)new MethodInsnNode(184, "me/ries/module/impl/ItemAnimationsModule", "renderItemInFirstPersonHook", "(Ljava/lang/Object;F)V", false));
            il.add((AbstractInsnNode)lblSkip);
            il.add((AbstractInsnNode)new VarInsnNode(25, 0));
            il.add((AbstractInsnNode)new VarInsnNode(23, 1));
            il.add((AbstractInsnNode)new MethodInsnNode(183, superName, string, desc, false));
            il.add((AbstractInsnNode)new InsnNode(177));
            cn.methods.add(mn);
        }
        if (mRenderItem != null) {
            String string = mRenderItem.getName();
            String desc = Type.getMethodDescriptor((Method)mRenderItem);
            Class<?>[] params = mRenderItem.getParameterTypes();
            MethodNode mn = new MethodNode(1, string, desc, null, null);
            InsnList il = mn.instructions;
            il.add((AbstractInsnNode)new FieldInsnNode(178, "me/ries/module/impl/ItemAnimationsModule", "enabled", "Z"));
            LabelNode lblSkip = new LabelNode();
            il.add((AbstractInsnNode)new JumpInsnNode(153, lblSkip));
            il.add((AbstractInsnNode)new VarInsnNode(25, 0));
            int pSlot = 1;
            for (Class<?> p : params) {
                il.add((AbstractInsnNode)new VarInsnNode(25, pSlot));
                ++pSlot;
            }
            StringBuilder hookDesc = new StringBuilder("(Ljava/lang/Object;");
            for (int i = 0; i < params.length; ++i) {
                hookDesc.append("Ljava/lang/Object;");
            }
            hookDesc.append(")V");
            il.add((AbstractInsnNode)new MethodInsnNode(184, "me/ries/module/impl/ItemAnimationsModule", "renderItemHook", hookDesc.toString(), false));
            il.add((AbstractInsnNode)lblSkip);
            il.add((AbstractInsnNode)new VarInsnNode(25, 0));
            pSlot = 1;
            for (Class<?> p : params) {
                il.add((AbstractInsnNode)new VarInsnNode(ItemRendererInjector.loadOpcode(p), pSlot));
                pSlot += ItemRendererInjector.slotSize(p);
            }
            il.add((AbstractInsnNode)new MethodInsnNode(183, superName, string, desc, false));
            il.add((AbstractInsnNode)new InsnNode(177));
            cn.methods.add(mn);
        }
        ClassWriter classWriter = new ClassWriter(3);
        cn.accept((ClassVisitor)classWriter);
        return classWriter.toByteArray();
    }

    private static int loadOpcode(Class<?> type) {
        if (type == Double.TYPE) {
            return 24;
        }
        if (type == Long.TYPE) {
            return 22;
        }
        if (type == Float.TYPE) {
            return 23;
        }
        if (type == Integer.TYPE || type == Boolean.TYPE || type == Byte.TYPE || type == Character.TYPE || type == Short.TYPE) {
            return 21;
        }
        return 25;
    }

    private static int slotSize(Class<?> type) {
        return type == Double.TYPE || type == Long.TYPE ? 2 : 1;
    }

    private static Class<?> defineClass(String name, byte[] bytes, ClassLoader parent) {
        try {
            Method defineMethod = ClassLoader.class.getDeclaredMethod("defineClass", String.class, byte[].class, Integer.TYPE, Integer.TYPE);
            defineMethod.setAccessible(true);
            Class c = (Class)defineMethod.invoke((Object)parent, name, bytes, 0, bytes.length);
            System.out.println("[ItemAnim] defineClass SUCCESS (primary) loader=" + parent);
            return c;
        }
        catch (Throwable t) {
            System.out.println("[ItemAnim] defineClass primary failed: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            try {
                Class<?> c = new ByteClassLoader(parent, name, bytes).loadClass(name);
                System.out.println("[ItemAnim] defineClass SUCCESS (fallback)");
                return c;
            }
            catch (Throwable e) {
                System.out.println("[ItemAnim] defineClass fallback failed: " + e.getMessage());
                return null;
            }
        }
    }

    private static void copyFields(Object src, Object dst, Class<?> startClass) {
        for (Class<?> cur = startClass; cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            for (Field f : cur.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                try {
                    f.setAccessible(true);
                    f.set(dst, f.get(src));
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
    }

    private static final class ByteClassLoader
    extends ClassLoader {
        private final String name;
        private final byte[] bytes;

        ByteClassLoader(ClassLoader parent, String name, byte[] bytes) {
            super(parent);
            this.name = name;
            this.bytes = bytes;
        }

        @Override
        protected Class<?> findClass(String className) throws ClassNotFoundException {
            return className.equals(this.name) ? this.defineClass(this.name, this.bytes, 0, this.bytes.length) : super.findClass(className);
        }
    }
}

