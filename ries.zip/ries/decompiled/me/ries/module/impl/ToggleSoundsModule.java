/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Method;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.Logger;

public class ToggleSoundsModule
extends Module {
    private final StringOption soundMode = new StringOption("Sound", "Click", this, "Pling", "Click", "Orb", "LevelUp", "Burp");
    private final NumberOption volume = new NumberOption("Volume", 0.7, 0.1, 1.0, 0.05, this);
    private static Method cachedPlaySoundMethod = null;
    private static boolean playSoundCached = false;

    public ToggleSoundsModule() {
        super("ToggleSounds", "Plays sounds when toggling modules", Category.RENDER, 0);
        this.soundMode.setGroup("General");
        this.volume.setGroup("General");
        this.addOptions(this.soundMode, this.volume);
    }

    @Override
    public void onEnable() {
        Logger.info("ToggleSounds enabled");
    }

    @Override
    public void onDisable() {
        Logger.info("ToggleSounds disabled");
    }

    @Override
    public void onUpdate() {
    }

    public void playToggleSound(boolean enable) {
        try {
            float pitch;
            Object player = MinecraftMapper.getThePlayer();
            if (player == null) {
                return;
            }
            String soundName = this.getSoundName((String)this.soundMode.getValue());
            float vol = ((Double)this.volume.getValue()).floatValue();
            float f = pitch = enable ? 1.0f : 0.8f;
            if (!playSoundCached) {
                playSoundCached = true;
                for (Class<?> current = player.getClass(); current != null && current != Object.class; current = current.getSuperclass()) {
                    for (Method m : current.getDeclaredMethods()) {
                        Class<?>[] params;
                        if (m.getParameterCount() != 3 || (params = m.getParameterTypes())[0] != String.class || params[1] != Float.TYPE || params[2] != Float.TYPE) continue;
                        m.setAccessible(true);
                        cachedPlaySoundMethod = m;
                        break;
                    }
                    if (cachedPlaySoundMethod != null) break;
                }
            }
            if (cachedPlaySoundMethod != null) {
                cachedPlaySoundMethod.invoke(player, soundName, Float.valueOf(vol), Float.valueOf(pitch));
            }
        }
        catch (Throwable t) {
            Logger.warn("Failed to play toggle sound: " + t.getMessage());
        }
    }

    private String getSoundName(String mode) {
        switch (mode) {
            case "Click": {
                return "random.click";
            }
            case "Orb": {
                return "random.orb";
            }
            case "LevelUp": {
                return "random.levelup";
            }
            case "Burp": {
                return "random.burp";
            }
        }
        return "note.pling";
    }
}

