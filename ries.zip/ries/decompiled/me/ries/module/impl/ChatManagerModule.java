/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import me.ries.module.Category;
import me.ries.module.Module;

public class ChatManagerModule
extends Module {
    public ChatManagerModule() {
        super("ChatManager", "Disables client-side command manager prefix (.)", Category.MISC, 0);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
    }
}

