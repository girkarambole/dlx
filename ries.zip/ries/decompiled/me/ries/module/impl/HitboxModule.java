/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.util.BotTracker;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.opengl.GL11;

public class HitboxModule
extends Module {
    public static HitboxModule instance;
    public final NumberOption size;
    public final BooleanOption drawCage;
    public final NumberOption cageDistance;
    public final NumberOption cageAlpha;
    public final NumberOption cageThickness;
    private Field posXf;
    private Field posYf;
    private Field posZf;
    private Method eyeHMethod;
    private Method healthMethod;
    private boolean cached;

    private static String x(String dummy1) {
        char[] cArray = dummy1.toCharArray();
        for (int i = 0; i < cArray.length; ++i) {
            cArray[i] = (char)(cArray[i] ^ 0x5A);
        }
        return new String(cArray);
    }

    public HitboxModule() {
        super(HitboxModule.x("\u00123.85\""), HitboxModule.x("\u001f\"*;4>)z*6;#?(z23.85\"?)z<5(z?;)3?(z;3734="), Category.COMBAT, 0);
        HitboxModule dummy1;
        dummy1.size = new NumberOption(HitboxModule.x("\t3 ?"), 0.08, 0.0, 0.5, 0.01, dummy1);
        dummy1.drawCage = new BooleanOption(HitboxModule.x("\u001e(;-\u0019;=?"), false, (Module)dummy1);
        dummy1.cageDistance = new NumberOption(HitboxModule.x("\u0019;=?\u001e3).;49?"), 99.0, 5.0, 99.0, 1.0, dummy1);
        dummy1.cageAlpha = new NumberOption(HitboxModule.x("\u0019;=?\u001b6*2;"), 0.5, 0.1, 1.0, 0.01, dummy1);
        dummy1.cageThickness = new NumberOption(HitboxModule.x("\u0019;=?\u000e23914?))"), 1.5, 0.5, 3.0, 0.1, dummy1);
        dummy1.cached = false;
        instance = dummy1;
        dummy1.size.setGroup(HitboxModule.x("\u0019578;."));
        dummy1.drawCage.setGroup(HitboxModule.x("\f3)/;6)"));
        dummy1.cageDistance.setGroup(HitboxModule.x("\f3)/;6)"));
        dummy1.cageAlpha.setGroup(HitboxModule.x("\f3)/;6)"));
        dummy1.cageThickness.setGroup(HitboxModule.x("\f3)/;6)"));
        dummy1.addOptions(dummy1.size, dummy1.drawCage, dummy1.cageDistance, dummy1.cageAlpha, dummy1.cageThickness);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    HitboxModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
    }

    private void buildCache() {
        HitboxModule dummy1;
        if (!dummy1.cached) {
            try {
                Method method;
                dummy1.posXf = MappingUtils.getField(HitboxModule.x("\u001f4.3.#t*5)\u0002"));
                dummy1.posYf = MappingUtils.getField(HitboxModule.x("\u001f4.3.#t*5)\u0003"));
                dummy1.posZf = MappingUtils.getField(HitboxModule.x("\u001f4.3.#t*5)\u0000"));
                if (dummy1.posXf != null) {
                    dummy1.posXf.setAccessible(true);
                }
                if (dummy1.posYf != null) {
                    dummy1.posYf.setAccessible(true);
                }
                if (dummy1.posZf != null) {
                    dummy1.posZf.setAccessible(true);
                }
                if ((method = MappingUtils.getMethod(HitboxModule.x("\u001f4.3.#t=?.\u001f#?\u0012?3=2."))) != null) {
                    method.setAccessible(true);
                    dummy1.eyeHMethod = method;
                }
                if ((method = MappingUtils.getMethod(HitboxModule.x("\u001f4.3.#\u00163,34=\u0018;)?t=?.\u0012?;6.2"))) != null) {
                    method.setAccessible(true);
                    dummy1.healthMethod = method;
                }
                dummy1.cached = true;
            }
            catch (Throwable throwable) {
                Logger.warn("[Hitbox] buildCache FAILED: " + throwable.getMessage());
            }
        }
    }

    @Override
    public void onEnable() {
        HitboxModule dummy1;
        dummy1.buildCache();
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
        HitboxModule dummy1;
        dummy1.buildCache();
    }

    private double eyeH(Object object) {
        HitboxModule dummy1;
        if (dummy1.eyeHMethod != null) {
            try {
                return ((Number)dummy1.eyeHMethod.invoke(object, new Object[0])).doubleValue();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return 1.62;
    }

    private boolean valid(Object object, Object object2) {
        if (object != null && object != object2) {
            block13: {
                try {
                    HitboxModule dummy1;
                    if (!dummy1.isValidCombatTarget(object)) {
                        return false;
                    }
                    BotTracker.observe(object);
                    if (BotTracker.isBot(object)) {
                        return false;
                    }
                    if (BotTracker.isBotByHp(object)) {
                        return false;
                    }
                    Method method = MappingUtils.getMethod(HitboxModule.x("\u001f4.3.#t=?.\u001c6;="));
                    if (method != null) {
                        method.setAccessible(true);
                        try {
                            Object object3 = method.invoke(object, 5);
                            if (object3 instanceof Boolean && ((Boolean)object3).booleanValue()) {
                                return false;
                            }
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    if (dummy1.healthMethod == null) break block13;
                    try {
                        float f = ((Number)dummy1.healthMethod.invoke(object, new Object[0])).floatValue();
                        if (f <= 0.0f) {
                            return false;
                        }
                    }
                    catch (Throwable throwable) {}
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            return true;
        }
        return false;
    }

    public void onRender3D(float f) {
        Object object;
        HitboxModule dummy1;
        if (dummy1.isEnabled() && ((Boolean)dummy1.drawCage.getValue()).booleanValue() && (object = dummy1.getThePlayer()) != null) {
            dummy1.buildCache();
            double d = (Double)dummy1.cageDistance.getValue() == 99.0 ? Double.MAX_VALUE : (Double)dummy1.cageDistance.getValue() * (Double)dummy1.cageDistance.getValue();
            float f2 = ((Double)dummy1.cageAlpha.getValue()).floatValue();
            float f3 = ((Double)dummy1.cageThickness.getValue()).floatValue();
            double d2 = (Double)dummy1.size.getValue();
            try {
                double d3 = dummy1.posXf.getDouble(object);
                double d4 = dummy1.posYf.getDouble(object);
                double d5 = dummy1.posZf.getDouble(object);
                double d6 = MappingUtils.getRenderPosX();
                double d7 = MappingUtils.getRenderPosY();
                double d8 = MappingUtils.getRenderPosZ();
                List<Object> list = MinecraftMapper.getPlayerEntitiesInWorld();
                GL11.glPushAttrib((int)1048575);
                GL11.glDisable((int)3553);
                GL11.glDisable((int)2929);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glEnable((int)2848);
                GL11.glLineWidth((float)f3);
                for (Object object2 : list) {
                    double[] dArray;
                    double d9;
                    double d10;
                    double d11;
                    double d12;
                    double d13;
                    double d14;
                    if (!dummy1.valid(object2, object) || (d14 = (d13 = dummy1.posXf.getDouble(object2)) - d3) * d14 + (d12 = (d11 = dummy1.posYf.getDouble(object2)) - d4) * d12 + (d10 = (d9 = dummy1.posZf.getDouble(object2)) - d5) * d10 > d || (dArray = MappingUtils.getInterpolatedPos(object2, f)) == null || dArray.length < 3) continue;
                    double d15 = 0.3 + d2;
                    double d16 = 1.8 + d2;
                    double d17 = dArray[0] - d6;
                    double d18 = dArray[1] - d7 - d2 * 0.5;
                    double d19 = dArray[2] - d8;
                    GL11.glBegin((int)1);
                    GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)f2);
                    GL11.glVertex3d((double)(d17 - d15), (double)d18, (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)d18, (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)d18, (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)d18, (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)d18, (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)d18, (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 - dummy1.cleanW(d15)), (double)d18, (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)d18, (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)(d18 + d16), (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)(d18 + d16), (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)(d18 + d16), (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)(d18 + d16), (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)(d18 + d16), (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)(d18 + d16), (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)(d18 + d16), (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)(d18 + d16), (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)d18, (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)(d18 + d16), (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)d18, (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)(d18 + d16), (double)(d19 - d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)d18, (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 + d15), (double)(d18 + d16), (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)d18, (double)(d19 + d15));
                    GL11.glVertex3d((double)(d17 - d15), (double)(d18 + d16), (double)(d19 + d15));
                    GL11.glEnd();
                }
                GL11.glPopAttrib();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private double cleanW(double d) {
        return d;
    }
}

