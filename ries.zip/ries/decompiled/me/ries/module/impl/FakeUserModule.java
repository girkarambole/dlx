/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import me.ries.command.CommandManager;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.TextOption;

public class FakeUserModule
extends Module {
    public static TextOption targetUsername;

    public FakeUserModule() {
        super("FakeUser", "Copies skin, name and VIP of online target player", Category.RENDER, 0);
        targetUsername = new TextOption("Username", "Izoly", (Module)this);
        this.addOptions(targetUsername);
    }

    @Override
    public void onEnable() {
        CommandManager.targetFakeUser = targetUsername.getText();
        CommandManager.fakeUserEnabled = true;
        CommandManager.copyTargetUser(CommandManager.targetFakeUser);
    }

    @Override
    public void onDisable() {
        CommandManager.fakeUserEnabled = false;
        CommandManager.restoreOriginals();
        CommandManager.addChatMessageToGui("\u00c3\u201a\u00c2\u00a7d[FakeUser] \u00c3\u201a\u00c2\u00a7fDevre d\u00c3\u201e\u00c2\u00b1\u00c3\u2026\u00c5\u00b8\u00c3\u201e\u00c2\u00b1 b\u00c3\u201e\u00c2\u00b1rak\u00c3\u201e\u00c2\u00b1ld\u00c3\u201e\u00c2\u00b1.");
    }

    @Override
    public void onUpdate() {
        if (CommandManager.fakeUserEnabled) {
            CommandManager.targetFakeUser = targetUsername.getText();
            CommandManager.copyTargetUser(CommandManager.targetFakeUser);
        }
    }
}

