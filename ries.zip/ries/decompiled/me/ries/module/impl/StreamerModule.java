/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import me.ries.command.CommandManager;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.StringOption;
import me.ries.setting.TextOption;

public class StreamerModule
extends Module {
    public static BooleanOption allahPrefix;
    public static TextOption prefixVal;
    public static StringOption prefixColorOpt;
    public static StringOption nameColorOpt;
    public static TextOption customName;

    public StreamerModule() {
        super("Streamer", "Hides your real name and rank from visuals", Category.RENDER, 0);
        allahPrefix = new BooleanOption("Allah Prefix", false, (Module)this);
        prefixVal = new TextOption("Prefix Text", "Allah", (Module)this);
        prefixColorOpt = new StringOption("Prefix Color", "Dark Red", this, "Red", "Dark Red", "Gold", "Yellow", "Green", "Dark Green", "Blue", "Dark Blue", "Aqua", "Dark Aqua", "Light Purple", "Dark Purple", "White", "Gray", "Dark Gray", "Black");
        nameColorOpt = new StringOption("Name Color", "Red", this, "Red", "Dark Red", "Gold", "Yellow", "Green", "Dark Green", "Blue", "Dark Blue", "Aqua", "Dark Aqua", "Light Purple", "Dark Purple", "White", "Gray", "Dark Gray", "Black");
        customName = new TextOption("Custom Name", "", (Module)this);
        this.addOptions(allahPrefix, prefixVal, prefixColorOpt, nameColorOpt, customName);
    }

    @Override
    public void onEnable() {
        this.updateValues();
        CommandManager.streamerEnabled = true;
    }

    @Override
    public void onDisable() {
        CommandManager.streamerEnabled = false;
        CommandManager.allahPrefixEnabled = false;
        CommandManager.customNameText = "";
        CommandManager.applyAllahPrefix();
    }

    @Override
    public void onUpdate() {
        if (this.isEnabled()) {
            this.updateValues();
        }
    }

    private void updateValues() {
        CommandManager.allahPrefixEnabled = (Boolean)allahPrefix.getValue();
        CommandManager.prefixText = prefixVal.getText();
        CommandManager.prefixColor = this.getColorCode((String)prefixColorOpt.getValue());
        CommandManager.nameColor = this.getColorCode((String)nameColorOpt.getValue());
        CommandManager.customNameText = customName.getText();
        CommandManager.applyAllahPrefix();
    }

    private String getColorCode(String string) {
        switch (string) {
            case "Dark Red": {
                return "4";
            }
            case "Red": {
                return "c";
            }
            case "Gold": {
                return "6";
            }
            case "Yellow": {
                return "e";
            }
            case "Dark Green": {
                return "2";
            }
            case "Green": {
                return "a";
            }
            case "Dark Blue": {
                return "1";
            }
            case "Blue": {
                return "9";
            }
            case "Dark Aqua": {
                return "3";
            }
            case "Aqua": {
                return "b";
            }
            case "Dark Purple": {
                return "5";
            }
            case "Light Purple": {
                return "d";
            }
            case "Gray": {
                return "7";
            }
            case "Dark Gray": {
                return "8";
            }
            case "Black": {
                return "0";
            }
        }
        return "f";
    }
}

