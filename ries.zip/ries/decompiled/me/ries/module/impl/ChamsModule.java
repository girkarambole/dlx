/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL13
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.OptionBase;
import me.ries.util.BotTracker;
import me.ries.util.MappingUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

public class ChamsModule
extends Module {
    private static Method renderEntityStaticMethod = null;
    private static Method renderEntitySimpleMethod = null;
    private static boolean methodSearchAttempted = false;

    public ChamsModule() {
        super("Chams", "Renders players normally through walls (Wallhack)", Category.RENDER, 0);
        this.addOptions(new OptionBase[0]);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    ChamsModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
    }

    private void onRender3D(float partialTicks) {
        if (!this.isEnabled()) {
            return;
        }
        Object mc = MinecraftMapper.getMinecraft();
        if (mc == null) {
            return;
        }
        Object renderManager = this.getRenderManagerInstance(mc);
        if (renderManager == null) {
            return;
        }
        Object[] entities = MappingUtils.getPlayerEntitiesInWorld();
        if (entities == null || entities.length == 0) {
            return;
        }
        this.resolveRenderMethods(renderManager.getClass());
        GL11.glPushMatrix();
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)2896);
        GL13.glActiveTexture((int)33984);
        GL11.glEnable((int)3553);
        GL13.glActiveTexture((int)33985);
        GL11.glDisable((int)3553);
        GL13.glActiveTexture((int)33984);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glEnable((int)32823);
        GL11.glPolygonOffset((float)1.0f, (float)-1500000.0f);
        for (Object entity : entities) {
            if (entity == null || entity == MinecraftMapper.getPlayer() || !this.isValidTarget(entity)) continue;
            this.renderEntity(renderManager, entity, partialTicks);
        }
        GL11.glDisable((int)32823);
        GL11.glPopAttrib();
        GL11.glPopMatrix();
    }

    private void renderEntity(Object renderManager, Object entity, float partialTicks) {
        try {
            if (renderEntityStaticMethod != null) {
                renderEntityStaticMethod.invoke(renderManager, entity, Float.valueOf(partialTicks), false);
            } else if (renderEntitySimpleMethod != null) {
                renderEntitySimpleMethod.invoke(renderManager, entity, Float.valueOf(partialTicks));
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private Object getRenderManagerInstance(Object mc) {
        try {
            Method getRM = MappingUtils.getMethod("Minecraft.getRenderManager");
            if (getRM != null) {
                return getRM.invoke(mc, new Object[0]);
            }
            Class<?> rmClass = MappingUtils.get("RenderManager");
            if (rmClass != null) {
                for (Field f : mc.getClass().getDeclaredFields()) {
                    if (!rmClass.isAssignableFrom(f.getType())) continue;
                    f.setAccessible(true);
                    Object val = f.get(mc);
                    if (val == null) continue;
                    return val;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private void resolveRenderMethods(Class<?> rmClass) {
        block6: {
            if (methodSearchAttempted) {
                return;
            }
            methodSearchAttempted = true;
            try {
                Class<?>[] p;
                Class<Object> entityClass = MappingUtils.get("Entity");
                if (entityClass == null) {
                    entityClass = Object.class;
                }
                for (Method m : rmClass.getDeclaredMethods()) {
                    p = m.getParameterTypes();
                    if (p.length != 3 || !p[0].isAssignableFrom(entityClass) || p[1] != Float.TYPE || p[2] != Boolean.TYPE) continue;
                    m.setAccessible(true);
                    renderEntityStaticMethod = m;
                    System.out.println("[Chams] Found renderEntityStatic method: " + m.getName());
                    break;
                }
                if (renderEntityStaticMethod != null) break block6;
                for (Method m : rmClass.getDeclaredMethods()) {
                    p = m.getParameterTypes();
                    if (p.length != 2 || !p[0].isAssignableFrom(entityClass) || p[1] != Float.TYPE) continue;
                    m.setAccessible(true);
                    renderEntitySimpleMethod = m;
                    System.out.println("[Chams] Found renderEntitySimple method: " + m.getName());
                    break;
                }
            }
            catch (Throwable t) {
                System.out.println("[Chams] Method resolve error: " + t.getMessage());
            }
        }
    }

    private boolean isValidTarget(Object entity) {
        block15: {
            if (entity == null) {
                return false;
            }
            try {
                Object p = MinecraftMapper.getPlayer();
                if (entity.equals(p)) {
                    return false;
                }
            }
            catch (Throwable p) {
                // empty catch block
            }
            try {
                String name = MappingUtils.getName(entity);
                if (name != null) {
                    String clean = name.replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim();
                    if (clean.startsWith("[CR]") || clean.matches(".*[\\[\\]].*") || clean.isEmpty()) {
                        return false;
                    }
                    break block15;
                }
                return false;
            }
            catch (Throwable ignored) {
                return false;
            }
        }
        try {
            Field f = MappingUtils.getField("Entity.isInvisible");
            if (f == null) {
                f = MappingUtils.getField("Entity.invisible");
            }
            if (f != null) {
                f.setAccessible(true);
                Object v = f.get(entity);
                if (v instanceof Boolean && ((Boolean)v).booleanValue()) {
                    return false;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (BotTracker.isBot(entity)) {
            return false;
        }
        BotTracker.observe(entity);
        if (BotTracker.isBotByHp(entity)) {
            return false;
        }
        return !(MappingUtils.getEntityHealth(entity) <= 0.0f);
    }
}

