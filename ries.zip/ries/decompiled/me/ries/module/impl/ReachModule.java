/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  io.netty.buffer.Unpooled
 *  io.netty.channel.Channel
 *  org.lwjgl.input.Mouse
 */
package me.ries.module.impl;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import java.lang.reflect.Constructor;
import java.lang.reflect.Executable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.UUID;
import me.ries.command.CommandManager;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.HitboxModule;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.util.BotTracker;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;

public class ReachModule
extends Module {
    private final NumberOption range = new NumberOption("Range", 4.0, 3.0, 30.0, 0.01, this);
    private final BooleanOption wallCheck = new BooleanOption("WallCheck", true, (Module)this);
    private final NumberOption jitter = new NumberOption("Range Jitter", 0.15, 0.0, 0.5, 0.05, this);
    private final NumberOption hitChance = new NumberOption("Hit Chance", 90.0, 50.0, 100.0, 5.0, this);
    private final NumberOption fov = new NumberOption("Reach FOV", 22.0, 10.0, 90.0, 1.0, this);
    private final BooleanOption dynamicChance = new BooleanOption("DynamicChance", true, (Module)this);
    private final BooleanOption autoRange = new BooleanOption("AutoRange", true, (Module)this);
    private Field posXf;
    private Field posYf;
    private Field posZf;
    private Field prevPosXf;
    private Field prevPosZf;
    private Field yawf;
    private Field pitchf;
    private Field typeOfHitField;
    private Field sendQueueField;
    private Method eyeHMethod;
    private Method healthMethod;
    private Method sendPacketMethod;
    private Method rayTraceMethod;
    private Constructor<?> vec3Ctor;
    private boolean cached = false;
    private boolean wasMouseDown = false;
    private long lastAttackTime = 0L;
    private long nextClickDelay = 100L;

    public ReachModule() {
        super("Reach", "Packet reach", Category.COMBAT, 0);
        this.range.setGroup("Combat");
        this.wallCheck.setGroup("Combat");
        this.jitter.setGroup("Combat");
        this.hitChance.setGroup("Combat");
        this.fov.setGroup("Combat");
        this.dynamicChance.setGroup("Combat");
        this.autoRange.setGroup("Combat");
        this.addOptions(this.range, this.wallCheck, this.jitter, this.hitChance, this.fov, this.dynamicChance, this.autoRange);
    }

    @Override
    public String getOptionPrefix() {
        double d = (Double)this.range.getValue();
        return d == Math.floor(d) ? String.valueOf((int)d) : String.format("%.1f", d);
    }

    @Override
    public void onEnable() {
        this.cached = false;
        Logger.info("[Reach] on range=" + this.range.getValue());
        try {
            Object object = this.getMinecraftInstance();
            if (object != null) {
                Logger.info("DUMPING Minecraft int fields:");
                for (Field field : object.getClass().getDeclaredFields()) {
                    if (field.getType() != Integer.TYPE || Modifier.isStatic(field.getModifiers())) continue;
                    field.setAccessible(true);
                    Logger.info("Field " + field.getName() + " = " + field.getInt(object));
                }
            } else {
                Logger.info("Minecraft instance is null!");
            }
        }
        catch (Throwable throwable) {
            Logger.info("Failed to dump: " + throwable.toString());
        }
    }

    private Object getMinecraftInstance() {
        try {
            Class<?> clazz = MappingUtils.get("Minecraft");
            if (clazz != null) {
                for (Field field : clazz.getDeclaredFields()) {
                    if (!Modifier.isStatic(field.getModifiers()) || field.getType() != clazz) continue;
                    field.setAccessible(true);
                    Object object = field.get(null);
                    if (object == null) continue;
                    return object;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    @Override
    public void onDisable() {
        this.cached = false;
        Logger.info("[Reach] off");
    }

    private void buildCache() {
        if (!this.cached) {
            try {
                Class<?> clazz;
                Method method;
                block16: {
                    Object object;
                    Class<?> clazz2;
                    Constructor<?>[] constructorArray;
                    this.posXf = ReachModule.f("Entity.posX");
                    this.posYf = ReachModule.f("Entity.posY");
                    this.posZf = ReachModule.f("Entity.posZ");
                    this.prevPosXf = ReachModule.f("Entity.prevPosX");
                    this.prevPosZf = ReachModule.f("Entity.prevPosZ");
                    this.yawf = ReachModule.f("Entity.rotationYaw");
                    this.pitchf = ReachModule.f("Entity.rotationPitch");
                    this.typeOfHitField = ReachModule.f("MovingObjectPosition.typeOfHit");
                    this.sendQueueField = ReachModule.f("EntityPlayerSP.sendQueue");
                    method = MappingUtils.getMethod("Entity.getEyeHeight");
                    if (method != null) {
                        method.setAccessible(true);
                        this.eyeHMethod = method;
                    }
                    if ((method = MappingUtils.getMethod("EntityLivingBase.getHealth")) != null) {
                        method.setAccessible(true);
                        this.healthMethod = method;
                    }
                    try {
                        constructorArray = MappingUtils.get("NetHandlerPlayClient");
                        clazz2 = MappingUtils.get("Packet");
                        if (constructorArray == null || clazz2 == null) break block16;
                        object = constructorArray.getMethods();
                        int n = ((Method[])object).length;
                        for (int i = 0; i < n; ++i) {
                            Executable executable = object[i];
                            Class<?>[] object2 = ((Method)executable).getParameterTypes();
                            if (object2.length != 1 || !clazz2.isAssignableFrom(object2[0])) continue;
                            ((Method)executable).setAccessible(true);
                            this.sendPacketMethod = executable;
                            break;
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    try {
                        constructorArray = MappingUtils.get("EntityPlayer");
                        clazz2 = MappingUtils.get("ItemStack");
                        if (constructorArray == null || clazz2 == null) break block16;
                        for (object = constructorArray; object != Object.class && object != null; object = object.getSuperclass()) {
                            for (Field field : object.getDeclaredFields()) {
                                if (field.getType() != clazz2) continue;
                                field.setAccessible(true);
                                FieldCache.itemInUse = field;
                                break;
                            }
                            if (FieldCache.itemInUse == null) {
                                continue;
                            }
                            break;
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
                method = MappingUtils.getMethod("Entity.rayTrace");
                if (method != null) {
                    method.setAccessible(true);
                    this.rayTraceMethod = method;
                }
                if ((clazz = MappingUtils.get("Vec3")) != null) {
                    for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                        Class<?>[] classArray = constructor.getParameterTypes();
                        if (classArray.length != 3 || classArray[0] != Double.TYPE) continue;
                        constructor.setAccessible(true);
                        this.vec3Ctor = constructor;
                        break;
                    }
                }
                Logger.info("[Reach] cache: posX=" + (this.posXf != null) + " yaw=" + (this.yawf != null) + " sendQ=" + (this.sendQueueField != null) + " eyeH=" + (this.eyeHMethod != null) + " health=" + (this.healthMethod != null) + " sendPkt=" + (this.sendPacketMethod != null));
                this.cached = true;
            }
            catch (Throwable throwable) {
                Logger.warn("[Reach] buildCache FAILED: " + throwable.getMessage());
            }
        }
    }

    private static Field f(String string) {
        Field field = MappingUtils.getField(string);
        if (field != null) {
            field.setAccessible(true);
        }
        return field;
    }

    private long getNextClickDelay() {
        double d = Math.random();
        if (d < 0.08) {
            return 45L + (long)(Math.random() * 20.0);
        }
        if (d < 0.25) {
            return 115L + (long)(Math.random() * 55.0);
        }
        return 70L + (long)(Math.random() * 40.0);
    }

    @Override
    public void onUpdate() {
        block17: {
            if (this.isEnabled()) {
                try {
                    boolean bl = false;
                    try {
                        bl = Mouse.isButtonDown((int)0);
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    if (!bl) {
                        this.wasMouseDown = false;
                        break block17;
                    }
                    if (this.wasMouseDown) break block17;
                    this.wasMouseDown = true;
                    if (this.isGuiOpen()) break block17;
                    this.buildCache();
                    Object object = this.getThePlayer();
                    if (object == null) break block17;
                    boolean bl2 = false;
                    if (FieldCache.itemInUse != null) {
                        try {
                            bl2 = FieldCache.itemInUse.get(object) != null;
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    boolean bl3 = false;
                    Method method = MappingUtils.getMethod("EntityPlayer.isBlocking");
                    if (method != null) {
                        try {
                            bl3 = (Boolean)method.invoke(object, new Object[0]);
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    if (bl2 || bl3) {
                        return;
                    }
                    Object object2 = this.findTarget(object);
                    if (!(object2 == null || ((Boolean)this.wallCheck.getValue()).booleanValue() && this.isBlocked(object, object2))) {
                        double d = this.distanceTo(object, object2);
                        if (d > 3.0) {
                            double d2;
                            double d3 = (Double)this.hitChance.getValue();
                            if (((Boolean)this.dynamicChance.getValue()).booleanValue() && (d2 = ((Double)this.range.getValue()).doubleValue()) > 3.0) {
                                double d4 = (d - 3.0) / (d2 - 3.0);
                                d3 = 95.0 - d4 * (95.0 - d3);
                            }
                            if (Math.random() * 100.0 > d3) {
                                this.lastAttackTime = System.currentTimeMillis();
                                this.nextClickDelay = this.getNextClickDelay();
                                this.swing(object);
                                return;
                            }
                        }
                        this.lastAttackTime = System.currentTimeMillis();
                        this.nextClickDelay = this.getNextClickDelay();
                        this.swing(object);
                        this.attack(object2, object);
                    }
                }
                catch (Throwable throwable) {
                    Logger.warn("[Reach] onUpdate error: " + throwable.getMessage());
                }
            }
        }
    }

    private int getPlayerPing() {
        block8: {
            try {
                Field field;
                Object object;
                Object object2;
                Object object3 = this.getMinecraftInstance();
                if (object3 == null || (object2 = this.getThePlayer()) == null) break block8;
                UUID uUID = null;
                try {
                    object = object2.getClass().getMethod("getUniqueID", new Class[0]);
                    uUID = (UUID)((Method)object).invoke(object2, new Object[0]);
                }
                catch (Throwable throwable) {
                    try {
                        field = object2.getClass().getDeclaredField("entityUniqueID");
                        field.setAccessible(true);
                        uUID = (UUID)field.get(object2);
                    }
                    catch (Throwable throwable2) {
                        // empty catch block
                    }
                }
                if (uUID != null && (object = CommandManager.getPlayerInfoMap()) != null && (field = object.get(uUID)) != null) {
                    for (Field field2 : field.getClass().getDeclaredFields()) {
                        if (field2.getType() != Integer.TYPE || !field2.getName().contains("responseTime") && !field2.getName().contains("ping")) continue;
                        field2.setAccessible(true);
                        return field2.getInt(field);
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return 50;
    }

    private Object findTarget(Object object) {
        try {
            double d;
            double d2;
            double d3 = this.posXf.getDouble(object);
            double d4 = this.posYf.getDouble(object) + this.eyeH(object);
            double d5 = this.posZf.getDouble(object);
            float f = this.yawf.getFloat(object);
            float f2 = this.pitchf.getFloat(object);
            double d6 = Math.toRadians((double)f + 90.0);
            double d7 = Math.toRadians(-f2);
            double d8 = Math.cos(d7) * Math.cos(d6);
            double d9 = Math.sin(d7);
            double d10 = Math.cos(d7) * Math.sin(d6);
            double d11 = (Double)this.range.getValue();
            if (((Boolean)this.autoRange.getValue()).booleanValue()) {
                d2 = (double)this.getPlayerPing() / 200.0;
                d = 3.15 + d2 * 0.45;
                if (d > d11) {
                    d = d11;
                }
                d11 = d;
            }
            d2 = 0.0;
            if (HitboxModule.instance != null && HitboxModule.instance.isEnabled()) {
                d2 = (Double)HitboxModule.instance.size.getValue();
            }
            d = d2 > 0.0 ? d2 * (0.55 + Math.random() * 0.45) : 0.0;
            Object object2 = null;
            double d12 = Double.MAX_VALUE;
            for (Object object3 : MinecraftMapper.getPlayerEntitiesInWorld()) {
                double d13;
                double d14;
                double d15;
                double d16;
                double d17;
                double d18;
                double d19;
                double d20;
                double d21;
                double d22;
                double d23;
                double d24;
                if (!this.valid(object3, object)) continue;
                double d25 = this.posXf.getDouble(object3);
                double d26 = this.posYf.getDouble(object3);
                double d27 = this.posZf.getDouble(object3);
                double d28 = 0.0;
                if (this.prevPosXf != null && this.prevPosZf != null) {
                    try {
                        d24 = this.prevPosXf.getDouble(object3);
                        d23 = this.prevPosZf.getDouble(object3);
                        d22 = d25 - d24;
                        double d29 = d27 - d23;
                        double d30 = d22 * d8 + d29 * d10;
                        if (d30 > 0.005) {
                            d28 = d30;
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
                d24 = d28 * 2.5;
                d23 = d11 - d24 - Math.random() * (Double)this.jitter.getValue();
                d22 = d23 + d;
                boolean bl = false;
                double[] dArray = new double[]{0.0, 0.3, 0.6, 0.9, 1.3, 1.7};
                double[] dArray2 = dArray;
                int n = dArray2.length;
                for (int i = 0; i < n; ++i) {
                    double d31 = d25 - d3;
                    double d32 = dArray2[i];
                    double d33 = d26 + d32 - d4;
                    double d34 = d27 - d5;
                    if (!(d31 * d31 + d33 * d33 + d34 * d34 <= d22 * d22)) continue;
                    bl = true;
                    break;
                }
                if (!bl || (d21 = Math.sqrt((d20 = d25 - d3) * d20 + (d19 = d26 + 0.9 - d4) * d19 + (d18 = d27 - d5) * d18)) < 1.0E-9 || (d17 = (d20 * d8 + d19 * d9 + d18 * d10) / d21) < 0.0 || (d16 = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, d17))))) > (Double)this.fov.getValue() || d16 >= (d15 = (d14 = 3.0 + d * 12.0) + (d13 = Math.toDegrees(Math.atan2(0.45, d21)))) || d16 >= d12) continue;
                d12 = d16;
                object2 = object3;
            }
            return object2;
        }
        catch (Throwable throwable) {
            Logger.warn("[Reach] findTarget ex: " + throwable.getMessage());
            return null;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private boolean isBlocked(Object object, Object object2) {
        if (this.rayTraceMethod == null) {
            return false;
        }
        try {
            double d = this.posXf.getDouble(object);
            double d2 = this.posYf.getDouble(object) + this.eyeH(object);
            double d3 = this.posZf.getDouble(object);
            double d4 = this.posXf.getDouble(object2);
            double d5 = this.posYf.getDouble(object2);
            double d6 = this.posZf.getDouble(object2);
            double[] dArray = new double[]{0.1, 0.9, 1.65};
            for (double d7 : dArray) {
                try {
                    double d8 = d4 - d;
                    double d9 = d5 + d7 - d2;
                    double d10 = d6 - d3;
                    double d11 = Math.sqrt(d8 * d8 + d9 * d9 + d10 * d10);
                    float[] fArray = new float[]{this.posXf != null ? 0.0f : 0.0f};
                    Field field = MappingUtils.getField("Entity.rotationYaw");
                    Field field2 = MappingUtils.getField("Entity.rotationPitch");
                    if (field == null || field2 == null) {
                        return false;
                    }
                    field.setAccessible(true);
                    field2.setAccessible(true);
                    float f = field.getFloat(object);
                    float f2 = field2.getFloat(object);
                    float f3 = (float)(Math.toDegrees(Math.atan2(d10, d8)) - 90.0);
                    float f4 = (float)(-Math.toDegrees(Math.atan2(d9, Math.sqrt(d8 * d8 + d10 * d10))));
                    field.setFloat(object, f3);
                    field2.setFloat(object, f4);
                    Object object3 = null;
                    try {
                        object3 = this.rayTraceMethod.invoke(object, d11 + 0.1, Float.valueOf(1.0f));
                    }
                    finally {
                        field.setFloat(object, f);
                        field2.setFloat(object, f2);
                    }
                    if (object3 == null) {
                        return false;
                    }
                    if (this.typeOfHitField == null) {
                        return false;
                    }
                    Object object4 = this.typeOfHitField.get(object3);
                    if (object4 instanceof Enum) {
                        if (((Enum)object4).ordinal() == 1) continue;
                        return false;
                    }
                    String string = object4 != null ? object4.toString() : "";
                    String string2 = string;
                    if (string.contains("BLOCK")) continue;
                    return false;
                }
                catch (Throwable throwable) {
                    return false;
                }
            }
            return true;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private void attack(Object object, Object object2) {
        try {
            MinecraftMapper.attackEntity(object);
        }
        catch (Throwable throwable) {
            Logger.debug("[Reach] attack error: " + throwable.getMessage());
        }
    }

    private void swing(Object object) {
        try {
            Channel channel;
            Class<?> clazz;
            Object object2;
            if (this.sendPacketMethod != null && this.sendQueueField != null && (object2 = this.sendQueueField.get(object)) != null && (clazz = MappingUtils.get("C0APacketAnimation")) != null) {
                for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                    if (constructor.getParameterTypes().length != 0) continue;
                    constructor.setAccessible(true);
                    Object obj = constructor.newInstance(new Object[0]);
                    this.sendPacketMethod.invoke(object2, obj);
                    return;
                }
            }
            if ((channel = MinecraftMapper.getNetworkChannel()) != null && channel.isActive()) {
                Constructor<?>[] constructorArray = Unpooled.buffer();
                constructorArray.writeByte(10);
                channel.writeAndFlush((Object)constructorArray);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private int getEntityId(Object object) {
        try {
            Field field = MappingUtils.getField("Entity.entityId");
            if (field != null) {
                field.setAccessible(true);
                return field.getInt(object);
            }
            Method method = MappingUtils.getMethod("Entity.getEntityId");
            if (method != null) {
                method.setAccessible(true);
                return ((Number)method.invoke(object, new Object[0])).intValue();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return -1;
    }

    private boolean isGuiOpen() {
        try {
            Object object = MinecraftMapper.getMinecraft();
            if (object == null) {
                return false;
            }
            Field field = MappingUtils.getField("Minecraft.currentScreen");
            if (field == null) {
                return false;
            }
            field.setAccessible(true);
            return field.get(object) != null;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private double eyeH(Object object) {
        if (this.eyeHMethod != null) {
            try {
                return ((Number)this.eyeHMethod.invoke(object, new Object[0])).doubleValue();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return 1.62;
    }

    private boolean valid(Object object, Object object2) {
        if (object != null && object != object2) {
            block13: {
                try {
                    if (!this.isValidCombatTarget(object)) {
                        return false;
                    }
                    BotTracker.observe(object);
                    if (BotTracker.isBot(object)) {
                        return false;
                    }
                    if (BotTracker.isBotByHp(object)) {
                        return false;
                    }
                    Method method = MappingUtils.getMethod("Entity.getFlag");
                    if (method != null) {
                        method.setAccessible(true);
                        try {
                            Object object3 = method.invoke(object, 5);
                            if (object3 instanceof Boolean && ((Boolean)object3).booleanValue()) {
                                return false;
                            }
                        }
                        catch (Throwable throwable) {
                            // empty catch block
                        }
                    }
                    if (this.healthMethod == null) break block13;
                    try {
                        float f = ((Number)this.healthMethod.invoke(object, new Object[0])).floatValue();
                        if (f <= 0.0f) {
                            return false;
                        }
                    }
                    catch (Throwable throwable) {}
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            return true;
        }
        return false;
    }

    private static void writeVarInt(ByteBuf byteBuf, int n) {
        while ((n & 0xFFFFFF80) != 0) {
            byteBuf.writeByte(n & 0x7F | 0x80);
            n >>>= 7;
        }
        byteBuf.writeByte(n);
    }

    private double distanceTo(Object object, Object object2) {
        try {
            Method method = MappingUtils.getMethod("Entity.getDistanceToEntity");
            if (method != null) {
                method.setAccessible(true);
                return ((Float)method.invoke(object, object2)).doubleValue();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        try {
            double d = this.posXf.getDouble(object) - this.posXf.getDouble(object2);
            double d2 = this.posYf.getDouble(object) - this.posYf.getDouble(object2);
            double d3 = this.posZf.getDouble(object) - this.posZf.getDouble(object2);
            return Math.sqrt(d * d + d2 * d2 + d3 * d3);
        }
        catch (Throwable throwable) {
            return 0.0;
        }
    }

    private static class FieldCache {
        static Field itemInUse = null;

        private FieldCache() {
        }
    }
}

