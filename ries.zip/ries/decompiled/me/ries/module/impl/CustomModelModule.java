/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package me.ries.module.impl;

import java.io.File;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.MappingUtils;
import org.lwjgl.opengl.GL11;

public class CustomModelModule
extends Module {
    private final StringOption modelName;
    private final NumberOption scale;
    private final StringOption target;
    private float[] vertices = null;
    private float[] normals = null;
    private String loadedModel = null;
    private Field renderYawOffsetField = null;
    private Field prevRenderYawOffsetField = null;
    private static final String MODEL_DIR = "C:\\ries\\models";

    public CustomModelModule() {
        super("CustomModel", "Renders a GLB model on players", Category.MISC, 0);
        String[] models = CustomModelModule.getModelNames();
        String defModel = models.length > 0 ? models[0] : "none";
        this.modelName = new StringOption("Model", defModel, this, models);
        this.scale = new NumberOption("Scale", 1.0, 0.1, 5.0, 0.1, this);
        this.target = new StringOption("Target", "OnlyMe", this, "OnlyMe", "Everyone");
        this.modelName.setGroup("Model");
        this.scale.setGroup("Model");
        this.target.setGroup("Model");
        this.addOptions(this.modelName, this.scale, this.target);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    CustomModelModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
    }

    private static String[] getModelNames() {
        File dir = new File(MODEL_DIR);
        if (!dir.exists() || !dir.isDirectory()) {
            return new String[]{"none"};
        }
        File[] files = dir.listFiles((d, n) -> n.toLowerCase().endsWith(".glb"));
        if (files == null || files.length == 0) {
            return new String[]{"none"};
        }
        String[] names = new String[files.length];
        for (int i = 0; i < files.length; ++i) {
            names[i] = files[i].getName();
        }
        return names;
    }

    @Override
    public void onEnable() {
        this.vertices = null;
        this.loadedModel = null;
    }

    @Override
    public void onDisable() {
        this.vertices = null;
        this.loadedModel = null;
    }

    @Override
    public void onUpdate() {
    }

    private void onRender3D(float partialTicks) {
        if (!this.isEnabled()) {
            return;
        }
        String sel = (String)this.modelName.getValue();
        if ("none".equals(sel)) {
            return;
        }
        if (!sel.equals(this.loadedModel)) {
            this.loadModel(new File(MODEL_DIR, sel));
            this.loadedModel = sel;
        }
        if (this.vertices == null || this.vertices.length == 0) {
            return;
        }
        boolean onlyMe = "OnlyMe".equals(this.target.getValue());
        Object localPlayer = MinecraftMapper.getPlayer();
        if (localPlayer == null) {
            return;
        }
        if (onlyMe) {
            this.renderOnPlayer(localPlayer, partialTicks);
        } else {
            List<Object> entities = MinecraftMapper.getPlayerEntitiesInWorld();
            if (entities != null) {
                for (Object e : entities) {
                    this.renderOnPlayer(e, partialTicks);
                }
            }
            this.renderOnPlayer(localPlayer, partialTicks);
        }
    }

    private void renderOnPlayer(Object player, float partialTicks) {
        try {
            double[] pos = MappingUtils.getInterpolatedPos(player, partialTicks);
            if (pos == null) {
                return;
            }
            double camX = MappingUtils.getRenderPosX();
            double camY = MappingUtils.getRenderPosY();
            double camZ = MappingUtils.getRenderPosZ();
            double x = pos[0] - camX;
            double y = pos[1] - camY;
            double z = pos[2] - camZ;
            float yaw = this.getBodyYaw(player, partialTicks);
            double s = (Double)this.scale.getValue();
            GL11.glPushMatrix();
            GL11.glPushAttrib((int)1048575);
            GL11.glEnable((int)2929);
            GL11.glDepthMask((boolean)true);
            GL11.glDisable((int)3553);
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)2896);
            GL11.glEnable((int)16384);
            GL11.glEnable((int)2903);
            GL11.glShadeModel((int)7425);
            GL11.glTranslated((double)x, (double)y, (double)z);
            GL11.glRotatef((float)(180.0f - yaw), (float)0.0f, (float)1.0f, (float)0.0f);
            GL11.glScaled((double)s, (double)s, (double)s);
            GL11.glTranslatef((float)0.0f, (float)0.0f, (float)0.0f);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GL11.glBegin((int)4);
            int triCount = this.vertices.length / 9;
            for (int i = 0; i < triCount; ++i) {
                int base = i * 9;
                if (this.normals != null && this.normals.length == this.vertices.length) {
                    GL11.glNormal3f((float)this.normals[base], (float)this.normals[base + 1], (float)this.normals[base + 2]);
                    GL11.glVertex3f((float)this.vertices[base], (float)this.vertices[base + 1], (float)this.vertices[base + 2]);
                    GL11.glNormal3f((float)this.normals[base + 3], (float)this.normals[base + 4], (float)this.normals[base + 5]);
                    GL11.glVertex3f((float)this.vertices[base + 3], (float)this.vertices[base + 4], (float)this.vertices[base + 5]);
                    GL11.glNormal3f((float)this.normals[base + 6], (float)this.normals[base + 7], (float)this.normals[base + 8]);
                    GL11.glVertex3f((float)this.vertices[base + 6], (float)this.vertices[base + 7], (float)this.vertices[base + 8]);
                    continue;
                }
                GL11.glVertex3f((float)this.vertices[base], (float)this.vertices[base + 1], (float)this.vertices[base + 2]);
                GL11.glVertex3f((float)this.vertices[base + 3], (float)this.vertices[base + 4], (float)this.vertices[base + 5]);
                GL11.glVertex3f((float)this.vertices[base + 6], (float)this.vertices[base + 7], (float)this.vertices[base + 8]);
            }
            GL11.glEnd();
            GL11.glPopAttrib();
            GL11.glPopMatrix();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void loadModel(File file) {
        this.vertices = null;
        this.normals = null;
        try {
            if (!file.exists()) {
                return;
            }
            byte[] data = CustomModelModule.readAllBytes(file);
            if (data.length < 12) {
                return;
            }
            ByteBuffer bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            int magic = bb.getInt(0);
            if (magic != 1179937895) {
                return;
            }
            int chunk0Len = bb.getInt(12);
            int chunk0Type = bb.getInt(16);
            byte[] jsonBytes = new byte[chunk0Len];
            System.arraycopy(data, 20, jsonBytes, 0, chunk0Len);
            String json = new String(jsonBytes, "UTF-8");
            int binOffset = 20 + chunk0Len;
            byte[] binData = null;
            if (binOffset + 8 <= data.length) {
                int chunk1Len = bb.getInt(binOffset);
                binData = new byte[chunk1Len];
                System.arraycopy(data, binOffset + 8, binData, 0, chunk1Len);
            }
            if (binData == null) {
                return;
            }
            Map<String, Object> gltf = this.parseGltfJson(json);
            this.vertices = this.extractPositions(gltf, binData);
            this.normals = this.extractNormals(gltf, binData);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private float[] extractPositions(Map<String, Object> gltf, byte[] bin) {
        try {
            List<Map<String, Object>> meshes = this.getList(gltf, "meshes");
            if (meshes == null || meshes.isEmpty()) {
                return null;
            }
            ArrayList<float[]> allTris = new ArrayList<float[]>();
            for (Map<String, Object> mesh : meshes) {
                List<Map<String, Object>> primitives = this.getList(mesh, "primitives");
                if (primitives == null) continue;
                for (Map<String, Object> prim : primitives) {
                    int[] indices;
                    float[] positions;
                    int posIdx;
                    Map<String, Object> attrs = this.getMap(prim, "attributes");
                    if (attrs == null || (posIdx = this.getInt(attrs, "POSITION", -1)) < 0 || (positions = this.readFloatAccessor(gltf, bin, posIdx)) == null) continue;
                    int indicesIdx = this.getInt(prim, "indices", -1);
                    if (indicesIdx >= 0 && (indices = this.readIndexAccessor(gltf, bin, indicesIdx)) != null) {
                        float[] tris = new float[indices.length * 3];
                        for (int i = 0; i < indices.length; ++i) {
                            int vi = indices[i] * 3;
                            tris[i * 3] = positions[vi];
                            tris[i * 3 + 1] = positions[vi + 1];
                            tris[i * 3 + 2] = positions[vi + 2];
                        }
                        this.addAll(allTris, tris);
                        continue;
                    }
                    this.addAll(allTris, positions);
                }
            }
            return this.flatten(allTris);
        }
        catch (Exception e) {
            return null;
        }
    }

    private float[] extractNormals(Map<String, Object> gltf, byte[] bin) {
        try {
            List<Map<String, Object>> meshes = this.getList(gltf, "meshes");
            if (meshes == null || meshes.isEmpty()) {
                return null;
            }
            ArrayList<float[]> allNormals = new ArrayList<float[]>();
            for (Map<String, Object> mesh : meshes) {
                List<Map<String, Object>> primitives = this.getList(mesh, "primitives");
                if (primitives == null) continue;
                for (Map<String, Object> prim : primitives) {
                    int[] indices;
                    float[] norms;
                    int normIdx;
                    Map<String, Object> attrs = this.getMap(prim, "attributes");
                    if (attrs == null || (normIdx = this.getInt(attrs, "NORMAL", -1)) < 0 || (norms = this.readFloatAccessor(gltf, bin, normIdx)) == null) continue;
                    int indicesIdx = this.getInt(prim, "indices", -1);
                    if (indicesIdx >= 0 && (indices = this.readIndexAccessor(gltf, bin, indicesIdx)) != null) {
                        float[] expanded = new float[indices.length * 3];
                        for (int i = 0; i < indices.length; ++i) {
                            int vi = indices[i] * 3;
                            expanded[i * 3] = norms[vi];
                            expanded[i * 3 + 1] = norms[vi + 1];
                            expanded[i * 3 + 2] = norms[vi + 2];
                        }
                        this.addAll(allNormals, expanded);
                        continue;
                    }
                    this.addAll(allNormals, norms);
                }
            }
            return this.flatten(allNormals);
        }
        catch (Exception e) {
            return null;
        }
    }

    private float[] readFloatAccessor(Map<String, Object> gltf, byte[] bin, int accIdx) {
        try {
            List<Map<String, Object>> accessors = this.getList(gltf, "accessors");
            List<Map<String, Object>> bufferViews = this.getList(gltf, "bufferViews");
            if (accessors == null || bufferViews == null) {
                return null;
            }
            if (accIdx >= accessors.size()) {
                return null;
            }
            Map<String, Object> acc = accessors.get(accIdx);
            int bvIdx = this.getInt(acc, "bufferView", -1);
            int count = this.getInt(acc, "count", 0);
            int compType = this.getInt(acc, "componentType", 5126);
            String type = this.getString(acc, "type", "VEC3");
            int byteOffset = this.getInt(acc, "byteOffset", 0);
            int numComponents = this.typeComponents(type);
            if (bvIdx < 0 || bvIdx >= bufferViews.size()) {
                return null;
            }
            Map<String, Object> bv = bufferViews.get(bvIdx);
            int bvOffset = this.getInt(bv, "byteOffset", 0);
            int bvLen = this.getInt(bv, "byteLength", 0);
            int startByte = bvOffset + byteOffset;
            ByteBuffer buf = ByteBuffer.wrap(bin, startByte, bvLen - byteOffset).order(ByteOrder.LITTLE_ENDIAN);
            float[] result = new float[count * numComponents];
            if (compType == 5126) {
                for (int i = 0; i < result.length; ++i) {
                    result[i] = buf.getFloat();
                }
            } else if (compType == 5121) {
                for (int i = 0; i < result.length; ++i) {
                    result[i] = (float)(buf.get() & 0xFF) / 255.0f;
                }
            } else if (compType == 5123) {
                for (int i = 0; i < result.length; ++i) {
                    result[i] = (float)(buf.getShort() & 0xFFFF) / 65535.0f;
                }
            }
            return result;
        }
        catch (Exception e) {
            return null;
        }
    }

    private int[] readIndexAccessor(Map<String, Object> gltf, byte[] bin, int accIdx) {
        try {
            List<Map<String, Object>> accessors = this.getList(gltf, "accessors");
            List<Map<String, Object>> bufferViews = this.getList(gltf, "bufferViews");
            if (accessors == null || bufferViews == null) {
                return null;
            }
            if (accIdx >= accessors.size()) {
                return null;
            }
            Map<String, Object> acc = accessors.get(accIdx);
            int bvIdx = this.getInt(acc, "bufferView", -1);
            int count = this.getInt(acc, "count", 0);
            int compType = this.getInt(acc, "componentType", 5123);
            int byteOffset = this.getInt(acc, "byteOffset", 0);
            if (bvIdx < 0 || bvIdx >= bufferViews.size()) {
                return null;
            }
            Map<String, Object> bv = bufferViews.get(bvIdx);
            int bvOffset = this.getInt(bv, "byteOffset", 0);
            int bvLen = this.getInt(bv, "byteLength", 0);
            int startByte = bvOffset + byteOffset;
            ByteBuffer buf = ByteBuffer.wrap(bin, startByte, bvLen - byteOffset).order(ByteOrder.LITTLE_ENDIAN);
            int[] result = new int[count];
            if (compType == 5121) {
                for (int i = 0; i < count; ++i) {
                    result[i] = buf.get() & 0xFF;
                }
            } else if (compType == 5123) {
                for (int i = 0; i < count; ++i) {
                    result[i] = buf.getShort() & 0xFFFF;
                }
            } else if (compType == 5125) {
                for (int i = 0; i < count; ++i) {
                    result[i] = buf.getInt();
                }
            }
            return result;
        }
        catch (Exception e) {
            return null;
        }
    }

    private int typeComponents(String type) {
        switch (type) {
            case "SCALAR": {
                return 1;
            }
            case "VEC2": {
                return 2;
            }
            case "VEC3": {
                return 3;
            }
            case "VEC4": {
                return 4;
            }
        }
        return 3;
    }

    private Map<String, Object> parseGltfJson(String json) {
        json = json.trim();
        Object parsed = this.parseValue(new int[]{0}, json);
        if (parsed instanceof Map) {
            return (Map)parsed;
        }
        return new HashMap<String, Object>();
    }

    private Object parseValue(int[] pos, String s) {
        this.skipWhitespace(pos, s);
        if (pos[0] >= s.length()) {
            return null;
        }
        char c = s.charAt(pos[0]);
        if (c == '{') {
            return this.parseObject(pos, s);
        }
        if (c == '[') {
            return this.parseArray(pos, s);
        }
        if (c == '\"') {
            return this.parseString(pos, s);
        }
        if (c == 't') {
            pos[0] = pos[0] + 4;
            return Boolean.TRUE;
        }
        if (c == 'f') {
            pos[0] = pos[0] + 5;
            return Boolean.FALSE;
        }
        if (c == 'n') {
            pos[0] = pos[0] + 4;
            return null;
        }
        return this.parseNumber(pos, s);
    }

    private Map<String, Object> parseObject(int[] pos, String s) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        pos[0] = pos[0] + 1;
        this.skipWhitespace(pos, s);
        while (pos[0] < s.length() && s.charAt(pos[0]) != '}') {
            this.skipWhitespace(pos, s);
            String key = this.parseString(pos, s);
            this.skipWhitespace(pos, s);
            pos[0] = pos[0] + 1;
            Object val = this.parseValue(pos, s);
            map.put(key, val);
            this.skipWhitespace(pos, s);
            if (pos[0] < s.length() && s.charAt(pos[0]) == ',') {
                pos[0] = pos[0] + 1;
            }
            this.skipWhitespace(pos, s);
        }
        if (pos[0] < s.length()) {
            pos[0] = pos[0] + 1;
        }
        return map;
    }

    private List<Object> parseArray(int[] pos, String s) {
        ArrayList<Object> list = new ArrayList<Object>();
        pos[0] = pos[0] + 1;
        this.skipWhitespace(pos, s);
        while (pos[0] < s.length() && s.charAt(pos[0]) != ']') {
            list.add(this.parseValue(pos, s));
            this.skipWhitespace(pos, s);
            if (pos[0] < s.length() && s.charAt(pos[0]) == ',') {
                pos[0] = pos[0] + 1;
            }
            this.skipWhitespace(pos, s);
        }
        if (pos[0] < s.length()) {
            pos[0] = pos[0] + 1;
        }
        return list;
    }

    private String parseString(int[] pos, String s) {
        pos[0] = pos[0] + 1;
        StringBuilder sb = new StringBuilder();
        while (pos[0] < s.length()) {
            int n = pos[0];
            pos[0] = n + 1;
            char c = s.charAt(n);
            if (c == '\"') break;
            if (c == '\\' && pos[0] < s.length()) {
                int n2 = pos[0];
                pos[0] = n2 + 1;
                char e = s.charAt(n2);
                if (e == 'n') {
                    sb.append('\n');
                    continue;
                }
                if (e == 't') {
                    sb.append('\t');
                    continue;
                }
                sb.append(e);
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private Number parseNumber(int[] pos, String s) {
        int start = pos[0];
        boolean isFloat = false;
        while (pos[0] < s.length()) {
            char c = s.charAt(pos[0]);
            if (c == '.' || c == 'e' || c == 'E') {
                isFloat = true;
            }
            if (!Character.isDigit(c) && c != '-' && c != '+' && c != '.' && c != 'e' && c != 'E') break;
            pos[0] = pos[0] + 1;
        }
        String num = s.substring(start, pos[0]);
        try {
            if (isFloat) {
                return Double.parseDouble(num);
            }
            return Long.parseLong(num);
        }
        catch (Exception e) {
            return 0;
        }
    }

    private void skipWhitespace(int[] pos, String s) {
        while (pos[0] < s.length() && Character.isWhitespace(s.charAt(pos[0]))) {
            pos[0] = pos[0] + 1;
        }
    }

    private List<Map<String, Object>> getList(Map<String, Object> map, String key) {
        Object v = map.get(key);
        if (!(v instanceof List)) {
            return null;
        }
        return (List)v;
    }

    private Map<String, Object> getMap(Map<String, Object> map, String key) {
        Object v = map.get(key);
        if (!(v instanceof Map)) {
            return null;
        }
        return (Map)v;
    }

    private int getInt(Map<String, Object> map, String key, int def) {
        Object v = map.get(key);
        if (v instanceof Number) {
            return ((Number)v).intValue();
        }
        return def;
    }

    private String getString(Map<String, Object> map, String key, String def) {
        Object v = map.get(key);
        if (v instanceof String) {
            return (String)v;
        }
        return def;
    }

    private void addAll(List<float[]> list, float[] arr) {
        list.add(arr);
    }

    private float[] flatten(List<float[]> list) {
        int total = 0;
        for (float[] a : list) {
            total += a.length;
        }
        float[] result = new float[total];
        int i = 0;
        for (float[] a : list) {
            System.arraycopy(a, 0, result, i, a.length);
            i += a.length;
        }
        return result;
    }

    private float getBodyYaw(Object player, float partialTicks) {
        try {
            if (this.renderYawOffsetField == null) {
                this.renderYawOffsetField = MappingUtils.getField("EntityLivingBase.renderYawOffset");
            }
            if (this.prevRenderYawOffsetField == null) {
                this.prevRenderYawOffsetField = MappingUtils.getField("EntityLivingBase.prevRenderYawOffset");
            }
            if (this.renderYawOffsetField != null && this.prevRenderYawOffsetField != null) {
                float curr;
                float prev = this.prevRenderYawOffsetField.getFloat(player);
                float interp = (prev + ((curr = this.renderYawOffsetField.getFloat(player)) - prev) * partialTicks) % 360.0f;
                return interp < 0.0f ? interp + 360.0f : interp;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return MappingUtils.getYaw(player);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static byte[] readAllBytes(File file) throws Exception {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r");){
            byte[] data = new byte[(int)raf.length()];
            raf.readFully(data);
            byte[] byArray = data;
            return byArray;
        }
    }
}

