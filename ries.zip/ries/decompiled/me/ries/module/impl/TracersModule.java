/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.GLU
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.nio.Buffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render2DEvent;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.FriendManagerModule;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.BotTracker;
import me.ries.util.MappingUtils;
import me.ries.util.ScissorUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public class TracersModule
extends Module {
    private final StringOption drawMode = new StringOption("Draw Mode", "Crosshair", this, "Crosshair", "Bottom", "3D");
    private final StringOption colorMode = new StringOption("Color Mode", "Custom", this, "Custom", "Distance", "Static");
    private final NumberOption customRed = new NumberOption("Red", 255.0, 0.0, 255.0, 1.0, this);
    private final NumberOption customGreen = new NumberOption("Green", 255.0, 0.0, 255.0, 1.0, this);
    private final NumberOption customBlue = new NumberOption("Blue", 0.0, 0.0, 255.0, 1.0, this);
    private final NumberOption opacity = new NumberOption("Opacity", 1.0, 0.1, 1.0, 0.05, this);
    private final NumberOption range = new NumberOption("Range", 256.0, 16.0, 512.0, 16.0, this);
    private final NumberOption lineWidth = new NumberOption("LineWidth", 1.5, 0.5, 3.0, 0.5, this);
    private final FloatBuffer modelView = BufferUtils.createFloatBuffer((int)16);
    private final FloatBuffer projection = BufferUtils.createFloatBuffer((int)16);
    private final IntBuffer viewport = BufferUtils.createIntBuffer((int)16);
    private boolean matricesCached = false;

    public TracersModule() {
        super("Tracers", "Draws lines to active players around you", Category.RENDER, 0);
        this.customRed.setDependency("Color Mode:Custom");
        this.customGreen.setDependency("Color Mode:Custom");
        this.customBlue.setDependency("Color Mode:Custom");
        this.addOptions(this.drawMode, this.colorMode, this.customRed, this.customGreen, this.customBlue, this.opacity, this.range, this.lineWidth);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    TracersModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
        Ries.getInstance().getEventBus().subscribe(Render2DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render2DEvent) {
                    TracersModule.this.onRender2D(((Render2DEvent)event).getPartialTicks());
                }
            }
        });
    }

    @Override
    public void onEnable() {
        this.matricesCached = false;
    }

    @Override
    public void onDisable() {
        this.matricesCached = false;
    }

    @Override
    public void onUpdate() {
    }

    private void onRender3D(float f) {
        if (!this.isEnabled()) {
            return;
        }
        ((Buffer)this.modelView).clear();
        ((Buffer)this.projection).clear();
        ((Buffer)this.viewport).clear();
        GL11.glGetFloat((int)2982, (FloatBuffer)this.modelView);
        GL11.glGetFloat((int)2983, (FloatBuffer)this.projection);
        GL11.glGetInteger((int)2978, (IntBuffer)this.viewport);
        this.matricesCached = true;
        if (!"3D".equals(this.drawMode.getValue())) {
            return;
        }
        Object[] objectArray = MappingUtils.getPlayerEntitiesInWorld();
        if (objectArray == null || objectArray.length == 0) {
            return;
        }
        double d = MappingUtils.getRenderPosX();
        double d2 = MappingUtils.getRenderPosY();
        double d3 = MappingUtils.getRenderPosZ();
        double d4 = (Double)this.range.getValue();
        double d5 = d4 * d4;
        GL11.glPushMatrix();
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        float f2 = ((Double)this.lineWidth.getValue()).floatValue();
        for (Object object : objectArray) {
            if (object == null || object == MinecraftMapper.getPlayer() || !this.isValidTarget(object)) continue;
            try {
                double[] dArray = MappingUtils.getInterpolatedPos(object, f);
                double d6 = dArray[0] - d;
                double d7 = dArray[1] - d2;
                double d8 = dArray[2] - d3;
                double d9 = d6 * d6 + d7 * d7 + d8 * d8;
                if (!(d9 <= d5)) continue;
                double d10 = Math.sqrt(d9);
                float f3 = this.distAlpha(d10, d4);
                this.drawTracer3D(d6, d7, d8, object, f3, f2, d10);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        GL11.glPopMatrix();
        GL11.glPopAttrib();
    }

    private void onRender2D(float f) {
        if (!this.isEnabled()) {
            return;
        }
        if (!this.matricesCached) {
            return;
        }
        if ("3D".equals(this.drawMode.getValue())) {
            return;
        }
        Object[] objectArray = MappingUtils.getPlayerEntitiesInWorld();
        if (objectArray == null || objectArray.length == 0) {
            return;
        }
        double d = MappingUtils.getRenderPosX();
        double d2 = MappingUtils.getRenderPosY();
        double d3 = MappingUtils.getRenderPosZ();
        double d4 = (Double)this.range.getValue();
        double d5 = d4 * d4;
        float f2 = ScissorUtil.getScaledWidth();
        float f3 = ScissorUtil.getScaledHeight();
        float f4 = ((Double)this.lineWidth.getValue()).floatValue();
        float f5 = f2 * 0.5f;
        float f6 = "Crosshair".equals(this.drawMode.getValue()) ? f3 * 0.5f : f3;
        GL11.glPushMatrix();
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        for (Object object : objectArray) {
            if (object == null || object == MinecraftMapper.getPlayer() || !this.isValidTarget(object)) continue;
            try {
                double d6;
                float[] fArray;
                double[] dArray = MappingUtils.getInterpolatedPos(object, f);
                double d7 = dArray[0] - d;
                double d8 = dArray[1] - d2;
                double d9 = dArray[2] - d3;
                double d10 = d7 * d7 + d8 * d8 + d9 * d9;
                if (!(d10 <= d5) || (fArray = this.projectToScreen(dArray[0], d6 = dArray[1] + (double)MappingUtils.getEyeHeight(object) * 0.5, dArray[2])) == null || !(fArray[2] < 1.0f)) continue;
                double d11 = Math.sqrt(d10);
                float f7 = this.distAlpha(d11, d4);
                this.drawTracer2D(f5, f6, fArray[0], fArray[1], object, f7, f4, d11);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        GL11.glPopMatrix();
        GL11.glPopAttrib();
    }

    private void drawTracer3D(double d, double d2, double d3, Object object, float f, float f2, double d4) {
        double d5 = d2 + (double)MappingUtils.getEyeHeight(object) * 0.5;
        GL11.glLineWidth((float)(f2 * 2.0f));
        GL11.glBegin((int)1);
        GL11.glColor4f((float)0.0f, (float)0.0f, (float)0.0f, (float)(f * 0.3f));
        GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)d, (double)d5, (double)d3);
        GL11.glEnd();
        GL11.glLineWidth((float)f2);
        GL11.glBegin((int)1);
        this.setColor(object, d4, f);
        GL11.glVertex3d((double)0.0, (double)0.0, (double)0.0);
        GL11.glVertex3d((double)d, (double)d5, (double)d3);
        GL11.glEnd();
    }

    private void drawTracer2D(float f, float f2, float f3, float f4, Object object, float f5, float f6, double d) {
        GL11.glLineWidth((float)(f6 * 2.0f));
        GL11.glBegin((int)1);
        GL11.glColor4f((float)0.0f, (float)0.0f, (float)0.0f, (float)(f5 * 0.3f));
        GL11.glVertex2f((float)f, (float)f2);
        GL11.glVertex2f((float)f3, (float)f4);
        GL11.glEnd();
        GL11.glLineWidth((float)f6);
        GL11.glBegin((int)1);
        this.setColor(object, d, f5);
        GL11.glVertex2f((float)f, (float)f2);
        GL11.glVertex2f((float)f3, (float)f4);
        GL11.glEnd();
    }

    private void setColor(Object object, double d, float f) {
        String string = (String)this.colorMode.getValue();
        if ("Custom".equals(string)) {
            float f2 = ((Double)this.customRed.getValue()).floatValue() / 255.0f;
            float f3 = ((Double)this.customGreen.getValue()).floatValue() / 255.0f;
            float f4 = ((Double)this.customBlue.getValue()).floatValue() / 255.0f;
            GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f);
        } else if ("Distance".equals(string)) {
            float f5 = (float)(d / 120.0);
            if (f5 > 1.0f) {
                f5 = 1.0f;
            }
            GL11.glColor4f((float)f5, (float)(1.0f - f5), (float)0.2f, (float)f);
        } else if (FriendManagerModule.isFriend(object)) {
            GL11.glColor4f((float)0.2f, (float)0.9f, (float)0.35f, (float)f);
        } else {
            GL11.glColor4f((float)0.96f, (float)0.96f, (float)0.98f, (float)f);
        }
    }

    private float[] projectToScreen(double d, double d2, double d3) {
        FloatBuffer floatBuffer = BufferUtils.createFloatBuffer((int)16);
        ((Buffer)this.modelView).rewind();
        floatBuffer.put(this.modelView);
        ((Buffer)floatBuffer).rewind();
        double d4 = MappingUtils.getRenderPosX();
        double d5 = MappingUtils.getRenderPosY();
        double d6 = MappingUtils.getRenderPosZ();
        float f = floatBuffer.get(0);
        float f2 = floatBuffer.get(1);
        float f3 = floatBuffer.get(2);
        float f4 = floatBuffer.get(3);
        float f5 = floatBuffer.get(4);
        float f6 = floatBuffer.get(5);
        float f7 = floatBuffer.get(6);
        float f8 = floatBuffer.get(7);
        float f9 = floatBuffer.get(8);
        float f10 = floatBuffer.get(9);
        float f11 = floatBuffer.get(10);
        float f12 = floatBuffer.get(11);
        float f13 = floatBuffer.get(12);
        float f14 = floatBuffer.get(13);
        float f15 = floatBuffer.get(14);
        float f16 = floatBuffer.get(15);
        float f17 = (float)(-d4 * (double)f - d5 * (double)f5 - d6 * (double)f9 + (double)f13);
        float f18 = (float)(-d4 * (double)f2 - d5 * (double)f6 - d6 * (double)f10 + (double)f14);
        float f19 = (float)(-d4 * (double)f3 - d5 * (double)f7 - d6 * (double)f11 + (double)f15);
        float f20 = (float)(-d4 * (double)f4 - d5 * (double)f8 - d6 * (double)f12 + (double)f16);
        floatBuffer.put(12, f17);
        floatBuffer.put(13, f18);
        floatBuffer.put(14, f19);
        floatBuffer.put(15, f20);
        ((Buffer)floatBuffer).rewind();
        FloatBuffer floatBuffer2 = BufferUtils.createFloatBuffer((int)3);
        ((Buffer)this.projection).rewind();
        ((Buffer)this.viewport).rewind();
        if (!GLU.gluProject((float)((float)d), (float)((float)d2), (float)((float)d3), (FloatBuffer)floatBuffer, (FloatBuffer)this.projection, (IntBuffer)this.viewport, (FloatBuffer)floatBuffer2)) {
            return null;
        }
        int n = ScissorUtil.getScaleFactor();
        float f21 = floatBuffer2.get(0) / (float)n;
        float f22 = ((float)Display.getHeight() - floatBuffer2.get(1)) / (float)n;
        float f23 = floatBuffer2.get(2);
        return new float[]{f21, f22, f23};
    }

    private float distAlpha(double d, double d2) {
        float f = (float)(1.0 - d / d2 * 0.4);
        if (f < 0.1f) {
            f = 0.1f;
        }
        return f * ((Double)this.opacity.getValue()).floatValue();
    }

    private boolean isValidTarget(Object object) {
        Object object2;
        Object object3;
        block15: {
            if (object == null) {
                return false;
            }
            try {
                object3 = MinecraftMapper.getPlayer();
                if (object.equals(object3)) {
                    return false;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            try {
                object3 = MappingUtils.getName(object);
                if (object3 != null) {
                    object2 = ((String)object3).replaceAll("\u00c3\u201a\u00c2\u00a7.", "").trim();
                    if (((String)object2).startsWith("[CR]") || ((String)object2).matches(".*[\\[\\]].*") || ((String)object2).isEmpty()) {
                        return false;
                    }
                    break block15;
                }
                return false;
            }
            catch (Throwable throwable) {
                return false;
            }
        }
        try {
            object3 = MappingUtils.getField("Entity.isInvisible");
            if (object3 == null) {
                object3 = MappingUtils.getField("Entity.invisible");
            }
            if (object3 != null) {
                ((Field)object3).setAccessible(true);
                object2 = ((Field)object3).get(object);
                if (object2 instanceof Boolean && ((Boolean)object2).booleanValue()) {
                    return false;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (BotTracker.isBot(object)) {
            return false;
        }
        BotTracker.observe(object);
        if (BotTracker.isBotByHp(object)) {
            return false;
        }
        return !(MappingUtils.getEntityHealth(object) <= 0.0f);
    }
}

