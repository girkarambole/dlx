/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import me.ries.util.MappingUtils;

public class SpinbotModule
extends Module {
    private float currentYaw = 0.0f;
    private Field fRenderYawOffset;
    private Field fPrevRenderYawOffset;
    private Field fRotationYawHead;
    private boolean cacheInit = false;

    public SpinbotModule() {
        super("Spinbot", "Spins your body model", Category.MOVEMENT, 0);
        this.addOptions(new NumberOption("Speed", 20.0, 1.0, 50.0, 1.0, this));
        this.initCache();
    }

    @Override
    public String getOptionPrefix() {
        double s = (Double)((NumberOption)this.getOption("Speed")).getValue();
        return String.valueOf((int)s);
    }

    private double speed() {
        return (Double)((NumberOption)this.getOption("Speed")).getValue();
    }

    private void initCache() {
        try {
            this.fRenderYawOffset = MappingUtils.getField("EntityLivingBase.renderYawOffset");
            this.fPrevRenderYawOffset = MappingUtils.getField("EntityLivingBase.prevRenderYawOffset");
            this.fRotationYawHead = MappingUtils.getField("EntityLivingBase.rotationYawHead");
            if (this.fRenderYawOffset != null) {
                this.fRenderYawOffset.setAccessible(true);
            }
            if (this.fPrevRenderYawOffset != null) {
                this.fPrevRenderYawOffset.setAccessible(true);
            }
            if (this.fRotationYawHead != null) {
                this.fRotationYawHead.setAccessible(true);
            }
            this.cacheInit = this.fRenderYawOffset != null && this.fPrevRenderYawOffset != null && this.fRotationYawHead != null;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Override
    public void onDisable() {
        this.currentYaw = 0.0f;
    }

    @Override
    public void onEnable() {
        this.currentYaw = 0.0f;
        if (!this.cacheInit) {
            this.initCache();
        }
    }

    @Override
    public void onUpdate() {
        Object player = MinecraftMapper.getPlayer();
        if (player != null) {
            if (!this.cacheInit) {
                this.initCache();
            } else {
                try {
                    this.currentYaw = (this.currentYaw + (float)this.speed()) % 360.0f;
                    if (this.fRenderYawOffset != null) {
                        this.fRenderYawOffset.setFloat(player, this.currentYaw);
                    }
                    if (this.fPrevRenderYawOffset != null) {
                        this.fPrevRenderYawOffset.setFloat(player, this.currentYaw);
                    }
                    if (this.fRotationYawHead != null) {
                        this.fRotationYawHead.setFloat(player, this.currentYaw);
                    }
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
    }
}

