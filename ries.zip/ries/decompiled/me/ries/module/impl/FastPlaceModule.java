/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import me.ries.util.MappingUtils;
import me.ries.util.UnsafeHelper;
import sun.misc.Unsafe;

public class FastPlaceModule
extends Module {
    private final NumberOption delay = new NumberOption("Delay", 0.0, 0.0, 4.0, 1.0, this);

    public FastPlaceModule() {
        super("FastPlace", "Removes block placement delay", Category.PLAYER, 0);
        this.delay.setGroup("Placement");
        this.addOptions(this.delay);
    }

    @Override
    public String getOptionPrefix() {
        return String.valueOf(((Double)this.delay.getValue()).intValue());
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    private boolean isHoldingBlock() {
        try {
            Object object = this.getThePlayer();
            if (object == null) {
                return false;
            }
            Object object2 = MappingUtils.getInventory(object);
            if (object2 == null) {
                return false;
            }
            Field field = MappingUtils.getField("InventoryPlayer.currentItem");
            if (field == null) {
                return false;
            }
            field.setAccessible(true);
            int n = field.getInt(object2);
            Field field2 = MappingUtils.getField("InventoryPlayer.mainInventory");
            if (field2 == null) {
                return false;
            }
            field2.setAccessible(true);
            Object object3 = field2.get(object2);
            if (!(object3 instanceof Object[])) {
                return false;
            }
            Object[] objectArray = (Object[])object3;
            if (n < 0 || n >= objectArray.length) {
                return false;
            }
            Object object4 = objectArray[n];
            if (object4 == null) {
                return false;
            }
            String string = MappingUtils.getItemName(object4);
            if (string == null) {
                return false;
            }
            return this.isBlockItem(string);
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private boolean isBlockItem(String string) {
        String string2 = string.toLowerCase();
        return !string2.contains("sword") && !string2.contains("axe") && !string2.contains("pickaxe") && !string2.contains("shovel") && !string2.contains("apple") && !string2.contains("skull") && !string2.contains("head") && !string2.contains("helmet") && !string2.contains("potion") && !string2.contains("bow") && !string2.contains("arrow") && !string2.contains("bucket") && !string2.contains("compass") && !string2.contains("clock") && !string2.contains("shears");
    }

    @Override
    public void onUpdate() {
        if (this.isEnabled()) {
            if (!this.isHoldingBlock()) {
                return;
            }
            try {
                long l;
                Object object = this.getMinecraft();
                if (object == null) {
                    return;
                }
                Unsafe unsafe = UnsafeHelper.getUnsafe();
                if (unsafe == null) {
                    return;
                }
                int n = ((Double)this.delay.getValue()).intValue();
                Field field = MappingUtils.getField("Minecraft.cps1");
                Field field2 = MappingUtils.getField("Minecraft.cps2");
                if (field != null && unsafe.getInt(object, l = unsafe.objectFieldOffset(field)) > n) {
                    unsafe.putInt(object, l, n);
                }
                if (field2 != null && unsafe.getInt(object, l = unsafe.objectFieldOffset(field2)) > n) {
                    unsafe.putInt(object, l, n);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }
}

