/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.ItemRendererDiagnostic;
import me.ries.module.impl.ItemRendererInjector;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.GlStateManager;
import me.ries.util.MappingUtils;

public class ItemAnimationsModule
extends Module {
    public static boolean enabled = false;
    public static StringOption swingMode;
    public static StringOption blockMode;
    public static StringOption spinAxis;
    public static NumberOption scale;
    public static NumberOption xOffset;
    public static NumberOption yOffset;
    public static NumberOption zOffset;
    public static NumberOption swingSpeed;
    public static NumberOption spinSpeed;
    private static Field swingProgressField;
    private static int hookCallCount;
    private static int renderItemHookCallCount;
    private static long lastDebugLog;

    public ItemAnimationsModule() {
        super("ItemAnimations", "Custom scale, offsets and animations for held items", Category.RENDER, 0);
        swingMode = new StringOption("Swing Style", "1.7", this, "Classic", "1.7", "Spin", "Swing", "Punch", "Sigma");
        blockMode = new StringOption("Block Style", "Classic", this, "Classic", "1.7", "Sigma");
        spinAxis = new StringOption("Spin Axis", "Horizontal", this, "Horizontal", "Vertical");
        spinAxis.setDependency("Swing Style:Spin");
        scale = new NumberOption("Scale", 1.0, 0.2, 2.0, 0.05, this);
        xOffset = new NumberOption("X Offset", 0.0, -1.0, 1.0, 0.05, this);
        yOffset = new NumberOption("Y Offset", 0.0, -1.0, 1.0, 0.05, this);
        zOffset = new NumberOption("Z Offset", 0.0, -1.0, 1.0, 0.05, this);
        swingSpeed = new NumberOption("Swing Speed", 1.0, 0.2, 3.0, 0.1, this);
        spinSpeed = new NumberOption("Spin Speed", 1.0, 0.5, 5.0, 0.1, this);
        spinSpeed.setDependency("Swing Style:Spin");
        this.addOptions(swingMode, blockMode, spinAxis, scale, xOffset, yOffset, zOffset, swingSpeed, spinSpeed);
    }

    @Override
    public void onEnable() {
        enabled = true;
        hookCallCount = 0;
        renderItemHookCallCount = 0;
        System.out.println("[ItemAnim] Module ENABLED - calling inject()");
        ItemRendererDiagnostic.analyze();
        ItemRendererInjector.inject();
    }

    @Override
    public void onDisable() {
        enabled = false;
        System.out.println("[ItemAnim] Module DISABLED");
    }

    @Override
    public void onUpdate() {
        ItemRendererInjector.verifyInjection();
        long now = System.currentTimeMillis();
        if (now - lastDebugLog > 5000L) {
            lastDebugLog = now;
            System.out.println("[ItemAnim] STATS: renderItemInFirstPerson calls=" + hookCallCount + " renderItem calls=" + renderItemHookCallCount);
            hookCallCount = 0;
            renderItemHookCallCount = 0;
        }
    }

    public static boolean isModuleEnabled() {
        return enabled;
    }

    public static void renderItemInFirstPersonHook(Object itemRenderer, float partialTicks) {
        ++hookCallCount;
        try {
            float s;
            float x = ((Double)xOffset.getValue()).floatValue();
            float y = ((Double)yOffset.getValue()).floatValue();
            float z = ((Double)zOffset.getValue()).floatValue();
            if (x != 0.0f || y != 0.0f || z != 0.0f) {
                GlStateManager.translate(x, y, z);
            }
            if ((s = ((Double)scale.getValue()).floatValue()) != 1.0f) {
                GlStateManager.scale(s, s, s);
            }
            GlStateManager.rotate(10.0f, 0.0f, 0.0f, 1.0f);
        }
        catch (Throwable t) {
            System.out.println("[ItemAnim] renderItemInFirstPersonHook ERROR: " + t.getMessage());
        }
    }

    public static void renderItemHook(Object itemRenderer, Object entity, Object stack, Object transformType) {
        ++renderItemHookCallCount;
        try {
            float swingProgress = ItemAnimationsModule.getSwingProgressVal(entity);
            float sp = swingProgress * ((Double)swingSpeed.getValue()).floatValue();
            if (sp > 1.0f) {
                sp = 1.0f;
            }
            float f = (float)Math.sin((double)sp * Math.PI);
            float f1 = (float)Math.sin(Math.sqrt(sp) * Math.PI);
            String mode = (String)swingMode.getValue();
            if ("Spin".equals(mode)) {
                float spin = sp * 360.0f * ((Double)spinSpeed.getValue()).floatValue();
                if ("Horizontal".equals(spinAxis.getValue())) {
                    GlStateManager.rotate(spin, 0.0f, 1.0f, 0.0f);
                } else {
                    GlStateManager.rotate(spin, 0.0f, 0.0f, 1.0f);
                }
            } else if ("Punch".equals(mode)) {
                GlStateManager.translate(0.0f, f1 * 0.15f, f1 * -0.2f);
                GlStateManager.rotate(f1 * -30.0f, 1.0f, 0.0f, 0.0f);
            } else if ("Sigma".equals(mode)) {
                GlStateManager.rotate(f1 * -30.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.rotate(f1 * -40.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.rotate(f1 * -30.0f, 0.0f, 0.0f, 1.0f);
            } else if ("1.7".equals(mode)) {
                GlStateManager.rotate(f * -20.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.rotate(f1 * -20.0f, 0.0f, 0.0f, 1.0f);
                GlStateManager.rotate(f1 * -40.0f, 1.0f, 0.0f, 0.0f);
            } else if ("Swing".equals(mode)) {
                GlStateManager.rotate(f1 * -40.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.rotate(f1 * -30.0f, 0.0f, 0.0f, 1.0f);
                GlStateManager.rotate(f1 * -60.0f, 1.0f, 0.0f, 0.0f);
            }
        }
        catch (Throwable t) {
            System.out.println("[ItemAnim] renderItemHook ERROR: " + t.getMessage());
        }
    }

    public static float getSwingProgressVal(Object entity) {
        block13: {
            if (entity == null) {
                return 0.0f;
            }
            if (swingProgressField == null) {
                try {
                    Class<?> elbClass = MappingUtils.get("EntityLivingBase");
                    if (elbClass == null) break block13;
                    try {
                        swingProgressField = elbClass.getDeclaredField("swingProgress");
                    }
                    catch (NoSuchFieldException e1) {
                        try {
                            swingProgressField = elbClass.getDeclaredField("field_70733_aV");
                        }
                        catch (NoSuchFieldException e2) {
                            for (Field f : elbClass.getDeclaredFields()) {
                                String name;
                                if (f.getType() != Float.TYPE || Modifier.isStatic(f.getModifiers()) || (name = f.getName().toLowerCase()).contains("width") || name.contains("height") || name.contains("step")) continue;
                                swingProgressField = f;
                                break;
                            }
                        }
                    }
                    if (swingProgressField != null) {
                        swingProgressField.setAccessible(true);
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
        if (swingProgressField != null) {
            try {
                return swingProgressField.getFloat(entity);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return 0.0f;
    }

    static {
        swingProgressField = null;
        hookCallCount = 0;
        renderItemHookCallCount = 0;
        lastDebugLog = 0L;
    }
}

