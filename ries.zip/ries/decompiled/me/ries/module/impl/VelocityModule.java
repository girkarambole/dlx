/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.SimpleDateFormat;
import java.util.Date;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.PacketReceiveEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import sun.misc.Unsafe;

public class VelocityModule
extends Module {
    private final NumberOption horizontal = new NumberOption("Horizontal", 0.0, 0.0, 100.0, 1.0, this);
    private final NumberOption vertical = new NumberOption("Vertical", 0.0, 0.0, 100.0, 1.0, this);
    private EventListener packetListener;
    private static final Unsafe UNSAFE = VelocityModule.getUnsafe();
    private int logCount = 0;
    private int totalPacketCount = 0;
    private int matchDumpCount = 0;
    private static final String VEL_LOG = "C:\\ries\\logs\\vel_debug.log";
    private static final SimpleDateFormat SDF = new SimpleDateFormat("HH:mm:ss.SSS");

    private static Unsafe getUnsafe() {
        try {
            Field field = Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            return (Unsafe)field.get(null);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    public VelocityModule() {
        super("Velocity", "Reduces or eliminates knockback", Category.COMBAT, 0);
        this.horizontal.setGroup("Knockback");
        this.vertical.setGroup("Knockback");
        this.addOptions(this.horizontal, this.vertical);
    }

    @Override
    public String getOptionPrefix() {
        int n = ((Double)this.horizontal.getValue()).intValue();
        int n2 = ((Double)this.vertical.getValue()).intValue();
        return "H:" + n + "% V:" + n2 + "%";
    }

    @Override
    public void onEnable() {
        this.logCount = 0;
        this.totalPacketCount = 0;
        this.matchDumpCount = 0;
        VelocityModule.velLog("[VEL] Velocity ENABLED");
        this.packetListener = new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof PacketReceiveEvent) {
                    VelocityModule.this.handlePacket((PacketReceiveEvent)event);
                }
            }
        };
        try {
            Field field = MappingUtils.getField("S12PacketEntityVelocity.motionX");
            Field field2 = MappingUtils.getField("S12PacketEntityVelocity.motionY");
            Field field3 = MappingUtils.getField("S12PacketEntityVelocity.motionZ");
            if (field != null && field2 != null && field3 != null) {
                VelocityModule.velLog("[VEL] Mapped motion fields: fx=" + field.getName() + " (type=" + field.getType().getSimpleName() + "), fy=" + field2.getName() + " (type=" + field2.getType().getSimpleName() + "), fz=" + field3.getName() + " (type=" + field3.getType().getSimpleName() + ")");
            } else {
                VelocityModule.velLog("[VEL] Mapped motion fields are NULL!");
            }
        }
        catch (Throwable throwable) {
            VelocityModule.velLog("[VEL] Failed to log mapped fields: " + throwable.getMessage());
        }
        try {
            Ries.getInstance().getEventBus().subscribe(PacketReceiveEvent.class, this.packetListener);
            Logger.info("Velocity: enabled");
        }
        catch (Throwable throwable) {
            Logger.warn("Velocity: subscribe failed: " + throwable.getMessage());
            VelocityModule.velLog("[VEL] Subscribe failed: " + throwable.getMessage());
        }
    }

    @Override
    public void onDisable() {
        VelocityModule.velLog("[VEL] Velocity DISABLED");
        if (this.packetListener != null) {
            try {
                Ries.getInstance().getEventBus().unsubscribe(PacketReceiveEvent.class, this.packetListener);
                Logger.info("Velocity: disabled");
            }
            catch (Throwable throwable) {
                Logger.warn("Velocity: unsubscribe failed: " + throwable.getMessage());
            }
            this.packetListener = null;
        }
    }

    @Override
    public void onUpdate() {
    }

    private int getPacketEntityId(Object object) throws Exception {
        Method method = MappingUtils.getMethod("S12PacketEntityVelocity.getEntityID");
        if (method != null) {
            method.setAccessible(true);
            return (Integer)method.invoke(object, new Object[0]);
        }
        Field field = MappingUtils.getField("S12PacketEntityVelocity.entityId");
        if (field != null) {
            field.setAccessible(true);
            return field.getInt(object);
        }
        Field field2 = MappingUtils.getField("S12PacketEntityVelocity.motionX");
        Field field3 = MappingUtils.getField("S12PacketEntityVelocity.motionY");
        Field field4 = MappingUtils.getField("S12PacketEntityVelocity.motionZ");
        for (Field field5 : object.getClass().getDeclaredFields()) {
            if (field5.getType() != Integer.TYPE || Modifier.isStatic(field5.getModifiers()) || field5.equals(field2) || field5.equals(field3) || field5.equals(field4)) continue;
            field5.setAccessible(true);
            return field5.getInt(object);
        }
        for (Field field5 : object.getClass().getDeclaredFields()) {
            if (field5.getType() != Integer.TYPE || Modifier.isStatic(field5.getModifiers())) continue;
            field5.setAccessible(true);
            return field5.getInt(object);
        }
        throw new NoSuchFieldException("entityId not found in S12PacketEntityVelocity");
    }

    private int getPlayerEntityId(Object object) throws Exception {
        Method method = MappingUtils.getMethod("Entity.getEntityId");
        if (method != null) {
            method.setAccessible(true);
            return (Integer)method.invoke(object, new Object[0]);
        }
        Field field = MappingUtils.getField("Entity.entityId");
        if (field != null) {
            field.setAccessible(true);
            return field.getInt(object);
        }
        for (Class<?> clazz = object.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
            for (Field field2 : clazz.getDeclaredFields()) {
                if (field2.getType() != Integer.TYPE || Modifier.isStatic(field2.getModifiers())) continue;
                field2.setAccessible(true);
                int n = field2.getInt(object);
                if (n <= 0) continue;
                return n;
            }
        }
        throw new NoSuchFieldException("entityId not found in player entity");
    }

    private boolean unsafePutInt(Object object, Field field, int n) {
        if (UNSAFE == null) {
            return false;
        }
        try {
            long l = UNSAFE.objectFieldOffset(field);
            UNSAFE.putInt(object, l, n);
            return true;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    private void handlePacket(PacketReceiveEvent packetReceiveEvent) {
        block35: {
            try {
                Object object;
                Object object2 = packetReceiveEvent.getPacket();
                if (object2 == null) {
                    return;
                }
                String string = object2.getClass().getName();
                ++this.totalPacketCount;
                if (this.logCount < 150 && (string.toLowerCase().contains("velocity") || string.toLowerCase().contains("s12") || string.toLowerCase().contains("explosion") || string.toLowerCase().contains("s27"))) {
                    ++this.logCount;
                    VelocityModule.velLog("[VEL] Received interesting packet: " + string + " (#" + this.totalPacketCount + ")");
                }
                Class<?> clazz = MinecraftMapper.get("S12PacketEntityVelocity");
                Class<?> clazz2 = MappingUtils.get("S27PacketExplosion");
                if (clazz2 != null && clazz2.isInstance(object2)) {
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] S27PacketExplosion intercepted, cancelling to reduce knockback!");
                    }
                    packetReceiveEvent.cancel();
                    return;
                }
                if (clazz == null) {
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] S12PacketEntityVelocity class not mapped in registry!");
                    }
                    return;
                }
                if (!clazz.isInstance(object2)) {
                    return;
                }
                if (this.logCount < 150) {
                    ++this.logCount;
                    VelocityModule.velLog("[VEL] S12 packet identified: " + string);
                }
                int n = -999;
                try {
                    n = this.getPacketEntityId(object2);
                }
                catch (Throwable throwable) {
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] Failed to read packet entity ID: " + throwable.getMessage());
                    }
                    return;
                }
                Object object3 = MinecraftMapper.getThePlayer();
                if (object3 == null) {
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] Local player object is null!");
                    }
                    return;
                }
                int n2 = -999;
                try {
                    n2 = this.getPlayerEntityId(object3);
                }
                catch (Throwable throwable) {
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] Failed to read player entity ID: " + throwable.getMessage());
                    }
                    return;
                }
                if (this.logCount < 150) {
                    ++this.logCount;
                    VelocityModule.velLog("[VEL] ID check: packetEntityId=" + n + ", playerEntityId=" + n2);
                }
                if (n != n2) {
                    return;
                }
                if (this.matchDumpCount < 5) {
                    ++this.matchDumpCount;
                    VelocityModule.velLog("[VEL] Matched packet dump " + this.matchDumpCount + ":");
                    for (Field field : object2.getClass().getDeclaredFields()) {
                        try {
                            field.setAccessible(true);
                            object = field.get(object2);
                            VelocityModule.velLog("[VEL]   Field: name=" + field.getName() + ", type=" + field.getType().getName() + ", value=" + object);
                            if (object == null || field.getType().isPrimitive() || field.getType().getName().startsWith("java.lang") || field.getType().getName().startsWith("java.util") || field.getType().getName().startsWith("[Ljava.lang")) continue;
                            VelocityModule.velLog("[VEL]     Inner Object " + field.getType().getName() + " fields:");
                            for (Field field2 : object.getClass().getDeclaredFields()) {
                                try {
                                    field2.setAccessible(true);
                                    Object object4 = field2.get(object);
                                    VelocityModule.velLog("[VEL]       InnerField: name=" + field2.getName() + ", type=" + field2.getType().getName() + ", value=" + object4);
                                }
                                catch (Throwable throwable) {
                                    // empty catch block
                                }
                            }
                        }
                        catch (Throwable throwable) {
                            VelocityModule.velLog("[VEL]   Field: name=" + field.getName() + " (failed to read: " + throwable.getMessage() + ")");
                        }
                    }
                }
                double d = (Double)this.horizontal.getValue() / 100.0;
                double d2 = (Double)this.vertical.getValue() / 100.0;
                if (d == 0.0 && d2 == 0.0) {
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] H & V are 0%, cancelling S12 packet completely!");
                    }
                    packetReceiveEvent.cancel();
                    return;
                }
                object = MappingUtils.getField("S12PacketEntityVelocity.motionX");
                Field[] fieldArray = MappingUtils.getField("S12PacketEntityVelocity.motionY");
                Field field = MappingUtils.getField("S12PacketEntityVelocity.motionZ");
                if (object == null || fieldArray == null || field == null) {
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] motion fields null in mappings! Cancelling packet as fallback.");
                    }
                    packetReceiveEvent.cancel();
                    return;
                }
                try {
                    this.scaleAndWriteField(object2, (Field)object, d);
                    this.scaleAndWriteField(object2, (Field)fieldArray, d2);
                    this.scaleAndWriteField(object2, field, d);
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] Scaled packet successfully! H_multiplier=" + d + ", V_multiplier=" + d2);
                    }
                }
                catch (Throwable throwable) {
                    packetReceiveEvent.cancel();
                    if (this.logCount < 150) {
                        ++this.logCount;
                        VelocityModule.velLog("[VEL] Failed to write scaled values: " + throwable.getMessage() + ". Cancelled packet as fallback.");
                    }
                }
            }
            catch (Throwable throwable) {
                if (this.logCount >= 150) break block35;
                ++this.logCount;
                StringWriter stringWriter = new StringWriter();
                throwable.printStackTrace(new PrintWriter(stringWriter));
                VelocityModule.velLog("[VEL] handlePacket Exception: " + stringWriter.toString());
            }
        }
    }

    private void scaleAndWriteField(Object object, Field field, double d) throws Throwable {
        field.setAccessible(true);
        Object object2 = field.get(object);
        if (!(object2 instanceof Number)) {
            return;
        }
        double d2 = ((Number)object2).doubleValue();
        double d3 = d2 * d;
        Class<?> clazz = field.getType();
        if (clazz == Double.TYPE || clazz == Double.class) {
            if (UNSAFE != null) {
                UNSAFE.putDouble(object, UNSAFE.objectFieldOffset(field), d3);
            } else {
                field.setDouble(object, d3);
            }
        } else if (clazz == Float.TYPE || clazz == Float.class) {
            if (UNSAFE != null) {
                UNSAFE.putFloat(object, UNSAFE.objectFieldOffset(field), (float)d3);
            } else {
                field.setFloat(object, (float)d3);
            }
        } else if (clazz == Integer.TYPE || clazz == Integer.class) {
            int n = (int)Math.round(d3);
            if (UNSAFE != null) {
                UNSAFE.putInt(object, UNSAFE.objectFieldOffset(field), n);
            } else {
                field.setInt(object, n);
            }
        } else if (clazz == Short.TYPE || clazz == Short.class) {
            short s = (short)Math.round(d3);
            if (UNSAFE != null) {
                UNSAFE.putShort(object, UNSAFE.objectFieldOffset(field), s);
            } else {
                field.setShort(object, s);
            }
        } else if (clazz == Long.TYPE || clazz == Long.class) {
            long l = Math.round(d3);
            if (UNSAFE != null) {
                UNSAFE.putLong(object, UNSAFE.objectFieldOffset(field), l);
            } else {
                field.setLong(object, l);
            }
        } else if (clazz == Byte.TYPE || clazz == Byte.class) {
            byte by = (byte)Math.round(d3);
            if (UNSAFE != null) {
                UNSAFE.putByte(object, UNSAFE.objectFieldOffset(field), by);
            } else {
                field.setByte(object, by);
            }
        }
    }

    private static void velLog(String string) {
        String string2 = SDF.format(new Date()) + " " + string;
        Logger.info(string2);
        try (PrintWriter printWriter = new PrintWriter(new FileWriter(VEL_LOG, true));){
            printWriter.println(string2);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

