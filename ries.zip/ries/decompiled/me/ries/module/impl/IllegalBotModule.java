/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.util.ChatUtils;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class IllegalBotModule
extends Module {
    private boolean active = false;
    private long lastClickTime = 0L;

    public IllegalBotModule() {
        super("IllegalBot", "Automated W-walking and armor stripping for grinding", Category.MOD, 0);
    }

    @Override
    public void onUpdate() {
        double d;
        double d2;
        if (!this.isEnabled()) {
            return;
        }
        Object object = this.getThePlayer();
        if (object == null) {
            return;
        }
        double d3 = MinecraftMapper.getPosX();
        if (this.isAtStart(d3, d2 = MinecraftMapper.getPosY(), d = MinecraftMapper.getPosZ())) {
            if (!this.active) {
                this.active = true;
                ChatUtils.addChatMessage("\u00a77[IllegalBot] \u00a7aBa\u015flang\u0131\u00e7 konumuna ula\u015f\u0131ld\u0131 (0, 87, -18). W bas\u0131l\u0131yor ve setler \u00e7\u0131kar\u0131l\u0131yor.");
            }
            this.stripArmor(object);
        }
        if (this.isAtTarget(d3, d2, d) && this.active) {
            this.active = false;
            this.setMoveForward(object, 0.0f);
            this.setKeyForward(false);
            ChatUtils.addChatMessage("\u00a77[IllegalBot] \u00a7cHedef konuma ula\u015f\u0131ld\u0131 (0, 48, 1). Durduruldu.");
        }
        if (this.active) {
            this.setKeyForward(true);
            this.setMoveForward(object, 1.0f);
            float f = MinecraftMapper.getRotationYaw();
            double d4 = 0.22;
            double d5 = Math.toRadians(f);
            MinecraftMapper.setMotionX(-Math.sin(d5) * d4);
            MinecraftMapper.setMotionZ(Math.cos(d5) * d4);
        }
    }

    @Override
    public void onEnable() {
        this.active = false;
    }

    @Override
    public void onDisable() {
        this.active = false;
        Object object = this.getThePlayer();
        if (object != null) {
            this.setMoveForward(object, 0.0f);
        }
        this.setKeyForward(false);
    }

    private boolean isAtStart(double d, double d2, double d3) {
        return Math.abs(d - 0.0) < 1.5 && Math.abs(d2 - 87.0) < 1.5 && Math.abs(d3 - -18.0) < 1.5;
    }

    private boolean isAtTarget(double d, double d2, double d3) {
        return Math.abs(d - 0.0) < 1.5 && Math.abs(d2 - 48.0) < 1.5 && Math.abs(d3 - 1.0) < 1.5;
    }

    private void stripArmor(Object object) {
        try {
            long l = System.currentTimeMillis();
            if (l - this.lastClickTime < 150L) {
                return;
            }
            Object object2 = MinecraftMapper.getMinecraft();
            if (object2 == null) {
                return;
            }
            Field field = MappingUtils.getField("Minecraft.playerController");
            if (field == null) {
                return;
            }
            field.setAccessible(true);
            Object object3 = field.get(object2);
            if (object3 == null) {
                return;
            }
            Method method = MappingUtils.getMethod("PlayerControllerMP.windowClick");
            if (method == null) {
                return;
            }
            method.setAccessible(true);
            Field field2 = MappingUtils.getField("EntityPlayer.inventoryContainer");
            if (field2 == null) {
                return;
            }
            field2.setAccessible(true);
            Object object4 = field2.get(object);
            if (object4 == null) {
                return;
            }
            Method method2 = MappingUtils.getMethod("Container.getSlot");
            Method method3 = MappingUtils.getMethod("Slot.getStack");
            if (method2 == null || method3 == null) {
                return;
            }
            method2.setAccessible(true);
            method3.setAccessible(true);
            for (int i = 5; i <= 8; ++i) {
                Object object5;
                Object object6 = method2.invoke(object4, i);
                if (object6 == null || (object5 = method3.invoke(object6, new Object[0])) == null) continue;
                method.invoke(object3, 0, i, 0, 1, object);
                this.lastClickTime = l;
                break;
            }
        }
        catch (Throwable throwable) {
            Logger.warn("[IllegalBot] stripArmor hatas\u0131: " + throwable.getMessage());
        }
    }

    private void setMoveForward(Object object, float f) {
        block5: {
            try {
                Object fieldArray = null;
                block2: for (Class<?> clazz = object.getClass(); clazz != null && fieldArray == null; clazz = clazz.getSuperclass()) {
                    for (Field fieldArray2 : clazz.getDeclaredFields()) {
                        if (!fieldArray2.getType().getName().toLowerCase().contains("movementinput")) continue;
                        fieldArray = fieldArray2;
                        continue block2;
                    }
                }
                if (fieldArray == null) break block5;
                ((Field)fieldArray).setAccessible(true);
                Object object2 = ((Field)fieldArray).get(object);
                if (object2 == null) break block5;
                Field[] fieldArray3 = object2.getClass().getDeclaredFields();
                int n = 0;
                for (Field field : fieldArray3) {
                    if (field.getType() != Float.TYPE) continue;
                    field.setAccessible(true);
                    if (++n != 2) continue;
                    field.setFloat(object2, f);
                    break;
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void setKeyForward(boolean bl) {
        try {
            Field field;
            Object object = MinecraftMapper.getMinecraft();
            if (object != null && (field = MappingUtils.getField("Minecraft.gameSettings")) != null) {
                Field field2;
                field.setAccessible(true);
                Object object2 = field.get(object);
                if (object2 != null && (field2 = MappingUtils.getField("GameSettings.keyBindForward")) != null) {
                    Field field3;
                    field2.setAccessible(true);
                    Object object3 = field2.get(object2);
                    if (object3 != null && (field3 = MappingUtils.getField("KeyBinding.pressed")) != null) {
                        field3.setAccessible(true);
                        field3.setBoolean(object3, bl);
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

