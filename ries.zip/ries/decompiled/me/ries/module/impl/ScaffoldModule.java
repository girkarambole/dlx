/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class ScaffoldModule
extends Module {
    private final NumberOption delay = new NumberOption("Delay", 50.0, 0.0, 500.0, 10.0, this);
    private final BooleanOption rotations = new BooleanOption("Rotations", true, (Module)this);
    private final BooleanOption safeWalk = new BooleanOption("SafeWalk", true, (Module)this);
    private long lastPlaceTime = 0L;
    private final Random random = new Random();
    private boolean loggedDiagnostics = false;
    private int exceptionCount = 0;
    private static final String SC_LOG = "C:\\ries\\logs\\sc_debug.log";
    private static final SimpleDateFormat SDF = new SimpleDateFormat("HH:mm:ss.SSS");

    public ScaffoldModule() {
        super("Scaffold", "Automatically places blocks under your feet", Category.MOVEMENT, 0);
        this.delay.setGroup("Placement");
        this.rotations.setGroup("Rotations");
        this.safeWalk.setGroup("Movement");
        this.addOptions(this.delay, this.rotations, this.safeWalk);
    }

    @Override
    public String getOptionPrefix() {
        return ((Double)this.delay.getValue()).intValue() + "ms";
    }

    @Override
    public void onEnable() {
        this.lastPlaceTime = 0L;
        this.loggedDiagnostics = false;
        this.exceptionCount = 0;
        ScaffoldModule.scLog("[SC] Scaffold ENABLED");
    }

    @Override
    public void onDisable() {
        ScaffoldModule.scLog("[SC] Scaffold DISABLED");
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        try {
            boolean bl;
            double d;
            double d2;
            int n;
            int n2;
            long l;
            long l2;
            long l3;
            Object object;
            Object object2 = this.getThePlayer();
            if (object2 == null) {
                return;
            }
            int n3 = this.findBlockSlot(object2);
            if (n3 == -1) {
                return;
            }
            if (!this.loggedDiagnostics) {
                this.loggedDiagnostics = true;
                try {
                    Object object3 = this.getMinecraft();
                    object = this.getTheWorld();
                    ScaffoldModule.scLog("[SC] Diagnostics: mc=" + (object3 != null ? object3.getClass().getName() : "null") + ", player=" + (object2 != null ? object2.getClass().getName() : "null") + ", world=" + (object != null ? object.getClass().getName() : "null"));
                    ScaffoldModule.scLog("[SC] Player Pos via Mapper (static): " + MinecraftMapper.getPosX() + ", " + MinecraftMapper.getPosY() + ", " + MinecraftMapper.getPosZ());
                    ScaffoldModule.scLog("[SC] Player Pos via Mapper (entity): " + MinecraftMapper.getPosX(object2) + ", " + MinecraftMapper.getPosY(object2) + ", " + MinecraftMapper.getPosZ(object2));
                    ScaffoldModule.scLog("[SC] inventory slots count: " + (MappingUtils.getInventory(object2) != null ? "ok" : "null"));
                }
                catch (Throwable throwable) {
                    ScaffoldModule.scLog("[SC] Diagnostics exception: " + throwable.getMessage());
                }
            }
            if ((l3 = System.currentTimeMillis()) - this.lastPlaceTime < (l2 = ((Double)this.delay.getValue()).longValue()) + (l = (long)this.random.nextInt(30))) {
                return;
            }
            double d3 = MinecraftMapper.getPosX(object2);
            double d4 = MinecraftMapper.getPosY(object2);
            double d5 = MinecraftMapper.getPosZ(object2);
            int n4 = (int)Math.floor(d3);
            int n5 = this.getBlockId(n4, n2 = (int)Math.floor(d4) - 1, n = (int)Math.floor(d5));
            if (this.isReplaceable(n5)) {
                object = this.findBlockData(n4, n2, n);
                if (object == null) {
                    object = this.findBlockData(n4, n2 - 1, n);
                }
                if (object != null) {
                    int n6 = this.getCurrentSlot(object2);
                    this.switchSlot(object2, n3);
                    Object object4 = MappingUtils.getInventory(object2);
                    if (object4 != null) {
                        Object[] objectArray = this.getMainInventory(object4);
                        if (objectArray != null && n3 < objectArray.length) {
                            Object object5 = objectArray[n3];
                            d2 = ((BlockData)object).x + 0.5;
                            d = ((BlockData)object).y + 0.5;
                            double d6 = ((BlockData)object).z + 0.5;
                            if (((BlockData)object).face == 1) {
                                d += 0.5;
                            } else if (((BlockData)object).face == 2) {
                                d6 -= 0.5;
                            } else if (((BlockData)object).face == 3) {
                                d6 += 0.5;
                            } else if (((BlockData)object).face == 4) {
                                d2 -= 0.5;
                            } else if (((BlockData)object).face == 5) {
                                d2 += 0.5;
                            }
                            float[] fArray = this.getRotations(d3, d4 + 1.62, d5, d2, d, d6);
                            if (((Boolean)this.rotations.getValue()).booleanValue()) {
                                float f = (this.random.nextFloat() - 0.5f) * 1.5f;
                                float f2 = (this.random.nextFloat() - 0.5f) * 1.5f;
                                this.sendSilentRotation(object2, fArray[0] + f, fArray[1] + f2);
                            }
                            this.placeBlock(object2, (BlockData)object, object5);
                            this.lastPlaceTime = l3;
                        } else {
                            ScaffoldModule.scLog("[SC] main inventory array null or slot out of bounds");
                        }
                    } else {
                        ScaffoldModule.scLog("[SC] player inventory is null");
                    }
                    this.switchSlot(object2, n6);
                }
            }
            if (((Boolean)this.safeWalk.getValue()).booleanValue() && (bl = this.isOnGround(object2))) {
                double d7 = MinecraftMapper.getMotionX();
                double d8 = MinecraftMapper.getMotionZ();
                d2 = d3 + d7 * 2.0;
                d = d5 + d8 * 2.0;
                int n7 = this.getBlockId((int)Math.floor(d2), n2, (int)Math.floor(d));
                if (this.isReplaceable(n7)) {
                    MinecraftMapper.setMotionX(0.0);
                    MinecraftMapper.setMotionZ(0.0);
                }
            }
        }
        catch (Throwable throwable) {
            ScaffoldModule.scLog("[SC] onUpdate Exception: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
        }
    }

    private int findBlockSlot(Object object) {
        try {
            Object object2 = MappingUtils.getInventory(object);
            if (object2 == null) {
                return -1;
            }
            Object[] objectArray = this.getMainInventory(object2);
            if (objectArray == null) {
                return -1;
            }
            for (int i = 0; i < 9; ++i) {
                String string;
                Object object3 = objectArray[i];
                if (object3 == null || (string = MappingUtils.getItemName(object3)) == null || !this.isBlockItem(string)) continue;
                return i;
            }
        }
        catch (Throwable throwable) {
            ScaffoldModule.scLog("[SC] findBlockSlot error: " + throwable.getMessage());
        }
        return -1;
    }

    private boolean isBlockItem(String string) {
        String string2 = string.toLowerCase();
        return !string2.contains("sword") && !string2.contains("axe") && !string2.contains("pickaxe") && !string2.contains("shovel") && !string2.contains("apple") && !string2.contains("skull") && !string2.contains("head") && !string2.contains("helmet") && !string2.contains("potion") && !string2.contains("bow") && !string2.contains("arrow") && !string2.contains("bucket") && !string2.contains("compass") && !string2.contains("clock") && !string2.contains("shears");
    }

    private boolean isReplaceable(int n) {
        return n == 0 || n == 8 || n == 9 || n == 10 || n == 11 || n == 31;
    }

    private int getCurrentSlot(Object object) {
        try {
            Field field;
            Object object2 = MappingUtils.getInventory(object);
            if (object2 != null && (field = MappingUtils.getField("InventoryPlayer.currentItem")) != null) {
                field.setAccessible(true);
                return field.getInt(object2);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return 0;
    }

    private void switchSlot(Object object, int n) {
        try {
            AnnotatedElement annotatedElement;
            Object object2 = MappingUtils.getInventory(object);
            if (object2 != null && (annotatedElement = MappingUtils.getField("InventoryPlayer.currentItem")) != null) {
                ((Field)annotatedElement).setAccessible(true);
                ((Field)annotatedElement).setInt(object2, n);
            }
            if ((annotatedElement = MinecraftMapper.get("C09PacketHeldItemChange")) != null) {
                Constructor constructor = ((Class)annotatedElement).getDeclaredConstructor(Integer.TYPE);
                constructor.setAccessible(true);
                Object t = constructor.newInstance(n);
                this.sendPacket(object, t);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void sendSilentRotation(Object object, float f, float f2) {
        try {
            Class<?> clazz = MappingUtils.get("C05PacketPlayerLook");
            if (clazz != null) {
                boolean bl = this.isOnGround(object);
                Constructor<?> constructor = clazz.getConstructor(Float.TYPE, Float.TYPE, Boolean.TYPE);
                constructor.setAccessible(true);
                Object obj = constructor.newInstance(Float.valueOf(f), Float.valueOf(f2), bl);
                this.sendPacket(object, obj);
                return;
            }
            Class<?> clazz2 = MappingUtils.get("C03PacketPlayer");
            if (clazz2 != null) {
                Constructor<?> constructor = clazz2.getConstructor(new Class[0]);
                constructor.setAccessible(true);
                Object obj = constructor.newInstance(new Object[0]);
                Field field = MappingUtils.getField("C03PacketPlayer.yaw");
                Field field2 = MappingUtils.getField("C03PacketPlayer.pitch");
                Field field3 = MappingUtils.getField("C03PacketPlayer.onGround");
                if (field != null && field2 != null) {
                    field.setAccessible(true);
                    field2.setAccessible(true);
                    field.setFloat(obj, f);
                    field2.setFloat(obj, f2);
                    if (field3 != null) {
                        field3.setAccessible(true);
                        field3.setBoolean(obj, this.isOnGround(object));
                    }
                    this.sendPacket(object, obj);
                }
            }
        }
        catch (Throwable throwable) {
            ScaffoldModule.scLog("[SC] sendSilentRotation Exception: " + throwable.getMessage());
        }
    }

    private void sendPacket(Object object, Object object2) {
        try {
            Field field = MappingUtils.getField("EntityPlayerSP.sendQueue");
            if (field == null) {
                field = MinecraftMapper.getFieldByType(object.getClass(), MinecraftMapper.get("NetHandlerPlayClient"));
            }
            if (field == null) {
                return;
            }
            field.setAccessible(true);
            Object object3 = field.get(object);
            if (object3 == null) {
                return;
            }
            Method method = MappingUtils.getMethod("NetHandlerPlayClient.sendPacket");
            if (method == null) {
                return;
            }
            method.setAccessible(true);
            method.invoke(object3, object2);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void swingArm(Object object) {
        try {
            Method method = MappingUtils.getMethod("EntityPlayerSP.swingItem");
            if (method != null) {
                method.setAccessible(true);
                method.invoke(object, new Object[0]);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private boolean isOnGround(Object object) {
        try {
            Field field = MappingUtils.getField("Entity.onGround");
            if (field != null) {
                field.setAccessible(true);
                return field.getBoolean(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return true;
    }

    private Object createBlockPos(int n, int n2, int n3) {
        try {
            Class<?> clazz = MappingUtils.get("BlockPos");
            if (clazz == null) {
                return null;
            }
            Constructor<?> constructor = clazz.getConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE);
            constructor.setAccessible(true);
            return constructor.newInstance(n, n2, n3);
        }
        catch (Throwable throwable) {
            try {
                Class<?> clazz = MappingUtils.get("BlockPos");
                Constructor<?> constructor = clazz.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE);
                constructor.setAccessible(true);
                return constructor.newInstance(n, n2, n3);
            }
            catch (Throwable throwable2) {
                return null;
            }
        }
    }

    private int getBlockId(int n, int n2, int n3) {
        block5: {
            try {
                Object object = this.getTheWorld();
                if (object == null) {
                    return 0;
                }
                Method method = MappingUtils.getMethod("World.getChunkFromChunkCoords");
                Method method2 = MappingUtils.getMethod("Chunk.getBlock");
                Method method3 = MappingUtils.getMethod("Block.getIdFromBlock");
                if (method != null && method2 != null && method3 != null) {
                    Object object2;
                    method.setAccessible(true);
                    method2.setAccessible(true);
                    method3.setAccessible(true);
                    Object object3 = method.invoke(object, n >> 4, n3 >> 4);
                    if (object3 != null && (object2 = method2.invoke(object3, n & 0xF, n2, n3 & 0xF)) != null) {
                        return (Integer)method3.invoke(null, object2);
                    }
                }
            }
            catch (Throwable throwable) {
                if (this.exceptionCount >= 5) break block5;
                ++this.exceptionCount;
                StringWriter stringWriter = new StringWriter();
                throwable.printStackTrace(new PrintWriter(stringWriter));
                ScaffoldModule.scLog("[SC] getBlockId exception " + this.exceptionCount + ": " + stringWriter.toString());
            }
        }
        return 0;
    }

    private BlockData getBlockData(int n, int n2, int n3) {
        Object object = this.createBlockPos(n, n2 - 1, n3);
        if (object != null && !this.isReplaceable(this.getBlockId(n, n2 - 1, n3))) {
            return new BlockData(object, 1, n, n2 - 1, n3);
        }
        Object object2 = this.createBlockPos(n, n2, n3 + 1);
        if (object2 != null && !this.isReplaceable(this.getBlockId(n, n2, n3 + 1))) {
            return new BlockData(object2, 2, n, n2, n3 + 1);
        }
        Object object3 = this.createBlockPos(n, n2, n3 - 1);
        if (object3 != null && !this.isReplaceable(this.getBlockId(n, n2, n3 - 1))) {
            return new BlockData(object3, 3, n, n2, n3 - 1);
        }
        Object object4 = this.createBlockPos(n + 1, n2, n3);
        if (object4 != null && !this.isReplaceable(this.getBlockId(n + 1, n2, n3))) {
            return new BlockData(object4, 4, n + 1, n2, n3);
        }
        Object object5 = this.createBlockPos(n - 1, n2, n3);
        if (object5 != null && !this.isReplaceable(this.getBlockId(n - 1, n2, n3))) {
            return new BlockData(object5, 5, n - 1, n2, n3);
        }
        return null;
    }

    private BlockData findBlockData(int n, int n2, int n3) {
        BlockData blockData = this.getBlockData(n, n2, n3);
        if (blockData != null) {
            return blockData;
        }
        blockData = this.getBlockData(n, n2 - 1, n3);
        if (blockData != null) {
            return blockData;
        }
        blockData = this.getBlockData(n - 1, n2, n3);
        if (blockData != null) {
            return blockData;
        }
        blockData = this.getBlockData(n + 1, n2, n3);
        if (blockData != null) {
            return blockData;
        }
        blockData = this.getBlockData(n, n2, n3 - 1);
        if (blockData != null) {
            return blockData;
        }
        blockData = this.getBlockData(n, n2, n3 + 1);
        if (blockData != null) {
            return blockData;
        }
        return null;
    }

    private void placeBlock(Object object, BlockData blockData, Object object2) {
        try {
            Constructor<?> constructor3;
            Class<?> clazz = MinecraftMapper.get("C08PacketPlayerBlockPlacement");
            if (clazz == null) {
                ScaffoldModule.scLog("[SC] C08 class null");
                return;
            }
            Class<?> clazz2 = MappingUtils.get("BlockPos");
            Class<?> clazz3 = MappingUtils.get("ItemStack");
            if (clazz2 == null || clazz3 == null) {
                ScaffoldModule.scLog("[SC] BlockPos/ItemStack class null");
                return;
            }
            Constructor<?> constructor2 = null;
            for (Constructor<?> constructor3 : clazz.getDeclaredConstructors()) {
                Class<?>[] classArray = constructor3.getParameterTypes();
                if (classArray.length != 6 || classArray[0] != clazz2 || classArray[1] != Integer.TYPE || classArray[2] != clazz3 || classArray[3] != Float.TYPE || classArray[4] != Float.TYPE || classArray[5] != Float.TYPE) continue;
                constructor2 = constructor3;
                break;
            }
            if (constructor2 == null) {
                ScaffoldModule.scLog("[SC] C08 constructor not found by exact type!");
                return;
            }
            constructor2.setAccessible(true);
            float f = 0.45f + this.random.nextFloat() * 0.1f;
            float f2 = 0.45f + this.random.nextFloat() * 0.1f;
            float f3 = 0.45f + this.random.nextFloat() * 0.1f;
            if (blockData.face == 1) {
                f2 = 0.9f + this.random.nextFloat() * 0.1f;
            } else if (blockData.face == 2) {
                f3 = 0.0f + this.random.nextFloat() * 0.1f;
            } else if (blockData.face == 3) {
                f3 = 0.9f + this.random.nextFloat() * 0.1f;
            } else if (blockData.face == 4) {
                f = 0.0f + this.random.nextFloat() * 0.1f;
            } else if (blockData.face == 5) {
                f = 0.9f + this.random.nextFloat() * 0.1f;
            }
            constructor3 = constructor2.newInstance(blockData.pos, blockData.face, object2, Float.valueOf(f), Float.valueOf(f2), Float.valueOf(f3));
            this.sendPacket(object, constructor3);
            this.swingArm(object);
        }
        catch (Throwable throwable) {
            ScaffoldModule.scLog("[SC] placeBlock Exception: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
        }
    }

    private Object[] getMainInventory(Object object) {
        try {
            Field field = MappingUtils.getField("InventoryPlayer.mainInventory");
            if (field != null) {
                field.setAccessible(true);
                Object object2 = field.get(object);
                if (object2 instanceof Object[]) {
                    return (Object[])object2;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private float[] getRotations(double d, double d2, double d3, double d4, double d5, double d6) {
        double d7 = d4 - d;
        double d8 = d5 - d2;
        double d9 = d6 - d3;
        double d10 = Math.sqrt(d7 * d7 + d9 * d9);
        float f = (float)(Math.atan2(d9, d7) * 180.0 / Math.PI) - 90.0f;
        float f2 = (float)(-(Math.atan2(d8, d10) * 180.0 / Math.PI));
        return new float[]{f, f2};
    }

    private static void scLog(String string) {
        String string2 = SDF.format(new Date()) + " " + string;
        Logger.info(string2);
        try (PrintWriter printWriter = new PrintWriter(new FileWriter(SC_LOG, true));){
            printWriter.println(string2);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static class BlockData {
        public Object pos;
        public int face;
        public double x;
        public double y;
        public double z;

        public BlockData(Object object, int n, double d, double d2, double d3) {
            this.pos = object;
            this.face = n;
            this.x = d;
            this.y = d2;
            this.z = d3;
        }
    }
}

