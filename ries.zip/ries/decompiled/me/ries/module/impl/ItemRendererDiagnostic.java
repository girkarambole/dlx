/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.objectweb.asm.ClassReader
 *  org.objectweb.asm.ClassVisitor
 *  org.objectweb.asm.Type
 *  org.objectweb.asm.tree.AbstractInsnNode
 *  org.objectweb.asm.tree.ClassNode
 *  org.objectweb.asm.tree.FieldInsnNode
 *  org.objectweb.asm.tree.MethodInsnNode
 *  org.objectweb.asm.tree.MethodNode
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import me.ries.loader.ClassByteResolver;
import me.ries.mapping.MinecraftMapper;
import me.ries.util.MappingUtils;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

public class ItemRendererDiagnostic {
    public static void analyze() {
        System.out.println("\n[DIAG] ====== ItemRenderer Call Analysis ======");
        try {
            byte[] erBytes;
            Class<?> cur;
            Class<?> entityRendererClass = MappingUtils.get("EntityRenderer");
            Class<?> itemRendererClass = MappingUtils.get("ItemRenderer");
            if (entityRendererClass == null) {
                System.out.println("[DIAG] EntityRenderer class NOT mapped!");
                return;
            }
            if (itemRendererClass == null) {
                System.out.println("[DIAG] ItemRenderer class NOT mapped!");
                return;
            }
            String irInternalName = Type.getInternalName(itemRendererClass);
            String erInternalName = Type.getInternalName(entityRendererClass);
            System.out.println("[DIAG] EntityRenderer = " + entityRendererClass.getName() + " (" + erInternalName + ")");
            System.out.println("[DIAG] ItemRenderer = " + itemRendererClass.getName() + " (" + irInternalName + ")");
            Method mRIFP = MappingUtils.getMethod("ItemRenderer.renderItemInFirstPerson");
            Method mRI = MappingUtils.getMethod("ItemRenderer.renderItem");
            String rifpName = mRIFP != null ? mRIFP.getName() : null;
            String riName = mRI != null ? mRI.getName() : null;
            System.out.println("[DIAG] renderItemInFirstPerson obf name = " + rifpName);
            System.out.println("[DIAG] renderItem obf name = " + riName);
            System.out.println("[DIAG] --- ItemRenderer fields in EntityRenderer ---");
            Object mc = MinecraftMapper.getMinecraft();
            Object er = null;
            if (mc != null) {
                for (cur = mc.getClass(); cur != null && cur != Object.class; cur = cur.getSuperclass()) {
                    for (Field f : cur.getDeclaredFields()) {
                        if (MappingUtils.get("EntityRenderer") == null || !MappingUtils.get("EntityRenderer").isAssignableFrom(f.getType())) continue;
                        f.setAccessible(true);
                        er = f.get(mc);
                        System.out.println("[DIAG] Found ER in mc." + f.getName() + " class=" + f.getType().getName());
                    }
                }
            }
            if (er != null) {
                for (cur = er.getClass(); cur != null && cur != Object.class; cur = cur.getSuperclass()) {
                    for (Field f : cur.getDeclaredFields()) {
                        if (Modifier.isStatic(f.getModifiers()) || !itemRendererClass.isAssignableFrom(f.getType())) continue;
                        f.setAccessible(true);
                        Object val = f.get(er);
                        System.out.println("[DIAG] ER." + f.getName() + " type=" + f.getType().getName() + " val=" + (val != null ? val.getClass().getName() : "null") + " declared_in=" + cur.getSimpleName() + " isFinal=" + Modifier.isFinal(f.getModifiers()));
                    }
                }
            }
            if ((erBytes = MinecraftMapper.getClassBytes(entityRendererClass)) == null || erBytes.length == 0) {
                erBytes = ClassByteResolver.readClassBytes(entityRendererClass);
            }
            if (erBytes == null || erBytes.length == 0) {
                System.out.println("[DIAG] Cannot read EntityRenderer bytecode!");
                return;
            }
            ClassNode erNode = new ClassNode();
            new ClassReader(erBytes).accept((ClassVisitor)erNode, 0);
            System.out.println("[DIAG] --- Scanning EntityRenderer methods for IR calls ---");
            for (MethodNode mn : erNode.methods) {
                for (AbstractInsnNode insn : mn.instructions.toArray()) {
                    if (!(insn instanceof MethodInsnNode)) continue;
                    MethodInsnNode call = (MethodInsnNode)insn;
                    if (!call.owner.equals(irInternalName) && !ItemRendererDiagnostic.isCallToIRMethod(call, rifpName, riName)) continue;
                    String opcName = ItemRendererDiagnostic.opcodeToName(call.getOpcode());
                    System.out.println("[DIAG] FOUND CALL: " + mn.name + mn.desc + " -> " + opcName + " " + call.owner + "." + call.name + call.desc);
                    AbstractInsnNode prev = ItemRendererDiagnostic.findPreviousFieldLoad(insn);
                    if (!(prev instanceof FieldInsnNode)) continue;
                    FieldInsnNode fld = (FieldInsnNode)prev;
                    System.out.println("[DIAG]   loaded from field: " + fld.owner + "." + fld.name + " (" + fld.desc + ")");
                }
            }
            System.out.println("[DIAG] --- Scanning ItemRenderer own methods ---");
            byte[] irBytes = MinecraftMapper.getClassBytes(itemRendererClass);
            if (irBytes == null || irBytes.length == 0) {
                irBytes = ClassByteResolver.readClassBytes(itemRendererClass);
            }
            if (irBytes != null && irBytes.length > 0) {
                ClassNode irNode = new ClassNode();
                new ClassReader(irBytes).accept((ClassVisitor)irNode, 0);
                System.out.println("[DIAG] ItemRenderer methods:");
                for (MethodNode mn : irNode.methods) {
                    if ("<init>".equals(mn.name) || "<clinit>".equals(mn.name)) continue;
                    System.out.println("[DIAG]   " + mn.name + mn.desc + " access=" + ItemRendererDiagnostic.accessToString(mn.access));
                }
                if (rifpName != null) {
                    for (MethodNode mn : irNode.methods) {
                        if (!mn.name.equals(rifpName)) continue;
                        System.out.println("[DIAG] Inside " + rifpName + ":");
                        for (AbstractInsnNode insn : mn.instructions.toArray()) {
                            if (!(insn instanceof MethodInsnNode)) continue;
                            MethodInsnNode call = (MethodInsnNode)insn;
                            if (!call.owner.equals(irInternalName)) continue;
                            System.out.println("[DIAG]   calls " + ItemRendererDiagnostic.opcodeToName(call.getOpcode()) + " " + call.name + call.desc);
                        }
                    }
                }
            }
            System.out.println("[DIAG] ====== Analysis Complete ======\n");
        }
        catch (Throwable t) {
            System.out.println("[DIAG] Analysis FAILED: " + t.getClass().getName() + ": " + t.getMessage());
            t.printStackTrace();
        }
    }

    private static boolean isCallToIRMethod(MethodInsnNode call, String rifpName, String riName) {
        if (rifpName != null && call.name.equals(rifpName)) {
            return true;
        }
        return riName != null && call.name.equals(riName);
    }

    private static AbstractInsnNode findPreviousFieldLoad(AbstractInsnNode insn) {
        AbstractInsnNode cur = insn.getPrevious();
        for (int depth = 0; cur != null && depth < 20; cur = cur.getPrevious(), ++depth) {
            FieldInsnNode fld;
            if (!(cur instanceof FieldInsnNode) || (fld = (FieldInsnNode)cur).getOpcode() != 180 && fld.getOpcode() != 178) continue;
            return fld;
        }
        return null;
    }

    private static String opcodeToName(int opcode) {
        switch (opcode) {
            case 182: {
                return "INVOKEVIRTUAL";
            }
            case 183: {
                return "INVOKESPECIAL";
            }
            case 184: {
                return "INVOKESTATIC";
            }
            case 185: {
                return "INVOKEINTERFACE";
            }
        }
        return "INVOKE_" + opcode;
    }

    private static String accessToString(int access) {
        StringBuilder sb = new StringBuilder();
        if ((access & 1) != 0) {
            sb.append("public ");
        }
        if ((access & 2) != 0) {
            sb.append("private ");
        }
        if ((access & 4) != 0) {
            sb.append("protected ");
        }
        if ((access & 0x10) != 0) {
            sb.append("final ");
        }
        if ((access & 8) != 0) {
            sb.append("static ");
        }
        return sb.toString().trim();
    }
}

