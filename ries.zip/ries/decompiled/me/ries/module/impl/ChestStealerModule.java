/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
package me.ries.module.impl;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import me.ries.Ries;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.InvManagerModule;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;

public class ChestStealerModule
extends Module {
    private final NumberOption delay = new NumberOption("Delay", 80.0, 0.0, 500.0, 10.0, this);
    private final BooleanOption autoClose = new BooleanOption("Auto Close", true, (Module)this);
    private long lastLootTime = 0L;
    private boolean cacheBuilt = false;
    private Field containerFieldOnGui = null;
    private Field slotsListField = null;
    private Field windowIdField = null;
    private Method getSlotMethod = null;
    private Method getStackMethod = null;
    private Method windowClickMethod = null;
    private Field playerControllerField = null;
    private static final String CS_LOG = "C:\\ries\\logs\\cs_debug.log";
    private static final SimpleDateFormat SDF = new SimpleDateFormat("HH:mm:ss.SSS");

    public ChestStealerModule() {
        super("ChestStealer", "Automatically steals items from chests", Category.PLAYER, 0);
        this.delay.setGroup("Stealer");
        this.autoClose.setGroup("Stealer");
        this.addOptions(this.delay, this.autoClose);
    }

    @Override
    public String getOptionPrefix() {
        return ((Double)this.delay.getValue()).intValue() + "ms";
    }

    @Override
    public void onEnable() {
        this.lastLootTime = 0L;
        this.cacheBuilt = false;
        ChestStealerModule.csLog("[CS] ChestStealer ENABLED");
    }

    @Override
    public void onDisable() {
        ChestStealerModule.csLog("[CS] ChestStealer DISABLED");
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        try {
            void var12_20;
            Object object2 = MinecraftMapper.getCurrentScreen();
            if (object2 == null) {
                return;
            }
            Class<?> clazz = MinecraftMapper.get("GuiChest");
            if (clazz == null) {
                ChestStealerModule.csLog("[CS] GuiChest class not mapped");
                return;
            }
            if (!clazz.isInstance(object2)) {
                return;
            }
            long l = System.currentTimeMillis();
            if (l - this.lastLootTime < ((Double)this.delay.getValue()).longValue()) {
                return;
            }
            if (!this.cacheBuilt) {
                this.buildCache(object2);
            }
            if (!this.cacheBuilt) {
                ChestStealerModule.csLog("[CS] Cache build failed, aborting tick");
                return;
            }
            Object object3 = this.getContainer(object2);
            if (object3 == null) {
                ChestStealerModule.csLog("[CS] container is null");
                return;
            }
            List<?> list = this.getSlots(object3);
            if (list == null || list.isEmpty()) {
                ChestStealerModule.csLog("[CS] slots list is null or empty");
                return;
            }
            int n = 0;
            try {
                for (Class<?> clazz2 = object3.getClass(); clazz2 != null && clazz2 != Object.class; clazz2 = clazz2.getSuperclass()) {
                    for (Field field : clazz2.getDeclaredFields()) {
                        if (field.getType() != Integer.TYPE) continue;
                        field.setAccessible(true);
                        int n2 = field.getInt(object3);
                        ChestStealerModule.csLog("[CS] Container Field: " + clazz2.getSimpleName() + "." + field.getName() + " = " + n2);
                        if (n2 <= 0 || n2 >= 200) continue;
                        n = n2;
                    }
                }
            }
            catch (Throwable throwable) {
                ChestStealerModule.csLog("[CS] Container field scan failed: " + throwable.getMessage());
            }
            if (n == 0) {
                n = this.getWindowId(object3);
            }
            ChestStealerModule.csLog("[CS] windowId resolved = " + n);
            int n3 = list.size() - 36;
            if (n3 <= 0) {
                ChestStealerModule.csLog("[CS] chestSize=" + n3 + " (slots=" + list.size() + ")");
                return;
            }
            Object object = this.getMC();
            if (object == null) {
                ChestStealerModule.csLog("[CS] mc null");
                return;
            }
            Object object4 = this.getPlayerController(object);
            if (object4 == null) {
                ChestStealerModule.csLog("[CS] playerController null");
                return;
            }
            Object object5 = this.getThePlayer();
            if (object5 == null) {
                ChestStealerModule.csLog("[CS] player null");
                return;
            }
            Object var12_18 = null;
            try {
                InvManagerModule invManagerModule = Ries.getInstance().getModuleManager().getModule(InvManagerModule.class);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            boolean bl = var12_20 != null && var12_20.isEnabled();
            boolean bl2 = false;
            for (int i = 0; i < n3; ++i) {
                Object object6 = this.getStackInSlot(object3, i);
                if (object6 == null || bl && !var12_20.shouldLootItem(object6, object5)) continue;
                bl2 = true;
                try {
                    this.windowClickMethod.invoke(object4, n, i, 0, 1, object5);
                    ChestStealerModule.csLog("[CS] clicked slot " + i + " windowId=" + n);
                }
                catch (Throwable throwable) {
                    ChestStealerModule.csLog("[CS] windowClick invoke failed: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
                    try {
                        this.windowClickMethod.invoke(object4, n, i, 0, 0, object5);
                        ChestStealerModule.csLog("[CS] fallback click slot " + i);
                    }
                    catch (Throwable throwable2) {
                        ChestStealerModule.csLog("[CS] fallback also failed: " + throwable2.getMessage());
                    }
                }
                this.lastLootTime = l;
                return;
            }
            if (!bl2) {
                ChestStealerModule.csLog("[CS] chest empty / nothing to loot");
                if (((Boolean)this.autoClose.getValue()).booleanValue()) {
                    ChestStealerModule.csLog("[CS] closing screen because Auto Close is active");
                    this.closeScreen(object);
                }
            }
        }
        catch (Throwable throwable) {
            ChestStealerModule.csLog("[CS] onUpdate EXCEPTION: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
        }
    }

    private void buildCache(Object object) {
        ChestStealerModule.csLog("[CS] buildCache start, screen=" + object.getClass().getName());
        try {
            Object object2;
            Class clazz;
            Class<?> clazz2 = MinecraftMapper.get("Container");
            if (clazz2 == null) {
                ChestStealerModule.csLog("[CS] Container class not mapped");
                return;
            }
            ChestStealerModule.csLog("[CS] Container class = " + clazz2.getName());
            this.containerFieldOnGui = MappingUtils.getField("Container.inventorySlots");
            if (this.containerFieldOnGui == null) {
                for (clazz = object.getClass(); clazz != null && clazz != Object.class; clazz = clazz.getSuperclass()) {
                    object2 = clazz.getDeclaredFields();
                    int n = ((Field[])object2).length;
                    for (int i = 0; i < n; ++i) {
                        Field field = object2[i];
                        if (!clazz2.isAssignableFrom(field.getType())) continue;
                        this.containerFieldOnGui = field;
                        ChestStealerModule.csLog("[CS] containerFieldOnGui found via scan: " + field.getName() + " in " + clazz.getName());
                        break;
                    }
                    if (this.containerFieldOnGui == null) {
                        continue;
                    }
                    break;
                }
            } else {
                ChestStealerModule.csLog("[CS] containerFieldOnGui from mapping: " + this.containerFieldOnGui.getName());
            }
            if (this.containerFieldOnGui == null) {
                ChestStealerModule.csLog("[CS] Cannot find container field on screen");
                return;
            }
            this.containerFieldOnGui.setAccessible(true);
            clazz = this.containerFieldOnGui.get(object);
            if (clazz == null || !clazz2.isInstance(clazz)) {
                ChestStealerModule.csLog("[CS] containerFieldOnGui gave wrong type: " + (clazz == null ? "null" : clazz.getClass().getName()));
                this.containerFieldOnGui = null;
                for (object2 = object.getClass(); object2 != null && object2 != Object.class; object2 = ((Class)object2).getSuperclass()) {
                    for (Field field : ((Class)object2).getDeclaredFields()) {
                        if (!clazz2.isAssignableFrom(field.getType())) continue;
                        field.setAccessible(true);
                        Object object3 = field.get(object);
                        if (object3 == null) continue;
                        this.containerFieldOnGui = field;
                        ChestStealerModule.csLog("[CS] container field brute-found: " + field.getName() + " value=" + object3.getClass().getName());
                        break;
                    }
                    if (this.containerFieldOnGui != null) break;
                }
            }
            if (this.containerFieldOnGui == null) {
                ChestStealerModule.csLog("[CS] container field unresolvable");
                return;
            }
            object2 = this.containerFieldOnGui.get(object);
            if (object2 == null) {
                ChestStealerModule.csLog("[CS] containerObj null after resolution");
                return;
            }
            ChestStealerModule.csLog("[CS] container object = " + object2.getClass().getName());
            this.slotsListField = MappingUtils.getField("Slot.inventorySlots");
            if (this.slotsListField == null) {
                for (Class<?> clazz3 = object2.getClass(); clazz3 != null && clazz3 != Object.class; clazz3 = clazz3.getSuperclass()) {
                    for (Field field : clazz3.getDeclaredFields()) {
                        if (field.getType() != List.class && !field.getType().getName().contains("List")) continue;
                        field.setAccessible(true);
                        Object object3 = field.get(object2);
                        if (!(object3 instanceof List) || ((List)object3).isEmpty()) continue;
                        this.slotsListField = field;
                        ChestStealerModule.csLog("[CS] slotsListField brute-found: " + field.getName());
                        break;
                    }
                    if (this.slotsListField != null) break;
                }
            }
            if (this.slotsListField == null) {
                ChestStealerModule.csLog("[CS] slotsListField not found");
                return;
            }
            this.slotsListField.setAccessible(true);
            this.windowIdField = MappingUtils.getField("Container.windowId");
            if (this.windowIdField == null) {
                for (Class<?> clazz4 = object2.getClass(); clazz4 != null && clazz4 != Object.class; clazz4 = clazz4.getSuperclass()) {
                    for (Field field : clazz4.getDeclaredFields()) {
                        if (field.getType() != Integer.TYPE) continue;
                        field.setAccessible(true);
                        int n = field.getInt(object2);
                        if (n <= 0) continue;
                        this.windowIdField = field;
                        ChestStealerModule.csLog("[CS] windowIdField brute-found: " + field.getName() + " val=" + n);
                        break;
                    }
                    if (this.windowIdField != null) break;
                }
            }
            if (this.windowIdField == null) {
                ChestStealerModule.csLog("[CS] windowIdField not found (will use 0)");
            } else {
                this.windowIdField.setAccessible(true);
            }
            this.getSlotMethod = MappingUtils.getMethod("Container.getSlot");
            this.getStackMethod = MappingUtils.getMethod("Slot.getStack");
            if (this.getSlotMethod == null) {
                ChestStealerModule.csLog("[CS] Container.getSlot not mapped");
            } else {
                this.getSlotMethod.setAccessible(true);
                ChestStealerModule.csLog("[CS] Container.getSlot = " + this.getSlotMethod.getName());
            }
            if (this.getStackMethod == null) {
                ChestStealerModule.csLog("[CS] Slot.getStack not mapped");
            } else {
                this.getStackMethod.setAccessible(true);
                ChestStealerModule.csLog("[CS] Slot.getStack = " + this.getStackMethod.getName());
            }
            this.windowClickMethod = MappingUtils.getMethod("PlayerControllerMP.windowClick");
            if (this.windowClickMethod == null) {
                ChestStealerModule.csLog("[CS] windowClick method not mapped");
                return;
            }
            this.windowClickMethod.setAccessible(true);
            ChestStealerModule.csLog("[CS] windowClick = " + this.windowClickMethod.getName());
            this.playerControllerField = MappingUtils.getField("Minecraft.playerController");
            if (this.playerControllerField == null) {
                ChestStealerModule.csLog("[CS] Minecraft.playerController field not mapped");
                return;
            }
            this.playerControllerField.setAccessible(true);
            this.cacheBuilt = true;
            ChestStealerModule.csLog("[CS] buildCache SUCCESS");
        }
        catch (Throwable throwable) {
            ChestStealerModule.csLog("[CS] buildCache EXCEPTION: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
        }
    }

    private Object getContainer(Object object) {
        try {
            return this.containerFieldOnGui.get(object);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private List<?> getSlots(Object object) {
        try {
            return (List)this.slotsListField.get(object);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private int getWindowId(Object object) {
        if (this.windowIdField == null) {
            return 0;
        }
        try {
            return this.windowIdField.getInt(object);
        }
        catch (Throwable throwable) {
            return 0;
        }
    }

    private Object getPlayerController(Object object) {
        try {
            return this.playerControllerField.get(object);
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private Object getStackInSlot(Object object, int n) {
        try {
            Object object2;
            if (this.getSlotMethod != null) {
                object2 = this.getSlotMethod.invoke(object, n);
                if (object2 == null) {
                    return null;
                }
                if (this.getStackMethod != null) {
                    return this.getStackMethod.invoke(object2, new Object[0]);
                }
            }
            if ((object2 = this.getSlots(object)) == null || n >= object2.size()) {
                return null;
            }
            Object obj = object2.get(n);
            if (obj == null) {
                return null;
            }
            if (this.getStackMethod != null) {
                return this.getStackMethod.invoke(obj, new Object[0]);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private void closeScreen(Object object) {
        AnnotatedElement annotatedElement;
        try {
            annotatedElement = MinecraftMapper.get("GuiScreen");
            if (annotatedElement != null) {
                Method method = null;
                for (Method method2 : object.getClass().getDeclaredMethods()) {
                    if (method2.getReturnType() != Void.TYPE || method2.getParameterCount() != 1 || method2.getParameterTypes()[0] != annotatedElement) continue;
                    method = method2;
                    break;
                }
                if (method != null) {
                    method.setAccessible(true);
                    method.invoke(object, new Object[]{null});
                    ChestStealerModule.csLog("[CS] Closed screen using displayGuiScreen(null)");
                    return;
                }
                ChestStealerModule.csLog("[CS] displayGuiScreen method not found in Minecraft class");
            } else {
                ChestStealerModule.csLog("[CS] GuiScreen class not mapped");
            }
        }
        catch (Throwable throwable) {
            ChestStealerModule.csLog("[CS] displayGuiScreen invoke failed: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
        }
        try {
            annotatedElement = MappingUtils.getField("Minecraft.currentScreen");
            if (annotatedElement != null) {
                ((Field)annotatedElement).setAccessible(true);
                ((Field)annotatedElement).set(object, null);
                ChestStealerModule.csLog("[CS] Closed screen via fallback (currentScreen = null)");
            }
            try {
                Mouse.setGrabbed((boolean)true);
            }
            catch (Throwable throwable) {}
        }
        catch (Throwable throwable) {
            ChestStealerModule.csLog("[CS] closeScreen fallback failed: " + throwable.getMessage());
        }
    }

    private static void csLog(String string) {
        String string2 = SDF.format(new Date()) + " " + string;
        Logger.info(string2);
        try (PrintWriter printWriter = new PrintWriter(new FileWriter(CS_LOG, true));){
            printWriter.println(string2);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private Object getMC() {
        try {
            Class<?> clazz = MappingUtils.get("Minecraft");
            if (clazz == null) {
                return null;
            }
            for (Field field : clazz.getDeclaredFields()) {
                if (!Modifier.isStatic(field.getModifiers()) || field.getType() != clazz) continue;
                field.setAccessible(true);
                return field.get(null);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }
}

