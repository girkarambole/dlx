/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.objectweb.asm.ClassVisitor
 *  org.objectweb.asm.ClassWriter
 *  org.objectweb.asm.Type
 *  org.objectweb.asm.tree.AbstractInsnNode
 *  org.objectweb.asm.tree.ClassNode
 *  org.objectweb.asm.tree.FieldInsnNode
 *  org.objectweb.asm.tree.InsnList
 *  org.objectweb.asm.tree.InsnNode
 *  org.objectweb.asm.tree.JumpInsnNode
 *  org.objectweb.asm.tree.LabelNode
 *  org.objectweb.asm.tree.MethodInsnNode
 *  org.objectweb.asm.tree.MethodNode
 *  org.objectweb.asm.tree.TypeInsnNode
 *  org.objectweb.asm.tree.VarInsnNode
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import me.ries.module.impl.ScoreBoardModule;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

public class FakeScoreBoardInjector {
    private static final String FAKE_CLASS_NAME = "me/ries/FakeScoreBoardUtil";
    private static final String FAKE_CLASS_BINARY = "me.ries.FakeScoreBoardUtil";
    private static final String MODULE_OWNER = "me/ries/module/impl/ScoreBoardModule";
    private static final String SCORE_BOARD_FLAG = "scoreBoard";
    private static final String FASTUTIL_MAP = "it/unimi/dsi/fastutil/ints/Int2ObjectOpenHashMap";
    private static boolean injected = false;

    public static void inject() {
        if (!injected) {
            try {
                FakeScoreBoardInjector.injectInternal();
                injected = true;
                Logger.info("FakeScoreBoardInjector: ScoreBoard proxy enjekte edildi.");
            }
            catch (Throwable e) {
                Logger.warn("FakeScoreBoardInjector: Enjeksiyon basarisiz - " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public static boolean isInjected() {
        return injected;
    }

    private static void injectInternal() throws Exception {
        Class<?> sbClass = MappingUtils.get("ScoreBoardUtil");
        if (sbClass == null) {
            Logger.warn("FakeScoreBoardInjector: ScoreBoardUtil mapping bulunamadi, inject atland\u00c3\u201e\u00c2\u00b1.");
        } else {
            Method getScoreBoardInfoMethod = FakeScoreBoardInjector.findGetScoreBoardInfoMethod(sbClass);
            if (getScoreBoardInfoMethod == null) {
                Logger.warn("FakeScoreBoardInjector: getScoreBoardInfo metodu bulunamadi, inject atland\u00c3\u201e\u00c2\u00b1.");
            } else {
                Field sbField = MappingUtils.getField("ClientUtils.scoreBoard");
                if (sbField == null) {
                    Logger.warn("FakeScoreBoardInjector: ClientUtils.scoreBoard bulunamadi, inject atland\u00c3\u201e\u00c2\u00b1.");
                } else {
                    sbField.setAccessible(true);
                    Object originalSB = sbField.get(null);
                    if (originalSB == null) {
                        Logger.warn("FakeScoreBoardInjector: ClientUtils.scoreBoard null, inject atland\u00c3\u201e\u00c2\u00b1.");
                    } else {
                        byte[] bytes = FakeScoreBoardInjector.generateFakeScoreBoardUtil(sbClass, getScoreBoardInfoMethod);
                        Class<?> fakeClass = FakeScoreBoardInjector.defineClass(FAKE_CLASS_BINARY, bytes, sbClass.getClassLoader());
                        if (fakeClass == null) {
                            Logger.warn("FakeScoreBoardInjector: defineClass basarisiz.");
                        } else {
                            Object fakeInstance = fakeClass.newInstance();
                            FakeScoreBoardInjector.copyFields(originalSB, fakeInstance, sbClass);
                            sbField.set(null, fakeInstance);
                            Field origRef = ScoreBoardModule.class.getDeclaredField("originalScoreBoardRef");
                            origRef.setAccessible(true);
                            origRef.set(null, originalSB);
                            Field fakeRef = ScoreBoardModule.class.getDeclaredField("fakeScoreBoardRef");
                            fakeRef.setAccessible(true);
                            fakeRef.set(null, fakeInstance);
                            Logger.info("FakeScoreBoardInjector: proxy='" + fakeClass.getName() + "' superclass='" + sbClass.getName() + "'");
                        }
                    }
                }
            }
        }
    }

    private static byte[] generateFakeScoreBoardUtil(Class<?> sbClass, Method getScoreBoardInfoMethod) {
        String superName = Type.getInternalName(sbClass);
        String methodName = getScoreBoardInfoMethod.getName();
        String mapDesc = Type.getMethodDescriptor((Method)getScoreBoardInfoMethod);
        ClassNode cn = new ClassNode();
        cn.version = 52;
        cn.access = 1;
        cn.name = FAKE_CLASS_NAME;
        cn.superName = superName;
        cn.interfaces = new ArrayList();
        MethodNode ctor = new MethodNode(1, "<init>", "()V", (String)null, (String[])null);
        ctor.instructions.add((AbstractInsnNode)new VarInsnNode(25, 0));
        ctor.instructions.add((AbstractInsnNode)new MethodInsnNode(183, superName, "<init>", "()V", false));
        ctor.instructions.add((AbstractInsnNode)new InsnNode(177));
        cn.methods.add(ctor);
        MethodNode mn = new MethodNode(1, methodName, mapDesc, (String)null, (String[])null);
        InsnList il = mn.instructions;
        il.add((AbstractInsnNode)new FieldInsnNode(178, MODULE_OWNER, SCORE_BOARD_FLAG, "Z"));
        LabelNode lblOrig = new LabelNode();
        il.add((AbstractInsnNode)new JumpInsnNode(153, lblOrig));
        il.add((AbstractInsnNode)new TypeInsnNode(187, FASTUTIL_MAP));
        il.add((AbstractInsnNode)new InsnNode(89));
        il.add((AbstractInsnNode)new MethodInsnNode(183, FASTUTIL_MAP, "<init>", "()V", false));
        il.add((AbstractInsnNode)new InsnNode(176));
        il.add((AbstractInsnNode)lblOrig);
        il.add((AbstractInsnNode)new VarInsnNode(25, 0));
        il.add((AbstractInsnNode)new MethodInsnNode(183, superName, methodName, mapDesc, false));
        il.add((AbstractInsnNode)new InsnNode(176));
        cn.methods.add(mn);
        ClassWriter cw = new ClassWriter(3);
        cn.accept((ClassVisitor)cw);
        return cw.toByteArray();
    }

    private static Class<?> defineClass(String name, byte[] bytes, ClassLoader parent) {
        try {
            Method defineMethod = ClassLoader.class.getDeclaredMethod("defineClass", String.class, byte[].class, Integer.TYPE, Integer.TYPE);
            defineMethod.setAccessible(true);
            return (Class)defineMethod.invoke((Object)parent, name, bytes, 0, bytes.length);
        }
        catch (Throwable var5) {
            try {
                return new ByteClassLoader(parent, name, bytes).loadClass(name);
            }
            catch (Throwable e) {
                Logger.warn("FakeScoreBoardInjector: defineClass fallback basarisiz - " + e.getMessage());
                return null;
            }
        }
    }

    private static void copyFields(Object src, Object dst, Class<?> startClass) {
        for (Class<?> cur = startClass; cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            for (Field f : cur.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                try {
                    f.setAccessible(true);
                    f.set(dst, f.get(src));
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
    }

    private static Method findGetScoreBoardInfoMethod(Class<?> sbClass) {
        Method m = MappingUtils.getMethod("ScoreBoardUtil.getScoreBoardInfo");
        if (m != null) {
            return m;
        }
        for (Method method : sbClass.getDeclaredMethods()) {
            if (method.getParameterCount() != 0 || !method.getReturnType().getName().contains("Int2ObjectOpenHashMap")) continue;
            method.setAccessible(true);
            return method;
        }
        for (Class<?> cur = sbClass.getSuperclass(); cur != null && cur != Object.class; cur = cur.getSuperclass()) {
            for (Method method : cur.getDeclaredMethods()) {
                if (method.getParameterCount() != 0 || !method.getReturnType().getName().contains("Int2ObjectOpenHashMap")) continue;
                method.setAccessible(true);
                return method;
            }
        }
        return null;
    }

    private static final class ByteClassLoader
    extends ClassLoader {
        private final String name;
        private final byte[] bytes;

        ByteClassLoader(ClassLoader parent, String name, byte[] bytes) {
            super(parent);
            this.name = name;
            this.bytes = bytes;
        }

        @Override
        protected Class<?> findClass(String className) throws ClassNotFoundException {
            return className.equals(this.name) ? this.defineClass(this.name, this.bytes, 0, this.bytes.length) : super.findClass(className);
        }
    }
}

