/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.ries.module.impl.BedBreakerModule
 *  org.lwjgl.input.Mouse
 */
package me.ries.module.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.module.impl.BedBreakerModule;
import me.ries.setting.NumberOption;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;

public class BlockRemoverModule
extends Module {
    private final NumberOption range = new NumberOption("Range", 4.5, 1.0, 6.0, 0.1, this);
    private boolean wasDown = false;
    private static Method cachedGetBlockPos = null;
    private static Method cachedGetBlockById = null;
    private static Method cachedGetDefaultState = null;
    private static Method cachedSetBlockState = null;

    public BlockRemoverModule() {
        super("BlockRemover", "Removes blocks client-side on click", Category.MISC, 0);
        this.range.setGroup("General");
        this.addOptions(this.range);
    }

    @Override
    public void onEnable() {
        this.wasDown = false;
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
        if (this.isEnabled()) {
            if (MinecraftMapper.getCurrentScreen() != null) {
                this.wasDown = false;
            } else {
                boolean isDown = Mouse.isButtonDown((int)0);
                if (isDown && !this.wasDown) {
                    this.removeTargetBlock();
                }
                this.wasDown = isDown;
            }
        }
    }

    private void removeTargetBlock() {
        try {
            int bz;
            double dz;
            int by;
            double dy;
            Object mc = this.getMinecraft();
            if (mc == null) {
                return;
            }
            Field mouseOverField = MappingUtils.getField("Minecraft.objectMouseOver");
            if (mouseOverField == null) {
                return;
            }
            Object mop = mouseOverField.get(mc);
            if (mop == null) {
                return;
            }
            Field typeOfHitField = MappingUtils.getField("MovingObjectPosition.typeOfHit");
            if (typeOfHitField == null) {
                return;
            }
            Enum typeOfHit = (Enum)typeOfHitField.get(mop);
            if (typeOfHit == null || typeOfHit.ordinal() != 1) {
                return;
            }
            Method getBlockPos = BlockRemoverModule.getBlockPosMethod();
            if (getBlockPos == null) {
                return;
            }
            Object blockPos = getBlockPos.invoke(mop, new Object[0]);
            if (blockPos == null) {
                return;
            }
            double px = BedBreakerModule.getPosX();
            double py = BedBreakerModule.getPosY();
            double pz = BedBreakerModule.getPosZ();
            Method getX = MappingUtils.getMethod("Vec3i.getX");
            Method getY = MappingUtils.getMethod("Vec3i.getY");
            Method getZ = MappingUtils.getMethod("Vec3i.getZ");
            if (getX == null || getY == null || getZ == null) {
                return;
            }
            int bx = (Integer)getX.invoke(blockPos, new Object[0]);
            double dx = px - ((double)bx + 0.5);
            double dist = Math.sqrt(dx * dx + (dy = py - ((double)(by = ((Integer)getY.invoke(blockPos, new Object[0])).intValue()) + 0.5)) * dy + (dz = pz - ((double)(bz = ((Integer)getZ.invoke(blockPos, new Object[0])).intValue()) + 0.5)) * dz);
            if (dist > (Double)this.range.getValue()) {
                return;
            }
            BlockRemoverModule.removeBlockLocally(bx, by, bz);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Object createBlockPos(int x, int y, int z) {
        try {
            Class<?> blockPosClass = MappingUtils.get("BlockPos");
            if (blockPosClass != null) {
                for (Constructor<?> c : blockPosClass.getDeclaredConstructors()) {
                    if (c.getParameterCount() != 3) continue;
                    Class<?>[] pts = c.getParameterTypes();
                    if (pts[0] == Integer.TYPE && pts[1] == Integer.TYPE && pts[2] == Integer.TYPE) {
                        return c.newInstance(x, y, z);
                    }
                    if (pts[0] != Double.TYPE || pts[1] != Double.TYPE || pts[2] != Double.TYPE) continue;
                    return c.newInstance(x, y, z);
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public static void removeBlockLocally(int x, int y, int z) {
        try {
            Object blockPos = BlockRemoverModule.createBlockPos(x, y, z);
            if (blockPos == null) {
                return;
            }
            Object world = MappingUtils.getWorldObj();
            if (world == null) {
                return;
            }
            Method getBlockById = BlockRemoverModule.getBlockByIdMethod();
            Method getDefaultState = BlockRemoverModule.getGetDefaultStateMethod();
            Method setBlockState = BlockRemoverModule.getSetBlockStateMethod();
            if (getBlockById != null && getDefaultState != null && setBlockState != null) {
                Object airBlock = getBlockById.invoke(null, 0);
                Object airState = getDefaultState.invoke(airBlock, new Object[0]);
                setBlockState.invoke(world, blockPos, airState, 3);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static Method getBlockPosMethod() {
        if (cachedGetBlockPos != null) {
            return cachedGetBlockPos;
        }
        try {
            Class<?> mopClass = MappingUtils.get("MovingObjectPosition");
            Class<?> blockPosClass = MappingUtils.get("BlockPos");
            if (mopClass != null && blockPosClass != null) {
                for (Method m : mopClass.getDeclaredMethods()) {
                    if (m.getReturnType() != blockPosClass || m.getParameterCount() != 0) continue;
                    cachedGetBlockPos = m;
                    return m;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    private static Method getBlockByIdMethod() {
        if (cachedGetBlockById != null) {
            return cachedGetBlockById;
        }
        try {
            Class<?> blockClass = MappingUtils.get("Block");
            if (blockClass != null) {
                for (Method m : blockClass.getDeclaredMethods()) {
                    if (!Modifier.isStatic(m.getModifiers()) || m.getReturnType() != blockClass || m.getParameterCount() != 1 || m.getParameterTypes()[0] != Integer.TYPE) continue;
                    cachedGetBlockById = m;
                    return m;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    private static Method getGetDefaultStateMethod() {
        if (cachedGetDefaultState != null) {
            return cachedGetDefaultState;
        }
        try {
            Class<?> blockClass = MappingUtils.get("Block");
            if (blockClass != null) {
                for (Method m : blockClass.getDeclaredMethods()) {
                    if (m.getParameterCount() != 0 || !m.getReturnType().isInterface() || m.getReturnType().getName().startsWith("java")) continue;
                    cachedGetDefaultState = m;
                    return m;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    private static Method getSetBlockStateMethod() {
        if (cachedSetBlockState != null) {
            return cachedSetBlockState;
        }
        try {
            Class<?> worldClass = MappingUtils.get("World");
            Class<?> blockPosClass = MappingUtils.get("BlockPos");
            if (worldClass != null && blockPosClass != null) {
                for (Method m : worldClass.getDeclaredMethods()) {
                    Class<?>[] params;
                    if (m.getReturnType() != Boolean.TYPE || m.getParameterCount() != 3 || (params = m.getParameterTypes())[0] != blockPosClass || !params[1].isInterface() || params[2] != Integer.TYPE) continue;
                    cachedSetBlockState = m;
                    return m;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }
}

