/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class InvManagerModule
extends Module {
    private final BooleanOption cleaner = new BooleanOption("Cleaner", true, (Module)this);
    private final BooleanOption keepFnsRodWebs = new BooleanOption("Keep FNS, Rod, Webs", false, (Module)this);
    private final BooleanOption keepBuckets = new BooleanOption("Keep Buckets", true, (Module)this);
    private final BooleanOption keepPotions = new BooleanOption("Keep Potions", true, (Module)this);
    private final BooleanOption keepArchery = new BooleanOption("Keep Archery", false, (Module)this);
    private final BooleanOption keepBlocks = new BooleanOption("Keep Blocks", true, (Module)this);
    private final BooleanOption keepSwords = new BooleanOption("Keep Swords", false, (Module)this);
    private final BooleanOption keepFoods = new BooleanOption("Keep Foods", true, (Module)this);
    private final BooleanOption keepTools = new BooleanOption("Keep Tools", false, (Module)this);
    private final BooleanOption keepArmors = new BooleanOption("Keep Armors", false, (Module)this);
    private final NumberOption manageDelay = new NumberOption("Manage Delay", 75.0, 0.0, 500.0, 5.0, this);
    private final NumberOption swordSlot = new NumberOption("Sword Slot", 1.0, 1.0, 9.0, 1.0, this);
    private long lastActionTime = 0L;

    public InvManagerModule() {
        super("InvManager", "Cleans inventory and sorts main slots", Category.PLAYER, 0);
        this.cleaner.setGroup("Manager");
        this.keepFnsRodWebs.setGroup("Manager");
        this.keepBuckets.setGroup("Manager");
        this.keepPotions.setGroup("Manager");
        this.keepArchery.setGroup("Manager");
        this.keepBlocks.setGroup("Manager");
        this.keepSwords.setGroup("Manager");
        this.keepFoods.setGroup("Manager");
        this.keepTools.setGroup("Manager");
        this.keepArmors.setGroup("Manager");
        this.manageDelay.setGroup("Manager");
        this.swordSlot.setGroup("Manager");
        this.addOptions(this.cleaner, this.keepFnsRodWebs, this.keepBuckets, this.keepPotions, this.keepArchery, this.keepBlocks, this.keepSwords, this.keepFoods, this.keepTools, this.keepArmors, this.manageDelay, this.swordSlot);
    }

    @Override
    public String getOptionPrefix() {
        return ((Double)this.manageDelay.getValue()).intValue() + "ms";
    }

    @Override
    public void onEnable() {
        this.lastActionTime = 0L;
        Logger.info("InvManager: enabled");
    }

    @Override
    public void onDisable() {
        Logger.info("InvManager: disabled");
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        try {
            int n;
            if (MinecraftMapper.getCurrentScreen() != null) {
                return;
            }
            long l = System.currentTimeMillis();
            if (l - this.lastActionTime < ((Double)this.manageDelay.getValue()).longValue()) {
                return;
            }
            Object object = this.getThePlayer();
            if (object == null) {
                return;
            }
            Object object2 = this.getMinecraft();
            if (object2 == null) {
                return;
            }
            Field field = MappingUtils.getField("Minecraft.playerController");
            if (field == null) {
                return;
            }
            field.setAccessible(true);
            Object object3 = field.get(object2);
            if (object3 == null) {
                return;
            }
            Method method = MappingUtils.getMethod("PlayerControllerMP.windowClick");
            if (method == null) {
                return;
            }
            method.setAccessible(true);
            Field field2 = MappingUtils.getField("EntityPlayer.inventoryContainer");
            if (field2 == null) {
                return;
            }
            field2.setAccessible(true);
            Object object4 = field2.get(object);
            if (object4 == null) {
                return;
            }
            Field field3 = MappingUtils.getField("Slot.inventorySlots");
            if (field3 == null) {
                return;
            }
            field3.setAccessible(true);
            List list = (List)field3.get(object4);
            if (list == null || list.size() < 45) {
                return;
            }
            Method method2 = MappingUtils.getMethod("Container.getSlot");
            Method method3 = MappingUtils.getMethod("Slot.getStack");
            if (method2 == null || method3 == null) {
                return;
            }
            method2.setAccessible(true);
            method3.setAccessible(true);
            int n2 = 0;
            int n3 = ((Double)this.swordSlot.getValue()).intValue() - 1;
            if (n3 >= 0 && n3 < 9) {
                int n4;
                n = -1;
                int n5 = -1;
                for (n4 = 9; n4 < 45; ++n4) {
                    int n6;
                    String string;
                    Object object5 = method3.invoke(method2.invoke(object4, n4), new Object[0]);
                    if (object5 == null || (string = MappingUtils.getItemName(object5)) == null || !string.toLowerCase().contains("sword") || (n6 = this.getSwordDamage(string)) <= n5) continue;
                    n5 = n6;
                    n = n4;
                }
                n4 = 36 + n3;
                if (n != -1 && n != n4) {
                    this.swapSlots(object3, n2, n, n4, method, object);
                    this.lastActionTime = l;
                    return;
                }
            }
            if (((Boolean)this.cleaner.getValue()).booleanValue()) {
                for (n = 9; n < 45; ++n) {
                    Object object6 = method3.invoke(method2.invoke(object4, n), new Object[0]);
                    if (object6 == null || this.shouldKeepInInventory(object6, object)) continue;
                    String string = MappingUtils.getItemName(object6);
                    method.invoke(object3, n2, n, 1, 4, object);
                    this.lastActionTime = l;
                    Logger.info("InvManager: dropped trash item " + string);
                    return;
                }
            }
        }
        catch (Throwable throwable) {
            Logger.warn("InvManager error: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
        }
    }

    public boolean shouldLootItem(Object object, Object object2) {
        Object object32;
        Object object4;
        Object object5;
        Object object6;
        int n;
        int n2;
        if (object == null) {
            return false;
        }
        String string = MappingUtils.getItemName(object);
        if (string == null) {
            return false;
        }
        if (this.isKeepItem(string)) {
            return true;
        }
        String string2 = string.toLowerCase();
        if (string2.contains("sword") || string2.contains("kilic")) {
            n2 = this.getSwordDamage(string);
            n = -1;
            try {
                Object object7 = MappingUtils.getInventory(object2);
                if (object7 != null && (object6 = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                    ((Field)object6).setAccessible(true);
                    object5 = (Object[])((Field)object6).get(object7);
                    if (object5 != null) {
                        object4 = object5;
                        int n3 = ((Object[])object4).length;
                        for (int i = 0; i < n3; ++i) {
                            int n4;
                            String string3;
                            Object object8 = object4[i];
                            if (object8 == null || (string3 = MappingUtils.getItemName(object8)) == null || !((String)(object32 = string3.toLowerCase())).contains("sword") && !((String)object32).contains("kilic") || (n4 = this.getSwordDamage(string3)) <= n) continue;
                            n = n4;
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (n2 > n) {
                return true;
            }
        }
        if ((string2.contains("helmet") || string2.contains("chestplate") || string2.contains("leggings") || string2.contains("boots") || string2.contains("kask") || string2.contains("gogus") || string2.contains("pantolon") || string2.contains("bot") || string2.contains("cap") || string2.contains("tunic") || string2.contains("greaves") || string2.contains("shoes") || string2.contains("skull") || string2.contains("head")) && (n2 = this.getArmorType(string)) != -1) {
            n = this.getArmorScore(string);
            int n5 = -1;
            try {
                object6 = MappingUtils.getInventory(object2);
                if (object6 != null) {
                    object5 = MappingUtils.getField("InventoryPlayer.armorInventory");
                    if (object5 != null) {
                        String string4;
                        Object object9;
                        ((Field)object5).setAccessible(true);
                        object4 = (Object[])((Field)object5).get(object6);
                        if (object4 != null && 3 - n2 >= 0 && 3 - n2 < ((Object)object4).length && (object9 = object4[3 - n2]) != null && (string4 = MappingUtils.getItemName(object9)) != null) {
                            n5 = this.getArmorScore(string4);
                        }
                    }
                    if ((object4 = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                        ((Field)object4).setAccessible(true);
                        Object[] objectArray = (Object[])((Field)object4).get(object6);
                        if (objectArray != null) {
                            for (Object object32 : objectArray) {
                                int n6;
                                String string5;
                                if (object32 == null || (string5 = MappingUtils.getItemName(object32)) == null || this.getArmorType(string5) != n2 || (n6 = this.getArmorScore(string5)) <= n5) continue;
                                n5 = n6;
                            }
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (n > n5) {
                return true;
            }
        }
        if ((string2.contains("pickaxe") || string2.contains("axe") || string2.contains("shovel") || string2.contains("kazma") || string2.contains("balta") || string2.contains("kurek")) && (n2 = this.getToolType(string)) != -1) {
            n = this.getToolTier(string);
            int n7 = -1;
            try {
                object6 = MappingUtils.getInventory(object2);
                if (object6 != null && (object5 = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                    ((Field)object5).setAccessible(true);
                    object4 = (Object[])((Field)object5).get(object6);
                    if (object4 != null) {
                        for (Object object10 : object4) {
                            int n8;
                            if (object10 == null || (object32 = MappingUtils.getItemName(object10)) == null || this.getToolType((String)object32) != n2 || (n8 = this.getToolTier((String)object32)) <= n7) continue;
                            n7 = n8;
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (n > n7) {
                return true;
            }
        }
        return false;
    }

    public boolean shouldKeepInInventory(Object object, Object object2) {
        int n;
        if (object == null) {
            return false;
        }
        String string = MappingUtils.getItemName(object);
        if (string == null) {
            return false;
        }
        if (this.isKeepItem(string)) {
            return true;
        }
        String string2 = string.toLowerCase();
        if (string2.contains("sword") || string2.contains("kilic")) {
            int n2 = this.getSwordDamage(string);
            int n3 = -1;
            try {
                Field field;
                Object object3 = MappingUtils.getInventory(object2);
                if (object3 != null && (field = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                    field.setAccessible(true);
                    Object[] objectArray = (Object[])field.get(object3);
                    if (objectArray != null) {
                        for (Object object4 : objectArray) {
                            int n4;
                            String string3;
                            if (object4 == null || (string3 = MappingUtils.getItemName(object4)) == null || !string3.toLowerCase().contains("sword") && !string3.toLowerCase().contains("kilic") || (n4 = this.getSwordDamage(string3)) <= n3) continue;
                            n3 = n4;
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return n2 >= n3;
        }
        if ((string2.contains("helmet") || string2.contains("chestplate") || string2.contains("leggings") || string2.contains("boots") || string2.contains("kask") || string2.contains("gogus") || string2.contains("pantolon") || string2.contains("bot") || string2.contains("cap") || string2.contains("tunic") || string2.contains("greaves") || string2.contains("shoes") || string2.contains("skull") || string2.contains("head")) && (n = this.getArmorType(string)) != -1) {
            int n5 = this.getArmorScore(string);
            int n6 = -1;
            try {
                Object object5 = MappingUtils.getInventory(object2);
                if (object5 != null) {
                    Object[] objectArray;
                    Field field = MappingUtils.getField("InventoryPlayer.armorInventory");
                    if (field != null) {
                        field.setAccessible(true);
                        objectArray = (Object[])field.get(object5);
                        if (objectArray != null) {
                            for (Object object6 : objectArray) {
                                int n7;
                                Object object7;
                                if (object6 == null || (object7 = MappingUtils.getItemName(object6)) == null || this.getArmorType((String)object7) != n || (n7 = this.getArmorScore((String)object7)) <= n6) continue;
                                n6 = n7;
                            }
                        }
                    }
                    if ((objectArray = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                        objectArray.setAccessible(true);
                        Object[] objectArray2 = (Object[])objectArray.get(object5);
                        if (objectArray2 != null) {
                            for (Object object7 : objectArray2) {
                                int n8;
                                String string4;
                                if (object7 == null || (string4 = MappingUtils.getItemName(object7)) == null || this.getArmorType(string4) != n || (n8 = this.getArmorScore(string4)) <= n6) continue;
                                n6 = n8;
                            }
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return n5 >= n6;
        }
        if ((string2.contains("pickaxe") || string2.contains("axe") || string2.contains("shovel") || string2.contains("kazma") || string2.contains("balta") || string2.contains("kurek")) && (n = this.getToolType(string)) != -1) {
            int n9 = this.getToolTier(string);
            int n10 = -1;
            try {
                Field field;
                Object object8 = MappingUtils.getInventory(object2);
                if (object8 != null && (field = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                    field.setAccessible(true);
                    Object[] objectArray = (Object[])field.get(object8);
                    if (objectArray != null) {
                        for (Object object9 : objectArray) {
                            int n11;
                            String string5;
                            if (object9 == null || (string5 = MappingUtils.getItemName(object9)) == null || this.getToolType(string5) != n || (n11 = this.getToolTier(string5)) <= n10) continue;
                            n10 = n11;
                        }
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            return n9 >= n10;
        }
        return false;
    }

    public boolean isKeepItem(String string) {
        if (string == null) {
            return false;
        }
        String string2 = string.toLowerCase();
        if (string2.contains("sword") || string2.contains("kilic")) {
            return (Boolean)this.keepSwords.getValue();
        }
        if (string2.contains("helmet") || string2.contains("chestplate") || string2.contains("leggings") || string2.contains("boots") || string2.contains("kask") || string2.contains("gogus") || string2.contains("pantolon") || string2.contains("bot") || string2.contains("cap") || string2.contains("tunic") || string2.contains("greaves") || string2.contains("shoes") || string2.contains("skull") || string2.contains("head")) {
            return (Boolean)this.keepArmors.getValue();
        }
        if (string2.contains("apple") || string2.contains("bread") || string2.contains("porkchop") || string2.contains("beef") || string2.contains("chicken") || string2.contains("mutton") || string2.contains("rabbit") || string2.contains("fish") || string2.contains("cookie") || string2.contains("melon") || string2.contains("potato") || string2.contains("carrot") || string2.contains("stew") || string2.contains("soup") || string2.contains("elma") || string2.contains("ekmek") || string2.contains("et") || string2.contains("patates") || string2.contains("havuc")) {
            return (Boolean)this.keepFoods.getValue();
        }
        if (string2.contains("cobblestone") || string2.contains("stone") || string2.contains("wood") || string2.contains("dirt") || string2.contains("planks") || string2.contains("obsidian") || string2.contains("sandstone") || string2.contains("gravel") || string2.contains("log") || string2.contains("brick") || string2.contains("clay") || string2.contains("wool") || string2.contains("block") || string2.contains("tas") || string2.contains("odun") || string2.contains("toprak") || string2.contains("tahta")) {
            return (Boolean)this.keepBlocks.getValue();
        }
        if (string2.contains("potion") || string2.contains("iksir")) {
            return (Boolean)this.keepPotions.getValue();
        }
        if (string2.contains("bucket") || string2.contains("kova")) {
            return (Boolean)this.keepBuckets.getValue();
        }
        if (string2.contains("flint_and_steel") || string2.contains("fishing_rod") || string2.contains("web") || string2.contains("cakmak") || string2.contains("olta") || string2.contains("ag")) {
            return (Boolean)this.keepFnsRodWebs.getValue();
        }
        if (string2.contains("bow") || string2.contains("arrow") || string2.contains("yay") || string2.contains("ok")) {
            return (Boolean)this.keepArchery.getValue();
        }
        if (string2.contains("pickaxe") || string2.contains("axe") || string2.contains("shovel") || string2.contains("shears") || string2.contains("kazma") || string2.contains("balta") || string2.contains("kurek") || string2.contains("makas")) {
            return (Boolean)this.keepTools.getValue();
        }
        return string2.contains("diamond") || string2.contains("iron_ingot") || string2.contains("gold_ingot") || string2.contains("emerald") || string2.contains("coal") || string2.contains("charcoal") || string2.contains("elmas") || string2.contains("demir") || string2.contains("altin") || string2.contains("zumrut") || string2.contains("compass") || string2.contains("pusula") || string2.contains("clock") || string2.contains("saat") || string2.contains("door") || string2.contains("kapi") || string2.contains("paper") || string2.contains("kagit") || string2.contains("pearl") || string2.contains("inci") || string2.contains("gapple") || string2.contains("golden_apple") || string2.contains("egg") || string2.contains("yumurta") || string2.contains("snowball") || string2.contains("kartopu") || string2.contains("tnt") || string2.contains("string") || string2.contains("ip");
    }

    private void swapSlots(Object object, int n, int n2, int n3, Method method, Object object2) throws Exception {
        method.invoke(object, n, n2, 0, 0, object2);
        method.invoke(object, n, n3, 0, 0, object2);
        method.invoke(object, n, n2, 0, 0, object2);
        Logger.info("InvManager: swapped slots " + n2 + " <-> " + n3);
    }

    private int getSwordDamage(String string) {
        String string2 = string.toLowerCase();
        if (string2.contains("diamond") || string2.contains("elmas")) {
            return 5;
        }
        if (string2.contains("iron") || string2.contains("demir")) {
            return 4;
        }
        if (string2.contains("stone") || string2.contains("tas")) {
            return 3;
        }
        if (string2.contains("gold") || string2.contains("altin")) {
            return 2;
        }
        if (string2.contains("wood") || string2.contains("tahta")) {
            return 1;
        }
        return 0;
    }

    private int getArmorType(String string) {
        if (string == null) {
            return -1;
        }
        String string2 = string.toLowerCase();
        if (string2.contains("helmet") || string2.contains("kask") || string2.contains("head") || string2.contains("cap") || string2.contains("skull")) {
            return 0;
        }
        if (string2.contains("chestplate") || string2.contains("gogus") || string2.contains("tunic")) {
            return 1;
        }
        if (string2.contains("leggings") || string2.contains("pantolon") || string2.contains("greaves")) {
            return 2;
        }
        if (string2.contains("boots") || string2.contains("bot") || string2.contains("shoes")) {
            return 3;
        }
        return -1;
    }

    private int getArmorScore(String string) {
        if (string == null) {
            return 0;
        }
        String string2 = string.toLowerCase();
        int n = 0;
        if (string2.contains("diamond") || string2.contains("elmas")) {
            n = 400;
        } else if (string2.contains("iron") || string2.contains("demir")) {
            n = 300;
        } else if (string2.contains("chain") || string2.contains("zincir")) {
            n = 200;
        } else if (string2.contains("gold") || string2.contains("altin")) {
            n = 150;
        } else if (string2.contains("leather") || string2.contains("deri")) {
            n = 100;
        }
        if (string2.contains("chest") || string2.contains("gogus")) {
            n += 8;
        } else if (string2.contains("leg") || string2.contains("pantolon")) {
            n += 6;
        } else if (string2.contains("helm") || string2.contains("kask")) {
            n += 3;
        } else if (string2.contains("boot") || string2.contains("bot")) {
            n += 2;
        }
        return n;
    }

    private int getToolType(String string) {
        String string2 = string.toLowerCase();
        if (string2.contains("pickaxe") || string2.contains("kazma")) {
            return 0;
        }
        if (string2.contains("axe") || string2.contains("balta")) {
            return 1;
        }
        if (string2.contains("shovel") || string2.contains("kurek")) {
            return 2;
        }
        return -1;
    }

    private int getToolTier(String string) {
        String string2 = string.toLowerCase();
        if (string2.contains("diamond") || string2.contains("elmas")) {
            return 5;
        }
        if (string2.contains("iron") || string2.contains("demir")) {
            return 4;
        }
        if (string2.contains("stone") || string2.contains("tas")) {
            return 3;
        }
        if (string2.contains("gold") || string2.contains("altin")) {
            return 2;
        }
        if (string2.contains("wood") || string2.contains("tahta")) {
            return 1;
        }
        return 0;
    }
}

