/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package me.ries.module.impl;

import java.awt.Color;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render2DEvent;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.ui.ClickGui;
import me.ries.util.FontUtil;
import me.ries.util.GaussianBlur;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import me.ries.util.RoundedUtil;
import me.ries.util.ScissorUtil;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class ScoreBoardModule
extends Module {
    private static Field scoreBoardInfoField;
    private static Field clientScoreBoardField;
    public static boolean scoreBoard;
    static Object originalScoreBoardRef;
    static Object fakeScoreBoardRef;
    public static float posX;
    public static float posY;
    private static boolean isDragging;
    private static float dragOffX;
    private static float dragOffY;
    private float panelAnim = 0.0f;
    private float smoothBoxW = 0.0f;
    private float smoothBoxH = 0.0f;
    private long lastFrameMs = 0L;
    private float dt = 0.0f;
    private final Map<String, EntryState> entryStates = new LinkedHashMap<String, EntryState>();
    private final List<String> orderedKeys = new ArrayList<String>();
    private final Map<String, String> liveData = new LinkedHashMap<String, String>();
    private long lastDataRefresh = 0L;
    private final BooleanOption showNumbers = new BooleanOption("Show Numbers", false, (Module)this);
    private final NumberOption scale = new NumberOption("Scale", 1.0, 0.6, 1.6, 0.1, this);
    private static final int[] MC_COLORS;

    public ScoreBoardModule() {
        super("ScoreBoard", "Vanilla scoreboard yerine ozel panel", Category.RENDER, 0);
        this.addOptions(this.showNumbers, this.scale);
        ScoreBoardModule.initReflection();
        Ries.getInstance().getEventBus().subscribe(Render2DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event e) {
                if (e instanceof Render2DEvent) {
                    ScoreBoardModule.this.render();
                }
            }
        });
    }

    private static void initReflection() {
        try {
            scoreBoardInfoField = MappingUtils.getField("ScoreBoardUtil.scoreBoardInfo");
            if (scoreBoardInfoField != null) {
                scoreBoardInfoField.setAccessible(true);
            }
        }
        catch (Exception var2) {
            Logger.warn("ScoreBoard: scoreBoardInfoField yok");
        }
        try {
            clientScoreBoardField = MappingUtils.getField("ClientUtils.scoreBoard");
            if (clientScoreBoardField != null) {
                clientScoreBoardField.setAccessible(true);
            }
        }
        catch (Exception var1) {
            Logger.warn("ScoreBoard: clientScoreBoardField yok");
        }
    }

    public static void resetDragState() {
        isDragging = false;
    }

    @Override
    public void onEnable() {
        scoreBoard = true;
        this.swapToFake();
    }

    @Override
    public void onDisable() {
        scoreBoard = false;
        this.restoreOriginal();
    }

    @Override
    public void onUpdate() {
    }

    private void swapToFake() {
        Object cur = ScoreBoardModule.getScoreBoardObj();
        if (cur != null) {
            boolean fake = cur.getClass().getName().contains("FakeScoreBoardUtil");
            if (!fake) {
                originalScoreBoardRef = cur;
            }
            if (fakeScoreBoardRef != null && !fake) {
                ScoreBoardModule.setScoreBoardObj(fakeScoreBoardRef);
            } else if (fakeScoreBoardRef == null && fake) {
                fakeScoreBoardRef = cur;
            }
        }
    }

    private void restoreOriginal() {
        Object cur = ScoreBoardModule.getScoreBoardObj();
        if (cur != null && cur.getClass().getName().contains("FakeScoreBoardUtil")) {
            fakeScoreBoardRef = cur;
        }
        if (originalScoreBoardRef != null) {
            ScoreBoardModule.setScoreBoardObj(originalScoreBoardRef);
        }
    }

    public static Map<Integer, String> getScoreBoardMap(Object inst) {
        if (scoreBoardInfoField == null) {
            return new HashMap<Integer, String>();
        }
        try {
            Object src;
            Object object = src = originalScoreBoardRef != null ? originalScoreBoardRef : inst;
            if (src == null) {
                return new HashMap<Integer, String>();
            }
            Object m = scoreBoardInfoField.get(src);
            if (m instanceof Map) {
                return (Map)m;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return new HashMap<Integer, String>();
    }

    public static Object getScoreBoardObj() {
        if (clientScoreBoardField == null) {
            return null;
        }
        try {
            return clientScoreBoardField.get(null);
        }
        catch (Exception var1) {
            return null;
        }
    }

    public static void setScoreBoardObj(Object o) {
        if (clientScoreBoardField != null) {
            try {
                clientScoreBoardField.set(null, o);
            }
            catch (Exception e) {
                Logger.warn("ScoreBoard.setObj: " + e.getMessage());
            }
        }
    }

    private void refreshData() {
        Object sb = ScoreBoardModule.getScoreBoardObj();
        if (sb == null) {
            this.liveData.clear();
        } else {
            Map<Integer, String> raw = ScoreBoardModule.getScoreBoardMap(sb);
            if (raw != null && !raw.isEmpty()) {
                this.liveData.clear();
                ArrayList<Integer> keys = new ArrayList<Integer>(raw.keySet());
                Collections.sort(keys, new Comparator<Integer>(){

                    @Override
                    public int compare(Integer a, Integer b) {
                        return b - a;
                    }
                });
                for (Integer k : keys) {
                    String lower;
                    String line = raw.get(k);
                    if (line == null || line.trim().isEmpty() || (lower = ScoreBoardModule.stripColors(line = ScoreBoardModule.sanitizeTurkish(line)).toLowerCase()).contains("www.") || lower.contains(".com") || lower.contains("craftrise") || lower.contains("discord")) continue;
                    this.liveData.put(String.valueOf(k), line);
                }
            } else {
                this.liveData.clear();
            }
        }
    }

    private void mergeEntries() {
        for (EntryState s : this.entryStates.values()) {
            if (this.liveData.containsKey(this.getKeyForState(s, this.entryStates))) continue;
            s.dying = true;
        }
        this.orderedKeys.clear();
        this.orderedKeys.addAll(this.liveData.keySet());
        for (String key : this.orderedKeys) {
            String newText = this.liveData.get(key);
            if (!this.entryStates.containsKey(key)) {
                EntryState ns = new EntryState(newText);
                ns.slideAnim = 0.0f;
                ns.alpha = 0.0f;
                this.entryStates.put(key, ns);
                continue;
            }
            EntryState es = this.entryStates.get(key);
            es.dying = false;
            if (newText.equals(es.displayText) || es.pendingText != null) continue;
            es.pendingText = newText;
            es.xfadeAlpha = 1.0f;
        }
    }

    private String getKeyForState(EntryState target, Map<String, EntryState> map) {
        for (Map.Entry<String, EntryState> e : map.entrySet()) {
            if (e.getValue() != target) continue;
            return e.getKey();
        }
        return "";
    }

    private void render() {
        if (this.isEnabled()) {
            long now = System.currentTimeMillis();
            if (this.lastFrameMs == 0L) {
                this.lastFrameMs = now;
            }
            this.dt = Math.min((float)(now - this.lastFrameMs) / 16.666666f, 3.0f);
            this.lastFrameMs = now;
            if (now - this.lastDataRefresh >= 100L) {
                this.lastDataRefresh = now;
                this.refreshData();
                this.mergeEntries();
            }
            boolean hasData = !this.liveData.isEmpty();
            this.panelAnim = ScoreBoardModule.lerp(this.panelAnim, hasData ? 1.0f : 0.0f, 0.12f * this.dt);
            if (!(this.panelAnim < 0.01f)) {
                float sc = ((Double)this.scale.getValue()).floatValue();
                float LINE_H = 13.0f * sc;
                float LINE_GAP = 2.0f * sc;
                float PAD_X = 7.0f * sc;
                float PAD_Y = 6.0f * sc;
                float TS = 0.65f * sc;
                float TTS = 0.7f * sc;
                float RADIUS = 4.0f * sc;
                int sw = ScissorUtil.getScaledWidth();
                int sh = ScissorUtil.getScaledHeight();
                this.animateEntries(sc);
                List<String> drawKeys = this.buildDrawList();
                float targetW = this.measureMaxWidth(drawKeys, PAD_X, sc, TS, TTS);
                float targetH = PAD_Y * 2.0f + (float)drawKeys.size() * LINE_H + (float)Math.max(0, drawKeys.size() - 1) * LINE_GAP;
                if (this.smoothBoxW < 1.0f) {
                    this.smoothBoxW = targetW;
                }
                if (this.smoothBoxH < 1.0f) {
                    this.smoothBoxH = targetH;
                }
                this.smoothBoxW = ScoreBoardModule.lerp(this.smoothBoxW, targetW, 0.14f * this.dt);
                this.smoothBoxH = ScoreBoardModule.lerp(this.smoothBoxH, targetH, 0.14f * this.dt);
                float boxW = this.smoothBoxW;
                float boxH = this.smoothBoxH;
                if (posX == -1.0f) {
                    posX = -(boxW + 10.0f);
                }
                if (posY < 0.0f || posY > (float)sh) {
                    posY = 10.0f;
                }
                float x = posX < 0.0f ? (float)sw + posX : posX;
                float y = posY;
                this.handleDrag(x, y, boxW, boxH, sw, sh);
                x = posX < 0.0f ? (float)sw + posX : posX;
                GL11.glPushAttrib((int)1048575);
                GL11.glMatrixMode((int)5889);
                GL11.glPushMatrix();
                GL11.glLoadIdentity();
                GL11.glOrtho((double)0.0, (double)sw, (double)sh, (double)0.0, (double)-1000.0, (double)1000.0);
                GL11.glMatrixMode((int)5888);
                GL11.glPushMatrix();
                GL11.glLoadIdentity();
                GL11.glDisable((int)2929);
                GL11.glDisable((int)2896);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glDisable((int)3008);
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                float alpha = this.panelAnim;
                GaussianBlur.renderBlurRounded(x, y, boxW, boxH, RADIUS, 10.0f * alpha);
                GL11.glDisable((int)3553);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                for (float s = 0.5f; s <= 3.0f; s += 0.5f) {
                    float op = (float)Math.pow(1.0f - s / 3.0f, 2.5) * 0.07f * alpha;
                    if (op < 0.003f) continue;
                    RoundedUtil.roundedRect((double)(x - s), (double)(y - s + 0.5f), (double)(boxW + s * 2.0f), (double)(boxH + s), (double)(RADIUS + s), new Color(0, 0, 0, (int)(255.0f * op)));
                }
                GL11.glDisable((int)3553);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                RoundedUtil.roundedRect((double)x, (double)y, (double)boxW, (double)boxH, (double)RADIUS, new Color(12, 12, 14, (int)(70.0f * alpha)));
                RoundedUtil.drawRoundOutline(x, y, boxW, boxH, RADIUS, 0.5f, new Color(255, 255, 255, (int)(20.0f * alpha)));
                if (isDragging) {
                    RoundedUtil.drawRoundOutline(x, y, boxW, boxH, RADIUS, 1.5f, new Color(100, 150, 255, (int)(120.0f * alpha)));
                }
                float curY = y + PAD_Y;
                for (int i = 0; i < drawKeys.size(); ++i) {
                    String key = drawKeys.get(i);
                    EntryState es = this.entryStates.get(key);
                    if (es == null) {
                        curY += LINE_H + LINE_GAP;
                        continue;
                    }
                    float entryAlpha = es.alpha * alpha;
                    if (entryAlpha < 0.005f) {
                        curY += LINE_H + LINE_GAP;
                        continue;
                    }
                    if (i == 0) {
                        this.drawTitle(es, x, curY, boxW, LINE_H, TTS, entryAlpha, PAD_X);
                        float sepY = curY + LINE_H + LINE_GAP * 0.35f;
                        RoundedUtil.rect((double)(x + PAD_X), (double)sepY, (double)(boxW - PAD_X * 2.0f), 0.5, new Color(255, 255, 255, (int)(40.0f * entryAlpha)).getRGB());
                    } else {
                        this.drawEntry(es, key, x, curY, boxW, LINE_H, TS, entryAlpha, PAD_X, sc);
                    }
                    curY += LINE_H + LINE_GAP;
                }
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GL11.glMatrixMode((int)5889);
                GL11.glPopMatrix();
                GL11.glMatrixMode((int)5888);
                GL11.glPopMatrix();
                GL11.glPopAttrib();
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                Iterator<Map.Entry<String, EntryState>> it = this.entryStates.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<String, EntryState> e = it.next();
                    if (!e.getValue().dying || !(e.getValue().alpha < 0.01f)) continue;
                    it.remove();
                }
            }
        }
    }

    private void animateEntries(float sc) {
        for (EntryState es : this.entryStates.values()) {
            if (es.dying) {
                es.alpha = ScoreBoardModule.lerp(es.alpha, 0.0f, 0.15f * this.dt);
                continue;
            }
            if (es.slideAnim < 1.0f) {
                es.slideAnim += (1.06f - es.slideAnim) * 0.055f * this.dt;
                if (es.slideAnim > 1.06f) {
                    es.slideAnim = 1.06f;
                }
                if (es.slideAnim > 1.0f) {
                    es.slideAnim += (1.0f - es.slideAnim) * 0.07f * this.dt;
                }
                es.slideAnim = Math.min(es.slideAnim, 1.06f);
            }
            es.alpha = ScoreBoardModule.lerp(es.alpha, 1.0f, 0.15f * this.dt);
            if (es.pendingText != null) {
                es.xfadeAlpha = ScoreBoardModule.lerp(es.xfadeAlpha, 0.0f, 0.18f * this.dt);
                if (!(es.xfadeAlpha < 0.05f)) continue;
                es.displayText = es.pendingText;
                es.pendingText = null;
                es.xfadeAlpha = 0.0f;
                continue;
            }
            if (!(es.xfadeAlpha < 1.0f)) continue;
            es.xfadeAlpha = ScoreBoardModule.lerp(es.xfadeAlpha, 1.0f, 0.18f * this.dt);
        }
    }

    private List<String> buildDrawList() {
        ArrayList<String> list = new ArrayList<String>(this.orderedKeys);
        for (Map.Entry<String, EntryState> e : this.entryStates.entrySet()) {
            if (!e.getValue().dying || list.contains(e.getKey())) continue;
            list.add(e.getKey());
        }
        return list;
    }

    private float measureMaxWidth(List<String> keys, float padX, float sc, float ts, float tts) {
        float max = 60.0f * sc;
        for (int i = 0; i < keys.size(); ++i) {
            EntryState es = this.entryStates.get(keys.get(i));
            if (es == null) continue;
            String plain = ScoreBoardModule.stripColors(es.displayText);
            float tsz = i == 0 ? tts : ts;
            float w = (float)FontUtil.getStringWidth(plain) * tsz;
            if (((Boolean)this.showNumbers.getValue()).booleanValue() && i > 0) {
                w += (float)FontUtil.getStringWidth(keys.get(i)) * ts * 0.72f + 4.0f * sc;
            }
            if (!(w > max)) continue;
            max = w;
        }
        return max + padX * 2.0f + 0.5f + 2.0f;
    }

    private void drawTitle(EntryState es, float bx, float lineY, float boxW, float lineH, float ts, float entryAlpha, float padX) {
        if (es.xfadeAlpha < 0.99f && es.pendingText != null) {
            this.drawColoredCentered(es.displayText, bx, lineY, boxW, lineH, ts, entryAlpha * es.xfadeAlpha);
        } else if (es.pendingText == null && es.xfadeAlpha < 0.99f) {
            this.drawColoredCentered(es.displayText, bx, lineY, boxW, lineH, ts, entryAlpha * es.xfadeAlpha);
        } else {
            this.drawColoredCentered(es.displayText, bx, lineY, boxW, lineH, ts, entryAlpha);
        }
    }

    private void drawEntry(EntryState es, String key, float bx, float lineY, float boxW, float lineH, float ts, float entryAlpha, float padX, float sc) {
        float textAlpha;
        float slide = Math.min(es.slideAnim, 1.0f);
        float offset = (1.0f - slide) * 16.0f * sc;
        float textX = bx + padX + offset;
        float fontH = (float)FontUtil.getFontHeight() * ts;
        float textY = lineY + (lineH - fontH) / 2.0f;
        if (((Boolean)this.showNumbers.getValue()).booleanValue()) {
            float numTs = ts * 0.72f;
            float numH = (float)FontUtil.getFontHeight() * numTs;
            float numY = lineY + (lineH - numH) / 2.0f;
            GL11.glPushMatrix();
            GL11.glTranslatef((float)textX, (float)numY, (float)0.0f);
            GL11.glScalef((float)numTs, (float)numTs, (float)1.0f);
            FontUtil.drawString(key, 0.0f, 0.0f, new Color(120, 200, 100, (int)(180.0f * entryAlpha)).getRGB(), false);
            GL11.glPopMatrix();
            textX += (float)FontUtil.getStringWidth(key) * numTs + 4.0f * sc;
        }
        if ((textAlpha = entryAlpha * es.xfadeAlpha) > 0.01f) {
            this.drawColoredLeft(es.displayText, textX, textY, ts, textAlpha);
        }
        if (es.pendingText != null || es.xfadeAlpha < 0.99f) {
            // empty if block
        }
        float accentH = lineH * 0.55f;
        float accentY = lineY + (lineH - accentH) / 2.0f;
        float accentX = bx + boxW - padX * 0.5f;
        RoundedUtil.rect((double)accentX, (double)accentY, 0.5, (double)accentH, new Color(255, 255, 255, (int)(150.0f * entryAlpha)));
    }

    private void handleDrag(float x, float y, float w, float h, int sw, int sh) {
        if (!ClickGui.isUiEditMode()) {
            isDragging = false;
        } else if (!Mouse.isGrabbed()) {
            boolean inside;
            int mx = ScissorUtil.mapMouseX(Mouse.getX());
            int my = ScissorUtil.mapMouseY(Mouse.getY());
            boolean bl = inside = (float)mx >= x && (float)mx <= x + w && (float)my >= y && (float)my <= y + h;
            if (Mouse.isButtonDown((int)0)) {
                if (!isDragging && inside) {
                    if (ClickGui.isDraggingAnyElement()) {
                        return;
                    }
                    isDragging = true;
                    dragOffX = (float)mx - x;
                    dragOffY = (float)my - y;
                    ClickGui.setDraggingAnyElement(true);
                }
                if (isDragging) {
                    float nx = Math.max(5.0f, Math.min((float)sw - w - 5.0f, (float)mx - dragOffX));
                    float ny = Math.max(5.0f, Math.min((float)sh - h - 5.0f, (float)my - dragOffY));
                    posX = nx + w / 2.0f > (float)sw / 2.0f ? -((float)sw - nx) : nx;
                    posY = ny;
                }
            } else {
                if (isDragging) {
                    ClickGui.setDraggingAnyElement(false);
                }
                isDragging = false;
            }
        }
    }

    private void drawColoredCentered(String text, float bx, float lineY, float boxW, float lineH, float ts, float alpha) {
        List<ColorSegment> segs = this.parseColors(text, alpha);
        float totalW = 0.0f;
        for (ColorSegment s : segs) {
            totalW += (float)FontUtil.getStringWidth(s.text) * ts;
        }
        float startX = bx + (boxW - totalW) / 2.0f;
        float fontH = (float)FontUtil.getFontHeight() * ts;
        float textY = lineY + (lineH - fontH) / 2.0f;
        float cx = startX;
        for (ColorSegment seg : segs) {
            if (seg.text.isEmpty()) continue;
            GL11.glPushMatrix();
            GL11.glTranslatef((float)cx, (float)textY, (float)0.0f);
            GL11.glScalef((float)ts, (float)ts, (float)1.0f);
            FontUtil.drawString(seg.text, 0.0f, 0.0f, seg.color, false);
            GL11.glPopMatrix();
            cx += (float)FontUtil.getStringWidth(seg.text) * ts;
        }
    }

    private void drawColoredLeft(String text, float startX, float textY, float ts, float alpha) {
        List<ColorSegment> segs = this.parseColors(text, alpha);
        float cx = startX;
        for (ColorSegment seg : segs) {
            if (seg.text.isEmpty()) continue;
            GL11.glPushMatrix();
            GL11.glTranslatef((float)cx, (float)textY, (float)0.0f);
            GL11.glScalef((float)ts, (float)ts, (float)1.0f);
            FontUtil.drawString(seg.text, 0.0f, 0.0f, seg.color, false);
            GL11.glPopMatrix();
            cx += (float)FontUtil.getStringWidth(seg.text) * ts;
        }
    }

    private List<ColorSegment> parseColors(String raw, float alpha) {
        ArrayList<ColorSegment> out = new ArrayList<ColorSegment>();
        if (raw != null && !raw.isEmpty()) {
            int curRgb = 0xFFFFFF;
            StringBuilder buf = new StringBuilder();
            for (int i = 0; i < raw.length(); ++i) {
                char c = raw.charAt(i);
                if ((c == '\u00a7' || c == '&') && i + 1 < raw.length()) {
                    char code;
                    if (buf.length() > 0) {
                        out.add(new ColorSegment(buf.toString(), ScoreBoardModule.mkColor(curRgb, alpha)));
                        buf.setLength(0);
                    }
                    if ((code = Character.toLowerCase(raw.charAt(++i))) >= '0' && code <= '9') {
                        curRgb = MC_COLORS[code - 48];
                        continue;
                    }
                    if (code >= 'a' && code <= 'f') {
                        curRgb = MC_COLORS[10 + (code - 97)];
                        continue;
                    }
                    if (code != 'r') continue;
                    curRgb = 0xFFFFFF;
                    continue;
                }
                buf.append(c);
            }
            if (buf.length() > 0) {
                out.add(new ColorSegment(buf.toString(), ScoreBoardModule.mkColor(curRgb, alpha)));
            }
            return out;
        }
        return out;
    }

    private static int mkColor(int rgb, float alpha) {
        return (int)(255.0f * alpha) << 24 | rgb & 0xFFFFFF;
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * Math.min(t, 1.0f);
    }

    private static String stripColors(String s) {
        return s == null ? "" : s.replaceAll("[\u00c3\u201a\u00c2\u00a7&][0-9a-fk-orA-FK-OR]", "");
    }

    private static String sanitizeTurkish(String s) {
        return s == null ? "" : s.replace("\u00c4\u00b1", "i").replace("\u00c4\u00b0", "I").replace("\u00c5\u0178", "s").replace("\u00c5\u009e", "S").replace("\u00c4\u0178", "g").replace("\u00c4\u009e", "G").replace("\u00c3\u00bc", "u").replace("\u00c3\u0153", "U").replace("\u00c3\u00b6", "o").replace("\u00c3\u2013", "O").replace("\u00c3\u00a7", "c").replace("\u00c3\u2021", "C");
    }

    static {
        scoreBoard = false;
        originalScoreBoardRef = null;
        fakeScoreBoardRef = null;
        posX = -1.0f;
        posY = 10.0f;
        isDragging = false;
        dragOffX = 0.0f;
        dragOffY = 0.0f;
        MC_COLORS = new int[]{0, 170, 43520, 43690, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA, 0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF};
    }

    private static final class EntryState {
        float slideAnim = 0.0f;
        float alpha = 1.0f;
        boolean dying = false;
        String displayText;
        String pendingText = null;
        float xfadeAlpha = 1.0f;

        EntryState(String text) {
            this.displayText = text;
        }
    }

    private static final class ColorSegment {
        final String text;
        final int color;

        ColorSegment(String t, int c) {
            this.text = t;
            this.color = c;
        }
    }
}

