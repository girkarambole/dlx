/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
package me.ries.module.impl;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;

public class FastUseModule
extends Module {
    private final BooleanOption forcePacket = new BooleanOption("ForcePacket", true, (Module)this);
    private final NumberOption forceDelay = new NumberOption("ForceDelay", 2.0, 1.0, 20.0, 1.0, this);
    private final BooleanOption blockSpoof = new BooleanOption("BlockSpoof", false, (Module)this);
    private final BooleanOption autoSwitch = new BooleanOption("AutoSwitch", true, (Module)this);
    private final List<Field> intFields = new ArrayList<Field>();
    private boolean scanned = false;
    private int ticksElapsed = 0;

    public FastUseModule() {
        super("FastUse", "Item kullanim gecikmelerini kaldirir ve zorla firlatma paketi gonderir.", Category.MISC, 0);
        this.addOptions(this.forcePacket, this.forceDelay, this.blockSpoof, this.autoSwitch);
    }

    @Override
    public void onEnable() {
        this.intFields.clear();
        this.scanned = false;
        this.ticksElapsed = 0;
    }

    @Override
    public void onDisable() {
        this.intFields.clear();
        this.scanned = false;
    }

    @Override
    public void onUpdate() {
        Object object = MinecraftMapper.getMinecraft();
        if (object == null) {
            return;
        }
        if (!this.scanned) {
            this.scanned = true;
            try {
                for (Field object2 : object.getClass().getDeclaredFields()) {
                    if (object2.getType() != Integer.TYPE || Modifier.isStatic(object2.getModifiers())) continue;
                    object2.setAccessible(true);
                    this.intFields.add(object2);
                }
            }
            catch (Throwable throwable) {
                Logger.warn("[FastUse] Scan failed: " + throwable.getMessage());
            }
        }
        for (Field field : this.intFields) {
            try {
                int n = field.getInt(object);
                if (n <= 0 || n > 10) continue;
                field.setInt(object, 0);
            }
            catch (Throwable throwable) {}
        }
        if (((Boolean)this.forcePacket.getValue()).booleanValue()) {
            ++this.ticksElapsed;
            double d = (Double)this.forceDelay.getValue();
            if ((double)this.ticksElapsed >= d) {
                this.ticksElapsed = 0;
                try {
                    Object object2;
                    Field field = MinecraftMapper.getField("Minecraft.currentScreen");
                    field.setAccessible(true);
                    if (field.get(object) != null) {
                        return;
                    }
                    if (Mouse.isButtonDown((int)1) && (object2 = MinecraftMapper.getPlayer()) != null) {
                        int n;
                        Object object3 = this.getHeldItem(object2);
                        if (((Boolean)this.autoSwitch.getValue()).booleanValue() && !this.isPotion(object3) && (n = this.findPotionSlot(object2)) != -1) {
                            this.switchSlot(object2, n);
                            object3 = this.getHeldItem(object2);
                        }
                        if (this.isPotion(object3)) {
                            this.sendPlacementPacket(object2, object3);
                        }
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
    }

    private Object getHeldItem(Object object) {
        try {
            Object object2 = MappingUtils.getInventory(object);
            if (object2 != null) {
                Field field = MappingUtils.getField("InventoryPlayer.currentItem");
                Field field2 = MappingUtils.getField("InventoryPlayer.mainInventory");
                if (field != null && field2 != null) {
                    field.setAccessible(true);
                    field2.setAccessible(true);
                    int n = field.getInt(object2);
                    Object object3 = field2.get(object2);
                    if (object3 instanceof Object[]) {
                        Object[] objectArray = (Object[])object3;
                        if (n >= 0 && n < objectArray.length) {
                            return objectArray[n];
                        }
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private int findPotionSlot(Object object) {
        try {
            Field field;
            Object object2 = MappingUtils.getInventory(object);
            if (object2 != null && (field = MappingUtils.getField("InventoryPlayer.mainInventory")) != null) {
                field.setAccessible(true);
                Object object3 = field.get(object2);
                if (object3 instanceof Object[]) {
                    Object[] objectArray = (Object[])object3;
                    for (int i = 0; i < 9; ++i) {
                        if (i >= objectArray.length || objectArray[i] == null || !this.isPotion(objectArray[i])) continue;
                        return i;
                    }
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return -1;
    }

    private void switchSlot(Object object, int n) {
        try {
            AnnotatedElement annotatedElement;
            Object object2 = MappingUtils.getInventory(object);
            if (object2 != null && (annotatedElement = MappingUtils.getField("InventoryPlayer.currentItem")) != null) {
                ((Field)annotatedElement).setAccessible(true);
                ((Field)annotatedElement).setInt(object2, n);
            }
            if ((annotatedElement = MinecraftMapper.get("C09PacketHeldItemChange")) != null) {
                Constructor constructor = ((Class)annotatedElement).getDeclaredConstructor(Integer.TYPE);
                constructor.setAccessible(true);
                Object t = constructor.newInstance(n);
                Field field = MinecraftMapper.getField("EntityPlayerSP.sendQueue");
                if (field == null) {
                    field = MinecraftMapper.getFieldByType(object.getClass(), MappingUtils.get("NetHandlerPlayClient"));
                }
                field.setAccessible(true);
                Object object3 = field.get(object);
                Method method = MappingUtils.getMethod("NetHandlerPlayClient.sendPacket");
                if (t != null && object3 != null && method != null) {
                    method.setAccessible(true);
                    method.invoke(object3, t);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private boolean isPotion(Object object) {
        if (object == null) {
            return false;
        }
        String string = MappingUtils.getItemName(object);
        if (string == null) {
            return false;
        }
        String string2 = string.toLowerCase();
        return string2.contains("potion") || string2.contains("iksir");
    }

    /*
     * WARNING - void declaration
     */
    private void sendPlacementPacket(Object object, Object object2) {
        try {
            void var7_11;
            float f;
            float f2;
            float f3;
            int n;
            Class<?> clazz = MinecraftMapper.get("C08PacketPlayerBlockPlacement");
            Class<?> clazz2 = MappingUtils.get("BlockPos");
            Class<?> clazz3 = MappingUtils.get("ItemStack");
            if (clazz == null || clazz2 == null || clazz3 == null) {
                return;
            }
            Constructor<?> constructor = null;
            for (Constructor<?> constructor2 : clazz.getDeclaredConstructors()) {
                Class<?>[] classArray = constructor2.getParameterTypes();
                if (classArray.length != 6 || classArray[0] != clazz2 || classArray[1] != Integer.TYPE || classArray[2] != clazz3 || classArray[3] != Float.TYPE || classArray[4] != Float.TYPE || classArray[5] != Float.TYPE) continue;
                constructor = constructor2;
                break;
            }
            if (constructor == null) {
                return;
            }
            if (((Boolean)this.blockSpoof.getValue()).booleanValue()) {
                AccessibleObject accessibleObject;
                double d = 0.0;
                double d2 = 0.0;
                double d3 = 0.0;
                try {
                    accessibleObject = MinecraftMapper.getField("Entity.posX");
                    Field field = MinecraftMapper.getField("Entity.posY");
                    Field field2 = MinecraftMapper.getField("Entity.posZ");
                    ((Field)accessibleObject).setAccessible(true);
                    field.setAccessible(true);
                    field2.setAccessible(true);
                    d = ((Field)accessibleObject).getDouble(object);
                    d2 = field.getDouble(object);
                    d3 = field2.getDouble(object);
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                accessibleObject = clazz2.getDeclaredConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE);
                ((Constructor)accessibleObject).setAccessible(true);
                Object t = ((Constructor)accessibleObject).newInstance((int)Math.floor(d), (int)Math.floor(d2) - 1, (int)Math.floor(d3));
                n = 1;
                f3 = 0.5f;
                f2 = 1.0f;
                f = 0.5f;
            } else {
                Constructor<?> constructor3 = clazz2.getDeclaredConstructor(Integer.TYPE, Integer.TYPE, Integer.TYPE);
                constructor3.setAccessible(true);
                Object obj = constructor3.newInstance(-1, -1, -1);
                n = 255;
                f3 = 0.0f;
                f2 = 0.0f;
                f = 0.0f;
            }
            constructor.setAccessible(true);
            Object obj = constructor.newInstance(var7_11, n, object2, Float.valueOf(f3), Float.valueOf(f2), Float.valueOf(f));
            Field field = MinecraftMapper.getField("EntityPlayerSP.sendQueue");
            if (field == null) {
                field = MinecraftMapper.getFieldByType(object.getClass(), MappingUtils.get("NetHandlerPlayClient"));
            }
            field.setAccessible(true);
            Object object3 = field.get(object);
            Method method = MappingUtils.getMethod("NetHandlerPlayClient.sendPacket");
            if (obj != null && object3 != null && method != null) {
                method.setAccessible(true);
                method.invoke(object3, obj);
                Method method2 = MappingUtils.getMethod("EntityPlayerSP.swingItem");
                if (method2 == null) {
                    method2 = MappingUtils.getMethod("EntityPlayer.swingItem");
                }
                if (method2 != null) {
                    method2.setAccessible(true);
                    method2.invoke(object, new Object[0]);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

