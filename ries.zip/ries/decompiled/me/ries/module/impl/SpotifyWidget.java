/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package me.ries.module.impl;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.imageio.ImageIO;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.StringOption;
import me.ries.ui.ClickGui;
import me.ries.ui.IngameHud;
import me.ries.util.ChatUtils;
import me.ries.util.FontUtil;
import me.ries.util.GaussianBlur;
import me.ries.util.GlStateManager;
import me.ries.util.Logger;
import me.ries.util.RoundedUtil;
import me.ries.util.ScissorUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class SpotifyWidget
extends Module {
    private final StringOption nextKeyOpt = new StringOption("Next Key", "Right", this, "Right", "Left", "Up", "Down", "End", "Home", "Insert", "Delete", "PageUp", "PageDown", "None");
    private final StringOption prevKeyOpt = new StringOption("Prev Key", "Left", this, "Right", "Left", "Up", "Down", "End", "Home", "Insert", "Delete", "PageUp", "PageDown", "None");
    private final StringOption playPauseKeyOpt = new StringOption("Play/Pause Key", "None", this, "Right", "Left", "Up", "Down", "End", "Home", "Insert", "Delete", "PageUp", "PageDown", "None");
    private final StringOption stopKeyOpt = new StringOption("Stop/Pause Key", "End", this, "Right", "Left", "Up", "Down", "End", "Home", "Insert", "Delete", "PageUp", "PageDown", "None");
    public static volatile String nativeTrack = "No Track";
    public static volatile String nativeArtist = "";
    public static volatile boolean nativePlaying = false;
    public static volatile boolean nativeAvailable = false;
    public static volatile long nativePosition = 0L;
    public static volatile long nativeDuration = 0L;
    public static volatile int nativeCommand = 0;
    public static float posX = 10.0f;
    public static float posY = 10.0f;
    public static float width = 210.0f;
    public static float height = 62.0f;
    private static final float MIN_W = 180.0f;
    private static final float MAX_W = 420.0f;
    private static final float MIN_H = 50.0f;
    private static final float MAX_H = 110.0f;
    private static boolean isDragging = false;
    private static boolean isResizing = false;
    private static float dragOffX = 0.0f;
    private static float dragOffY = 0.0f;
    private long lastClickTime = 0L;
    private static final long CLICK_COOLDOWN = 200L;
    private int albumArtTex = -1;
    private boolean texLoaded = false;
    private AtomicBoolean isLoading = new AtomicBoolean(false);
    private BufferedImage pendingImage = null;
    private long lastArtCheck = 0L;
    private long lastArtMod = 0L;
    private float showAnim = 0.0f;
    private float progressAnim = 0.0f;
    private float trackChangeAnim = 1.0f;
    private String lastTrackUID = "";
    private String cachedTrack = "";
    private String cachedArtist = "";
    private float lastAvailW = 0.0f;
    private String lastRawTrack = "";
    private String lastRawArtist = "";
    private static final float RADIUS = 6.0f;
    private static final Color BG_COLOR = new Color(15, 15, 15, 130);
    private static final Color BORDER_COLOR = new Color(255, 255, 255, 32);
    private static final Color TEXT_PRIMARY = new Color(237, 237, 237);
    private static final Color TEXT_SECONDARY = new Color(160, 160, 160);
    private long lastKeyTime = 0L;

    public static void resetDragState() {
        isDragging = false;
        isResizing = false;
    }

    public SpotifyWidget() {
        super("SpotifyWidget", "Spotify media widget", Category.RENDER, 0);
        this.addOptions(this.nextKeyOpt, this.prevKeyOpt, this.playPauseKeyOpt, this.stopKeyOpt);
        try {
            float f = IngameHud.getWatermarkRight();
            posX = f + 8.0f;
            posY = IngameHud.watermarkY;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Override
    public void onEnable() {
        this.showAnim = 0.0f;
        this.progressAnim = 0.0f;
        this.texLoaded = false;
        this.isLoading.set(false);
        this.pendingImage = null;
        this.lastArtMod = 0L;
        if (this.albumArtTex != -1) {
            GL11.glDeleteTextures((int)this.albumArtTex);
            this.albumArtTex = -1;
        }
    }

    @Override
    public void onDisable() {
        if (this.albumArtTex != -1) {
            GL11.glDeleteTextures((int)this.albumArtTex);
            this.albumArtTex = -1;
        }
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        Object object = MinecraftMapper.getCurrentScreen();
        if (object != null) {
            return;
        }
        try {
            long l = System.currentTimeMillis();
            if (l - this.lastKeyTime > 350L) {
                int n = this.getKeyFromName((String)this.nextKeyOpt.getValue());
                int n2 = this.getKeyFromName((String)this.prevKeyOpt.getValue());
                int n3 = this.getKeyFromName((String)this.playPauseKeyOpt.getValue());
                int n4 = this.getKeyFromName((String)this.stopKeyOpt.getValue());
                if (n != 0 && Keyboard.isKeyDown((int)n)) {
                    nativeCommand = 3;
                    this.lastKeyTime = l;
                    ChatUtils.addChatMessage("\u00a77[Spotify] \u00a7aSonraki \u015fark\u0131.");
                } else if (n2 != 0 && Keyboard.isKeyDown((int)n2)) {
                    nativeCommand = 1;
                    this.lastKeyTime = l;
                    ChatUtils.addChatMessage("\u00a77[Spotify] \u00a7e\u00d6nceki \u015fark\u0131.");
                } else if (n3 != 0 && Keyboard.isKeyDown((int)n3)) {
                    nativeCommand = 2;
                    this.lastKeyTime = l;
                    ChatUtils.addChatMessage("\u00a77[Spotify] \u00a7cOynat/Durdur.");
                } else if (n4 != 0 && Keyboard.isKeyDown((int)n4) && nativePlaying) {
                    nativeCommand = 2;
                    this.lastKeyTime = l;
                    ChatUtils.addChatMessage("\u00a77[Spotify] \u00a7c\u015eark\u0131 durduruldu.");
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private int getKeyFromName(String string) {
        if ("Right".equals(string)) {
            return 205;
        }
        if ("Left".equals(string)) {
            return 203;
        }
        if ("Up".equals(string)) {
            return 200;
        }
        if ("Down".equals(string)) {
            return 208;
        }
        if ("End".equals(string)) {
            return 207;
        }
        if ("Home".equals(string)) {
            return 199;
        }
        if ("Insert".equals(string)) {
            return 210;
        }
        if ("Delete".equals(string)) {
            return 211;
        }
        if ("PageUp".equals(string)) {
            return 201;
        }
        if ("PageDown".equals(string)) {
            return 209;
        }
        return 0;
    }

    public void render() {
        if (this.isEnabled() && !ClickGui.isUiEditMode()) {
            this.renderInternal();
        }
    }

    public void renderForEditMode() {
        if (this.isEnabled()) {
            this.renderInternal();
        }
    }

    private void renderInternal() {
        float f;
        float f2;
        float f3;
        String string;
        String string2 = nativeTrack != null ? nativeTrack : "No Track";
        String string3 = nativeArtist != null ? nativeArtist : "";
        String string4 = string3;
        if (!nativeAvailable) {
            string2 = "Spotify";
            string3 = "Not Connected";
        }
        if (!(string = string2 + string3).equals(this.lastTrackUID)) {
            if (!this.lastTrackUID.isEmpty()) {
                this.trackChangeAnim = 0.0f;
            }
            this.lastTrackUID = string;
            this.texLoaded = false;
            this.lastArtMod = 0L;
            if (this.albumArtTex != -1) {
                try {
                    GL11.glDeleteTextures((int)this.albumArtTex);
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                this.albumArtTex = -1;
            }
        }
        this.showAnim += (1.0f - this.showAnim) * 0.15f;
        this.trackChangeAnim += (1.0f - this.trackChangeAnim) * 0.1f;
        int n = ScissorUtil.getScaledWidth();
        int n2 = ScissorUtil.getScaledHeight();
        int n3 = ScissorUtil.mapMouseX(Mouse.getX());
        int n4 = ScissorUtil.mapMouseY(Mouse.getY());
        boolean bl = ClickGui.isUiEditMode();
        boolean bl2 = !Mouse.isGrabbed();
        boolean bl3 = bl2;
        if (bl2) {
            this.handleInput(n3, n4, n, n2);
        }
        posX = Math.max(5.0f, Math.min((float)n - width - 5.0f, posX));
        posY = Math.max(5.0f, Math.min((float)n2 - height - 5.0f, posY));
        float f4 = this.showAnim;
        GL11.glPushAttrib((int)1048575);
        GlStateManager.pushMatrix();
        GlStateManager.translate(posX, posY, 0.0f);
        float f5 = 0.0f;
        float f6 = 0.0f;
        if (!isDragging && !isResizing) {
            GaussianBlur.renderBlurRounded(posX, posY, width, height, 6.0f, 8.0f * f4);
        }
        RoundedUtil.roundedRect((double)f5, (double)f6, (double)width, (double)height, 6.0, this.applyAlpha(BG_COLOR, f4));
        Color color = this.applyAlpha(BORDER_COLOR, f4);
        if (bl && (isDragging || isResizing)) {
            color = this.applyAlpha(new Color(0, 110, 254), f4);
        }
        RoundedUtil.drawRoundOutline(f5, f6, width, height, 6.0f, 1.0f, color);
        RoundedUtil.rect((double)(f5 + 4.0f), (double)(f6 + 4.0f), 1.0, (double)(height - 8.0f), this.applyAlpha(new Color(255, 255, 255, 120), f4));
        if (bl) {
            f3 = 8.0f;
            RoundedUtil.roundedRect((double)(f5 + width - f3 - 3.0f), (double)(f6 + height - f3 - 3.0f), (double)f3, (double)f3, 1.5, isResizing ? new Color(0, 110, 254, 150) : new Color(255, 255, 255, 40));
        }
        f3 = f5 + 10.0f;
        float f7 = height - 20.0f;
        float f8 = f5 + 12.0f;
        float f9 = f6 + 10.0f;
        float f10 = f7 / 2.0f;
        float f11 = f8 + f10;
        float f12 = f9 + f10;
        if (!isDragging && !isResizing) {
            this.checkAndLoadAlbumArt("C:\\ries\\spotify_art.png");
            if (this.pendingImage != null) {
                this.uploadTexture();
            }
        }
        float f13 = 1.0f;
        if (this.trackChangeAnim < 1.0f) {
            f13 = 1.0f + (float)Math.sin((double)this.trackChangeAnim * Math.PI) * 0.1f;
        }
        if (f13 != 1.0f) {
            GL11.glPushMatrix();
            GL11.glTranslatef((float)f11, (float)f12, (float)0.0f);
            GL11.glScalef((float)f13, (float)f13, (float)1.0f);
            GL11.glTranslatef((float)(-f11), (float)(-f12), (float)0.0f);
        }
        float f14 = f10 - 3.0f;
        if (this.texLoaded && this.albumArtTex != -1 && !isDragging && !isResizing) {
            this.drawRoundedTexture(this.albumArtTex, f11 - f14, f12 - f14, f14 * 2.0f, f4, f14);
        } else {
            RoundedUtil.roundedRect((double)(f11 - f14), (double)(f12 - f14), (double)(f14 * 2.0f), (double)(f14 * 2.0f), (double)f14, this.applyAlpha(new Color(30, 30, 30), f4));
        }
        if (f13 != 1.0f) {
            GL11.glPopMatrix();
        }
        if (nativeDuration > 0L) {
            f2 = (float)nativePosition / (float)nativeDuration;
            this.progressAnim += (f2 - this.progressAnim) * 0.15f;
            this.progressAnim = Math.max(0.0f, Math.min(1.0f, this.progressAnim));
            GL11.glDisable((int)3553);
            GL11.glEnable((int)3042);
            GL11.glEnable((int)2848);
            GL11.glLineWidth((float)2.0f);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)(0.15f * f4));
            GL11.glBegin((int)3);
            f = f10 - 1.0f;
            for (int i = 0; i <= 360; i += 5) {
                double d = (double)i * Math.PI / 180.0;
                GL11.glVertex2d((double)((double)f11 + Math.sin(d) * (double)f), (double)((double)f12 - Math.cos(d) * (double)f));
            }
            GL11.glEnd();
            Color color2 = this.applyAlpha(TEXT_PRIMARY, f4);
            GL11.glColor4f((float)((float)color2.getRed() / 255.0f), (float)((float)color2.getGreen() / 255.0f), (float)((float)color2.getBlue() / 255.0f), (float)((float)color2.getAlpha() / 255.0f));
            GL11.glBegin((int)3);
            int n5 = (int)(360.0f * this.progressAnim);
            for (int i = 0; i <= n5; i += 2) {
                double d = (double)i * Math.PI / 180.0;
                GL11.glVertex2d((double)((double)f11 + Math.sin(d) * (double)f), (double)((double)f12 - Math.cos(d) * (double)f));
            }
            GL11.glEnd();
            GL11.glDisable((int)2848);
        }
        f2 = f8 + f7 + 16.0f;
        f = width - (f2 - f5) - 6.0f;
        float f15 = f - 90.0f;
        float f16 = f6 + height * 0.5f;
        if (!string2.equals(this.lastRawTrack) || !string3.equals(this.lastRawArtist) || Math.abs(f15 - this.lastAvailW) > 2.0f) {
            this.cachedTrack = FontUtil.trimToWidth(this.sanitize(string2), (int)f15, 0.85f);
            this.cachedArtist = FontUtil.trimToWidth(this.sanitize(string3), (int)f15, 0.65f);
            this.lastRawTrack = string2;
            this.lastRawArtist = string3;
            this.lastAvailW = f15;
        }
        float f17 = f4;
        float f18 = 0.0f;
        if (this.trackChangeAnim < 1.0f) {
            f17 = f4 * this.trackChangeAnim;
            f18 = (1.0f - this.trackChangeAnim) * 3.0f;
        }
        int n6 = this.applyAlpha(TEXT_PRIMARY, f17).getRGB();
        int n7 = this.applyAlpha(TEXT_SECONDARY, f17).getRGB();
        GL11.glPushMatrix();
        GL11.glTranslatef((float)f2, (float)(f16 - 9.0f + f18), (float)0.0f);
        GL11.glScalef((float)0.85f, (float)0.85f, (float)1.0f);
        FontUtil.drawString(this.cachedTrack, 0.0f, 0.0f, n6, false);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef((float)f2, (float)(f16 + 5.0f + f18), (float)0.0f);
        GL11.glScalef((float)0.65f, (float)0.65f, (float)1.0f);
        FontUtil.drawString(this.cachedArtist, 0.0f, 0.0f, n7, false);
        GL11.glPopMatrix();
        float f19 = f5 + width - 40.0f;
        float f20 = f6 + height * 0.5f;
        float f21 = 24.0f;
        float f22 = (float)n3 - posX;
        float f23 = (float)n4 - posY;
        boolean bl4 = this.hovered(f22, f23, f19 - f21 - 5.0f, f20 - 5.0f, 10.0f, 10.0f);
        boolean bl5 = this.hovered(f22, f23, f19 - 5.0f, f20 - 5.0f, 10.0f, 10.0f);
        boolean bl6 = this.hovered(f22, f23, f19 + f21 - 5.0f, f20 - 5.0f, 10.0f, 10.0f);
        Color color3 = bl4 ? TEXT_PRIMARY : TEXT_SECONDARY;
        Color color4 = bl5 ? TEXT_PRIMARY : TEXT_SECONDARY;
        Color color5 = bl6 ? TEXT_PRIMARY : TEXT_SECONDARY;
        this.drawPrevIcon(f19 - f21, f20, 10.0f, color3, f4);
        if (nativePlaying) {
            this.drawPauseIcon(f19, f20, 11.0f, color4, f4);
        } else {
            this.drawPlayIcon(f19, f20, 11.0f, color4, f4);
        }
        this.drawNextIcon(f19 + f21, f20, 10.0f, color5, f4);
        if (Mouse.isButtonDown((int)0)) {
            if (bl4 && this.cooldown()) {
                nativeCommand = 1;
            }
            if (bl5 && this.cooldown()) {
                nativeCommand = 2;
            }
            if (bl6 && this.cooldown()) {
                nativeCommand = 3;
            }
        }
        GlStateManager.popMatrix();
        GL11.glPopAttrib();
    }

    private void handleInput(int n, int n2, int n3, int n4) {
        if (!ClickGui.isUiEditMode()) {
            isDragging = false;
            isResizing = false;
        } else {
            float f = posX;
            float f2 = posY;
            float f3 = width;
            float f4 = height;
            boolean bl = (float)n >= f && (float)n <= f + f3 && (float)n2 >= f2 && (float)n2 <= f2 + f4;
            boolean bl2 = (float)n >= f + f3 - 20.0f && (float)n <= f + f3 + 5.0f && (float)n2 >= f2 + f4 - 20.0f && (float)n2 <= f2 + f4 + 5.0f;
            boolean bl3 = bl2;
            if (Mouse.isButtonDown((int)0)) {
                if (!isDragging && !isResizing) {
                    if (ClickGui.isDraggingAnyElement()) {
                        return;
                    }
                    if (bl2) {
                        isResizing = true;
                        ClickGui.setDraggingAnyElement(true);
                    } else if (bl) {
                        boolean bl4 = (float)n >= f + f3 - 60.0f && (float)n <= f + f3;
                        boolean bl5 = bl4;
                        if (!bl4) {
                            isDragging = true;
                            dragOffX = (float)n - f;
                            dragOffY = (float)n2 - f2;
                            ClickGui.setDraggingAnyElement(true);
                        }
                    }
                }
                if (isDragging) {
                    posX = Math.max(5.0f, Math.min((float)n3 - width - 5.0f, (float)n - dragOffX));
                    posY = Math.max(5.0f, Math.min((float)n4 - height - 5.0f, (float)n2 - dragOffY));
                }
                if (isResizing) {
                    width = Math.max(180.0f, Math.min(420.0f, (float)n - f));
                    height = Math.max(50.0f, Math.min(110.0f, (float)n2 - f2));
                }
            } else {
                if (isDragging || isResizing) {
                    ClickGui.setDraggingAnyElement(false);
                }
                isDragging = false;
                isResizing = false;
            }
        }
    }

    private void checkAndLoadAlbumArt(String string) {
        long l;
        if (!this.isLoading.get() && this.pendingImage == null && (l = System.currentTimeMillis()) - this.lastArtCheck >= 2000L) {
            this.lastArtCheck = l;
            File file = new File(string);
            if (file.exists()) {
                long l2 = file.lastModified();
                if (!this.texLoaded || l2 != this.lastArtMod) {
                    this.isLoading.set(true);
                    new Thread(() -> {
                        try {
                            Thread.sleep(120L);
                            byte[] byArray = Files.readAllBytes(file.toPath());
                            if (byArray.length > 0) {
                                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byArray);
                                BufferedImage bufferedImage = ImageIO.read(byteArrayInputStream);
                                if (bufferedImage != null) {
                                    this.pendingImage = bufferedImage;
                                    this.lastArtMod = l2;
                                    Logger.info("SpotifyWidget: Album art loaded successfully! (" + byArray.length + " bytes)");
                                } else {
                                    Logger.warn("SpotifyWidget: ImageIO.read returned null!");
                                }
                            }
                        }
                        catch (Throwable throwable) {
                            Logger.warn("SpotifyWidget: Failed to load album art: " + throwable.getMessage());
                        }
                        finally {
                            this.isLoading.set(false);
                        }
                    }, "SpotifyArtLoader").start();
                }
            }
        }
    }

    private void uploadTexture() {
        if (this.pendingImage != null) {
            try {
                int n;
                int n2;
                if (this.albumArtTex != -1) {
                    GL11.glDeleteTextures((int)this.albumArtTex);
                }
                this.albumArtTex = GL11.glGenTextures();
                BufferedImage bufferedImage = this.pendingImage;
                if (bufferedImage.getWidth() >= 100 && bufferedImage.getHeight() >= 100) {
                    n2 = bufferedImage.getWidth();
                    n = (int)((double)n2 * 0.7766666666666666);
                    int n3 = (int)((double)n2 * 0.11);
                    try {
                        bufferedImage = bufferedImage.getSubimage(n3, 0, n, n);
                    }
                    catch (Throwable throwable) {
                        Logger.warn("SpotifyWidget: Crop failed: " + throwable.getMessage());
                    }
                }
                n2 = bufferedImage.getWidth();
                n = bufferedImage.getHeight();
                int[] nArray = new int[n2 * n];
                bufferedImage.getRGB(0, 0, n2, n, nArray, 0, n2);
                int n4 = nArray[0];
                int n5 = n4 >> 24 & 0xFF;
                int n6 = n4 >> 16 & 0xFF;
                int n7 = n4 >> 8 & 0xFF;
                int n8 = n4 & 0xFF;
                Logger.info("SpotifyWidget upload: size=" + n2 + "x" + n + " first_pixel=A:" + n5 + ",R:" + n6 + ",G:" + n7 + ",B:" + n8);
                ByteBuffer byteBuffer = BufferUtils.createByteBuffer((int)(n2 * n * 4));
                for (int n9 : nArray) {
                    byteBuffer.put((byte)(n9 >> 16 & 0xFF));
                    byteBuffer.put((byte)(n9 >> 8 & 0xFF));
                    byteBuffer.put((byte)(n9 & 0xFF));
                    byteBuffer.put((byte)(n9 >> 24 & 0xFF));
                }
                Object object = byteBuffer;
                ((Buffer)object).flip();
                GL11.glBindTexture((int)3553, (int)this.albumArtTex);
                GL11.glTexParameteri((int)3553, (int)10241, (int)9729);
                GL11.glTexParameteri((int)3553, (int)10240, (int)9729);
                GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
                GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
                GL11.glTexImage2D((int)3553, (int)0, (int)32856, (int)n2, (int)n, (int)0, (int)6408, (int)5121, (ByteBuffer)byteBuffer);
                GL11.glBindTexture((int)3553, (int)0);
                this.texLoaded = true;
            }
            catch (Throwable throwable) {
                Logger.warn("SpotifyWidget: uploadTexture failed: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
            }
            this.pendingImage = null;
        }
    }

    private void drawRoundedTexture(int n, float f, float f2, float f3, float f4, float f5) {
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2884);
        GL11.glBindTexture((int)3553, (int)n);
        RoundedUtil.drawRoundTextured(f, f2, f3, f3, f5, f4);
        GL11.glBindTexture((int)3553, (int)0);
        GL11.glEnable((int)2884);
        GL11.glDisable((int)3553);
    }

    private void drawPrevIcon(float f, float f2, float f3, Color color, float f4) {
        this.prepareIcon(color, f4);
        float f5 = f3 * 0.45f;
        GL11.glBegin((int)1);
        GL11.glVertex2f((float)(f - f5), (float)(f2 - f5));
        GL11.glVertex2f((float)(f - f5), (float)(f2 + f5));
        GL11.glEnd();
        GL11.glBegin((int)2);
        GL11.glVertex2f((float)(f + f5), (float)(f2 - f5));
        GL11.glVertex2f((float)(f - f5 * 0.2f), (float)f2);
        GL11.glVertex2f((float)(f + f5), (float)(f2 + f5));
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    private void drawNextIcon(float f, float f2, float f3, Color color, float f4) {
        this.prepareIcon(color, f4);
        float f5 = f3 * 0.45f;
        GL11.glBegin((int)1);
        GL11.glVertex2f((float)(f + f5), (float)(f2 - f5));
        GL11.glVertex2f((float)(f + f5), (float)(f2 + f5));
        GL11.glEnd();
        GL11.glBegin((int)2);
        GL11.glVertex2f((float)(f - f5), (float)(f2 - f5));
        GL11.glVertex2f((float)(f + f5 * 0.2f), (float)f2);
        GL11.glVertex2f((float)(f - f5), (float)(f2 + f5));
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    private void drawPlayIcon(float f, float f2, float f3, Color color, float f4) {
        this.prepareIcon(color, f4);
        float f5 = f3 * 0.5f;
        GL11.glBegin((int)2);
        GL11.glVertex2f((float)(f - f5 * 0.4f), (float)(f2 - f5));
        GL11.glVertex2f((float)(f + f5 * 0.6f), (float)f2);
        GL11.glVertex2f((float)(f - f5 * 0.4f), (float)(f2 + f5));
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    private void drawPauseIcon(float f, float f2, float f3, Color color, float f4) {
        this.prepareIcon(color, f4);
        float f5 = f3 * 0.45f;
        float f6 = f5 * 0.35f;
        GL11.glBegin((int)1);
        GL11.glVertex2f((float)(f - f6), (float)(f2 - f5));
        GL11.glVertex2f((float)(f - f6), (float)(f2 + f5));
        GL11.glVertex2f((float)(f + f6), (float)(f2 - f5));
        GL11.glVertex2f((float)(f + f6), (float)(f2 + f5));
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    private void prepareIcon(Color color, float f) {
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)1.5f);
        Color color2 = this.applyAlpha(color, f);
        GL11.glColor4f((float)((float)color2.getRed() / 255.0f), (float)((float)color2.getGreen() / 255.0f), (float)((float)color2.getBlue() / 255.0f), (float)((float)color2.getAlpha() / 255.0f));
    }

    private Color applyAlpha(Color color, float f) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * f));
    }

    private boolean hovered(float f, float f2, float f3, float f4, float f5, float f6) {
        return f >= f3 && f <= f3 + f5 && f2 >= f4 && f2 <= f4 + f6;
    }

    private boolean cooldown() {
        long l = System.currentTimeMillis();
        if (l - this.lastClickTime > 200L) {
            this.lastClickTime = l;
            return true;
        }
        return false;
    }

    private String sanitize(String string) {
        return string == null ? "" : string.replace("\u00c5\u0178", "s").replace("\u00c5\u009e", "S").replace("\u00c4\u00b1", "i").replace("\u00c4\u00b0", "I").replace("\u00c4\u0178", "g").replace("\u00c4\u009e", "G").replace("\u00c3\u00bc", "u").replace("\u00c3\u0153", "U").replace("\u00c3\u00b6", "o").replace("\u00c3\u2013", "O").replace("\u00c3\u00a7", "c").replace("\u00c3\u2021", "C");
    }
}

