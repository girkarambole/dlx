/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.NumberOption;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;

public class AutoArmorModule
extends Module {
    private final NumberOption delay = new NumberOption("Delay", 100.0, 0.0, 500.0, 10.0, this);
    private long lastArmorTime = 0L;

    public AutoArmorModule() {
        super("AutoArmor", "Automatically equips the best armor in inventory", Category.PLAYER, 0);
        this.delay.setGroup("Armor");
        this.addOptions(this.delay);
    }

    @Override
    public String getOptionPrefix() {
        return ((Double)this.delay.getValue()).intValue() + "ms";
    }

    @Override
    public void onEnable() {
        this.lastArmorTime = 0L;
        Logger.info("AutoArmor: enabled");
    }

    @Override
    public void onDisable() {
        Logger.info("AutoArmor: disabled");
    }

    @Override
    public void onUpdate() {
        if (!this.isEnabled()) {
            return;
        }
        try {
            if (MinecraftMapper.getCurrentScreen() != null) {
                return;
            }
            long now = System.currentTimeMillis();
            if (now - this.lastArmorTime < ((Double)this.delay.getValue()).longValue()) {
                return;
            }
            Object player = this.getThePlayer();
            if (player == null) {
                return;
            }
            Object inv = MappingUtils.getInventory(player);
            if (inv == null) {
                return;
            }
            Object[] main = this.getMainInventory(inv);
            if (main == null) {
                return;
            }
            Object mc = this.getMinecraft();
            if (mc == null) {
                return;
            }
            Field pcField = MappingUtils.getField("Minecraft.playerController");
            if (pcField == null) {
                return;
            }
            pcField.setAccessible(true);
            Object pc = pcField.get(mc);
            if (pc == null) {
                return;
            }
            Method windowClick = MappingUtils.getMethod("PlayerControllerMP.windowClick");
            if (windowClick == null) {
                return;
            }
            windowClick.setAccessible(true);
            Field invContainerField = MappingUtils.getField("EntityPlayer.inventoryContainer");
            if (invContainerField == null) {
                return;
            }
            invContainerField.setAccessible(true);
            Object container = invContainerField.get(player);
            if (container == null) {
                return;
            }
            Field slotsField = MappingUtils.getField("Slot.inventorySlots");
            if (slotsField == null) {
                return;
            }
            slotsField.setAccessible(true);
            List slots = (List)slotsField.get(container);
            if (slots == null || slots.size() < 9) {
                return;
            }
            Method getSlotMethod = MappingUtils.getMethod("Container.getSlot");
            Method getStackMethod = MappingUtils.getMethod("Slot.getStack");
            if (getSlotMethod == null || getStackMethod == null) {
                return;
            }
            getSlotMethod.setAccessible(true);
            getStackMethod.setAccessible(true);
            int windowId = 0;
            int currentHelmetScore = this.getArmorScore(getStackMethod.invoke(getSlotMethod.invoke(container, 5), new Object[0]));
            int currentChestScore = this.getArmorScore(getStackMethod.invoke(getSlotMethod.invoke(container, 6), new Object[0]));
            int currentLegsScore = this.getArmorScore(getStackMethod.invoke(getSlotMethod.invoke(container, 7), new Object[0]));
            int currentBootsScore = this.getArmorScore(getStackMethod.invoke(getSlotMethod.invoke(container, 8), new Object[0]));
            int bestHelmetSlot = -1;
            int bestHelmetScore = currentHelmetScore;
            int bestChestSlot = -1;
            int bestChestScore = currentChestScore;
            int bestLegsSlot = -1;
            int bestLegsScore = currentLegsScore;
            int bestBootsSlot = -1;
            int bestBootsScore = currentBootsScore;
            for (int i = 9; i < 45; ++i) {
                String name;
                int type;
                Object itemStack;
                Object slot = getSlotMethod.invoke(container, i);
                if (slot == null || (itemStack = getStackMethod.invoke(slot, new Object[0])) == null || (type = this.getArmorType(name = MappingUtils.getItemName(itemStack))) == -1) continue;
                int score = this.getArmorScore(itemStack);
                if (type == 0 && score > bestHelmetScore) {
                    bestHelmetScore = score;
                    bestHelmetSlot = i;
                    continue;
                }
                if (type == 1 && score > bestChestScore) {
                    bestChestScore = score;
                    bestChestSlot = i;
                    continue;
                }
                if (type == 2 && score > bestLegsScore) {
                    bestLegsScore = score;
                    bestLegsSlot = i;
                    continue;
                }
                if (type != 3 || score <= bestBootsScore) continue;
                bestBootsScore = score;
                bestBootsSlot = i;
            }
            if (bestHelmetSlot != -1) {
                this.equipArmor(pc, windowId, 5, bestHelmetSlot, windowClick, player);
                this.lastArmorTime = now;
            } else if (bestChestSlot != -1) {
                this.equipArmor(pc, windowId, 6, bestChestSlot, windowClick, player);
                this.lastArmorTime = now;
            } else if (bestLegsSlot != -1) {
                this.equipArmor(pc, windowId, 7, bestLegsSlot, windowClick, player);
                this.lastArmorTime = now;
            } else if (bestBootsSlot != -1) {
                this.equipArmor(pc, windowId, 8, bestBootsSlot, windowClick, player);
                this.lastArmorTime = now;
            }
        }
        catch (Throwable t) {
            Logger.warn("AutoArmor error: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private void equipArmor(Object pc, int windowId, int armorSlot, int inventorySlot, Method windowClick, Object player) throws Exception {
        windowClick.invoke(pc, windowId, inventorySlot, 0, 0, player);
        windowClick.invoke(pc, windowId, armorSlot, 0, 0, player);
        windowClick.invoke(pc, windowId, inventorySlot, 0, 0, player);
        Logger.info("AutoArmor: Equipped slot " + inventorySlot + " to armor slot " + armorSlot);
    }

    private int getArmorType(String itemName) {
        if (itemName == null) {
            return -1;
        }
        String lower = itemName.toLowerCase();
        if (lower.contains("helmet") || lower.contains("kask") || lower.contains("head") || lower.contains("cap") || lower.contains("skull")) {
            return 0;
        }
        if (lower.contains("chestplate") || lower.contains("gogus") || lower.contains("plate") || lower.contains("tunic")) {
            return 1;
        }
        if (lower.contains("leggings") || lower.contains("pantolon") || lower.contains("greaves") || lower.contains("legs")) {
            return 2;
        }
        if (lower.contains("boots") || lower.contains("bot") || lower.contains("shoes")) {
            return 3;
        }
        return -1;
    }

    private int getArmorScore(Object itemStack) {
        if (itemStack == null) {
            return 0;
        }
        try {
            String name = MappingUtils.getItemName(itemStack);
            if (name == null) {
                return 0;
            }
            String lower = name.toLowerCase();
            int score = 0;
            if (lower.contains("diamond") || lower.contains("elmas")) {
                score = 400;
            } else if (lower.contains("iron") || lower.contains("demir")) {
                score = 300;
            } else if (lower.contains("chain") || lower.contains("zincir")) {
                score = 200;
            } else if (lower.contains("gold") || lower.contains("altin")) {
                score = 150;
            } else if (lower.contains("leather") || lower.contains("deri")) {
                score = 100;
            }
            if (lower.contains("chest") || lower.contains("gogus")) {
                score += 8;
            } else if (lower.contains("leg") || lower.contains("pantolon")) {
                score += 6;
            } else if (lower.contains("helm") || lower.contains("kask")) {
                score += 3;
            } else if (lower.contains("boot") || lower.contains("bot")) {
                score += 2;
            }
            return score;
        }
        catch (Throwable throwable) {
            return 0;
        }
    }

    private Object[] getMainInventory(Object inventoryPlayer) {
        try {
            Field f = MappingUtils.getField("InventoryPlayer.mainInventory");
            if (f != null) {
                f.setAccessible(true);
                Object arr = f.get(inventoryPlayer);
                if (arr instanceof Object[]) {
                    return (Object[])arr;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }
}

