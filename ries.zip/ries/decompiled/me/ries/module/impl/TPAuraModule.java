/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package me.ries.module.impl;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Random;
import me.ries.Ries;
import me.ries.event.Event;
import me.ries.event.EventListener;
import me.ries.event.Render3DEvent;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.util.BotTracker;
import me.ries.util.Logger;
import me.ries.util.MappingUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class TPAuraModule
extends Module {
    private final NumberOption targetRange = new NumberOption("Target Range", 6.0, 3.0, 8.0, 0.5, this);
    private final NumberOption cps = new NumberOption("CPS", 12.0, 5.0, 20.0, 1.0, this);
    private final NumberOption smoothness = new NumberOption("Smoothness", 0.2, 0.05, 0.5, 0.05, this);
    private final NumberOption spinRadius = new NumberOption("Spin Radius", 3.5, 2.0, 5.0, 0.25, this);
    private final NumberOption spinSpeed = new NumberOption("Spin Speed", 1.3, 1.0, 3.0, 0.05, this);
    private final NumberOption fov = new NumberOption("FOV", 360.0, 15.0, 360.0, 5.0, this);
    private final BooleanOption rotationEnabled = new BooleanOption("Rotation", true, (Module)this);
    private final StringOption rotationMode = new StringOption("RotMode", "Silent", this, "Silent", "Body");
    private final NumberOption rotationSpeed = new NumberOption("RotSpeed", 0.65, 0.1, 1.0, 0.05, this);
    private final NumberOption aimPoint = new NumberOption("AimPoint", 0.5, 0.0, 1.0, 0.05, this);
    private final StringOption targetLock = new StringOption("TargetLock", "Off", this, "On", "Off");
    private final BooleanOption rangeCircle = new BooleanOption("RangeCircle", true, (Module)this);
    private final BooleanOption targetMarker = new BooleanOption("TargetMarker", true, (Module)this);
    private final BooleanOption tracer = new BooleanOption("Tracer", false, (Module)this);
    private final BooleanOption headRide = new BooleanOption("HeadRide", false, (Module)this);
    private final NumberOption headHeight = new NumberOption("HeadHeight", 1.0, 0.0, 3.0, 0.5, this);
    private static final float VIS_WHITE = 0.96f;
    private static final float VIS_LIGHT = 0.78f;
    private static final float VIS_MID = 0.52f;
    private static final float VIS_DARK = 0.1f;
    private long lastAttackTime = 0L;
    private final Random random = new Random();
    private Object lastTarget = null;
    private long lastTargetTime = 0L;
    private double smoothTX = 0.0;
    private double smoothTY = 0.0;
    private double smoothTZ = 0.0;
    private boolean targetInit = false;
    private float lastYaw = 0.0f;
    private float lastPitch = 0.0f;
    private boolean rotationInitialized = false;

    public TPAuraModule() {
        super("TPAura", "Teleport aura", Category.COMBAT, 0);
        this.addOptions(this.targetRange, this.cps, this.smoothness, this.spinRadius, this.spinSpeed, this.fov, this.rotationEnabled, this.rotationMode, this.rotationSpeed, this.aimPoint, this.targetLock, this.rangeCircle, this.targetMarker, this.tracer, this.headRide, this.headHeight);
        Ries.getInstance().getEventBus().subscribe(Render3DEvent.class, new EventListener(){

            @Override
            public void onEvent(Event event) {
                if (event instanceof Render3DEvent) {
                    TPAuraModule.this.onRender3D(((Render3DEvent)event).getPartialTicks());
                }
            }
        });
    }

    public String getMode() {
        return "JumpSpin";
    }

    @Override
    public String getOptionPrefix() {
        double d = (Double)this.targetRange.getValue();
        return d == Math.floor(d) ? String.valueOf((int)d) : String.format("%.1f", d);
    }

    @Override
    public void onEnable() {
        this.lastYaw = MinecraftMapper.getRotationYaw();
        this.lastPitch = MinecraftMapper.getRotationPitch();
        this.rotationInitialized = false;
    }

    @Override
    public void onDisable() {
        this.resetState();
    }

    public Object getHudTarget() {
        return this.lastTarget;
    }

    @Override
    public void onUpdate() {
        Object object;
        if (this.isEnabled() && (object = MinecraftMapper.getPlayer()) != null) {
            float f;
            Object object2 = this.getBestTarget();
            if (object2 != null && ((Boolean)this.headRide.getValue()).booleanValue() && (f = MappingUtils.getEntityHealth(object2)) <= 0.0f) {
                object2 = null;
                this.lastTarget = null;
                this.targetInit = false;
                this.releaseHeadRide(object);
            }
            if (object2 == null) {
                this.lastTarget = null;
                this.targetInit = false;
                if (((Boolean)this.headRide.getValue()).booleanValue()) {
                    this.releaseHeadRide(object);
                }
            } else {
                this.lastTarget = object2;
                this.lastTargetTime = System.currentTimeMillis();
                double d = MinecraftMapper.getPosX(object2);
                double d2 = MinecraftMapper.getPosY(object2);
                double d3 = MinecraftMapper.getPosZ(object2);
                if (!this.targetInit) {
                    this.smoothTX = d;
                    this.smoothTY = d2;
                    this.smoothTZ = d3;
                    this.targetInit = true;
                }
                this.smoothTX = this.lerp(this.smoothTX, d, 0.25);
                this.smoothTY = this.lerp(this.smoothTY, d2, 0.25);
                this.smoothTZ = this.lerp(this.smoothTZ, d3, 0.25);
                double d4 = this.smoothTX;
                double d5 = this.smoothTY;
                double d6 = this.smoothTZ;
                double d7 = MinecraftMapper.getPosX();
                double d8 = MinecraftMapper.getPosY();
                double d9 = MinecraftMapper.getPosZ();
                if (((Boolean)this.headRide.getValue()).booleanValue()) {
                    this.handleHeadRide(object2, d7, d8, d9, d4, d5, d6);
                } else {
                    this.handleJumpSpin(d7, d8, d9, d4, d6);
                }
                long l = System.currentTimeMillis();
                if (l - this.lastAttackTime >= (long)(1000.0 / (Double)this.cps.getValue())) {
                    this.applyRotation(object2);
                    this.attackEntity(object2);
                    this.lastAttackTime = l;
                } else {
                    this.applyRotation(object2);
                }
            }
        }
    }

    private double[] computeSpinOrbit(double d, double d2) {
        double d3 = (double)System.currentTimeMillis() / 1000.0 * (Double)this.spinSpeed.getValue();
        double d4 = d + Math.cos(d3 * 3.0) * (Double)this.spinRadius.getValue();
        double d5 = d2 + Math.sin(d3 * 3.0) * (Double)this.spinRadius.getValue();
        return new double[]{d4, d5};
    }

    private void handleHeadRide(Object object, double d, double d2, double d3, double d4, double d5, double d6) {
        block26: {
            try {
                Field field;
                Field field2;
                AccessibleObject accessibleObject;
                float f = MappingUtils.getEntityHealth(object);
                if (f <= 0.0f) {
                    Object object2 = MinecraftMapper.getPlayer();
                    if (object2 != null) {
                        this.releaseHeadRide(object2);
                    }
                    return;
                }
                try {
                    Field field3 = MappingUtils.getField("Entity.isDead");
                    if (field3 == null) {
                        field3 = MappingUtils.getField("Entity.dead");
                    }
                    if (field3 != null) {
                        field3.setAccessible(true);
                        Object object3 = field3.get(object);
                        if (object3 instanceof Boolean && ((Boolean)object3).booleanValue()) {
                            Object object4 = MinecraftMapper.getPlayer();
                            if (object4 != null) {
                                this.releaseHeadRide(object4);
                            }
                            return;
                        }
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
                float f2 = MappingUtils.getEyeHeight(object);
                double d7 = d5 + (double)f2 * 1.1;
                double d8 = Math.min(3.0, Math.max(0.0, (Double)this.headHeight.getValue()));
                double d9 = d7 + d8;
                double d10 = d4;
                double d11 = d6;
                double d12 = d10 - d;
                double d13 = d11 - d3;
                double d14 = Math.sqrt(d12 * d12 + d13 * d13);
                Object object5 = MinecraftMapper.getPlayer();
                if (object5 == null) {
                    return;
                }
                if (!(d14 > 0.15) && !(Math.abs(d2 - d9) > 0.2)) break block26;
                double d15 = (Double)this.smoothness.getValue();
                double d16 = this.lerp(d, d10, d15 * 2.0);
                double d17 = this.lerp(d2, d9, d15 * 1.5);
                double d18 = this.lerp(d3, d11, d15 * 2.0);
                try {
                    accessibleObject = MappingUtils.getMethod("Entity.setPositionAndUpdate");
                    if (accessibleObject != null) {
                        ((Method)accessibleObject).setAccessible(true);
                        ((Method)accessibleObject).invoke(object5, d16, d17, d18);
                    } else {
                        field2 = MappingUtils.getField("Entity.posX");
                        field = MappingUtils.getField("Entity.posY");
                        Field field4 = MappingUtils.getField("Entity.posZ");
                        if (field2 != null) {
                            field2.setAccessible(true);
                            field2.setDouble(object5, d16);
                        }
                        if (field != null) {
                            field.setAccessible(true);
                            field.setDouble(object5, d17);
                        }
                        if (field4 != null) {
                            field4.setAccessible(true);
                            field4.setDouble(object5, d18);
                        }
                    }
                }
                catch (Throwable throwable) {
                    try {
                        field2 = MappingUtils.getField("Entity.posX");
                        field = MappingUtils.getField("Entity.posY");
                        Field field5 = MappingUtils.getField("Entity.posZ");
                        if (field2 != null) {
                            field2.setAccessible(true);
                            field2.setDouble(object5, d16);
                        }
                        if (field != null) {
                            field.setAccessible(true);
                            field.setDouble(object5, d17);
                        }
                        if (field5 != null) {
                            field5.setAccessible(true);
                            field5.setDouble(object5, d18);
                        }
                    }
                    catch (Throwable throwable2) {
                        // empty catch block
                    }
                }
                accessibleObject = MappingUtils.getField("Entity.motionX");
                field2 = MappingUtils.getField("Entity.motionY");
                field = MappingUtils.getField("Entity.motionZ");
                if (accessibleObject != null) {
                    ((Field)accessibleObject).setAccessible(true);
                    ((Field)accessibleObject).setDouble(object5, 0.0);
                }
                if (field2 != null) {
                    field2.setAccessible(true);
                    field2.setDouble(object5, 0.0);
                }
                if (field != null) {
                    field.setAccessible(true);
                    field.setDouble(object5, 0.0);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void releaseHeadRide(Object object) {
        try {
            Field field = MappingUtils.getField("Entity.motionY");
            if (field != null) {
                field.setAccessible(true);
                double d = field.getDouble(object);
                if (d >= -0.01) {
                    field.setDouble(object, -0.1);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void handleJumpSpin(double d, double d2, double d3, double d4, double d5) {
        double d6;
        double[] dArray = this.computeSpinOrbit(d4, d5);
        double d7 = (Double)this.smoothness.getValue();
        double d8 = this.lerp(d, dArray[0], d7);
        double d9 = this.lerp(d3, dArray[1], d7);
        double d10 = d8 - d;
        double d11 = d9 - d3;
        double d12 = (Double)this.spinSpeed.getValue();
        double d13 = 0.22;
        double d14 = d13 * d12;
        Object object = MinecraftMapper.getPlayer();
        if (object != null && this.isOnGround(object)) {
            this.setMotionY(0.42);
            d14 *= 1.2;
        }
        if ((d6 = Math.sqrt(d10 * d10 + d11 * d11)) > 0.001) {
            d10 = d10 / d6 * d14;
            d11 = d11 / d6 * d14;
        }
        MinecraftMapper.setMotionX(d10);
        MinecraftMapper.setMotionZ(d11);
    }

    private void attackEntity(Object object) {
        try {
            Object object2;
            String string = this.getName(object);
            float f = this.getHealth(object);
            double d = this.distanceTo(object);
            Logger.kaAttack("attackEntity -> name=" + string + " health=" + f + " dist=" + String.format("%.2f", d) + " mode=JumpSpin range=" + String.format("%.1f", this.targetRange.getValue()) + " cps=" + String.format("%.1f", this.cps.getValue()));
            try {
                Method method = MappingUtils.getMethod("EntityPlayerSP.swingItem");
                if (method == null) {
                    method = MappingUtils.getMethod("EntityPlayer.swingItem");
                }
                if (method == null) {
                    method = MappingUtils.getMethod("Entity.swingItem");
                }
                object2 = MinecraftMapper.getPlayer();
                if (method != null && object2 != null) {
                    method.setAccessible(true);
                    method.invoke(object2, new Object[0]);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            boolean bl = MinecraftMapper.attackEntity(object);
            if (!bl) {
                Logger.kaWarn("attackEntity: raw attack returned false -> target=" + string);
                Logger.warn("TPAura raw attack failed");
            } else {
                Logger.kaDebug("attackEntity: SUCCESS -> " + string);
            }
            try {
                if (Mouse.isButtonDown((int)1)) {
                    object2 = MinecraftMapper.getPlayer();
                    Method method = MappingUtils.getMethod("EntityPlayer.getHeldItem");
                    Method method2 = MappingUtils.getMethod("EntityPlayer.setItemInUse");
                    if (method != null && method2 != null && object2 != null) {
                        method.setAccessible(true);
                        method2.setAccessible(true);
                        Object object3 = method.invoke(object2, new Object[0]);
                        if (object3 != null) {
                            method2.invoke(object2, object3, 72000);
                        }
                    }
                }
            }
            catch (Throwable throwable) {}
        }
        catch (Throwable throwable) {
            Logger.kaWarn("attackEntity EXCEPTION: " + throwable.getClass().getSimpleName() + " -> " + throwable.getMessage());
            Logger.warn("TPAura attack failed: " + throwable.getMessage());
        }
    }

    private String getName(Object object) {
        return MinecraftMapper.getName(object);
    }

    private float getHealth(Object object) {
        return MappingUtils.getEntityHealth(object);
    }

    private Object getBestTarget() {
        double d;
        boolean bl = "On".equals(this.targetLock.getValue());
        if (this.lastTarget != null) {
            boolean bl2;
            boolean bl3 = bl2 = bl || System.currentTimeMillis() - this.lastTargetTime < 2000L;
            if (bl2 && this.isValidTarget(this.lastTarget)) {
                d = this.distanceTo(this.lastTarget);
                double d2 = (Double)this.targetRange.getValue();
                if (bl) {
                    d2 *= 1.5;
                }
                if (d <= d2) {
                    return this.lastTarget;
                }
            }
        }
        Object object = null;
        d = Double.MAX_VALUE;
        List<Object> list = MinecraftMapper.getPlayerEntitiesInWorld();
        if (list == null) {
            return null;
        }
        for (Object object2 : list) {
            double d3;
            BotTracker.observe(object2);
            if (!this.isValidTarget(object2) || !((d3 = this.distanceTo(object2)) <= (Double)this.targetRange.getValue()) || !(d3 < d)) continue;
            d = d3;
            object = object2;
        }
        return object;
    }

    private boolean isValidTarget(Object object) {
        if (object != null && object != MinecraftMapper.getPlayer()) {
            Object object2;
            Field field;
            float f;
            List<Object> list = MinecraftMapper.getPlayerEntitiesInWorld();
            if (list == null || !list.contains(object)) {
                return false;
            }
            if (!this.isValidCombatTarget(object)) {
                return false;
            }
            if (BotTracker.isBot(object)) {
                return false;
            }
            if (BotTracker.isBotByHp(object)) {
                return false;
            }
            float[] fArray = this.getRotationsTo(object);
            if (fArray != null && (double)(f = TPAuraModule.angleDiff(MinecraftMapper.getRotationYaw(), fArray[0])) > (Double)this.fov.getValue()) {
                return false;
            }
            try {
                field = MappingUtils.getField("Entity.isDead");
                if (field == null) {
                    field = MappingUtils.getField("Entity.dead");
                }
                if (field != null) {
                    field.setAccessible(true);
                    object2 = field.get(object);
                    if (object2 instanceof Boolean && ((Boolean)object2).booleanValue()) {
                        return false;
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            try {
                field = MappingUtils.getField("EntityLivingBase.deathTime");
                if (field == null) {
                    field = MappingUtils.getField("EntityLiving.deathTime");
                }
                if (field != null) {
                    field.setAccessible(true);
                    if (field.getInt(object) > 0) {
                        return false;
                    }
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            float f2 = MappingUtils.getEntityHealth(object);
            if (f2 <= 0.0f) {
                return false;
            }
            object2 = MinecraftMapper.getName(object);
            return object2 != null && !((String)object2).replaceAll("\u00a7.", "").trim().isEmpty();
        }
        return false;
    }

    private double distanceTo(Object object) {
        try {
            double d = MinecraftMapper.getPosX() - MinecraftMapper.getPosX(object);
            double d2 = MinecraftMapper.getPosY() - MinecraftMapper.getPosY(object);
            double d3 = MinecraftMapper.getPosZ() - MinecraftMapper.getPosZ(object);
            return Math.sqrt(d * d + d2 * d2 + d3 * d3);
        }
        catch (Throwable throwable) {
            return Double.MAX_VALUE;
        }
    }

    private double lerp(double d, double d2, double d3) {
        return d + (d2 - d) * d3;
    }

    private void resetState() {
        this.lastTarget = null;
        this.targetInit = false;
        this.smoothTX = 0.0;
        this.smoothTY = 0.0;
        this.smoothTZ = 0.0;
    }

    public void onRender3D(float f) {
        if (this.isEnabled()) {
            Object object;
            if (((Boolean)this.rangeCircle.getValue()).booleanValue()) {
                this.renderRangeCircle(f);
            }
            if ((object = this.lastTarget) != null) {
                if (((Boolean)this.targetMarker.getValue()).booleanValue()) {
                    this.renderTargetMarker(object, f);
                }
                if (((Boolean)this.tracer.getValue()).booleanValue()) {
                    this.renderTracer(object, f);
                }
            }
        }
    }

    private void glMono(float f, float f2) {
        GL11.glColor4f((float)f, (float)f, (float)(f + 0.02f), (float)f2);
    }

    private void pushVisualState() {
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
    }

    private void drawGroundRing(double d, float f, float f2, float f3, int n) {
        GL11.glBegin((int)2);
        this.glMono(f2, f3);
        for (int i = 0; i <= 360; i += n) {
            double d2 = Math.toRadians(i);
            GL11.glVertex3d((double)(Math.cos(d2) * d), (double)f, (double)(Math.sin(d2) * d));
        }
        GL11.glEnd();
    }

    private void drawHorizontalRing(float f, float f2, float f3, float f4, float f5, float f6, int n) {
        GL11.glBegin((int)2);
        this.glMono(f5, f6);
        for (int i = 0; i < n; ++i) {
            double d = Math.PI * 2 * (double)i / (double)n;
            GL11.glVertex3d((double)((double)f + Math.cos(d) * (double)f4), (double)f3, (double)((double)f2 + Math.sin(d) * (double)f4));
        }
        GL11.glEnd();
    }

    private void renderRangeCircle(float f) {
        Object object = this.getThePlayer();
        if (object != null) {
            double d;
            double d2;
            double d3;
            int n;
            double[] dArray = MappingUtils.getInterpolatedPos(object, f);
            double d4 = MappingUtils.getRenderPosX();
            double d5 = MappingUtils.getRenderPosY();
            double d6 = MappingUtils.getRenderPosZ();
            double d7 = (Double)this.targetRange.getValue();
            double d8 = (double)(System.currentTimeMillis() % 4000L) / 4000.0 * Math.PI * 2.0;
            double d9 = (double)(-(System.currentTimeMillis() % 6000L)) / 6000.0 * Math.PI * 2.0;
            this.pushVisualState();
            GL11.glPushMatrix();
            GL11.glTranslated((double)(dArray[0] - d4), (double)(dArray[1] - d5), (double)(dArray[2] - d6));
            GL11.glBegin((int)5);
            for (n = 0; n <= 360; n += 4) {
                d3 = Math.toRadians(n);
                d2 = Math.cos(d3) * d7;
                d = Math.sin(d3) * d7;
                this.glMono(0.78f, 0.1f);
                GL11.glVertex3d((double)d2, (double)0.02, (double)d);
                this.glMono(0.78f, 0.0f);
                GL11.glVertex3d((double)d2, (double)0.38, (double)d);
            }
            GL11.glEnd();
            GL11.glLineWidth((float)1.0f);
            this.drawGroundRing(d7, 0.03f, 0.96f, 0.88f, 4);
            GL11.glLineWidth((float)0.6f);
            this.drawGroundRing(d7 * 0.94, 0.025f, 0.52f, 0.35f, 6);
            GL11.glLineWidth((float)1.0f);
            GL11.glBegin((int)1);
            for (n = 0; n < 4; ++n) {
                d3 = d8 + 0.7853981633974483 + (double)n * 1.5707963267948966;
                d2 = Math.cos(d3);
                d = Math.sin(d3);
                this.glMono(0.96f, 0.75f);
                GL11.glVertex3d((double)(d2 * d7 * 0.98), (double)0.03, (double)(d * d7 * 0.98));
                GL11.glVertex3d((double)(d2 * (d7 + 0.32)), (double)0.03, (double)(d * (d7 + 0.32)));
            }
            GL11.glEnd();
            GL11.glLineWidth((float)1.2f);
            n = 8;
            int n2 = 6;
            double d10 = Math.toRadians(18.0);
            for (int i = 0; i < n; ++i) {
                d = d9 + (double)i * (Math.PI * 2 / (double)n);
                GL11.glBegin((int)3);
                this.glMono(0.96f, 0.5f);
                for (int j = 0; j <= n2; ++j) {
                    double d11 = d + d10 * (double)j / (double)n2;
                    double d12 = d7 + 0.06;
                    GL11.glVertex3d((double)(Math.cos(d11) * d12), (double)0.03, (double)(Math.sin(d11) * d12));
                }
                GL11.glEnd();
            }
            GL11.glPopMatrix();
            GL11.glPopAttrib();
        }
    }

    private void renderTargetMarker(Object object, float f) {
        double[] dArray = MappingUtils.getInterpolatedPos(object, f);
        double d = MappingUtils.getRenderPosX();
        double d2 = MappingUtils.getRenderPosY();
        double d3 = MappingUtils.getRenderPosZ();
        float f2 = 2400.0f;
        float f3 = (float)(System.currentTimeMillis() % (long)f2) / f2;
        float f4 = f3 < 0.5f ? f3 * 2.0f : 2.0f - f3 * 2.0f;
        float f5 = f4 * f4 * (3.0f - 2.0f * f4);
        float f6 = 0.08f + 1.5f * f5;
        this.pushVisualState();
        GL11.glPushMatrix();
        GL11.glTranslated((double)(dArray[0] - d), (double)(dArray[1] - d2), (double)(dArray[2] - d3));
        float f7 = 0.42f;
        float f8 = 0.16f;
        GL11.glLineWidth((float)1.4f);
        this.drawCornerBrackets(f7, f7, f6, f8, 0.96f, 0.92f);
        GL11.glLineWidth((float)1.0f);
        this.drawHorizontalRing(0.0f, 0.0f, f6, f7 * 0.58f, 0.78f, 0.55f, 24);
        GL11.glLineWidth((float)0.8f);
        this.drawHorizontalRing(0.0f, 0.0f, f6, f7 * 0.14f, 0.52f, 0.45f, 16);
        GL11.glPopMatrix();
        GL11.glPopAttrib();
    }

    private void renderTracer(Object object, float f) {
        Object object2 = this.getThePlayer();
        if (object2 != null) {
            double[] dArray = MappingUtils.getInterpolatedPos(object2, f);
            double[] dArray2 = MappingUtils.getInterpolatedPos(object, f);
            double d = MappingUtils.getRenderPosX();
            double d2 = MappingUtils.getRenderPosY();
            double d3 = MappingUtils.getRenderPosZ();
            double d4 = dArray[0];
            double d5 = dArray[1] + 1.62;
            double d6 = dArray[2];
            double d7 = dArray2[0];
            double d8 = dArray2[1] + 0.81;
            double d9 = dArray2[2];
            this.pushVisualState();
            GL11.glPushMatrix();
            GL11.glTranslated((double)(-d), (double)(-d2), (double)(-d3));
            GL11.glLineWidth((float)2.2f);
            GL11.glBegin((int)1);
            this.glMono(0.1f, 0.28f);
            GL11.glVertex3d((double)d4, (double)d5, (double)d6);
            GL11.glVertex3d((double)d7, (double)d8, (double)d9);
            GL11.glEnd();
            GL11.glLineWidth((float)1.0f);
            GL11.glBegin((int)1);
            this.glMono(0.96f, 0.72f);
            GL11.glVertex3d((double)d4, (double)d5, (double)d6);
            GL11.glVertex3d((double)d7, (double)d8, (double)d9);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glPopAttrib();
        }
    }

    private void drawCornerBrackets(float f, float f2, float f3, float f4, float f5, float f6) {
        float f7 = f4 * 0.28f;
        f7 = Math.min(f7, f4 * 0.45f);
        this.drawBracketStrip(-f, -f2, f3, f4, f7, 1.0f, 1.0f, f5, f6);
        this.drawBracketStrip(f, -f2, f3, f4, f7, -1.0f, 1.0f, f5, f6);
        this.drawBracketStrip(-f, f2, f3, f4, f7, 1.0f, -1.0f, f5, f6);
        this.drawBracketStrip(f, f2, f3, f4, f7, -1.0f, -1.0f, f5, f6);
    }

    private void drawBracketStrip(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9) {
        GL11.glBegin((int)3);
        this.glMono(f8, f9);
        GL11.glVertex3d((double)(f + f6 * f4), (double)f3, (double)f2);
        GL11.glVertex3d((double)(f + f6 * f5), (double)f3, (double)f2);
        float f10 = f + f6 * f5;
        float f11 = f2 + f7 * f5;
        double d = f7 > 0.0f ? 4.71238898038469 : 1.5707963267948966;
        double d2 = f6 > 0.0f ? Math.PI : 0.0;
        double d3 = d2 - d;
        if (d3 > Math.PI) {
            d3 -= Math.PI * 2;
        } else if (d3 < -Math.PI) {
            d3 += Math.PI * 2;
        }
        for (int i = 0; i <= 5; ++i) {
            double d4 = d + d3 * ((double)i / 5.0);
            GL11.glVertex3d((double)((double)f10 + Math.cos(d4) * (double)f5), (double)f3, (double)((double)f11 + Math.sin(d4) * (double)f5));
        }
        GL11.glVertex3d((double)f, (double)f3, (double)(f2 + f7 * f4));
        GL11.glEnd();
    }

    private float[] getRotationsTo(Object object) {
        Object object2 = MinecraftMapper.getPlayer();
        if (object2 != null && object != null) {
            double d = MinecraftMapper.getPosX(object2);
            double d2 = MinecraftMapper.getPosY(object2) + (double)MappingUtils.getEyeHeight(object2);
            double d3 = MinecraftMapper.getPosZ(object2);
            double d4 = MinecraftMapper.getPosX(object);
            double d5 = MappingUtils.getEyeHeight(object);
            double d6 = MinecraftMapper.getPosZ(object);
            double d7 = (Double)this.aimPoint.getValue();
            double d8 = MinecraftMapper.getPosY(object) + d5 * d7 * 2.0 * 0.9;
            double d9 = d4 - d;
            double d10 = d8 - d2;
            double d11 = d6 - d3;
            double d12 = Math.sqrt(d9 * d9 + d11 * d11);
            float f = (float)Math.toDegrees(Math.atan2(d11, d9)) - 90.0f;
            float f2 = (float)(-Math.toDegrees(Math.atan2(d10, d12)));
            return new float[]{f, f2};
        }
        return null;
    }

    private float smoothAngle(float f, float f2, float f3) {
        float f4;
        float f5;
        float f6;
        for (f6 = f2 - f; f6 > 180.0f; f6 -= 360.0f) {
        }
        while (f6 < -180.0f) {
            f6 += 360.0f;
        }
        if (f3 <= 0.5f) {
            f5 = 0.1f + (f3 - 0.1f) * 2.25f;
            f4 = 1.0f;
        } else {
            f5 = 1.0f;
            f4 = 1.0f - (f3 - 0.5f) / 0.5f;
        }
        float f7 = f6 * f5;
        if (f4 > 0.0f) {
            f7 += (float)(this.random.nextGaussian() * 0.4 * (double)f4);
        }
        return f + f7;
    }

    private static float snapToGCD(float f, float f2) {
        return (float)Math.round(f / f2) * f2;
    }

    private float getGCDFix() {
        float f = 0.5f;
        float f2 = f * 0.6f + 0.2f;
        return f2 * f2 * f2 * 1.2f;
    }

    private static float angleDiff(float f, float f2) {
        float f3 = Math.abs(f - f2) % 360.0f;
        return f3 > 180.0f ? 360.0f - f3 : f3;
    }

    private boolean applyRotation(Object object) {
        if (!((Boolean)this.rotationEnabled.getValue()).booleanValue()) {
            return true;
        }
        float[] fArray = this.getRotationsTo(object);
        if (fArray == null) {
            return true;
        }
        float f = fArray[0];
        float f2 = fArray[1];
        if (f2 > 90.0f) {
            f2 = 90.0f;
        }
        if (f2 < -90.0f) {
            f2 = -90.0f;
        }
        if (!this.rotationInitialized) {
            Object object2 = MinecraftMapper.getPlayer();
            if (object2 != null) {
                try {
                    Field field;
                    Field field2 = MappingUtils.getField("Entity.rotationYaw");
                    if (field2 != null) {
                        field2.setAccessible(true);
                        this.lastYaw = field2.getFloat(object2);
                    }
                    if ((field = MappingUtils.getField("Entity.rotationPitch")) != null) {
                        field.setAccessible(true);
                        this.lastPitch = field.getFloat(object2);
                    }
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            this.rotationInitialized = true;
        }
        float f3 = ((Double)this.rotationSpeed.getValue()).floatValue();
        float f4 = this.smoothAngle(this.lastYaw, f, f3);
        float f5 = this.smoothAngle(this.lastPitch, f2, f3);
        float f6 = this.getGCDFix();
        float f7 = f4 - this.lastYaw;
        float f8 = f5 - this.lastPitch;
        f4 = this.lastYaw + TPAuraModule.snapToGCD(f7, f6);
        f5 = this.lastPitch + TPAuraModule.snapToGCD(f8, f6);
        this.lastYaw = f4;
        this.lastPitch = f5;
        boolean bl = "Silent".equals(this.rotationMode.getValue());
        if (bl) {
            this.sendSilentRotation(f4, f5);
        } else {
            this.setPlayerRotation(f4, f5);
        }
        return true;
    }

    private void setPlayerRotation(float f, float f2) {
        try {
            Object object = MinecraftMapper.getPlayer();
            if (object == null) {
                return;
            }
            Field field = MappingUtils.getField("Entity.rotationYaw");
            Field field2 = MappingUtils.getField("Entity.rotationPitch");
            if (field != null) {
                field.setAccessible(true);
                field.setFloat(object, f);
            }
            if (field2 != null) {
                field2.setAccessible(true);
                field2.setFloat(object, f2);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void sendSilentRotation(float f, float f2) {
        block10: {
            try {
                Class<?> clazz = MappingUtils.get("C05PacketPlayerLook");
                if (clazz != null) {
                    Field field;
                    Object object = MinecraftMapper.getPlayer();
                    boolean bl = true;
                    try {
                        field = MappingUtils.getField("Entity.onGround");
                        if (field != null) {
                            field.setAccessible(true);
                            bl = field.getBoolean(object);
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    field = clazz.getConstructor(Float.TYPE, Float.TYPE, Boolean.TYPE).newInstance(Float.valueOf(f), Float.valueOf(f2), bl);
                    this.sendPacket(field);
                    return;
                }
                Class<?> clazz2 = MappingUtils.get("C03PacketPlayer");
                if (clazz2 == null) break block10;
                Object obj = clazz2.getConstructor(new Class[0]).newInstance(new Object[0]);
                Field field = MappingUtils.getField("C03PacketPlayer.yaw");
                Field field2 = MappingUtils.getField("C03PacketPlayer.pitch");
                Field field3 = MappingUtils.getField("C03PacketPlayer.onGround");
                if (field == null || field2 == null) break block10;
                field.setAccessible(true);
                field2.setAccessible(true);
                field.setFloat(obj, f);
                field2.setFloat(obj, f2);
                if (field3 != null) {
                    field3.setAccessible(true);
                    Object object = MinecraftMapper.getPlayer();
                    try {
                        Field field4 = MappingUtils.getField("Entity.onGround");
                        if (field4 != null) {
                            field4.setAccessible(true);
                            field3.setBoolean(obj, field4.getBoolean(object));
                        }
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                }
                this.sendPacket(obj);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private void sendPacket(Object object) {
        try {
            Object object2 = MinecraftMapper.getPlayer();
            if (object2 == null) {
                return;
            }
            Field field = MappingUtils.getField("EntityPlayerSP.sendQueue");
            if (field != null) {
                field.setAccessible(true);
                Object object3 = field.get(object2);
                Method method = MappingUtils.getMethod("NetHandlerPlayClient.sendPacket");
                if (object != null && object3 != null && method != null) {
                    method.setAccessible(true);
                    method.invoke(object3, object);
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private boolean isOnGround(Object object) {
        try {
            Field field = MappingUtils.getField("Entity.onGround");
            if (field != null) {
                field.setAccessible(true);
                return field.getBoolean(object);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return true;
    }

    private void setMotionY(double d) {
        try {
            Field field;
            Object object = MinecraftMapper.getPlayer();
            if (object != null && (field = MappingUtils.getField("Entity.motionY")) != null) {
                field.setAccessible(true);
                field.setDouble(object, d);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }
}

