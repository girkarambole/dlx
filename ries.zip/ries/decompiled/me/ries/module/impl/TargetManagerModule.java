/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import me.ries.Ries;
import me.ries.mapping.MinecraftMapper;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.TextOption;
import me.ries.util.ChatUtils;
import me.ries.util.Logger;

public class TargetManagerModule
extends Module {
    public static final Set<String> targets = Collections.synchronizedSet(new HashSet());
    private final TextOption targetName = new TextOption("Target Name", "", (Module)this);

    public TargetManagerModule() {
        super("TargetManager", "Forces combat modules to only target specific players", Category.MOD, 0);
        this.addOptions(this.targetName);
    }

    @Override
    public boolean isHidden() {
        return true;
    }

    @Override
    public void onEnable() {
        try {
            Module module = Ries.getInstance().getModuleManager().getModule("FriendManager");
            if (module != null && module.isEnabled()) {
                module.disable();
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        Logger.info("[TargetManager] enabled, targets=" + targets.size());
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onUpdate() {
    }

    public static boolean isTarget(String string) {
        if (string == null) {
            return false;
        }
        String string2 = string.replaceAll("\u00a7.", "").trim().toLowerCase();
        return targets.contains(string2);
    }

    public static boolean isTarget(Object object) {
        return object == null ? false : TargetManagerModule.isTarget(MinecraftMapper.getName(object));
    }

    public String getTargetName() {
        return String.join((CharSequence)",", targets);
    }

    public void setTargetName(String string) {
        this.targetName.setText(string);
        targets.clear();
        if (string != null && !string.trim().isEmpty()) {
            for (String string2 : string.split(",")) {
                String string3 = string2.trim().toLowerCase();
                if (string3.isEmpty()) continue;
                targets.add(string3);
            }
        }
    }

    public void handleTargetCommand(String[] stringArray) {
        if (stringArray.length < 2) {
            TargetManagerModule.sendHelp();
            return;
        }
        switch (stringArray[1].toLowerCase()) {
            case "add": {
                if (stringArray.length < 3) {
                    ChatUtils.addChatMessage("\u00a7cUsage: .target add <name>");
                    break;
                }
                TargetManagerModule.addTarget(stringArray[2]);
                break;
            }
            case "remove": 
            case "rm": 
            case "delete": 
            case "del": {
                if (stringArray.length < 3) {
                    ChatUtils.addChatMessage("\u00a7cUsage: .target remove <name>");
                    break;
                }
                TargetManagerModule.removeTarget(stringArray[2]);
                break;
            }
            case "list": {
                TargetManagerModule.listTargets();
                break;
            }
            case "clear": 
            case "reset": 
            case "sifirla": 
            case "s\u0131f\u0131rla": {
                targets.clear();
                this.targetName.setText("");
                ChatUtils.addChatMessage("\u00a7a[TargetManager] \u00a7fTarget list cleared.");
                break;
            }
            default: {
                TargetManagerModule.sendHelp();
            }
        }
    }

    public static void addTarget(String string) {
        String string2 = string.toLowerCase();
        if (targets.contains(string2)) {
            ChatUtils.addChatMessage("\u00a7e[TargetManager] \u00a7f" + string + " \u00a77is already a target");
        } else {
            targets.add(string2);
            TargetManagerModule targetManagerModule = Ries.getInstance().getModuleManager().getModule(TargetManagerModule.class);
            if (targetManagerModule != null) {
                targetManagerModule.targetName.setText(String.join((CharSequence)",", targets));
            }
            ChatUtils.addChatMessage("\u00a77[TargetManager] \u00a7a+ \u00a7f" + string);
            Logger.info("[TargetManager] added: " + string);
        }
    }

    public static void removeTarget(String string) {
        String string2 = string.toLowerCase();
        if (targets.remove(string2)) {
            TargetManagerModule targetManagerModule = Ries.getInstance().getModuleManager().getModule(TargetManagerModule.class);
            if (targetManagerModule != null) {
                targetManagerModule.targetName.setText(String.join((CharSequence)",", targets));
            }
            ChatUtils.addChatMessage("\u00a77[TargetManager] \u00a7c- \u00a7f" + string);
            Logger.info("[TargetManager] removed: " + string);
        } else {
            ChatUtils.addChatMessage("\u00a7e[TargetManager] \u00a7f" + string + " \u00a77is not a target");
        }
    }

    private static void listTargets() {
        if (targets.isEmpty()) {
            ChatUtils.addChatMessage("\u00a77[TargetManager] \u00a7fNo targets added yet");
        } else {
            ChatUtils.addChatMessage("\u00a77[TargetManager] \u00a7f(" + targets.size() + "): \u00a7a" + String.join((CharSequence)"\u00a77, \u00a7a", targets));
        }
    }

    private static void sendHelp() {
        ChatUtils.addChatMessage("\u00a77[TargetManager] \u00a7f.target add/remove <name> | list | clear");
    }
}

