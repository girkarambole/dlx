/*
 * Decompiled with CFR 0.152.
 */
package me.ries.module.impl;

import java.awt.Color;
import me.ries.module.Category;
import me.ries.module.Module;
import me.ries.setting.BooleanOption;
import me.ries.setting.ColorOption;
import me.ries.setting.NumberOption;
import me.ries.setting.StringOption;
import me.ries.ui.ClickGui;

public class ClickGuiModule
extends Module {
    public static BooleanOption moduleAlerts;
    public static BooleanOption chatAlerts;
    public static NumberOption notifAlpha;
    public static NumberOption notifBlur;

    public ClickGuiModule() {
        super("ClickGUI", "Interactive module menu", Category.RENDER, 54);
        moduleAlerts = new BooleanOption("Module Alerts", true, (Module)this);
        moduleAlerts.setGroup("Visual");
        chatAlerts = new BooleanOption("Chat Messages", true, (Module)this);
        chatAlerts.setGroup("Visual");
        notifAlpha = new NumberOption("Notif Alpha", 0.35, 0.0, 1.0, 0.05, this);
        notifAlpha.setGroup("Notifications");
        notifBlur = new NumberOption("Notif Blur Radius", 8.0, 0.0, 20.0, 0.5, this);
        notifBlur.setGroup("Notifications");
        this.addOptions(new NumberOption("Overlay Alpha", 0.58, 0.2, 0.85, 0.01, this).setGroup("Visual"), new StringOption("Panel Style", "Glass", this, "Glass", "Solid", "Compact").setGroup("Panels"), new ColorOption("Accent", new Color(99, 102, 241, 255), (Module)this).setGroup("Panels"), new ColorOption("Card Border", new Color(60, 60, 75, 200), (Module)this).setGroup("Panels"), moduleAlerts, chatAlerts, notifAlpha, notifBlur);
    }

    @Override
    public void onEnable() {
        ClickGui.open();
    }

    @Override
    public void onDisable() {
        ClickGui.close();
    }

    @Override
    public void onUpdate() {
    }
}

